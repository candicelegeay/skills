# Source policy

## Purpose

This skill separates research evidence from the user's original idea. Every external signal should remain attributable to an external source.

## Collection rules

- Prefer official APIs, authorized connectors, RSS feeds, and user-provided exports.
- Do not bypass platform access controls.
- Do not invent engagement metrics.
- Preserve canonical URL, author, publication date, and source type whenever available.
- Mark local/demo data with `is_mock: true`.

## Interpretation rules

- Engagement is a conversation signal, not factual validation.
- A dominant theme means "frequent in the collected corpus", not "true" or "universally accepted".
- Contrarian positions should be described neutrally and linked to evidence.
- Hook analysis captures rhetorical mechanisms rather than copying creators' wording.
