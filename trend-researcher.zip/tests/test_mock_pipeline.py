import subprocess
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


def test_mock_pipeline(tmp_path):
    out = tmp_path / "report.yaml"
    subprocess.run(
        [
            sys.executable,
            str(ROOT / "tools" / "trend_researcher.py"),
            "--query",
            str(ROOT / "examples" / "TrendQuery.example.yaml"),
            "--provider",
            "mock",
            "--output",
            str(out),
        ],
        check=True,
    )
    report = yaml.safe_load(out.read_text(encoding="utf-8"))
    assert report["sources"]
    assert all(source["is_mock"] for source in report["sources"])
