import json
from pathlib import Path

import yaml
from jsonschema import Draft7Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]


def test_example_report_matches_schema():
    schema = json.loads((ROOT / "schemas" / "TrendReport.schema.json").read_text(encoding="utf-8"))
    report = yaml.safe_load((ROOT / "examples" / "TrendReport.example.yaml").read_text(encoding="utf-8"))
    errors = list(Draft7Validator(schema, format_checker=FormatChecker()).iter_errors(report))
    assert not errors, [e.message for e in errors]


def test_query_has_required_fields():
    query = yaml.safe_load((ROOT / "examples" / "TrendQuery.example.yaml").read_text(encoding="utf-8"))
    assert query["domains"]
    assert query["time_window"]["start"]
    assert query["time_window"]["end"]
