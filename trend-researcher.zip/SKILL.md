---
name: trend-researcher
description: Analyse les tendances récentes autour d'un IdeaBrief, en séparant strictement signaux externes, preuves, opportunités éditoriales et pensée originale de l'utilisateur.
version: 1.0.0
---

# trend-researcher

## Objectif

Transformer un sujet ou un `IdeaBrief` en `TrendReport` traçable sur une fenêtre temporelle explicite, en identifiant ce qui est **dominant**, **émergent**, **contrariant**, **représentatif** et éditorialement utile.

Le skill ne rédige pas l'article et ne modifie pas la thèse de l'utilisateur. Il fournit une couche de recherche récente, séparée de la pensée originale, afin que les étapes suivantes puissent décider quoi intégrer.

## Principes non négociables

1. **Séparation de provenance** : une tendance externe n'est jamais attribuée à l'utilisateur.
2. **Preuve avant synthèse** : chaque thème, position ou signal important doit pointer vers des sources vérifiables.
3. **Popularité ≠ vérité** : l'engagement est un signal de conversation, pas une preuve factuelle.
4. **Fenêtre temporelle explicite** : la recherche utilise la période fournie ; par défaut, viser les 7 derniers jours pour les tendances sociales récentes.
5. **APIs officielles ou accès autorisés d'abord** : ne pas contourner les restrictions d'une plateforme.
6. **LinkedIn** : ne pas supposer une recherche publique de posts via API. Utiliser un import manuel/CSV ou une source autorisée si l'accès API requis n'est pas disponible.
7. **Hooks** : extraire le mécanisme d'accroche, pas copier le texte d'un créateur.
8. **Pas d'invention de métriques** : si vues/likes/commentaires ne sont pas disponibles, laisser le signal vide ou le qualifier comme inconnu.

## Entrées

Le contrat d'entrée canonique est `schemas/TrendQuery.schema.yaml`.

Champs principaux :

- `idea_id` : identifiant de l'IdeaBrief associé, si disponible.
- `domains` : concepts, mots-clés, domaines ou requêtes à investiguer.
- `time_window.start` / `time_window.end` : fenêtre temporelle ISO `YYYY-MM-DD`.
- `platforms` : sources ciblées, par exemple `X`, `LinkedIn`, `RSS`, `Web`, `ManualCSV`.
- `language` : langue d'analyse souhaitée.
- `max_items_per_source` : garde-fou de collecte.

## Sources autorisées et stratégie de fallback

### X / Twitter

Utiliser un fournisseur officiel ou autorisé capable de faire une recherche récente. Conserver au minimum : texte ou extrait, auteur, URL, date, métriques disponibles et type de source.

### LinkedIn

Ne pas supposer l'accès à une recherche publique de posts. Priorité :

1. données fournies par l'utilisateur ;
2. export CSV / capture structurée ;
3. API autorisée si les permissions nécessaires sont effectivement disponibles.

### Blogs, RSS, publications et web

Utiliser des flux RSS, APIs, pages accessibles et autres mécanismes conformes aux conditions d'utilisation. Éviter les scrapers agressifs ou les contournements d'accès.

### Mode local / sans clé API

Utiliser `provider=mock` ou `ManualCSV`. Le package doit rester exécutable sans secret.

## Méthodologie

### 1. Collecte

Construire les requêtes à partir de `domains` et, lorsqu'il est fourni, du `IdeaBrief` en amont. Récupérer uniquement des éléments dans la fenêtre temporelle cible.

### 2. Nettoyage

Normaliser les champs, dédupliquer par URL / identifiant / contenu proche, retirer le spam évident et marquer les métriques absentes.

### 3. Clustering thématique

Regrouper par similarité sémantique pour faire émerger des thèmes cohérents. Les clusters doivent être interprétables et soutenus par plusieurs éléments lorsque possible.

### 4. Analyse des tendances

Distinguer :

- `dominant_themes` : sujets récurrents et fortement représentés ;
- `emerging_themes` : nouveaux thèmes, arguments ou sous-sujets en croissance ;
- `contrarian_positions` : positions qui contestent explicitement le récit dominant ;
- `representative_content` : éléments particulièrement illustratifs du débat ;
- `hook_patterns` : mécanismes d'ouverture récurrents ;
- `idea_overlap` : zones déjà communes, éléments différenciants et nouveauté potentielle ;
- `editorial_opportunities` : angles de réaction, approfondissement ou contrepoint sans réécrire l'idée originale.

### 5. Analyse de l'engagement

Comparer les métriques uniquement à l'intérieur d'un contexte comparable. Ne pas conclure qu'un post est important ou vrai parce qu'il est populaire.

### 6. Vérification

Avant sortie :

- chaque thème a au moins une source ;
- aucune source n'est inventée ;
- les dates respectent la fenêtre ;
- les positions externes sont formulées comme externes ;
- les opportunités éditoriales mentionnent explicitement leur relation avec l'idée originale.

## Sortie

Le contrat de sortie canonique est `schemas/TrendReport.schema.json`.

Le rapport doit contenir au minimum :

- `research_date`
- `time_window`
- `dominant_themes`
- `emerging_themes`
- `contrarian_positions`
- `representative_content`
- `hook_patterns`
- `idea_overlap`
- `editorial_opportunities`
- `sources`

## Format de provenance

Tout élément analytique doit pouvoir être relié à une ou plusieurs entrées de `sources`. Le rapport n'emploie jamais une formulation qui ferait passer une source externe pour une opinion de l'utilisateur.

Exemple de règle :

```yaml
editorial_opportunities:
  - opportunity: "Approfondir le rôle du control plane"
    rationale: "Plusieurs sources discutent d'autonomie, peu détaillent le contrôle opérationnel"
    relationship_to_original_idea: "Renforce un axe déjà présent dans l'IdeaBrief sans le modifier"
```

## Utilisation des tools

Le fichier `tools/tools.yaml` décrit les outils disponibles. Le runtime de référence fournit :

- `mock` : jeu de données local reproductible ;
- `manual_csv` : ingestion de posts/URLs fournis manuellement ;
- `rss` : collecte de flux RSS ;
- `x_recent` : interface prévue pour un client API officiel, désactivée sans credentials.

Le skill doit préférer les outils disponibles et conformes, puis signaler clairement les sources non accessibles plutôt que de simuler une collecte réelle.

## Critères d'arrêt

Arrêter la recherche lorsque :

- la fenêtre cible a été couverte ;
- les thèmes principaux sont stabilisés ;
- chaque conclusion substantielle possède des preuves ;
- de nouvelles sources n'ajoutent plus de thème ou de nuance significative ;
- ou la limite de collecte configurée est atteinte.

## Anti-patterns

Ne pas :

- écrire l'article final ;
- fusionner tendance et opinion utilisateur ;
- inventer des URLs, auteurs, dates ou métriques ;
- présenter un buzz comme un consensus ;
- copier des hooks mot pour mot ;
- contourner les restrictions d'accès d'une plateforme ;
- remplacer une recherche indisponible par des résultats fictifs sans les marquer `mock`.

## Exemple rapide

```bash
python tools/trend_researcher.py \
  --query examples/TrendQuery.example.yaml \
  --provider mock \
  --output /tmp/TrendReport.yaml
```

Puis valider :

```bash
python tools/validate_report.py /tmp/TrendReport.yaml
```
