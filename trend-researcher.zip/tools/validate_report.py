#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml
from jsonschema import Draft7Validator, FormatChecker


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report")
    parser.add_argument("--schema", default=str(Path(__file__).resolve().parents[1] / "schemas" / "TrendReport.schema.json"))
    args = parser.parse_args()

    report = yaml.safe_load(Path(args.report).read_text(encoding="utf-8"))
    schema = json.loads(Path(args.schema).read_text(encoding="utf-8"))
    validator = Draft7Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(report), key=lambda e: list(e.path))
    if errors:
        for e in errors:
            print(f"ERROR at {list(e.path)}: {e.message}")
        raise SystemExit(1)
    print("TrendReport valid")


if __name__ == "__main__":
    main()
