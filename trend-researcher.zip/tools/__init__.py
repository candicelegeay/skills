"""trend-researcher tools package."""
