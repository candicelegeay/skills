from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Protocol


@dataclass
class ContentItem:
    platform: str
    author: str
    url: str
    published_at: str
    text: str
    title: str = ""
    engagement: str | None = None
    source_type: str = "Unknown"
    provider: str = "unknown"
    is_mock: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


class Provider(Protocol):
    def collect(self, query: dict) -> list[ContentItem]: ...
