from __future__ import annotations

from .base import ContentItem


class MockProvider:
    """Deterministic local provider for tests and offline demos."""

    def collect(self, query: dict) -> list[ContentItem]:
        return [
            ContentItem(
                platform="Mock",
                author="Mock Author A",
                url="https://example.org/mock/agent-autonomy",
                published_at="2026-09-25",
                title="Agent autonomy debate",
                text="Teams are debating how much autonomy AI agents should receive in production.",
                engagement="mock: medium engagement",
                source_type="Social",
                provider="mock",
                is_mock=True,
            ),
            ContentItem(
                platform="Mock",
                author="Mock Author B",
                url="https://example.org/mock/continuous-evaluation",
                published_at="2026-09-27",
                title="Continuous evaluation for agents",
                text="Continuous evaluation and observability are becoming central to agent deployments.",
                engagement="mock: medium engagement",
                source_type="Blog",
                provider="mock",
                is_mock=True,
            ),
            ContentItem(
                platform="Mock",
                author="Mock Researcher",
                url="https://example.org/mock/control-over-autonomy",
                published_at="2026-09-28",
                title="Control over autonomy",
                text="Maximizing autonomy may be the wrong objective; permissions, evaluation and control matter more.",
                engagement="mock: high relative engagement",
                source_type="Social",
                provider="mock",
                is_mock=True,
            ),
        ]
