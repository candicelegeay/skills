from __future__ import annotations

import os

from .base import ContentItem


class XRecentProvider:
    """Thin interface placeholder for an official X API client.

    This package intentionally does not ship scraping logic or silently emulate
    live X results. Wire your approved client here and return ContentItem objects.
    """

    def __init__(self, bearer_token: str | None = None):
        self.bearer_token = bearer_token or os.getenv("X_BEARER_TOKEN")

    def collect(self, query: dict) -> list[ContentItem]:
        if not self.bearer_token:
            raise RuntimeError("X_BEARER_TOKEN is required for provider=x_recent")
        raise NotImplementedError(
            "Connect an approved X API v2 recent-search client in x_recent_provider.py."
        )
