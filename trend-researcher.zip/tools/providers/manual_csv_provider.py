from __future__ import annotations

import csv
from pathlib import Path

from .base import ContentItem


class ManualCSVProvider:
    REQUIRED = {"platform", "author", "url", "published_at", "text"}

    def __init__(self, path: str):
        self.path = Path(path)

    def collect(self, query: dict) -> list[ContentItem]:
        with self.path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            fields = set(reader.fieldnames or [])
            missing = self.REQUIRED - fields
            if missing:
                raise ValueError(f"CSV missing required columns: {sorted(missing)}")
            items = []
            for row in reader:
                items.append(
                    ContentItem(
                        platform=row["platform"],
                        author=row["author"],
                        url=row["url"],
                        published_at=row["published_at"],
                        text=row["text"],
                        title=row.get("title", ""),
                        engagement=row.get("engagement") or None,
                        source_type="ManualImport",
                        provider="manual_csv",
                        is_mock=False,
                    )
                )
            return items
