from __future__ import annotations

from datetime import datetime, timezone
from typing import Iterable

import feedparser

from .base import ContentItem


class RSSProvider:
    def __init__(self, feed_urls: Iterable[str]):
        self.feed_urls = list(feed_urls)

    def collect(self, query: dict) -> list[ContentItem]:
        items: list[ContentItem] = []
        for feed_url in self.feed_urls:
            feed = feedparser.parse(feed_url)
            for entry in feed.entries:
                published = self._date(entry)
                items.append(
                    ContentItem(
                        platform="RSS",
                        author=entry.get("author", feed.feed.get("title", "Unknown")),
                        url=entry.get("link", feed_url),
                        published_at=published,
                        text=entry.get("summary", "") or entry.get("description", ""),
                        title=entry.get("title", ""),
                        source_type="RSS",
                        provider="rss",
                        is_mock=False,
                    )
                )
        return items

    @staticmethod
    def _date(entry) -> str:
        parsed = entry.get("published_parsed") or entry.get("updated_parsed")
        if parsed:
            return datetime(*parsed[:6], tzinfo=timezone.utc).date().isoformat()
        return datetime.now(timezone.utc).date().isoformat()
