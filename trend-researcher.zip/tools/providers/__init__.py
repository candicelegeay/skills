"""Data providers for trend-researcher."""
