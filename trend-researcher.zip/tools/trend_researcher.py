#!/usr/bin/env python3
from __future__ import annotations

import argparse
from collections import Counter
from datetime import date
from pathlib import Path
import re

import yaml

from providers.mock_provider import MockProvider
from providers.manual_csv_provider import ManualCSVProvider


STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "are", "from", "into", "more",
    "les", "des", "une", "pour", "dans", "avec", "sur", "est", "sont", "plus", "que",
    "de", "la", "le", "un", "et", "du", "au", "en", "a", "to", "of", "is", "in",
}


def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def in_window(item, query: dict) -> bool:
    start = query["time_window"]["start"]
    end = query["time_window"]["end"]
    return start <= item.published_at <= end


def dedupe(items):
    seen = set()
    out = []
    for item in items:
        key = item.url.strip().lower() or re.sub(r"\s+", " ", item.text.strip().lower())
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def keyword_signals(items, domains: list[str]) -> list[tuple[str, int]]:
    tokens = []
    for item in items:
        tokens.extend(re.findall(r"[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ0-9_-]{2,}", item.text.lower()))
    counts = Counter(t for t in tokens if t not in STOPWORDS)
    for domain in domains:
        d = domain.lower().strip()
        if d:
            counts[d] += sum(d in item.text.lower() for item in items)
    return counts.most_common(8)


def build_report(query: dict, items) -> dict:
    items = dedupe([i for i in items if in_window(i, query)])
    urls = [i.url for i in items]
    signals = keyword_signals(items, query.get("domains", []))

    # This CLI intentionally provides a deterministic baseline report.
    # In an agent runtime, semantic clustering and editorial analysis should be
    # performed by the skill instructions in SKILL.md using these collected items.
    dominant = []
    if signals:
        top_term, count = signals[0]
        dominant.append({
            "theme": top_term,
            "evidence": f"Signal lexical observé {count} fois dans {len(items)} éléments collectés.",
            "sources": urls[: min(3, len(urls))],
        })

    emerging = []
    if len(signals) > 1:
        term, count = signals[1]
        emerging.append({
            "theme": term,
            "evidence": f"Signal secondaire observé {count} fois ; à confirmer par analyse sémantique.",
            "sources": urls[: min(2, len(urls))],
        })

    representative = [
        {
            "author": i.author,
            "platform": i.platform,
            "url": i.url,
            "published_at": i.published_at,
            "observed_signal": i.engagement,
            "relevance": "Élément représentatif du corpus collecté ; pertinence éditoriale à qualifier par l'agent.",
        }
        for i in items[:3]
    ]

    report = {
        "research_date": date.today().isoformat(),
        "time_window": query["time_window"],
        "idea_id": query.get("idea_id"),
        "dominant_themes": dominant,
        "emerging_themes": emerging,
        "contrarian_positions": [],
        "representative_content": representative,
        "hook_patterns": [],
        "idea_overlap": {
            "already_common": [],
            "differentiated_elements": [],
            "potential_novelty": [],
        },
        "editorial_opportunities": [],
        "sources": [
            {
                "url": i.url,
                "title": i.title or i.url,
                "author": i.author,
                "date": i.published_at,
                "source_type": i.source_type,
                "provider": i.provider,
                "is_mock": i.is_mock,
            }
            for i in items
        ],
    }
    return report


def make_provider(args):
    if args.provider == "mock":
        return MockProvider()
    if args.provider == "manual_csv":
        if not args.csv:
            raise SystemExit("--csv is required with --provider manual_csv")
        return ManualCSVProvider(args.csv)
    if args.provider == "rss":
        if not args.rss:
            raise SystemExit("At least one --rss URL is required with --provider rss")
        from providers.rss_provider import RSSProvider
        return RSSProvider(args.rss)
    if args.provider == "x_recent":
        from providers.x_recent_provider import XRecentProvider
        return XRecentProvider()
    raise SystemExit(f"Unknown provider: {args.provider}")


def main():
    parser = argparse.ArgumentParser(description="Collect trend signals and emit a TrendReport baseline.")
    parser.add_argument("--query", required=True, help="Path to TrendQuery YAML")
    parser.add_argument("--provider", choices=["mock", "manual_csv", "rss", "x_recent"], default="mock")
    parser.add_argument("--csv", help="Manual CSV path")
    parser.add_argument("--rss", action="append", default=[], help="RSS/Atom URL; repeatable")
    parser.add_argument("--output", help="Output YAML path; stdout if omitted")
    args = parser.parse_args()

    query = load_yaml(args.query)
    provider = make_provider(args)
    items = provider.collect(query)
    report = build_report(query, items)
    rendered = yaml.safe_dump(report, sort_keys=False, allow_unicode=True)

    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    else:
        print(rendered)


if __name__ == "__main__":
    main()
