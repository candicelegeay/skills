# trend-researcher

Standalone package for skill #2: **trend-researcher**.

## Contents

- `SKILL.md` — agent instructions and behavior contract
- `skill.yaml` — portable manifest
- `schemas/` — input/output contracts
- `examples/` — valid query/report examples + CSV import example
- `tools/` — CLI plus mock, manual CSV, RSS and X recent-search provider interfaces
- `config/` — defaults
- `references/` — source/provenance policy
- `tests/` — schema and mock-pipeline tests

## Quick start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make test
make run-mock
```

Generate a report file:

```bash
python tools/trend_researcher.py \
  --query examples/TrendQuery.example.yaml \
  --provider mock \
  --output /tmp/TrendReport.yaml

python tools/validate_report.py /tmp/TrendReport.yaml
```

## Live sources

`mock` and `manual_csv` run without credentials. `rss` needs feed URLs. `x_recent` is intentionally only an interface stub: connect an approved official API client and provide `X_BEARER_TOKEN`; the package does not ship scraping or pretend live results are real.
