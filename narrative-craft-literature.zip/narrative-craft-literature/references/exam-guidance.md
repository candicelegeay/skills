# CR Visio du 17 février 2026_Recommandations pour lexamen.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: A2FLT12_ Visio du 17 février 2026 / Organisation pratique de l’examen
- PDF page 2: - / Le titre d’une nouvelle doit être écrit entre guillemets et le titre d’un roman doit être

## PDF page 1

A2FLT12_ Visio du 17 février 2026 
 
Organisation pratique de l’examen 
- 
Vous aurez 1h15 à partir du moment où vous ouvrez le sujet jusqu’au moment de le 
rendre. Il s’agit d’une épreuve d’une heure, ce quart d’heure supplémentaire est là pour 
pallier à toute difficulté technique que vous pourriez rencontrer (déconnexion par 
exemple).  
ð Si vous rencontrez une difficulté technique quelconque, il faut m’écrire un email au 
plus vite. De manière générale, si vous rencontrez des difficultés, merci de m’en 
tenir informée par email. 
- 
Il vous sera demandé de rendre un devoir tapé sur l’ordinateur (word ou pdf). 
- 
Si vous bénéficiez d’un tiers-temps, merci de m’envoyer votre plan d’accompagnement 
au plus vite par email. Si vous avez droit à un tiers-temps, merci de m’envoyer votre 
copie directement par email 1h20 (ou 1h30) après le moment de votre connexion. 
 
Organisation des questions de l’examen (j’ai diminué le nombre de question par rapport 
à ce que j’avais annoncé initialement pour vous donner le temps de bien rédiger chacune 
de vos réponses). 
- 
Vous aurez 2 questions de vocabulaire (2,5 points par terme à définir). Une définition 
claire est attendue. Il est recommandé de donner un exemple lorsque vous le pouvez 
(exemple issu des nouvelles, ou de votre culture générale).  
- 
Vous aurez ensuite 3 questions liées au vocabulaire de l’analyse littéraire au début de la 
brochure (5 points par question). Ces questions seront accompagnées d’un court extrait 
des nouvelles à analyser 
Les attendus pour l’examen 
Connaissances 
- 
Une bonne connaissance et compréhension du vocabulaire littéraire de la brochure 
- 
Une bonne connaissance et compréhension des nouvelles. Vous ne serez interrogés que 
sur les nouvelles qui ont été travaillés dans le TD. 
Capacités d’analyse 
- 
Votre capacité à analyser les textes à travers la question posée. Lorsque vous utilisez 
un terme de vocabulaire littéraire, il est recommandé d’en donner la définition (par 
exemple : « the narrator is omniscient » => explain what omniscient means). 
La qualité de l’anglais écrit 
- 
La qualité de l’orthographe, du vocabulaire et de la grammaire entre aussi dans la 
notation. Veillez donc à garder 10mn pour vous relire à la fin de l’épreuve. 
Comment organiser votre heure de travail ? 
- 
5-10 mn : vocabulaire 
- 
45 mn : 3 questions d’analyse (15mn par question) 
- 
5-10mn : relecture attentive 
Quelle longueur pour vos réponses ? 
- 
L’organisation du temps par question d’analyse (15mn) est une indication par rapport à 
la longueur des réponses attendues. De manière générale, un minimum de 5 lignes est 
attendu.  
 
Quelques remarques formelles pour la rédaction de vos devoirs 
- 
La qualité de l’anglais joue un rôle non négligeable dans la notation prenez donc soin 
de présenter vos idées dans un anglais clair et correct. Une langue simple et claire 
correspond tout à fait aux attendus, il est inutile de chercher à compliquer les choses 
avec des phrases longues et inutilement complexes. 


## PDF page 2

- 
Le titre d’une nouvelle doit être écrit entre guillemets et le titre d’un roman doit être 
écrit en italique ou souligné lors ce que vous écrivez à la main 
 
ð Ex: “The Tell-Tale Heart” and Strange Case of Dr Jekyll and Mr Hyde 
(Strange Case of Dr Jekyll and Mr Hyde if the paper is handwritten) 
- 
En anglais, les titres prennent une majuscule sur tous les mots, à l’inverse du français 
où seul le premier substantif prend une majuscule.  
- 
Il faut utiliser le présent pour évoquer ce qui se passe dans le texte. L’utilisation du 
présent marque une distance avec les événements du texte et permet de montrer qu’il 
s’agit non pas d’événements réels qui auraient eu lieu dans le passé mais bien d’une 
fiction. N’oubliez pas qu’au présent la troisième personne du singulier prend 
systématiquement 1 « s » (ex : the narrator says ») 
- 
Veillez à utiliser un vocabulaire qui soit toujours le plus spécifique possible : utiliser 
ainsi des verbes liés à l’analyse pour faire référence à votre travail (to analyze, to study, 
to discuss, to demonstrate, to show et non pas « to talk about ») 
- 
Si vous pouvez bien sûr mentionner l’auteur, l’analyse doit se concentrer principalement 
sur le narrateur, c’est bien en effet la voix narrative qui doit être au cœur de votre travail 
d’analyse. 
Remarques de vocabulaire 
- 
Attention à ne pas confondre « short story » (une nouvelle) et « novel » (roman). 
- 
« to discuss » ne veut pas dire la même chose que « discuter » en français. « To discuss » 
veut dire analyser. Il est donc un terme très approprié pour analyser un texte, à l’inverse 
du verbe « to talk about » qui donne l’impression que vous allez simplement évoquer le 
texte sans entrer dans une analyse sérieuse. 
Attention : on ne dit pas « to discuss about » mais « to discuss + objet direct », par 
exemple : “to discuss the theme of loneliness in the text” 
- 
Pour traduire le « on » français, il vaut mieux choisir « one » plutôt que « you » 
Ex : One feels the old man’s loneliness in reading the text. 
 
 
 
 
 

