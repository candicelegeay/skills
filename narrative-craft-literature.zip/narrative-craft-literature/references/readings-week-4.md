# Week 4.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: 1 / Week 4: Short stories
- PDF page 2: 2 / opening gives a sense of a neutral narrator, though we see soon that he/she has a very specific
- PDF page 3: 3 / of the outside of their houses before moving inside the houses. Here the narrator gives a lot of
- PDF page 4: 4 / We move from what seems at first like an absence of emotion which enhances the sense of
- PDF page 5: 5 / O. Henry, “The Gift of the Magi” (1905): excerpt from line 23 “Out of his trance” to the
- PDF page 6: 6 / 2. How does the narrator emphasize the irony of the situation?
- PDF page 7: 7 / scrutiny…”, showing that the narrator is leading us through the story, pointing

## PDF page 1

 
1 
Week 4: Short stories 
- 
Angela Carter, “The Werewolf” (1978): excerpt from the beginning to line 15, “stone her to 
death” 
- 
O. Henry, “The Gift of the Magi” (1905): excerpt from line 23 “Out of his trance” to the end 
of the story 
 
 
Angela Carter. “The Werewolf” (1978): excerpt from the beginning to line 15, “stone her to death” 
 
The story follows a three-part narrative arc: it opens on what sounds like an objective account 
of the life of the people in this “Northern” country, followed by a modern rewriting of the Little 
Red Riding Hood story (she meets a wolf, finds her ailing grandmother), but the reversal 
happens when she realizes that her grandmother is the wolf. The child calls on the neihbors to 
help her fight the old woman. One sentence concludes the story, telling us that the girl ended 
up living and “prospering” in the house. 
ð This is a story which sets up a very specific atmosphere of harshness and superstition in its 
opening paragraphs (the passage we will be working on), and which then brings us to the 
fairy tale of Red Riding Hood, a familiar story which is then debunked, or turned around 
in the last part of the story. We are going to look at the way the narrator sets up a very 
specific atmosphere in the opening paragraphs of the text. 
 
This is an extremely concise text: in one page Angela Carter manages to create a very specific 
atmosphere. This introduction sets a very particular scene, one of a very harsh environment and 
population. We can see how Angela Carter debunks the traditional motif of the fairy tale, 
presenting an atmosphere of harshness and difficulty as well as a sense of uncertainty. At the 
end of the short story the reader is indeed not fully certain of what has happened: the almost 
anthropological account of superstition collapses and gives credence to what was presented 
before as superstition. The text plays with our expectations. The narrator betrays the reader who 
starts with rational expectations and is presented with a medieval tale of witches and witch 
transformation into a wolf and back into a witch. The introduction plays a key role in setting a 
particular atmosphere of harshness and superstition. The superstition of these men and women 
is underlined by the narrator in the introduction as superstition, as unreal – yet the conclusion 
seems to suggest that witches might indeed exist in this tale, thus putting the reader in a position 
of uncertainty. 
 
The text is narrated by a third person omniscient voice which is undefined (though the narrator 
refers to himself/herself with the pronoun “I” at the beginning of the third paragraph). The 


## PDF page 2

 
2 
opening gives a sense of a neutral narrator, though we see soon that he/she has a very specific 
point of view on the people described.  
The beginning gives the impression of an anthropological description, as if made by a traveler 
or anthropologist, underlining the superstitious beliefs of these people. The description is in the 
present tense with short nominal sentences and no connectors between them which gives the 
impression of a very detached and objective narrative made of a series of facts. There are no 
stylistic flourishes: the text gives an impression of extreme brevity and simplicity. However, 
starting on line 5 the narrator’s voice addresses the reader directly (“anyone will tell you that”, 
line 10), this creates a sense of proximity between the narrator and us; it underlines the 
opposition between our rational perspective (the narrator’s and the reader’s) and the superstition 
of the people described in the text. The narrator suggests that these people whom he calls “these 
upland woodsmen” are very different from him/her and us. 
 
ð  How does the narrator set up this very specific atmosphere? How do the descriptive 
opening paragraphs prepare us for this rewriting of the story of Little Red Riding Hood?  
ð We will first how the text manages to create this atmosphere as one of harshness and 
repetition before looking at the way the text sets the people of this country as very different 
from the world of the readers and the narrators. We’ll then see how the text mixes together 
a narrative that seems very factual, with a very fictional description of superstition. 
 
 Setting an atmosphere: harshness and superstition 
The narrative voice seems very detached and “objective”. If we look at the first sentence: 
it is made of three parts, each dedicated to a very factual description: geography, weather and 
psychology. The repetition of the same adjective, “cold” to refer to the weather and the people’s 
hearts suggests that everything we learn about the outside reality of this region is an illustration 
of the inner, psychological reality of the people living there.  
We are given very little information, only that the place is located in the North (“It is a 
northern country”), yet the text manages to create a clear sense of the specificities of this place. 
The narrator relies on the adjective “cold” which, unrelated to a noun, at the opening of the 
second paragraph (line 2) doubles its effect. The text’s second sentence manages to create an 
impession through a ternary rhythm: here again as with the opening sentence: we have a list of 
three items which set up the scene. The next two sentences are very short: “it is a hard life”: a 
brutal and final statement which does not allow for any exceptions. The narrator then moves 
from a general presentation to a description of these people’s living conditions: the description 


## PDF page 3

 
3 
of the outside of their houses before moving inside the houses. Here the narrator gives a lot of 
detail and opens up the subject of these people’s beliefs with the mention that “there will be a 
crude icon of the virgin”. The verb “will” shows that this is a supposition, but one that is very 
likely; while the adjective “crude” underlines the absence of taste of these people. And then the 
paragraph ends on two more short sentences which are also built on a ternary rhythm, which 
echoes the beginning and suggests that this is a world marked by repetitions, lives being lived 
the same way from generation to generation.  
The third paragraph develops the theme of superstition which was hinted at with the 
mention of the “crude icons”. Now, the text explains very clearly how these people believe in 
the devil. The narrator tells us that the people don’t know other people (“they have not seen us 
nor know we exist”): they live in complete separation from the rest of the world, but, because 
of this the text seems to suggest, they are a very superstitious people who strongly believe in 
the devil.   
The narrator anchors the description on the lexical field of superstition, with the mention 
of the devil, vampires, witches, or sinister practices stoning people to death, black cats. The 
narrator describes the landscape as so harsh that no flowers can grow on it, which underlines 
the harshness of the cemeteries with no flowers and only votive objects. The metaphor 
“townships of the dead” to refer to the cemetery shows the distance that the narrator is putting 
between our reality and that of the people described. The narrator adopts the point of view of 
the people at the end of the third paragraph when he focalizes on their perspective: “At midnight 
especially on Walpurgisnacht, the Devil holds picnics in the graveyards and invites witches; 
then they dig up fresh corpses and eat them. Anyone will tell you that”. The last sentence 
« anyone will tell you that » makes us go back on the previous sentence and realize that what 
was described belonged to the point of view of the people, not the narrator who is here showing 
his ironic and distant perspective.  
ð We see in these opening paragraphs how the narrator changes his point of view: he moves 
from a neutral to an ironic perspective. He underlines the harshness of life on this land 
which explains the superstition of these people. But he marks a distance between these 
people and the narrator and the readers.  
Facts and fiction: preparing the scene for the fairy tale1 
 
1 Students often wonder whether they should refer to other parts of the story when they are analyzing an 
excerpt from a story : yes, it is absolutely possible to do so, as I do in this second part. Note though that I 
am still remaining focused on the passage, only analyzing it from the perspective of someone who has read 
the story and know what will happen next. This allows me to bring out how the passage sets the tone for 
what is coming next.  


## PDF page 4

 
4 
We move from what seems at first like an absence of emotion which enhances the sense of 
rationality and thus prepares for a greater surprise. At the same time, the narrator underlines 
the limited and superstitious perspective of the villagers. We are therefore made to have a 
distant perspective on them. 
In the fourth paragraph, we learn of how the townspeople are governed by their superstition 
which makes them believe that a “blue-eyed child born feet-first on the night of St John’s Eve 
will have second sight”, or supernatural powers. In the same way, if a woman is followed by 
her cat, she will be considered a witch and will be stoned to death. The narrator brings out these 
stories to set a certain tone and to make us consider these people as backward. Because of this, 
we understand that this land is propitious to folk tales and fairy tales. The reader is given all 
the themes and motifs that appear in folk tales: we are therefore prepared for the rewriting of 
the fairy tale of Little Red Riding Hood. 
 
Creating an opposition with the people in the text and proximity with the readers 
The narrator takes the reader along with him in looking at these people as backward and 
superstitious. It is indeed striking that the narrative which starts off as so “neutral” looking, 
contains moments when the narrator intervenes directly: on line 5, the narrator mentions himself 
as having the same point of view as the reader (“To these upland woodsmen, the Devil is as real 
as you or I”). Then the sentence “anyone will tell you that” shows another instance when we 
get to hear the narrator’s subjective point of view and then in the 4th paragraph “oh sinister!” is 
a direct presentation of the narrator’s subjective point of view on the superstition of the 
villagers. There is therefore a discrepancy between the sense of neutrality at the opening of the 
story and the gradual opening up of his subjective perspective on these people.  
 
Conclusion 
The text plays on magical realism: this means that it gives an account that is realistic (this seems 
to be a real country, with real people) and which does not seem fictional but that looks, rather, 
like an anthropological account. Yet there is a place made for magic in the story and for a return 
to the fairy tale. The difference between magic and reality is a little hard to distinguish. The text 
operates a variation on a folktale theme which is presented in a very modern sensibility, thus 
creating surprise at the end. 
  
 


## PDF page 5

 
5 
O. Henry, “The Gift of the Magi” (1905): excerpt from line 23 “Out of his trance” to the 
end of the story 
=> This document presents a possible outline and analysis of this excerpt. I have underlined the 
methodology used for you to see how I came to this choice of outline. Note that there are many possible 
ways of analyzing a text. What is important is to ground the outline on a thorough summary of the text, 
on key notions and on specific analyses of passages from the text. 
 
Introduction  
This passage is situated at the end of the short story, it presents us with two successive 
revelations about the gifts offered by the wife to her husband and by the husband to his wife. 
These are revelations for the characters and for the readers. These revelations underline the 
irony of the situation, the fact that they both relinquish their most precious possessions in order 
to give a wonderful gift to the other, but neither will be able to enjoy his or her gift since they 
have given away her hair, in Della’s case, and his watch in Jim’s case. The narrator concludes 
these revelations with a final commentary on the moral meaning of this story. (this is the 
summary of the text) 
 In other words, the text underlines the the love between the two characters as well as the irony 
of the situation, two elements on which the narrator builds his moral commentary at the end. 
(this is a shorter summary in which I put forward the main aspects of the text. It’s on these 
notions that I will build my outline). 
It will be important to look at the narrator’s role in bringing out the story’s moral at the end. I 
will show how the character’s selfless love is underlined by the text, before underlining the 
irony of the situation and ultimately how these two elements transform the story into a moral 
fable. (this is my outline: note how it grows naturally from the previous paragraph). 
 
1. How does the narrator underline the characters’ love for one another? 
a. The text underlines the two characters’ sacrifices.  
b. The narrator underlines the intensity of their feelings, as for instance line 32 with 
the succession of Della’s intense emotions: “And then an ecstatic scream of joy, 
and then, alas, a quick feminine change to hysterical tears”: the narrator insists 
on the order of events though the repetition of “and then”, the use of adjectives 
“ecstatic, quick, feminine” and the interjection “alas” allows him to share his 
opening about the intensity of their love. 
 


## PDF page 6

 
6 
2. How does the narrator emphasize the irony of the situation? 
ð Here at the beginning on this part on irony, it is important to define the term in 
relation to the text. 
The two characters have sacrificed their most treasured possession in order to give a gift to the 
other, which in turns will keep them from enjoying their gift. The intended result of the gift is 
met with the opposite result, which leads to the sense of irony which pervades the text. We can 
take three examples underlining this sense of irony: 
a. The detailed description of the comb’s beauty (lines 35-39) underlines the 
paradox that she will not be able to use them. “Beautiful combs, pure tortoise 
shell, with jewelled rims – just the shade to wear in the beautiful vanished hair”. 
The accumulation of adjectives (“beautiful, pure, jewelled, beautiful”) comes in 
stark contrast with the final adjective “vanished” which comes as an ironic and 
sharp conclusion to the fact that Della will not be able to use the comb. 
b. L. 38-39: “And now, they were hers, but the tresses that should have adorned 
the coveted adornments were gone”. Here, we “hear” the narrator’s voice 
commenting on the irony of the situation “but the tresses that should have 
adorned” is a commentary on the narrator’s part illustrating the irony of the 
situation. 
c. L. 50 “I sold the watch to get the money to buy your combs”: the factual 
statement made by Jim illustrates the whole irony of the situation. The repetition 
of the sentence “And now suppose you put the chops on” (50-51) which echoes 
what Della’s question line 21-22 “Shall I put the chops on, Jim?”. Their dinner 
(“the chops”) stands for their daily life, in opposition to the extraordinary gifts 
they each tried to give to the other. Going on with their dinner as a reaction to 
the gift shows that the gift is not what was important to either of them. 
 
3. The importance of the narrative voice in establishing the moral of the story 
The external (or heterodiegetic, or extradiegetic. See page 20 in the brochure for definitions) 
narrator is an overt narrator (see page 20 also) who comments on the story he conveys. His 
comments seek to convey the love between the two characters and the irony of the situation.  
a. Line 26-27 “This dark assertion will be illuminated later on”: the narrator 
prepares the readers for the revelation that will come. He also involves the 
readers in the story on line 23-25 “For ten seconds let us regard with discreet 


## PDF page 7

 
7 
scrutiny…”, showing that the narrator is leading us through the story, pointing 
our reading in certain directions (here, the scrutiny of the situation). 
b. Lines 38-39: the narrator provides a commentary on the situation to explain it to 
the reader (note that I have already referred to this quotation: it is absolutely 
possible to refer to the same part of the text) 
c. The last paragraph transforms the story into a fable where the two characters are 
no longer to be understand as specific round characters (see “characterization 
section of the brochure, pp. 21-22), but flat characters, types standing for the 
notions of love and generosity, they become “two foolish children” (line 55), 
“the magi”, illustrating a fable about love and generosity. The references line 52 
to the story of Jesus in the Bible (“the Babe in the manger”) puts forward the 
transcendent dimension of the characters’ selflessness.  
 
Conclusion 
This passage at the end of the story illustrates how the plot (the diegesis) is presented by the 
narrator in a light which underlines the moral dimension of the story. The last paragraph, 
the denouement of the story is addressed directly to the readers in order to show the 
didactic dimension of the story, its ambition to teach them a moral. Indeed, we see 
through the emphasis put on the characters’ relationship (first part) and the irony of the 
situation which also underlines their selflessness (2nd part) that the narrator uses the text 
to bring out a moral message to the readers (3rd part). “The Gift of the Magi”, as its title 
suggests, is a modern fable about selflessness and generosity. 
ð The conclusion serves to summarize the stages of your demonstration and to conclude on 
it. 
 
 

