# Fiche méthodologique pour le commentaire de texte littéraire.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: Fiche méthodologique pour le commentaire de texte littéraire / But du commentaire de texte : montrer comment un texte fonctionne à la fois c
- PDF page 2: o Citer le texte pour montrer où ce thème est visible spécifiquement dans le / passage

## PDF page 1

Fiche méthodologique pour le commentaire de texte littéraire 
 
But du commentaire de texte : montrer comment un texte fonctionne à la fois comme récit ou 
histoire et comme construction littéraire. Cela veut dire qu’il faut analyser ce que dit le texte 
(l’histoire) mais aussi et c’est absolument essentiel comment le texte dit les choses. Pour cela 
il faut absolument analyser la voix narrative : qui parle dans le texte ? comment parle-t-il ? et 
pourquoi parle-t-il comme cela ?  
ð Votre réflexion doit toujours prendre en compte les deux niveaux que sont 
l’histoire et la narration 
 
Points pris en compte dans la notation 
- 
La connaissance de la nouvelle ou du roman et la compréhension du passage 
- 
La qualité de l’anglais écrit (il faut utiliser le présent simple pour évoquer ce qui se 
passe dans le texte et ne pas oublier le « s » à la 3ème personne du singulier au présent) 
- 
La compréhension des enjeux du passage dans l’histoire et la mise en avant des 
questions thématiques abordée dans le passage 
- 
L’organisation d’un plan cohérent, autour d’un angle de lecture qui permette de 
montrer les points saillants du texte 
- 
La capacité à analyser la manière dont un texte est écrit. Ce niveau d’analyse est 
absolument essentiel à un commentaire de texte réussi. Il s’agit de démontrer 
quelles sont les outils littéraires utilisés pour favoriser la création de certains effets 
sur le lecteur. 
ð Les trois premiers points sont très importants, mais le commentaire ne commence 
vraiment qu’avec les 3ème et 4ème points, lorsque vous commencez à expliquer comment 
le texte est écrit et pour quel effet, autour d’une problématique clairement énoncée. 
 
Introduction 
- 
Présentation de l’œuvre (une phrase) 
- 
Présentation du passage à analyser (3 ou 4 phrases) 
o Situation dans l’œuvre et dans la diégèse (l’histoire) 
o Résumé de ce qui se passe dans le passage 
o Résumer la situation narrative : passage narratif ou dialogue ? ou les deux ? Qui 
est le narrateur, quel est son point de vue ? 
o Présentation des enjeux principaux du passage : enjeux par rapport à l’histoire, 
enjeux thématiques, caractéristiques formelles du passage… 
- 
Annonce de l’angle choisi pour l’analyse du passage (la présentation du passage juste 
avant ce moment de l’introduction va permettre de justifier à l’avance votre choix 
d’angle d’analyse) : 1 phrase 
o Ceci peut être formulé sous forme de question ou d’affirmation. Si vous 
choisissez la forme interrogative veillez à ce que la phrase soit 
grammaticalement correcte : 
§ We will see how the text builds tension 
§ How does the text build tension? 
- 
Annonce du plan 
 
Pour chaque partie 
- 
Une phrase d’introduction pour indiquer ce sur quoi cette partie va porter 
- 
Pour chaque thème abordé : 
o Présenter l’importance du thème abordé dans le passage 


## PDF page 2

o Citer le texte pour montrer où ce thème est visible spécifiquement dans le 
passage 
o Analyser la citation. L’analyse doit expliquer la citation par rapport au thème 
analysé mais aussi, c’est absolument essentiel, par rapport à la manière dont la 
citation est écrite. En d’autres termes il faut montrer comment l’écriture du texte 
permet de renforcer le thème analysé.  
- 
Une phrase de conclusion qui rappelle ce que vous avez montré dans la partie et qui 
annonce la partie suivante. 
 
Conclusion 
- 
Revenir sur ce qu’a montré chacune des parties (une ou deux phrases) 
- 
Proposer une dernière vue d’ensemble sur le passage et ce qu’il s’y passe, autant dans 
l’histoire que dans l’écriture 
- 
Il n’est pas nécessaire d’ouvrir le commentaire. Vous pouvez le faire si vous avez 
quelque chose de pertinent à dire mais ce n’est pas nécessaire si vous ne savez pas 
comment ouvrir le commentaire. 

