# A2FLT11 12 Lecture 2 PDF.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: A2FLT11 – CM – Lecture 2 / Narration & Focalization
- PDF page 2: 1. Narrator  (more than simple 1st person or 3rd person split) / (the one who speaks)
- PDF page 3: 2. The Focalizer (term from Genette): / (the one who sees or feels)
- PDF page 4: Samples from the short stories: / The people had done it so many times that they only half listened to the directions: most of them were qui
- PDF page 5: Samples from the short stories: / “The Garden Party”
- PDF page 6: 3. The Narratee / (the one who’s being spoken to)                       (often in first-person acounts, dramatic monologue)
- PDF page 7: Narrative Distance in first-person narratives: / The implied distance (in time) between the narrated-I and the narrating-I.

## PDF page 1

A2FLT11 – CM – Lecture 2
Narration & Focalization
(see p.7 of your brochure)


## PDF page 2

1. Narrator  (more than simple 1st person or 3rd person split)
(the one who speaks)
external (extradiegetic) narrator (outside the story)
internal (intradiegetic)  (a character telling the tale)
subordinate (hypodiegetic) (when characters tell a quick story to the protagonist, for example)
an autodiegetic narrator (the main character – e.g., Jane Eyre in Brontë’s Jane Eyre)
homodiegetic (part of the main group of characters – e.g., Nick in Fitzgerald’s The Great Gatsby)
heterodiegetic (a fictional character but not part of main story –e.g., the unnamed narrator in 
George Eliot’s Middlemarch) 
covert vs. overt narration (i.e., Is the narrator identified?)
constant vs. shifting narration (i.e., Does the narrator ever change?)
actional or explicative narration (i.e., Are events narrated, or is the focus more on 
feelings/motivations/thoughts?)
unintrusive or intrusive narration (i.e., Do we nearly forget we have a narrator 
or does the narrator ‘interrupt’ the story?)
reliable or unreliable/fallible (i.e., Can we trust what the narrator tells us?  
e.g., Benjy in The Sound & the Fury, Humbert Humbert in Lolita, Poe narrators)


## PDF page 3

2. The Focalizer (term from Genette): 
(the one who sees or feels)
also called ‘point of view character’ / reflector / mirror / centre of consciousness (Henry James)
- focalization or point of view / perspective / angle of vision
note : 
focalization by someone—emphasis on who is perceiving
focalization on someone—emphasis on who/what is being perceived
3 main cases:
A. EXTERNAL FOCALIZERS  (usually the narrator)
1.  the detached observer / witness (restricted knowledge)
2.  ‘zero-focalization’ / omniscience (unrestricted knowledge)
B. INTERNAL FOCALIZERS (character-focalizers)
Constant or shifting point of view?
Covert or overt focalizers?
Reliable or unreliable/fallible focalizers?


## PDF page 4

Samples from the short stories:
The people had done it so many times that they only half listened to the directions: most of them were quiet, wetting 
their lips, not looking around. Then Mr. Summers raised one hand high and said, 'Adams.' A man disengaged himself 
from the crowd and came forward. (“The Lottery”)
nar: extrad, covert, constant, actional, unintrusive, reliable / foc: EXT – detached observer, constant, covert, rel.
Out of his trance Jim seemed quickly to wake. He enfolded his Della. For ten seconds let us regard with discreet 
scrutiny some inconsequential object in the other direction. Eight dollars a week or a million a year--what is the 
difference? A mathematician or a wit would give you the wrong answer. (“The Gift of the Magi”)
External narrator pretending to be in room, covert, constant, explicative&actional, intrusive, reliable
Foc: ext/omnisocient overall, more than a simple observer
Framton Nuttel endeavoured to say the correct something which should duly flatter the niece of the moment 
without unduly discounting the aunt that was to come.  Privately he doubted more than ever whether these formal 
visits on a succession of total strangers would do much towards helping the nerve cure which he was supposed to 
be undergoing.   (“The Open Window”)
Nar: Extrad, covert, explicative/actional, unintrusive, reliable / FOC: INTERNAL (overt: Nuttel), 
constant, unreliable
The child has a scabby coat of sheepskin to keep out the cold, she knew the forest too well 
to fear it but she must always be on her guard. When she heard the freezing howl of a wolf,
she dropped her gifts, seized her knife and turned on the beast.  (“The Werewolf”) –
Nar: extrad, covert, mainly actional & reliable / FOC: shifting: mainly external/observer 
but occasional subtle hints at what she’s thinking (INT) like here / covert vs overt / reliable


## PDF page 5

Samples from the short stories:
“The Garden Party”
His smile was so easy, so friendly that Laura recovered. What nice eyes he had, small, but such a dark blue! And 
now she looked at the others, they were smiling too. "Cheer up, we won't bite," their smile seemed to say. How very 
nice workmen were! And what a beautiful morning! She mustn't mention the morning; she must be business-like. 
The marquee. (p.61)
“What mother?"
No, better not put such ideas into the child's head! "Nothing! Run along." (p.67)
(NAR- extrad, covert, constant, explicative/actional, unintrusive, reliable; FOC: seems INTERN throughout but it 
suddenly & briefly shifts p.67: so more omniscient/zero-foc)
“A Clean Well-Lighted Place”
They sat together at a table that was close against the wall near the door of the cafe and looked at the terrace where 
the tables were all empty except where the old man sat in the shadow of the leaves of the tree that moved slightly in 
the wind. A girl and a soldier went by in the street. The street light shone on the brass number on his collar. The girl 
wore no head covering and hurried beside him (p.70)
"Good night," the other said. Turning off the electric light he continued the conversation 
with himself. It was the light of course but it is necessary that the place be clean and 
pleasant. You do not want music. Certainly you do not want music. (p.71-72)
NAR-extrad, constant, etc. but FOC shifts in last paragraph or so, from this line to 
the end, from ext observer & reliable to INT & less reliable (depressed, nihilistic)


## PDF page 6

3. The Narratee
(the one who’s being spoken to)                       (often in first-person acounts, dramatic monologue)
Is it an extradiegetic narratee (outside the story) or an intradiegetic narratee (inside the story)
Is it constant or shifting?
Is it overt or covert?
e.g.,
You don’t know about me, without you have read a book by the name of “The Adventures of Tom 
Sawyer,” but that ain’t no matter…                       (The Adventures of Huck Finn)
If you really want to hear about it, the first thing you'll probably want to know is where I was born, 
an what my lousy childhood was like, and how my parents were occupied and all before they had 
me, and all that David Copperfield kind of crap, but I don't feel like going into it, if you want to 
know the truth.          (The Catcher in the Rye)


## PDF page 7

Narrative Distance in first-person narratives:
The implied distance (in time) between the narrated-I and the narrating-I.
But there is something else about that paper-- the smell! I noticed it the moment we came into the room, 
but with so much air and sun it was not bad. Now we have had a week of fog and rain, and whether the 
windows are open or not, the smell is here.
It creeps all over the house.
I find it hovering in the dining-room, skulking in the parlor, hiding in the hall, lying in wait for me on the stairs. 
(“The Yellow Wall-Paper”)             (diary entries – almost no narrative distance, use of present tenses)
The former tenant of our house, a priest, had died in the back drawing-room. Air, musty from having been 
long enclosed, hung in all the rooms, and the waste room behind the kitchen was littered with old useless 
papers. Among these I found a few paper-covered books, the pages of which were curled and damp…           
(“Araby”)
I let myself out and went along the walk. It felt funny walking around outside in my nightgown and 
my robe. I thought to myself that I should try to remember this, walking around outside like this. 
(“I See the Smallest Things”)
I can see that figure now—pallidly neat, pitiably respectable, incurably forlorn! It was Bartleby.
After a few words touching his qualifications, I engaged him, glad to have among my corps of 
copyists a man of so singularly sedate an aspect, which I thought might operate beneficially 
upon the flighty temper of Turkey, and the fiery one of Nippers.   (“Bartleby, the Scrivener”)

