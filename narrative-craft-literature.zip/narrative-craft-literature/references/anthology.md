# A2FLT12 Brochure Literature short stories.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: 1 / A2FLT12 - Literature 2: Writing Fiction (Short Stories and Novels)
- PDF page 2: 2
- PDF page 3: 3 / • TABLE DES MATIÈRES
- PDF page 4: 4 / Some Literary Terms and Notions to Help with Textual Commentaries
- PDF page 5: 5 / Key Moments in the Plot:
- PDF page 6: 6
- PDF page 7: 7 / 1. Narrator  (more than simple 1st person or 3rd person split)
- PDF page 8: 8
- PDF page 9: 9 / b. Round Characters vs. Flat Characters
- PDF page 10: 10
- PDF page 11: 11 / E. Speech Representation in the Narration:
- PDF page 12: 12
- PDF page 13: 13 / F. Tone and Style
- PDF page 14: 14 / RHETORICAL EFFECTS / FIGURES OF SPEECH:                      C. Dauphin
- PDF page 15: 15 / The Short Story
- PDF page 16: 16 / Some Notes on the Short Story
- PDF page 17: 17 / Edgar Allan Poe
- PDF page 18: 18 / “The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849)
- PDF page 19: 19 / Presently I heard a slight groan, and I knew it was the groan of mortal terror. It was not a groan of pain or
- PDF page 20: 20 / information had been lodged at the police office, and they (the officers) had been deputed to search the
- PDF page 21: 21 / “Bartleby, the Scrivener” (1853), by Herman Melville
- PDF page 22: 22 / My chambers were up stairs at No.—Wall-street. At one end they looked upon the white wall of
- PDF page 23: 23 / "With submission, sir," said Turkey on this occasion, "I consider myself your right-hand man. In
- PDF page 24: 24 / rash, restive horse is said to feel his oats, so Turkey felt his coat. It made him insolent. He was a
- PDF page 25: 25 / which originally had afforded a lateral view of certain grimy back-yards and bricks, but which,
- PDF page 26: 26 / matter for the present, reserving it for my future leisure. So calling Nippers from the other room,
- PDF page 27: 27 / (The reader of nice perceptions will here perceive that, it being morning, Turkey's answer is
- PDF page 28: 28 / No answer.
- PDF page 29: 29 / Shall I acknowledge it? The conclusion of this whole business was, that it soon became a fixed
- PDF page 30: 30 / Bartleby was an immoral person. But what could he be doing there?—copying? Nay again,
- PDF page 31: 31 / I might know, from his long-continued motionlessness, that behind his screen he must be standing
- PDF page 32: 32 / Again I sat ruminating what I should do. Mortified as I was at his behavior, and resolved as I had
- PDF page 33: 33 / "No more."
- PDF page 34: 34 / "I will leave them here then," putting them under a weight on the table. Then taking my hat and
- PDF page 35: 35 / "Not gone!" I murmured at last. But again obeying that wondrous ascendancy which the
- PDF page 36: 36 / enlisted, should, especially with high-tempered men, prompt all beings to charity and
- PDF page 37: 37 / Ere revolving any complicated project, however, adapted to this end, I first simply suggested to
- PDF page 38: 38 / "I am very sorry, sir," said I, with assumed tranquility, but an inward tremor, "but, really, the man
- PDF page 39: 39 / "I would not like it at all; though, as I said before, I am not particular."
- PDF page 40: 40 / narrated all I knew, and closed by suggesting the idea of letting him remain in as indulgent
- PDF page 41: 41 / pityingly on my shoulder, sighed, "he died of consumption at Sing-Sing. So you weren't
- PDF page 42: 42 / died unhoping; good tidings for those who died stifled by unrelieved calamities. On errands of life,
- PDF page 43: 43 / “The Yellow Wallpaper” (1892), by Charlotte Perkins Gilman
- PDF page 44: 44 / him, at least, and that makes me very tired.
- PDF page 45: 45 / It is an airy and comfortable room as any one need wish, and, of course, I would not be so silly as to
- PDF page 46: 46 / Of course I didn't do a thing. Jennie sees to everything now.
- PDF page 47: 47 / any silly fancies run away with me.
- PDF page 48: 48 / somersault and there you are. It slaps you in the face, knocks you down, and tramples upon you. It is like
- PDF page 49: 49 / It is the strangest yellow, that wall-paper! It makes me think of all the yellow things I ever saw--not
- PDF page 50: 50 / ----------
- PDF page 51: 51 / Then I peeled off all the paper I could reach standing on the floor. It sticks horribly and the pattern just
- PDF page 52: 52 / “The Gift of the Magi” (1905), O. Henry (William Sydney Porter)
- PDF page 53: 53 / On went her old brown jacket; on went her old brown hat. With a whirl of skirts and with the brilliant
- PDF page 54: 54 / "Cut it off and sold it," said Della. "Don't you like me just as well, anyhow? I'm me without my hair,
- PDF page 55: 55 / “The Open Window” (1914), Saki (H.H. Munro)
- PDF page 56: 56 / "I hope Vera has been amusing you?" she said.
- PDF page 57: 57 / “Araby” (1914), James JOYCE
- PDF page 58: 58 / One evening I went into the back drawing-room in which the priest had died. It was a dark rainy evening
- PDF page 59: 59 / 'I'm afraid you may put off your bazaar for this night of Our Lord.'
- PDF page 60: 60 / I lingered before her stall, though I knew my stay was useless, to make my interest in her wares seem the
- PDF page 61: 61 / “The Garden Party” (1922) by Katherine Mansfield
- PDF page 62: 62 / Laura's upbringing made her wonder for a moment whether it was quite respectful of a workman to
- PDF page 63: 63 / The front door bell pealed, and there sounded the rustle of Sadie's print skirt on the stairs. A man's
- PDF page 64: 64 / "Now, Laura," said her mother quickly, "come with me into the smoking-room. I've got the names
- PDF page 65: 65 / "Know those little cottages just below here, miss?" Know them? Of course, she knew them. "Well,
- PDF page 66: 66 / "But, my dear child, use your common sense. It's only by accident we've heard of it. If some one had
- PDF page 67: 67 / "All over, all over, thank heaven," said Mrs. Sheridan. "Round up the others, Laura. Let's go and have
- PDF page 68: 68 / stopped as Laura drew near. The group parted. It was as though she was expected, as though they had
- PDF page 69: 69 / "No," sobbed Laura. "It was simply marvellous. But Laurie--" She stopped, she looked at her brother.
- PDF page 70: 70 / “A Clean, Well-Lighted Place” (1933) by Ernest Hemingway
- PDF page 71: 71 / "Fear for his soul."
- PDF page 72: 72 / was the light of course but it is necessary that the place be clean and pleasant. You do not want music.
- PDF page 73: 73 / “The Lottery” (1948) by Shirley Jackson (1916-1965)
- PDF page 74: 74 / Summers spoke frequently to the villagers about making a new box, but no one liked to upset even as
- PDF page 75: 75 / Mr. Summers consulted his list. 'Clyde Dunbar.' he said. 'That's right. He's broke his leg, hasn't he?
- PDF page 76: 76 / Old Man Warner snorted. 'Pack of crazy fools,' he said. 'Listening to the young folks, nothing's good
- PDF page 77: 77 / 'All right, then,' Mr. Summers said. 'Harry, you got their tickets back?'
- PDF page 78: 78 / Tessie Hutchinson was in the center of a cleared space by now, and she held her hands out desperately
- PDF page 79: 79 / “A Good Man Is Hard to Find” (1953), by Flannery O’CONNOR (1925-1964)
- PDF page 80: 80 / The old lady settled herself comfortably, removing her white cotton gloves and putting them up with her
- PDF page 81: 81 / she had been courted by a Mr. Edgar Atkins Teagarden from Jasper, Georgia. She said he was a very
- PDF page 82: 82 / His wife brought the orders, carrying the five plates all at once without a tray, two in each hand and one
- PDF page 83: 83 / "A dirt road," Bailey groaned.
- PDF page 84: 84 / continued to come on slowly, disappeared around a bend and appeared again, moving even slower, on top
- PDF page 85: 85 / "Yes mam," he said, "finest people in the world." When he smiled he showed a row of strong white teeth.
- PDF page 86: 86 / The Misfit kept scratching in the ground with the butt of his gun as if he were thinking about it. "Yes'm,
- PDF page 87: 87 / "Yes, thank you," the mother said faintly. Her left arm dangled helplessly and she was holding the baby,
- PDF page 88: 88 / "She was a talker, wasn't she?" Bobby Lee said, sliding down the ditch with a yodel.
- PDF page 89: 89 / “The A & P” (1961), by John Updike
- PDF page 90: 90 / She had sort of oaky hair that the sun and salt had bleached, done up in a bun that was unravelling, and a
- PDF page 91: 91 / Now here comes the sad part of the story, at least my family says it's sad but I don't think it's sad myself.
- PDF page 92: 92 / All this while, the customers had been showing up with their carts but, you know, sheep, seeing a scene,
- PDF page 93: 93 / I look around for my girls, but they're gone, of course. There wasn't anybody but some young married
- PDF page 94: 94 / “I Used to Live Here Once” in Sleep It Off Lady (1976), by Jean Rhys
- PDF page 95: 95 / “The Werewolf,” in The Bloody Chamber (1978), Angela CARTER (1940-1992)
- PDF page 96: 96 / her apron, wrapped the wolf’s paw in the cloth in which her mother had packed the oatcakes
- PDF page 97: 97 / “I Could See the Smallest Things” (1981), by Raymond Carver
- PDF page 98: 98 / I said, ‘Sam you scared me.’ I said, ‘What are you doing up?’ ‘Did you hear something?’ I said. ‘I
- PDF page 99: 99 / I closed my arms under my breasts and bent over to where he was shining his light. The thing
- PDF page 100: 100 / “A Family Supper” (1982), by Kazuo Ishiguro
- PDF page 101: 101 / 'I am - in retirement. I'm too old to involve myself in new ventures now. Business these days has
- PDF page 102: 102 / We were following a narrow path that wound through the shrubs and finished by the old well. As
- PDF page 103: 103 / We both looked around at the trees and shrubs. The light in the garden had grown very dim.
- PDF page 104: 104 / My father gave a laugh. He came up to the table and picked up the model. 'Since the firm folded,' he
- PDF page 105: 105 / 'Your mother.' His voice had become very hard. 'Can't you recognize your own mother?'
- PDF page 106: 106 / I got to my feet and followed him into the tea-room. The large sliding windows had been left open,
- PDF page 107: 107 / Excerpts from
- PDF page 108: 108 / Pride and Prejudice (1813), Jane AUSTEN
- PDF page 109: 109 / The Scarlet Letter (1850), Nathaniel HAWTHORNE
- PDF page 110: 110 / To the Lighthouse (1927), Virginia WOOLF
- PDF page 111: 111 / 35
- PDF page 112: 112 / Lolita (1955), Vladimir NABOKOV
- PDF page 113: 113 / The Handmaid’s Tale (1985), Margaret ATWOOD
- PDF page 114: 114 / Edition de référence des pages reproduites :

## PDF page 1

1 
A2FLT12 - Literature 2: Writing Fiction (Short Stories and Novels) 
UE Fondamentale / Responsable : Dennis TREDY (dennis.tredy@sorbonne-nouvelle.fr) 
Langue principale du cours : anglais 
                                            Class taught in English 
Type : CM/TD 
ECTS : 3 Nombre d’heures hebdomadaires: 2 heures (1h CM & 1h TD) 
Course description: 
This introductory course to fiction in English is designed to help students adopt a more analytical approach 
to the study of short stories and novels. Students will learn to apply literary notions specific to works of 
fiction, to place a work within its historical and literary context, and to perfect their skills in written and 
oral textual commentaries. The lecture class will focus on providing students with the necessary tools with 
which to analyze and discuss specific works in their tutorials. A collection of twelve short stories and 
some excerpts from novels will be provided in the A2FLI11 student brochure, and students will need to 
read one full novel for the course: Robert Louis Stevenson’s The Strange Case of Dr Jekyll and Mr Hyde. 
Descriptif : 
Ce cours propose une introduction à la fiction anglophone afin d’acquérir les compétences nécessaires à une 
lecture plus avisée et approfondie des nouvelles et des romans écrits en anglais (compréhension, expression 
orale et écrite, initiation à la méthodologie du commentaire spécifique à la fiction, connaissances des grands 
mouvements littéraires de la fiction anglaise et américaine). Le cours magistral donnera aux étudiants les 
outils nécessaires afin de mieux analyser les textes en TD. Les cours traitent plusieurs notions littéraires 
nécessaires à une bonne analyse de texte, ainsi qu’une lecture approfondie d’une sélection de nouvelles, 
d’extraits de romans et d’un roman dans son intégralité, The Strange Case of Dr Jekyll and Mr Hyde de 
Robert Louis Stevenson. 
Œuvres au programme / Set Reading: 
-indispensable (à avoir pour la rentrée) 
1. Une brochure de textes (quelques extraits de romans et une dizaine de nouvelles) à retirer au 
service de la reprographie. 
2. Le roman: The Strange Case of Dr Jekyll and Mr Hyde and Other Tales of Terror by Robert 
Louis Stevenson, Penguins Classics Edition. 
-ouvrages utiles 
Françoise Grellet, A Handbook of Literary Terms : Introduction au vocabulaire littéraire 
anglais, Hachette, 2013, ou Literature in English : Anthologie des littératures du monde 
anglophone, Hachette, 2015. 
NB : Votre enseignant pourra vous donner une bibliographie plus détaillée en cours ou sur 
iCampus. 
Type d’évaluation : 
Les étudiants seront notés par un examen en ligne (cours magistral), un examen écrit (en TD), 
des devoirs écrits et/ou oraux (en TD). NB : Le partiel écrit pour cette UE aura lieu pendant la 
session des épreuves longues, après la fin des cours. 
Objectifs / Compétences : 
• Procéder à un travail de compréhension et d’analyse de textes proposés dans le recueil de nouvelles et 
dans la brochure d’extraits de romans : étude du lexique, du style, de la narration, de la présentation des 
personnages, etc. 
• Savoir étudier un roman de manière approfondie et cerner les techniques narratives de l’auteur 
• Replacer des auteurs et leurs œuvres dans leur contexte historique et culturel 
• Rendre compte de la lecture grâce à un commentaire de texte en anglais 
• Mettre en relation les textes entre eux, démontrer leur appartenance à un certain courant littéraire, et 
étudier les jeux d’intertextualité. 


## PDF page 2

2 
 
 


## PDF page 3

3 
 
 
• TABLE DES MATIÈRES 
 
Literary Terms and Notions……………………………………………………………………. 4 
(Charts and graphics by Caroline Dauphin) 
 
I. Short Stories: 
 
Some Notes on the Short Story………………………………………………………………..... 16
 
 
 
Samples: 
Edgar Allan POE, “The Tell-Tale Heart” (1843)………………….……..…………………..… 18 
Herman MELVILLE, “Bartleby, the Scrivener” (1853)……………………………………….. 21 
Charlotte Perkins GILMAN, “The Yellow Wallpaper” (1892)………………………………...  43 
O. HENRY, “The Gift of the Magi” (1905)……………………………………………………. 52  
SAKI (H.H. Munro), “The Open Window” (1914)…………………………………………… 55 
James JOYCE, “Araby” (1914)…………………..……………………………………………. 57 
Katherine MANSFIELD, “The Garden Party” (1922)….………………………………….......  61 
Ernest HEMINGWAY, “A Clean, Well-Lighted Place” (1933)………………….……………  70 
Shirley JACKSON, “The Lottery” (1948)……...…………………………………...…………. 73 
Flannery O’CONNOR, “A Good Man Is Hard to Find” (1953)……………………..………… 79 
John UPDIKE, “The A & P” (1961)…………………………………………………..………..  89                    
Jean RHYS, “I Used to Live Here Once” in Sleep It Off Lady (1976)………………..………. 94 
Angela CARTER, “The Werewolf” (1978)……………………………………………...…….. 95 
Raymond CARVER, “I Could See the Smallest Things” (1981)…………………………...…. 97 
Kazuo ISHIGURO, “A Family Supper” (1982)……….……………………………………..... 100 
 
I. Excerpts from novels: 
 
Jane AUSTEN, from Pride and Prejudice (1813)…………………..…………………………. 108 
Nathaniel HAWTHORNE, from The Scarlet Letter (1850)…………..……………………….. 109 
Virginia WOOLF, from To the Lighthouse (1927)……………………..……………………… 110 
Vladimir NABOKOV, from Lolita (1955)………………………………..…………………… 112 
Margaret ATWOOD, from The Handmaid’s Tale (1985)…………………..……….………… 113 
  
Bibliographical Sources for the Texts……………………………………..…………..……….. 114 


## PDF page 4

4 
 
 
Some Literary Terms and Notions to Help with Textual Commentaries 
 
mimesis vs diegesis  (showing vs. telling) 
(cf. Aristotle’s Poetics, Plato’s The Republic, Book III; Genette, Rimmon-Kenan, et al.) 
 
A. Plot 
 
 
 
 
Plot vs. Story:  
-“‘The king died and then the queen died’ is a story. ‘The king died and then the queen died of grief’ 
is a plot.” (E.M. Forster, 1927) 
 
-a causal chain : “For want of a nail, the shoe was lost; for want of a shoe, the horse was lost; for 
want of a horse, a knight was lost; for want of a knight, the battle was lost; for want of a battle, the 
kingdom was lost—all for the want of a nail.”   (cf. “a chain of events”) 
 
-a plot-line, a story-line 
 
Key moments in the plot: 
In Poetics (4th century BC), Aristotle had already discussed the basic elements of a plot, explaining 
that there were three key parts to every story-line (beginning, middle & end), but that between them 
there were important stages of development.  His ‘dramatic arc’ would look like this: 
 
NB: This arc accurately corresponds to the traditional 5-act structure of classical Greek drama and 
notably Elizabethan drama, in which the main plot was divided into five acts. 
 
Example:   
Basic Plot of Shakespeare‘s Julius Caesar (1599):  
Act I – the murder plot is hatched and Caesar‘s friend Brutus accepts to be a part of it (exposition & 
complication) 
Act II – Brutus becomes more involved in the plot and warning signs to Caesar go unheeded (rising action) 
Act III –the murder of Caesar; Brutus‘s speech to justify it; Antony‘s speech that turns the people against 
Brutus and the other conspirators (climax and turning point) 
Act IV – Brutus and the conspirators are on the run; they begin turning against each other (falling action)  
Act V – Battles between Antony‘s and Brutus‘s forces.  The ‘Honorable‘ Brutus, the last of the conspirators, 
falls on his sword and kills himself  (denouement/catastrophe) 
 
NB: It is by breaking down the plot like this that we clearly see that the main character of the play is not in 
fact Julius Caesar, but Brutus.    
 


## PDF page 5

5 
 
 
Key Moments in the Plot: 
 
INCIPIT : 
 
 
 
TURNING POINTS : 
 
ENDINGS : 
-exposition 
 
 
 
-crisis  
 
 
 
-denouement 
   -background  
 
 
-anagnorisis (revelation) 
 
-catastrophe 
   -orientation   
  
 
-peripeteia / reversal of fortune 
-deus ex machina 
   -setting, mood, tone  
 
-a twist / -coup de théâtre  
 
-open-endedness 
   (creating an initial ‘tableau’) 
-crux (pl. cruces) 
 
 
   vs. closure 
   -adding a preface or a prologue 
-climax / anticlimax  
 
-to tie up loose ends 
-in medias res  
 
 
-epiphany / catharsis  
 
-a circular plot 
 
Multiple Plots: 
 
-Combining the main plot (main story-line) and one or more subplots  
 
 
 
-Interweaving several main plots or story-lines 
 
-Metadiegesis / mise-en-abime (a tale within a tale, a play within a play, etc.) 
A frame narrative and its embedded narrative(s) 
 
Pattern of Plot: 
linear / non-linear (cf. anachronies – flashbacks, flashforwards) 
episodic (e.g. Candide, Don Quixote)  
a tightly knit, a well-wrought plot vs. a loose plot 
 
 
B. Time Elements 
(most terms from Gérard Genette, Figures III) 
 
Genette’s notion of story-time vs. text-time 
 
ORDER : 
-linear vs. non-linear time 
-digressions from the plot  
[e.g., Salinger’s The Catcher in the Rye (1951), Laurence Stern’s Tristram Shandy (1760)] 
-anachronies : 
flashback (analepsis) & flashforward (prolepsis)   
(compare to echo, foreshadowing & amorce or snares) 
 
PACE / DURATION :   acceleration vs. deceleration 
scene (TT=ST) 
summary (TT<ST) 
(descriptive) pause  (TT>ST)        ellipsis (TT=0) 
         
 
FREQUENCY : 
singulative 
iterative (told once, happened x times)     repetitive (told x times, happened once) 
 
C. Narration and Point of View: 
(most terms from Genette’s Figures III) 
 
Three main literary constructs: 
The narrator (who speaks?) 
The focalizer (who sees or feels?) 
The narratee (who is spoken to?) 


## PDF page 6

6 
 
 


## PDF page 7

7 
 
 
1. Narrator  (more than simple 1st person or 3rd person split) 
external (extradiegetic) narrator (outside the story) 
internal (intradiegetic)  (a character telling the tale) 
subordinate (hypodiegetic) (when characters tell a quick story to the protagonist, for example) 
 
an autodiegetic narrator (the main character – e.g., Jane Eyre in Brontë’s Jane Eyre) 
homodiegetic (part of the main group of characters – e.g., Nick in Fitzgerald’s The Great Gatsby) 
heterodiegetic (a fictional character but not part of main story –e.g., the unnamed narrator in  
    George Eliot’s Middlemarch)  
 
covert vs. overt narration (i.e., Is the narrator identified?) 
constant vs. shifting narration (i.e., Does the narrator ever change?) 
actional or explicative narration (i.e., Are events narrated, or is the focus more on  
     feelings/motivations/thoughts?) 
unintrusive or intrusive narration (i.e., Do we nearly forget we have a narrator or does the  
     narrator ‘interrupt’ the story?) 
reliable or unreliable/fallible (i.e., Can we trust what the narrator tells us?  e.g., Benjy in The  
     Sound & the Fury, Humbert Humbert in Lolita, Poe narrators) 
 
2. The Focalizer (term from Genette):  
also called ‘point of view character’ / reflector / mirror / centre of consciousness (Henry James) 
- focalization or point of view / perspective / angle of vision 
note :  focalization by someone—emphasis on who is perceiving 
 
focalization on someone—emphasis on who/what is being perceived 
 
3 main cases: 
A. EXTERNAL FOCALIZERS  (usually the narrator) 
1.  the detached observer / witness (restricted knowledge) 
2.  ‘zero-focalization’ / omniscience (unrestricted knowledge) 
B. INTERNAL FOCALIZERS (character-focalizers) 
 
Constant or shifting point of view? 
Covert or overt focalizers? 
Reliable or unreliable/fallible focalizers? 
 
3. The Narratee 
Who is being spoken to? 
Is it an extradiegetic narratee (outside the story) or an intradiegetic narratee (inside the story) 
Is it constant or shifting? 
Is it overt or covert? 
 
D. Characterization & Speech Representation 
 
Basic Character Types 
 
1. Types of Characters : 
a. Basic Types 
-The protagonist(s) / main character(s)  
(the eponymous hero/heroine, an anti-hero, a mouthpiece for the author’s views, etc.) 
-The antagonist(s)       
(the villain, a foil, an adversary or a competitor, etc.) 
-secondary characters  
(the love interest, the side-kick, the messenger, the confidant, etc.) 


## PDF page 8

8 
 
 


## PDF page 9

9 
 
 
b. Round Characters vs. Flat Characters  
(E. M. Forster-- Aspects of the Novel, 1927; read p. 94, 97) 
     Round Characters (well-developed and complex, surprising) 
     Flat Characters (simple and undeveloped or unchanging) 
 
-common types of flat characters: 
    -caricatures (the flattest; only show one apparent trait) 
    -stock characters [e.g., the Harlequin (buffoon, intriguing servant) and the Pantaloon (rich 
elderly merchant) in Italian drama, comedia dell’arte; a stock villain (like the mustache-twirling 
villain foreclosing on the heroine’s house in early silent films); the saucy maid in théâtre de 
boulevard; the hard-boiled detective (Sam Spade, Mike Hammer, etc.) in the early 20th century 
detective novel, etc.) 
    -archetypes (recurring, symbolic character types (e.g., Satan as archetype of Evil) 
    -stereotypes (conform to oversimplified mental images of what a certain person would be like) 
 
2. Character Development 
 
-Is a character dynamic or static? Is there steady development? 
-Are their traits consistent or inconsistent? 
-Are they well-rendered? Ill-rendered? Overdrawn? 
-Are they credible/believable/realistic/verisimilar?  Is there verisimilitude? 
 
3. Methods of Characterization 
 
-Is it more diegesis or mimesis? 
 
-direct characterization 
(description and exposition by the narrative voice, or perhaps by other characters) 
 
-indirect characterization 
(through what the character does, says, thinks) 
 
-symbolic characterization 
     -Symbolic names (onomastics): e.g., Sir Toby Belch, the drunkard in Shakespeare’s Twelfth 
Night, or Mr. Thwackum, the brutal tutor in Fielding’s Tom Jones, or Faith in Hawthorne’s 
“Young Goodman Brown”) 
     -Symbolic contrast or parallels with the landscape or setting (e.g.,the cold, brutal characters in 
a cold, brutal landscape in Wharton’s Ethan Frome) 
     -Symbolic contrast or parallels to other characters (e.g., George and Lenny in Steinbeck’s Of 
Mice and Men) 
 
Common form of indirect characterization: Speech Mannerisms 
 
-a character’s particular ‘idiolect’ (the specific manner of speech designed for a character) 
-this can include… 
   a ‘dialect’ (for a certain region or community) or an accent 
   a ‘sociolect’ (showing a certain social class) 
   (e.g., use of street slang, colloquialisms, substandard or very high-brow English, etc.) 
   jargon (for a certain profession) 
 
-special cases: 
    -the use of malapropisms to show a character’s lack of education  
      (e.g., Mrs. Malaprop in Sheridan’s The Rivals) 
    -eye-grammar (when words are purposely misspelled in order to recreate a character’s idiolect) 
    -SKAZ (when the narration by the character sounds more like a person talking—informal,  
     mistakes, colloquialisms—than someone writing. e.g., Huck in Twain’s Huck Finn) 


## PDF page 10

10 
 
 


## PDF page 11

11 
 
 
E. Speech Representation in the Narration: 
As with characterization, the spectrum of speech presentation spans from diegetic to mimetic 
forms: 
 
Telling  -----------------------------------------------------------------------------------------→ Showing 
 Narrative Summary / Indirect Speech / Free Indirect Speech/ Direct Speech / Free Direct Speech 
 
1. Summary of the words by the narrator: 
 
e.g., After the supper Mr. Maudsley made a speech. […] With what seemed to me consummate skill he  
 
contrived to bring in almost every player by name and find something noteworthy in his performance.  
      (L.P. Hartley, The Go-Between) 
 
2. Indirect Speech: (gets closer to “actual” words uttered by the character; uses verbs of 
saying/thinking plus a tag; spatial or time references change as well as verbs according to the 
formal sequence of tenses) 
 
e.g., Bill said that he was a quiet family man and would get him a flop and go to bed. (John Dos Passos, USA) 
 
3. Semi-Indirect Speech: (although it remains indirect speech, quotation marks are used) 
 
e.g., As soon as he entered the Room, he told Joseph, “he was come to pray by him, and to prepare him for 
another World: In the first place, therefore, he hope he had repented all of his Sins?” (Henry Fielding, Joseph 
Andrews) 
 
4. Free Indirect Speech / Free Indirect Thought: (allows us to follow character’s words or thoughts 
without the narrator’s interventions; often ambiguous blend of narrator’s voice and character’s 
words/thoughts) 
 
e.g., Soon, however, she began to reason with herself, and try to be feeling less.  Eight years, almost eight years 
had passed, since all had been given up.  How absurd to be resuming the agitation which such an interval had 
banished into distance and indistictness!  What might not eight years do?  Events of every description, changes, 
alienations, removals—all, all must be comprised in it; and the oblivion of the past—how natural, how certain too!  It 
included nearly a third part of her life.  Alas! With all her reasonings, she found, that to retentive feelings eight years 
may be little more than nothing. (Jane Austen, Persuasion) 
 
5. Direct Speech (straightforward reporting of lines, as if we were witnessing the scene) 
   e.g., “Who’s that?” I said, pretending I didn’t know. 
           “It’s the Dragon Lady,” Kitty said.  “She’s coming to get you.”   (Paul Auster, Moon Palace) 
 
6. Free Direct Speech (often used in first-person interior monologue; the character-narrator seems 
to be talking directly to you) 
 e.g., She looked like she might have a pretty damn good idea what a bastard she was the mother of.  But you can’t 
always tell—with somebody’s mother, I mean. Mothers are all slightly insane. (J.D. Salinger, The Catcher in the Rye) 
 
Three common techniques used in literature to present a character’s thoughts more vividly: 
1. Dramatic Monologue   (the speaker addresses someone whose responses are not given) 
   (e.g. Robert Browning, “Fra Lippo Lippi”, Holden in Salinger’s Catcher in the Rye) 
 
2. Interior Monologue / Narrated Monologue: (character is ‘thinking aloud’, often through Free 
Indirect Speech)    (e.g., long passages from Henry James’s The Portrait of a Lady: Ah! She had been immensely 
under the charm! It had not passed away; it was there still: she still knew perfectly what it was that made Osmond 
delightful when he chose to be.) 
    
3. Stream of Consciousness (cf. William James, Principles of Psychology, 1890)  
(an attempt to render a flow of thoughts—which aren’t always verbalized or coherent or 
developed or fully conscious.  It has more of a rambling and disjointed structure than Interior 
Monologue and has freer associations). 
(e.g., James Joyce, Ulysses: no that’s no way for him has he no manners nor no refinement nor no nothing in his 
nature slapping us behind like that on my bottom because I didn’t call him Hugh the ignoramus that doesn’t know 
poetry from cabbage thats what you get for not keeping them in their proper place… 
 
NB: This example is ‘direct’ stream of consciousness, in which even basic rules of sentence structure are 
disregarded.  With the ‘indirect’ form, we are conscious of a narrator carefully selecting information and 
controlling the narrative to focus on thoughts and impressions (e.g., Virginia Woolf, Mrs. Dalloway)  


## PDF page 12

12 
 
 


## PDF page 13

13 
 
 
F. Tone and Style 
 
1. Tone:  
The tone of a text may be, for example, humorous or witty, satirical (using humor to criticize and 
improve moral and social behavior); ironic / ironical (using words that express the opposite of 
what is meant);  parodic (parody) (an imitation of someone‘s work or style for satirical or 
humorous intention);  bathetic (bathos): the failure to reach a sublime or elevated tone, which 
results in the ridiculous), pathetic (pathos: extreme emotion evoking pity or sadness), etc. 
 
Related terms: 
 
humour vs. wit 
verbal irony (sarcasm, antiphrasis, accismus, apophasis, etc.) vs. 
situational irony (dramatic irony, tragic irony, comic irony, etc.) 
hyperbole (overstatement) vs. meiosis (understatement) 
euphemism (replacing possibly offensive words), litotes (negating the opposite) 
 
satire (imitation & criticism) 
parody (imitation & mockery) 
pastiche (imitation of the style, mixing elements of other works) 
 
low burlesque (treating a serious subject very lightly, for comic effect) 
high burlesque (treating a low or light subject far too seriously, for comic effect) 
travesty (a false, absurd or distorted representation of something) 
 
2. Style:  
The style is the particular manner of writing of a work or of a writer.  Style may be ornate and 
mannered: it may be highbrow (highly intellectual) or precious (refined, delicate, affected), 
bombastic (grandiloquent, inflated and verbose, which makes the speaker sound insincere and 
pretentious), archaic (using obsolete words or syntax, often to convey a sense of the past), 
hackneyed (using phrases used so often that they have become trite, dull, and stereotyped), 
lowbrow, informal or casual, etc.   
 
3. Varieties of language: Language can vary according to the context it is used in. Variations in 
register are often associated with different social situations or social classes (cf. sociolects). 
Register ranges from dignified, formal, to colloquial or informal, to slang. Dialects can be used or 
represented (See definitions of ‘idiolect‘ and ‘sociolect‘ above). 
 
4. Imagery and figurative language  
Imagery includes:    
1. literal imagery: the people, the setting, the action; all the objects and pictures described or 
alluded to in a text 
2. figurative imagery: images which may not be part of the fictional world, but are brought in by 
the narrator to metaphorically compare objects or qualities in that world, or to express ideas about 
that world.  
e.g., similes (comparisons), metaphors, analogies, metonymy, synecdoche, etc. 
 
When a literal image, by association, begins to take on meaning beyond itself, it becomes a 
symbol.   
 


## PDF page 14

14 
 
 
 
 
 
                                  RHETORICAL EFFECTS / FIGURES OF SPEECH:                      C. Dauphin 
 
1/ PATTERNS OF REPETITION 
Anaphora 
X ……………………….... ; X ……………………….... 
“It was a town of red brick… It was a town of unnatural red and black…”  
Epiphora 
……………………….... X ; ……………………….... X 
 “The Choakumchild School was all fact, and the school of design was all fact” 
Epizeuxis  
X, X, X 
“Fact, fact, fact, everywhere in the immaterial” 
Epanalepsis 
X ……………………….... X 
“Fact was everything, and the town was all about fact” 
Chiasmus 
 
XY – YX 
“The jail might have been the infirmary, the infirmary might have been the jail” 
2/ SOUND EFFECTS 
Alliteration 
 
The consonant is repeated. 
 “a state of melancholy madness” 
Assonance  
 
The same vowel sounds are used with different consonants. 
“Coketown was all coal and moans.” 
Internal rhyme  
The same word-endings are used. 
“Eating, drinking, working, sleeping was all they knew about life” 
3/ IMAGERY  
Simile 
A directly expressed comparison between two objects. 
“The piston worked monotonously up and down, like the head of an elephant” 
Metaphor 
An implied analogy between two objects or ideas. 
“Interminable serpents of smoke” 
Personification 
Endowing an object with human characteristics. 
“Night was falling; Coketown was gently dozing off...” 
Hypotyposis 
A vivid, picturesque, colourful description of scene and events. 
 “It had a black canal in it, and a river that ran purple with ill-smelling dye” 
4/ LISTING UP THINGS 
Enumeration  
Listing up words. 
“I saw three skulls, five hands, and the bones of three or four legs and feet” 
Gradation 
Listing up words with the idea of an increasing intensity. 
“Misery, degradation, death and everything that God or Satan could inflict” 
Polysyndeton 
Addition of conjunctions. 
 “Misery, and degradation, and death would not have parted us” 
Asyndeton 
Omission of conjunctions. 
“Misery, degradation, death would not have parted us” 
5/ FUNNY STUFF 
Hyperbole 
A deliberate exaggeration. 
“My blood ran chill and my heart sank at the very horror of the spectacle” 
Polyptoton 
A word is repeated in different forms, tenses, genders, numbers… 
“You broke it, and in breaking it, you have broken my heart” 
Hypallage  
Attributing to someone or something characteristics belonging to a related object 
or person. 
“A pious house”, “a solitary night”, “a painful field” 
 


## PDF page 15

15 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
The Short Story 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 


## PDF page 16

16 
 
 
Some Notes on the Short Story 
 
Definition: a ‘short’ narrative format in prose 
  
But how short is ‘short’?   Lengths can vary… 
anecdotes, vignettes and ‘flash fiction’ / the short story / the novella / the novel 
  
Some specific features (compared to novels): 
-It is usually more pointed and direct 
-It is usually more end-oriented, has a ‘point’ or comes to a denouement 
-It has roots in oral storytelling and anecdote sharing 
   (e.g., “You won’t believe what happened to me the other day…”) 
-It usually has a limited number of characters, settings and incidents 
-It can have a complete dramatic arc (see p. 14) in spite of its size, but it can also be truncated or 
incomplete, or start in medias res, etc. The Modernists in particular experimented with variations 
on the format. 
  
A Brief History of the Short Story: 
  
-It originally comes from a long tradition of oral storytelling and fables. 
  
-14th century: “collected” and related tales (such as Chaucer’s The Canterbury Tales), which 
were often read aloud. 
  
-17th and 18th century: biblical parables and children’s fairy tales (e.g. Charles Perrault in the 17th 
century, the Brothers Grimm and Hans Christian Andersen in the 19th century, etc.) 
  
-Early 19th century:  
Even if novel was dominant, many English authors wrote short stories  
(e.g., Walter Scott, Charles Dickens) 
  
However, there was a more prominant rise of the short story in American literature: 
Washington Irving (“Rip Van Winkle”, “The Legend o Sleepy Hollow”) 
Nathaniel Hawthorne (Twice-Told Tales, “Young Goodman Brown”, etc.) 
And especially Edgar Allan Poe…  
 
        
 
          
                     
 
 
 
 
 
 
 
      Washington Irving              Nathaniel Hawthorne               Edgar Allan Poe 
 


## PDF page 17

17 
 
 
Edgar Allan Poe 
-Though Poe wrote poetry, he is most remembered for his many fantastic ‘tales’ and for 
popularizing the short story. 
-His main sub-genre was horror/fantastic (eg, “The Tell-Tale Heart”, “The Black Cat”, “Ligeia”) 
-They featured Poe’s unreliable “fancy-me-mad” narrator. The reader doesn’t know if the 
supernatural events are really occurring (cf. ‘the Marvellous’) or if they can be explained by the 
narrator’s hallucinations, madness or opium use (cf. ‘the Uncanny’). This hesitation between two 
readings is the very definition of ‘the Fantastic’ (according to Tzvetan Todorov). 
-In addition, Poe was also a pioneer in early detective fiction, which he called ‘tales of 
ratiocination’ (e.g., “Murders in the Rue Morgue”), but he also dabbled in early science fiction 
(e.g., “The Balloon Hoax”). 
-In his essay A Philosophy of Composition, he explained that to “hold’ the readers, they must be 
able to read the work in one sitting. 
-Poe wrote his shocking endings first, and then sought the best way to build tension ‘by degrees’ 
to that ending.  
-Also note that Poe was a journalist by profession, and thus had a knack for the short form.  
 
-Late 19th Century: 
-The short story grew with the rise of magazines and newspapers, which often needed 3000- to 
5000-word stories rather than just ‘instalments’ of novels. 
-Many novelists of the period would write a great number of short stories as well. For example: 
 
Britain: Thomas Hardy, Rudyard Kipling, Sir Arthur Conan Doyle, H.G. Wells, and others. 
France: Guy de Maupassant, among others; Russia: Ivan Turgenev, Fyodor Dostoyevski 
U.S.:  Mark Twain, Henry James (125 short stories as well as 22 novels) 
 
Henry James used Maupassant as his model for what he called “the belle and blest nouvelle”, 
“the small, perfect frame” that was the short story. In his notebooks, James repeatedly claims he 
wanted to do in English what Maupassant was doing so remarkably well in French. 
 
-Early 20th century: 
-The Modernists experimented with the short story as much as with the novel. Take for example 
the short works of Virginia Woolf, or James Joyce’s 1916 collection of short stories, Dubliners. 
Among American modernists working on the short story, there was F. Scott Fitzgerald, Ernest 
Hemingway, and William Faulkner (who wrote over 100 short stories). 
-The form was becoming so popular that there were many popular writers who focused 
exckusively or nearly exclusively on writing short stories, such as William Somerset Maugham 
and Saki (H.H. Munro) in Britain, and O. Henry (William Sydney Porter) in the United States. 
Note that the last two authors mentioned (Saki and O. Henry) were perhaps far less ‘literary’than 
the others, but they were widely read and perfected the use of the surprise or ironic ending in 
such short works of fiction. Also note that in the U.S. today, the national award given every year 
for the best short story is called The O. Henry Prize. 
 
-Mid- to Late 20th century  
Though the form was still common in Great Britain, it was more prominent in the U.S., with   
authors such as Flannery O’Connor (e.g., “A Good Man Is Hard to Find”), J.D. Salinger, John 
Cheever and Shirley Jackson (e.g., “The Lottery”) at mid-century. Later generations included 
John Updike, Joyce Carol Oates, Raymond Carver, Alice Munro (Canadian, Nobel Prize 2013), 
or the extremely popular Stephen King. Today, short stories are truly a part of U.S. literary 
culture and identity, with short story collections that can always be found on current best-seller 
lists.    
 


## PDF page 18

18 
 
 
 “The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849) 
 
Although Poe died poor and relatively unknown, he became very popular in France 
when Baudelaire later translated his works and is one of the most popular American 
authors today. His dark, gothic style pervades both his poetry (e.g., “The Raven”) and 
his many short works of fiction.  He was a pioneer in the early detective story (then 
called ‘tales of ratiocination’), but he is most famous for his tales of psychological 
horror, including “The Tell-Tale Heart” (excerpt below). He was a pioneer in the 
short story, thereby helping to make the short fictional work a key feature of 
American literature. 
  
 
 
TRUE! --nervous --very, very dreadfully nervous I had been and am; but why will you say that I am mad? 
The disease had sharpened my senses --not destroyed --not dulled them. Above all was the sense of hearing 
acute. I heard all things in the heaven and in the earth. I heard many things in hell. How, then, am I mad? 
Hearken! and observe how healthily --how calmly I can tell you the whole story. 
It is impossible to say how first the idea entered my brain; but once conceived, it haunted me day and night. 
Object there was none. Passion there was none. I loved the old man. He had never wronged me. He had 
never given me insult. For his gold I had no desire. I think it was his eye! yes, it was this! He had the eye of 
a vulture --a pale blue eye, with a film over it. Whenever it fell upon me, my blood ran cold; and so by 
degrees --very gradually --I made up my mind to take the life of the old man, and thus rid myself of the eye 
forever. 
Now this is the point. You fancy me mad. Madmen know nothing. But you should have seen me. You 
should have seen how wisely I proceeded --with what caution --with what foresight --with what 
dissimulation I went to work! I was never kinder to the old man than during the whole week before I killed 
him. And every night, about midnight, I turned the latch of his door and opened it --oh so gently! And then, 
when I had made an opening sufficient for my head, I put in a dark lantern, all closed, closed, that no light 
shone out, and then I thrust in my head. Oh, you would have laughed to see how cunningly I thrust it in! I 
moved it slowly --very, very slowly, so that I might not disturb the old man's sleep. It took me an hour to 
place my whole head within the opening so far that I could see him as he lay upon his bed. Ha! Would a 
madman have been so wise as this, And then, when my head was well in the room, I undid the lantern 
cautiously-oh, so cautiously --cautiously (for the hinges creaked) --I undid it just so much that a single thin 
ray fell upon the vulture eye. And this I did for seven long nights --every night just at midnight --but I 
found the eye always closed; and so it was impossible to do the work; for it was not the old man who vexed 
me, but his Evil Eye. And every morning, when the day broke, I went boldly into the chamber, and spoke 
courageously to him, calling him by name in a hearty tone, and inquiring how he has passed the night. So 
you see he would have been a very profound old man, indeed, to suspect that every night, just at twelve, I 
looked in upon him while he slept. 
Upon the eighth night I was more than usually cautious in opening the door. A watch's minute hand moves 
more quickly than did mine. Never before that night had I felt the extent of my own powers --of my 
sagacity. I could scarcely contain my feelings of triumph. To think that there I was, opening the door, little 
by little, and he not even to dream of my secret deeds or thoughts. I fairly chuckled at the idea; and perhaps 
he heard me; for he moved on the bed suddenly, as if startled. Now you may think that I drew back --but 
no. His room was as black as pitch with the thick darkness, (for the shutters were close fastened, through 
fear of robbers,) and so I knew that he could not see the opening of the door, and I kept pushing it on 
steadily, steadily. 
I had my head in, and was about to open the lantern, when my thumb slipped upon the tin fastening, and the 
old man sprang up in bed, crying out --"Who's there?" 
I kept quite still and said nothing. For a whole hour I did not move a muscle, and in the meantime I did not 
hear him lie down. He was still sitting up in the bed listening; --just as I have done, night after night, 
hearkening to the death watches in the wall. 


## PDF page 19

19 
 
 
Presently I heard a slight groan, and I knew it was the groan of mortal terror. It was not a groan of pain or 
of grief --oh, no! --it was the low stifled sound that arises from the bottom of the soul when overcharged 
with awe. I knew the sound well. Many a night, just at midnight, when all the world slept, it has welled up 
from my own bosom, deepening, with its dreadful echo, the terrors that distracted me. I say I knew it well. I 
knew what the old man felt, and pitied him, although I chuckled at heart. I knew that he had been lying 
awake ever since the first slight noise, when he had turned in the bed. His fears had been ever since 
growing upon him. He had been trying to fancy them causeless, but could not. He had been saying to 
himself --"It is nothing but the wind in the chimney --it is only a mouse crossing the floor," or "It is merely 
a cricket which has made a single chirp." Yes, he had been trying to comfort himself with these 
suppositions: but he had found all in vain. All in vain; because Death, in approaching him had stalked with 
his black shadow before him, and enveloped the victim. And it was the mournful influence of the 
unperceived shadow that caused him to feel --although he neither saw nor heard --to feel the presence of my 
head within the room. 
When I had waited a long time, very patiently, without hearing him lie down, I resolved to open a little --a 
very, very little crevice in the lantern. So I opened it --you cannot imagine how stealthily, stealthily --until, 
at length a simple dim ray, like the thread of the spider, shot from out the crevice and fell full upon the 
vulture eye. 
It was open --wide, wide open --and I grew furious as I gazed upon it. I saw it with perfect distinctness --all 
a dull blue, with a hideous veil over it that chilled the very marrow in my bones; but I could see nothing 
else of the old man's face or person: for I had directed the ray as if by instinct, precisely upon the damned 
spot. 
And have I not told you that what you mistake for madness is but over-acuteness of the sense? --now, I say, 
there came to my ears a low, dull, quick sound, such as a watch makes when enveloped in cotton. I knew 
that sound well, too. It was the beating of the old man's heart. It increased my fury, as the beating of a drum 
stimulates the soldier into courage. 
But even yet I refrained and kept still. I scarcely breathed. I held the lantern motionless. I tried how steadily 
I could maintain the ray upon the eve. Meantime the hellish tattoo of the heart increased. It grew quicker 
and quicker, and louder and louder every instant. The old man's terror must have been extreme! It grew 
louder, I say, louder every moment! --do you mark me well I have told you that I am nervous: so I am. And 
now at the dead hour of the night, amid the dreadful silence of that old house, so strange a noise as this 
excited me to uncontrollable terror. Yet, for some minutes longer I refrained and stood still. But the beating 
grew louder, louder! I thought the heart must burst. And now a new anxiety seized me --the sound would be 
heard by a neighbour! The old man's hour had come! With a loud yell, I threw open the lantern and leaped 
into the room. He shrieked once --once only. In an instant I dragged him to the floor, and pulled the heavy 
bed over him. I then smiled gaily, to find the deed so far done. But, for many minutes, the heart beat on 
with a muffled sound. This, however, did not vex me; it would not be heard through the wall. At length it 
ceased. The old man was dead. I removed the bed and examined the corpse. Yes, he was stone, stone dead. 
I placed my hand upon the heart and held it there many minutes. There was no pulsation. He was stone 
dead. His eve would trouble me no more. 
If still you think me mad, you will think so no longer when I describe the wise precautions I took for the 
concealment of the body. The night waned, and I worked hastily, but in silence. First of all I dismembered 
the corpse. I cut off the head and the arms and the legs. 
I then took up three planks from the flooring of the chamber, and deposited all between the scantlings. I 
then replaced the boards so cleverly, so cunningly, that no human eye --not even his --could have detected 
any thing wrong. There was nothing to wash out --no stain of any kind --no blood-spot whatever. I had been 
too wary for that. A tub had caught all --ha! ha! 
When I had made an end of these labors, it was four o'clock --still dark as midnight. As the bell sounded the 
hour, there came a knocking at the street door. I went down to open it with a light heart, --for what had I 
now to fear? There entered three men, who introduced themselves, with perfect suavity, as officers of the 
police. A shriek had been heard by a neighbour during the night; suspicion of foul play had been aroused; 


## PDF page 20

20 
 
 
information had been lodged at the police office, and they (the officers) had been deputed to search the 
premises. 
I smiled, --for what had I to fear? I bade the gentlemen welcome. The shriek, I said, was my own in a 
dream. The old man, I mentioned, was absent in the country. I took my visitors all over the house. I bade 
them search --search well. I led them, at length, to his chamber. I showed them his treasures, secure, 
undisturbed. In the enthusiasm of my confidence, I brought chairs into the room, and desired them here to 
rest from their fatigues, while I myself, in the wild audacity of my perfect triumph, placed my own seat 
upon the very spot beneath which reposed the corpse of the victim. 
The officers were satisfied. My manner had convinced them. I was singularly at ease. They sat, and while I 
answered cheerily, they chatted of familiar things. But, ere long, I felt myself getting pale and wished them 
gone. My head ached, and I fancied a ringing in my ears: but still they sat and still chatted. The ringing 
became more distinct: --It continued and became more distinct: I talked more freely to get rid of the feeling: 
but it continued and gained definiteness --until, at length, I found that the noise was not within my ears. 
No doubt I now grew very pale; --but I talked more fluently, and with a heightened voice. Yet the sound 
increased --and what could I do? It was a low, dull, quick sound --much such a sound as a watch makes 
when enveloped in cotton. I gasped for breath --and yet the officers heard it not. I talked more quickly --
more vehemently; but the noise steadily increased. I arose and argued about trifles, in a high key and with 
violent gesticulations; but the noise steadily increased. Why would they not be gone? I paced the floor to 
and fro with heavy strides, as if excited to fury by the observations of the men --but the noise steadily 
increased. Oh God! what could I do? I foamed --I raved --I swore! I swung the chair upon which I had been 
sitting, and grated it upon the boards, but the noise arose over all and continually increased. It grew louder -
-louder --louder! And still the men chatted pleasantly, and smiled. Was it possible they heard not? Almighty 
God! --no, no! They heard! --they suspected! --they knew! --they were making a mockery of my horror!-
this I thought, and this I think. But anything was better than this agony! Anything was more tolerable than 
this derision! I could bear those hypocritical smiles no longer! I felt that I must scream or die! and now --
again! --hark! louder! louder! louder! louder! 
"Villains!" I shrieked, "dissemble no more! I admit the deed! --tear up the planks! here, here! --It is the 
beating of his hideous heart!" 
 


## PDF page 21

21 
 
 
“Bartleby, the Scrivener” (1853), by Herman Melville  
 
Melville’s early writing career was largely based on his own sea travels on merchant 
and whaling ships as a young adult, resulting in semi-autobiographical works such as 
Typee, Omoo (both 1847) and Redburn: His First Voyage (1849). His incomprababel 
masterpiece Moby Dick (1851) would soon follow, a complex novel relying heavily 
on myth and the symbolism that pervades Captain Ahab’s obsessive quest for 
revenge on the Great Whote Whale. Only two years later, Melville would move away 
from his trademark sea adventures and write one of his finest short stories, “Bartleby, 
the Scrivener”, the story of a Wall Street lawyer who inadvertently hires an office 
clerk who soon becomes recalcitrant to the point of absurdity.  
 
 
I am a rather elderly man. The nature of my avocations for the last thirty years has brought me into 
more than ordinary contact with what would seem an interesting and somewhat singular set of 
men, of whom as yet nothing that I know of has ever been written:—I mean the law-copyists or 
scriveners. I have known very many of them, professionally and privately, and if I pleased, could 
relate divers histories, at which good-natured gentlemen might smile, and sentimental souls might 
weep. But I waive the biographies of all other scriveners for a few passages in the life of Bartleby, 
who was a scrivener of the strangest I ever saw or heard of. While of other law-copyists I might 
write the complete life, of Bartleby nothing of that sort can be done. I believe that no materials 
exist for a full and satisfactory biography of this man. It is an irreparable loss to literature. 
Bartleby was one of those beings of whom nothing is ascertainable, except from the original 
sources, and in his case those are very small. What my own astonished eyes saw of 
Bartleby, that is all I know of him, except, indeed, one vague report which will appear in the 
sequel. 
Ere introducing the scrivener, as he first appeared to me, it is fit I make some mention of myself, 
my employees, my business, my chambers, and general surroundings; because some such 
description is indispensable to an adequate understanding of the chief character about to be 
presented. 
Imprimis: I am a man who, from his youth upwards, has been filled with a profound conviction 
that the easiest way of life is the best. Hence, though I belong to a profession proverbially 
energetic and nervous, even to turbulence, at times, yet nothing of that sort have I ever suffered to 
invade my peace. I am one of those unambitious lawyers who never addresses a jury, or in any 
way draws down public applause; but in the cool tranquility of a snug retreat, do a snug business 
among rich men's bonds and mortgages and title-deeds. All who know me, consider me an 
eminently safe man. The late John Jacob Astor, a personage little given to poetic enthusiasm, had 
no hesitation in pronouncing my first grand point to be prudence; my next, method. I do not speak 
it in vanity, but simply record the fact, that I was not unemployed in my profession by the late 
John Jacob Astor; a name which, I admit, I love to repeat, for it hath a rounded and orbicular 
sound to it, and rings like unto bullion. I will freely add, that I was not insensible to the late John 
Jacob Astor's good opinion. 
Some time prior to the period at which this little history begins, my avocations had been largely 
increased. The good old office, now extinct in the State of New York, of a Master in Chancery, 
had been conferred upon me. It was not a very arduous office, but very pleasantly remunerative. I 
seldom lose my temper; much more seldom indulge in dangerous indignation at wrongs and 
outrages; but I must be permitted to be rash here and declare, that I consider the sudden and 
violent abrogation of the office of Master in Chancery, by the new Constitution, as a—premature 
act; inasmuch as I had counted upon a life-lease of the profits, whereas I only received those of a 
few short years. But this is by the way. 


## PDF page 22

22 
 
 
My chambers were up stairs at No.—Wall-street. At one end they looked upon the white wall of 
the interior of a spacious sky-light shaft, penetrating the building from top to bottom. This view 
might have been considered rather tame than otherwise, deficient in what landscape painters call 
"life." But if so, the view from the other end of my chambers offered, at least, a contrast, if nothing 
more. In that direction my windows commanded an unobstructed view of a lofty brick wall, black 
by age and everlasting shade; which wall required no spy-glass to bring out its lurking beauties, 
but for the benefit of all near-sighted spectators, was pushed up to within ten feet of my window 
panes. Owing to the great height of the surrounding buildings, and my chambers being on the 
second floor, the interval between this wall and mine not a little resembled a huge square cistern. 
At the period just preceding the advent of Bartleby, I had two persons as copyists in my 
employment, and a promising lad as an office-boy. First, Turkey; second, Nippers; third, Ginger 
Nut. These may seem names, the like of which are not usually found in the Directory. In truth they 
were nicknames, mutually conferred upon each other by my three clerks, and were deemed 
expressive of their respective persons or characters. Turkey was a short, pursy Englishman of 
about my own age, that is, somewhere not far from sixty. In the morning, one might say, his face 
was of a fine florid hue, but after twelve o'clock, meridian—his dinner hour—it blazed like a grate 
full of Christmas coals; and continued blazing—but, as it were, with a gradual wane—till 6 
o'clock, P.M. or thereabouts, after which I saw no more of the proprietor of the face, which gaining 
its meridian with the sun, seemed to set with it, to rise, culminate, and decline the following day, 
with the like regularity and undiminished glory. There are many singular coincidences I have 
known in the course of my life, not the least among which was the fact, that exactly when Turkey 
displayed his fullest beams from his red and radiant countenance, just then, too, at that critical 
moment, began the daily period when I considered his business capacities as seriously disturbed 
for the remainder of the twenty-four hours. Not that he was absolutely idle, or averse to business 
then; far from it. The difficulty was, he was apt to be altogether too energetic. There was a strange, 
inflamed, flurried, flighty recklessness of activity about him. He would be incautious in dipping 
his pen into his inkstand. All his blots upon my documents, were dropped there after twelve 
o'clock, meridian. Indeed, not only would he be reckless and sadly given to making blots in the 
afternoon, but some days he went further, and was rather noisy. At such times, too, his face flamed 
with augmented blazonry, as if cannel coal had been heaped on anthracite. He made an unpleasant 
racket with his chair; spilled his sand-box; in mending his pens, impatiently split them all to 
pieces, and threw them on the floor in a sudden passion; stood up and leaned over his table, boxing 
his papers about in a most indecorous manner, very sad to behold in an elderly man like him. 
Nevertheless, as he was in many ways a most valuable person to me, and all the time before twelve 
o'clock, meridian, was the quickest, steadiest creature too, accomplishing a great deal of work in a 
style not easy to be matched—for these reasons, I was willing to overlook his eccentricities, 
though indeed, occasionally, I remonstrated with him. I did this very gently, however, because, 
though the civilest, nay, the blandest and most reverential of men in the morning, yet in the 
afternoon he was disposed, upon provocation, to be slightly rash with his tongue, in fact, insolent. 
Now, valuing his morning services as I did, and resolved not to lose them; yet, at the same time 
made uncomfortable by his inflamed ways after twelve o'clock; and being a man of peace, 
unwilling by my admonitions to call forth unseemly retorts from him; I took upon me, one 
Saturday noon (he was always worse on Saturdays), to hint to him, very kindly, that perhaps now 
that he was growing old, it might be well to abridge his labors; in short, he need not come to my 
chambers after twelve o'clock, but, dinner over, had best go home to his lodgings and rest himself 
till teatime. But no; he insisted upon his afternoon devotions. His countenance became intolerably 
fervid, as he oratorically assured me—gesticulating with a long ruler at the other end of the 
room—that if his services in the morning were useful, how indispensable, then, in the afternoon? 


## PDF page 23

23 
 
 
"With submission, sir," said Turkey on this occasion, "I consider myself your right-hand man. In 
the morning I but marshal and deploy my columns; but in the afternoon I put myself at their head, 
and gallantly charge the foe, thus!"—and he made a violent thrust with the ruler. 
"But the blots, Turkey," intimated I. 
"True,—but, with submission, sir, behold these hairs! I am getting old. Surely, sir, a blot or two of 
a warm afternoon is not to be severely urged against gray hairs. Old age—even if it blot the 
page—is honorable. With submission, sir, we bothare getting old." 
This appeal to my fellow-feeling was hardly to be resisted. At all events, I saw that go he would 
not. So I made up my mind to let him stay, resolving, nevertheless, to see to it, that during the 
afternoon he had to do with my less important papers. 
Nippers, the second on my list, was a whiskered, sallow, and, upon the whole, rather piratical-
looking young man of about five and twenty. I always deemed him the victim of two evil 
powers—ambition and indigestion. The ambition was evinced by a certain impatience of the duties 
of a mere copyist, an unwarrantable usurpation of strictly professional affairs, such as the original 
drawing up of legal documents. The indigestion seemed betokened in an occasional nervous 
testiness and grinning irritability, causing the teeth to audibly grind together over mistakes 
committed in copying; unnecessary maledictions, hissed, rather than spoken, in the heat of 
business; and especially by a continual discontent with the height of the table where he worked. 
Though of a very ingenious mechanical turn, Nippers could never get this table to suit him. He put 
chips under it, blocks of various sorts, bits of pasteboard, and at last went so far as to attempt an 
exquisite adjustment by final pieces of folded blotting paper. But no invention would answer. If, 
for the sake of easing his back, he brought the table lid at a sharp angle well up towards his chin, 
and wrote there like a man using the steep roof of a Dutch house for his desk:—then he declared 
that it stopped the circulation in his arms. If now he lowered the table to his waistbands, and 
stooped over it in writing, then there was a sore aching in his back. In short, the truth of the matter 
was, Nippers knew not what he wanted. Or, if he wanted any thing, it was to be rid of a scrivener's 
table altogether. Among the manifestations of his diseased ambition was a fondness he had for 
receiving visits from certain ambiguous-looking fellows in seedy coats, whom he called his 
clients. Indeed I was aware that not only was he, at times, considerable of a ward-politician, but he 
occasionally did a little business at the Justices' courts, and was not unknown on the steps of the 
Tombs. I have good reason to believe, however, that one individual who called upon him at my 
chambers, and who, with a grand air, he insisted was his client, was no other than a dun, and the 
alleged title-deed, a bill. But with all his failings, and the annoyances he caused me, Nippers, like 
his compatriot Turkey, was a very useful man to me; wrote a neat, swift hand; and, when he chose, 
was not deficient in a gentlemanly sort of deportment. Added to this, he always dressed in a 
gentlemanly sort of way; and so, incidentally, reflected credit upon my chambers. Whereas with 
respect to Turkey, I had much ado to keep him from being a reproach to me. His clothes were apt 
to look oily and smell of eating-houses. He wore his pantaloons very loose and baggy in summer. 
His coats were execrable; his hat not to be handled. But while the hat was a thing of indifference to 
me, inasmuch as his natural civility and deference, as a dependent Englishman, always led him to 
doff it the moment he entered the room, yet his coat was another matter. Concerning his coats, I 
reasoned with him; but with no effect. The truth was, I suppose, that a man of so small an income, 
could not afford to sport such a lustrous face and a lustrous coat at one and the same time. As 
Nippers once observed, Turkey's money went chiefly for red ink. One winter day I presented 
Turkey with a highly-respectable looking coat of my own, a padded gray coat, of a most 
comfortable warmth, and which buttoned straight up from the knee to the neck. I thought Turkey 
would appreciate the favor, and abate his rashness and obstreperousness of afternoons. But no. I 
verily believe that buttoning himself up in so downy and blanket-like a coat had a pernicious effect 
upon him; upon the same principle that too much oats are bad for horses. In fact, precisely as a 


## PDF page 24

24 
 
 
rash, restive horse is said to feel his oats, so Turkey felt his coat. It made him insolent. He was a 
man whom prosperity harmed. 
Though concerning the self-indulgent habits of Turkey I had my own private surmises, yet 
touching Nippers I was well persuaded that whatever might be his faults in other respects, he was, 
at least, a temperate young man. But indeed, nature herself seemed to have been his vintner, and at 
his birth charged him so thoroughly with an irritable, brandy-like disposition, that all subsequent 
potations were needless. When I consider how, amid the stillness of my chambers, Nippers would 
sometimes impatiently rise from his seat, and stooping over his table, spread his arms wide apart, 
seize the whole desk, and move it, and jerk it, with a grim, grinding motion on the floor, as if the 
table were a perverse voluntary agent, intent on thwarting and vexing him; I plainly perceive that 
for Nippers, brandy and water were altogether superfluous. 
It was fortunate for me that, owing to its peculiar cause—indigestion—the irritability and 
consequent nervousness of Nippers, were mainly observable in the morning, while in the afternoon 
he was comparatively mild. So that Turkey's paroxysms only coming on about twelve o'clock, I 
never had to do with their eccentricities at one time. Their fits relieved each other like guards. 
When Nippers' was on, Turkey's was off; and vice versa. This was a good natural arrangement 
under the circumstances. 
Ginger Nut, the third on my list, was a lad some twelve years old. His father was a carman, 
ambitious of seeing his son on the bench instead of a cart, before he died. So he sent him to my 
office as student at law, errand boy, and cleaner and sweeper, at the rate of one dollar a week. He 
had a little desk to himself, but he did not use it much. Upon inspection, the drawer exhibited a 
great array of the shells of various sorts of nuts. Indeed, to this quick-witted youth the whole noble 
science of the law was contained in a nut-shell. Not the least among the employments of Ginger 
Nut, as well as one which he discharged with the most alacrity, was his duty as cake and apple 
purveyor for Turkey and Nippers. Copying law papers being proverbially dry, husky sort of 
business, my two scriveners were fain to moisten their mouths very often with Spitzenbergs to be 
had at the numerous stalls nigh the Custom House and Post Office. Also, they sent Ginger Nut 
very frequently for that peculiar cake—small, flat, round, and very spicy—after which he had been 
named by them. Of a cold morning when business was but dull, Turkey would gobble up scores of 
these cakes, as if they were mere wafers—indeed they sell them at the rate of six or eight for a 
penny—the scrape of his pen blending with the crunching of the crisp particles in his mouth. Of all 
the fiery afternoon blunders and flurried rashnesses of Turkey, was his once moistening a ginger-
cake between his lips, and clapping it on to a mortgage for a seal. I came within an ace of 
dismissing him then. But he mollified me by making an oriental bow, and saying—"With 
submission, sir, it was generous of me to find you in stationery on my own account." 
Now my original business—that of a conveyancer and title hunter, and drawer-up of recondite 
documents of all sorts—was considerably increased by receiving the master's office. There was 
now great work for scriveners. Not only must I push the clerks already with me, but I must have 
additional help. In answer to my advertisement, a motionless young man one morning, stood upon 
my office threshold, the door being open, for it was summer. I can see that figure now—pallidly 
neat, pitiably respectable, incurably forlorn! It was Bartleby. 
After a few words touching his qualifications, I engaged him, glad to have among my corps of 
copyists a man of so singularly sedate an aspect, which I thought might operate beneficially upon 
the flighty temper of Turkey, and the fiery one of Nippers. 
I should have stated before that ground glass folding-doors divided my premises into two parts, 
one of which was occupied by my scriveners, the other by myself. According to my humor I threw 
open these doors, or closed them. I resolved to assign Bartleby a corner by the folding-doors, but 
on my side of them, so as to have this quiet man within easy call, in case any trifling thing was to 
be done. I placed his desk close up to a small side-window in that part of the room, a window 


## PDF page 25

25 
 
 
which originally had afforded a lateral view of certain grimy back-yards and bricks, but which, 
owing to subsequent erections, commanded at present no view at all, though it gave some light. 
Within three feet of the panes was a wall, and the light came down from far above, between two 
lofty buildings, as from a very small opening in a dome. Still further to a satisfactory arrangement, 
I procured a high green folding screen, which might entirely isolate Bartleby from my sight, 
though not remove him from my voice. And thus, in a manner, privacy and society were 
conjoined. 
At first Bartleby did an extraordinary quantity of writing. As if long famishing for something to 
copy, he seemed to gorge himself on my documents. There was no pause for digestion. He ran a 
day and night line, copying by sun-light and by candle-light. I should have been quite delighted 
with his application, had he been cheerfully industrious. But he wrote on silently, palely, 
mechanically. 
It is, of course, an indispensable part of a scrivener's business to verify the accuracy of his copy, 
word by word. Where there are two or more scriveners in an office, they assist each other in this 
examination, one reading from the copy, the other holding the original. It is a very dull, 
wearisome, and lethargic affair. I can readily imagine that to some sanguine temperaments it 
would be altogether intolerable. For example, I cannot credit that the mettlesome poet Byron 
would have contentedly sat down with Bartleby to examine a law document of, say five hundred 
pages, closely written in a crimpy hand. 
Now and then, in the haste of business, it had been my habit to assist in comparing some brief 
document myself, calling Turkey or Nippers for this purpose. One object I had in placing Bartleby 
so handy to me behind the screen, was to avail myself of his services on such trivial occasions. It 
was on the third day, I think, of his being with me, and before any necessity had arisen for having 
his own writing examined, that, being much hurried to complete a small affair I had in hand, I 
abruptly called to Bartleby. In my haste and natural expectancy of instant compliance, I sat with 
my head bent over the original on my desk, and my right hand sideways, and somewhat nervously 
extended with the copy, so that immediately upon emerging from his retreat, Bartleby might 
snatch it and proceed to business without the least delay. 
In this very attitude did I sit when I called to him, rapidly stating what it was I wanted him to do—
namely, to examine a small paper with me. Imagine my surprise, nay, my consternation, when 
without moving from his privacy, Bartleby in a singularly mild, firm voice, replied, "I would 
prefer not to." 
I sat awhile in perfect silence, rallying my stunned faculties. Immediately it occurred to me that 
my ears had deceived me, or Bartleby had entirely misunderstood my meaning. I repeated my 
request in the clearest tone I could assume. But in quite as clear a one came the previous reply, "I 
would prefer not to." 
"Prefer not to," echoed I, rising in high excitement, and crossing the room with a stride. "What do 
you mean? Are you moon-struck? I want you to help me compare this sheet here—take it," and I 
thrust it towards him. 
"I would prefer not to," said he. 
I looked at him steadfastly. His face was leanly composed; his gray eye dimly calm. Not a wrinkle 
of agitation rippled him. Had there been the least uneasiness, anger, impatience or impertinence in 
his manner; in other words, had there been any thing ordinarily human about him, doubtless I 
should have violently dismissed him from the premises. But as it was, I should have as soon 
thought of turning my pale plaster-of-paris bust of Cicero out of doors. I stood gazing at him 
awhile, as he went on with his own writing, and then reseated myself at my desk. This is very 
strange, thought I. What had one best do? But my business hurried me. I concluded to forget the 


## PDF page 26

26 
 
 
matter for the present, reserving it for my future leisure. So calling Nippers from the other room, 
the paper was speedily examined. 
A few days after this, Bartleby concluded four lengthy documents, being quadruplicates of a 
week's testimony taken before me in my High Court of Chancery. It became necessary to examine 
them. It was an important suit, and great accuracy was imperative. Having all things arranged I 
called Turkey, Nippers and Ginger Nut from the next room, meaning to place the four copies in 
the hands of my four clerks, while I should read from the original. Accordingly Turkey, Nippers 
and Ginger Nut had taken their seats in a row, each with his document in hand, when I called to 
Bartleby to join this interesting group. 
"Bartleby! quick, I am waiting." 
I heard a slow scrape of his chair legs on the uncarpeted floor, and soon he appeared standing at 
the entrance of his hermitage. 
"What is wanted?" said he mildly. 
"The copies, the copies," said I hurriedly. "We are going to examine them. There"—and I held 
towards him the fourth quadruplicate. 
"I would prefer not to," he said, and gently disappeared behind the screen. 
For a few moments I was turned into a pillar of salt, standing at the head of my seated column of 
clerks. Recovering myself, I advanced towards the screen, and demanded the reason for such 
extraordinary conduct. 
"Why do you refuse?" 
"I would prefer not to." 
With any other man I should have flown outright into a dreadful passion, scorned all further 
words, and thrust him ignominiously from my presence. But there was something about Bartleby 
that not only strangely disarmed me, but in a wonderful manner touched and disconcerted me. I 
began to reason with him. 
"These are your own copies we are about to examine. It is labor saving to you, because one 
examination will answer for your four papers. It is common usage. Every copyist is bound to help 
examine his copy. Is it not so? Will you not speak? Answer!" 
"I prefer not to," he replied in a flute-like tone. It seemed to me that while I had been addressing 
him, he carefully revolved every statement that I made; fully comprehended the meaning; could 
not gainsay the irresistible conclusions; but, at the same time, some paramount consideration 
prevailed with him to reply as he did. 
"You are decided, then, not to comply with my request—a request made according to common 
usage and common sense?" 
He briefly gave me to understand that on that point my judgment was sound. Yes: his decision was 
irreversible. 
It is not seldom the case that when a man is browbeaten in some unprecedented and violently 
unreasonable way, he begins to stagger in his own plainest faith. He begins, as it were, vaguely to 
surmise that, wonderful as it may be, all the justice and all the reason is on the other side. 
Accordingly, if any disinterested persons are present, he turns to them for some reinforcement for 
his own faltering mind. 
"Turkey," said I, "what do you think of this? Am I not right?" 
"With submission, sir," said Turkey, with his blandest tone, "I think that you are." 
"Nippers," said I, "what do you think of it?" 
"I think I should kick him out of the office." 


## PDF page 27

27 
 
 
(The reader of nice perceptions will here perceive that, it being morning, Turkey's answer is 
couched in polite and tranquil terms, but Nippers replies in ill-tempered ones. Or, to repeat a 
previous sentence, Nippers' ugly mood was on duty and Turkey's off.) 
"Ginger Nut," said I, willing to enlist the smallest suffrage in my behalf, "what do you think of it?" 
"I think, sir, he's a little luny," replied Ginger Nut with a grin. 
"You hear what they say," said I, turning towards the screen, "come forth and do your duty." 
But he vouchsafed no reply. I pondered a moment in sore perplexity. But once more business 
hurried me. I determined again to postpone the consideration of this dilemma to my future leisure. 
With a little trouble we made out to examine the papers without Bartleby, though at every page or 
two, Turkey deferentially dropped his opinion that this proceeding was quite out of the common; 
while Nippers, twitching in his chair with a dyspeptic nervousness, ground out between his set 
teeth occasional hissing maledictions against the stubborn oaf behind the screen. And for his 
(Nippers') part, this was the first and the last time he would do another man's business without pay. 
Meanwhile Bartleby sat in his hermitage, oblivious to every thing but his own peculiar business 
there. 
Some days passed, the scrivener being employed upon another lengthy work. His late remarkable 
conduct led me to regard his ways narrowly. I observed that he never went to dinner; indeed that 
he never went any where. As yet I had never of my personal knowledge known him to be outside 
of my office. He was a perpetual sentry in the corner. At about eleven o'clock though, in the 
morning, I noticed that Ginger Nut would advance toward the opening in Bartleby's screen, as if 
silently beckoned thither by a gesture invisible to me where I sat. The boy would then leave the 
office jingling a few pence, and reappear with a handful of ginger-nuts which he delivered in the 
hermitage, receiving two of the cakes for his trouble. 
He lives, then, on ginger-nuts, thought I; never eats a dinner, properly speaking; he must be a 
vegetarian then; but no; he never eats even vegetables, he eats nothing but ginger-nuts. My mind 
then ran on in reveries concerning the probable effects upon the human constitution of living 
entirely on ginger-nuts. Ginger-nuts are so called because they contain ginger as one of their 
peculiar constituents, and the final flavoring one. Now what was ginger? A hot, spicy thing. Was 
Bartleby hot and spicy? Not at all. Ginger, then, had no effect upon Bartleby. Probably he 
preferred it should have none. 
Nothing so aggravates an earnest person as a passive resistance. If the individual so resisted be of a 
not inhumane temper, and the resisting one perfectly harmless in his passivity; then, in the better 
moods of the former, he will endeavor charitably to construe to his imagination what proves 
impossible to be solved by his judgment. Even so, for the most part, I regarded Bartleby and his 
ways. Poor fellow! thought I, he means no mischief; it is plain he intends no insolence; his aspect 
sufficiently evinces that his eccentricities are involuntary. He is useful to me. I can get along with 
him. If I turn him away, the chances are he will fall in with some less indulgent employer, and then 
he will be rudely treated, and perhaps driven forth miserably to starve. Yes. Here I can cheaply 
purchase a delicious self-approval. To befriend Bartleby; to humor him in his strange willfulness, 
will cost me little or nothing, while I lay up in my soul what will eventually prove a sweet morsel 
for my conscience. But this mood was not invariable with me. The passiveness of Bartleby 
sometimes irritated me. I felt strangely goaded on to encounter him in new opposition, to elicit 
some angry spark from him answerable to my own. But indeed I might as well have essayed to 
strike fire with my knuckles against a bit of Windsor soap. But one afternoon the evil impulse in 
me mastered me, and the following little scene ensued: 
"Bartleby," said I, "when those papers are all copied, I will compare them with you." 
"I would prefer not to." 
"How? Surely you do not mean to persist in that mulish vagary?" 


## PDF page 28

28 
 
 
No answer. 
I threw open the folding-doors near by, and turning upon Turkey and Nippers, exclaimed in an 
excited manner— 
"He says, a second time, he won't examine his papers. What do you think of it, Turkey?" 
It was afternoon, be it remembered. Turkey sat glowing like a brass boiler, his bald head steaming, 
his hands reeling among his blotted papers. 
"Think of it?" roared Turkey; "I think I'll just step behind his screen, and black his eyes for him!" 
So saying, Turkey rose to his feet and threw his arms into a pugilistic position. He was hurrying 
away to make good his promise, when I detained him, alarmed at the effect of incautiously rousing 
Turkey's combativeness after dinner. 
"Sit down, Turkey," said I, "and hear what Nippers has to say. What do you think of it, Nippers? 
Would I not be justified in immediately dismissing Bartleby?" 
"Excuse me, that is for you to decide, sir. I think his conduct quite unusual, and indeed unjust, as 
regards Turkey and myself. But it may only be a passing whim." 
"Ah," exclaimed I, "you have strangely changed your mind then—you speak very gently of him 
now." 
"All beer," cried Turkey; "gentleness is effects of beer—Nippers and I dined together to-day. You 
see how gentle I am, sir. Shall I go and black his eyes?" 
"You refer to Bartleby, I suppose. No, not to-day, Turkey," I replied; "pray, put up your fists." 
I closed the doors, and again advanced towards Bartleby. I felt additional incentives tempting me 
to my fate. I burned to be rebelled against again. I remembered that Bartleby never left the office. 
"Bartleby," said I, "Ginger Nut is away; just step round to the Post Office, won't you? (it was but a 
three minute walk,) and see if there is any thing for me." 
"I would prefer not to." 
"You will not?" 
"I prefer not." 
I staggered to my desk, and sat there in a deep study. My blind inveteracy returned. Was there any 
other thing in which I could procure myself to be ignominiously repulsed by this lean, penniless 
wight?—my hired clerk? What added thing is there, perfectly reasonable, that he will be sure to 
refuse to do? 
"Bartleby!" 
No answer. 
"Bartleby," in a louder tone. 
No answer. 
"Bartleby," I roared. 
Like a very ghost, agreeably to the laws of magical invocation, at the third summons, he appeared 
at the entrance of his hermitage. 
"Go to the next room, and tell Nippers to come to me." 
"I prefer not to," he respectfully and slowly said, and mildly disappeared. 
"Very good, Bartleby," said I, in a quiet sort of serenely severe self-possessed tone, intimating the 
unalterable purpose of some terrible retribution very close at hand. At the moment I half intended 
something of the kind. But upon the whole, as it was drawing towards my dinner-hour, I thought it 
best to put on my hat and walk home for the day, suffering much from perplexity and distress of 
mind. 


## PDF page 29

29 
 
 
Shall I acknowledge it? The conclusion of this whole business was, that it soon became a fixed 
fact of my chambers, that a pale young scrivener, by the name of Bartleby, and a desk there; that 
he copied for me at the usual rate of four cents a folio (one hundred words); but he was 
permanently exempt from examining the work done by him, that duty being transferred to Turkey 
and Nippers, one of compliment doubtless to their superior acuteness; moreover, said Bartleby was 
never on any account to be dispatched on the most trivial errand of any sort; and that even if 
entreated to take upon him such a matter, it was generally understood that he would prefer not to—
in other words, that he would refuse pointblank. 
As days passed on, I became considerably reconciled to Bartleby. His steadiness, his freedom from 
all dissipation, his incessant industry (except when he chose to throw himself into a standing 
revery behind his screen), his great stillness, his unalterableness of demeanor under all 
circumstances, made him a valuable acquisition. One prime thing was this,—he was always 
there;—first in the morning, continually through the day, and the last at night. I had a singular 
confidence in his honesty. I felt my most precious papers perfectly safe in his hands. Sometimes to 
be sure I could not, for the very soul of me, avoid falling into sudden spasmodic passions with 
him. For it was exceeding difficult to bear in mind all the time those strange peculiarities, 
privileges, and unheard of exemptions, forming the tacit stipulations on Bartleby's part under 
which he remained in my office. Now and then, in the eagerness of dispatching pressing business, 
I would inadvertently summon Bartleby, in a short, rapid tone, to put his finger, say, on the 
incipient tie of a bit of red tape with which I was about compressing some papers. Of course, from 
behind the screen the usual answer, "I prefer not to," was sure to come; and then, how could a 
human creature with the common infirmities of our nature, refrain from bitterly exclaiming upon 
such perverseness—such unreasonableness. However, every added repulse of this sort which I 
received only tended to lessen the probability of my repeating the inadvertence. 
Here it must be said, that according to the custom of most legal gentlemen occupying chambers in 
densely-populated law buildings, there were several keys to my door. One was kept by a woman 
residing in the attic, which person weekly scrubbed and daily swept and dusted my apartments. 
Another was kept by Turkey for convenience sake. The third I sometimes carried in my own 
pocket. The fourth I knew not who had. 
Now, one Sunday morning I happened to go to Trinity Church, to hear a celebrated preacher, and 
finding myself rather early on the ground, I thought I would walk around to my chambers for a 
while. Luckily I had my key with me; but upon applying it to the lock, I found it resisted by 
something inserted from the inside. Quite surprised, I called out; when to my consternation a key 
was turned from within; and thrusting his lean visage at me, and holding the door ajar, the 
apparition of Bartleby appeared, in his shirt sleeves, and otherwise in a strangely tattered 
dishabille, saying quietly that he was sorry, but he was deeply engaged just then, and—preferred 
not admitting me at present. In a brief word or two, he moreover added, that perhaps I had better 
walk round the block two or three times, and by that time he would probably have concluded his 
affairs. 
Now, the utterly unsurmised appearance of Bartleby, tenanting my law-chambers of a Sunday 
morning, with his cadaverously gentlemanly nonchalance, yet withal firm and self-possessed, had 
such a strange effect upon me, that incontinently I slunk away from my own door, and did as 
desired. But not without sundry twinges of impotent rebellion against the mild effrontery of this 
unaccountable scrivener. Indeed, it was his wonderful mildness chiefly, which not only disarmed 
me, but unmanned me, as it were. For I consider that one, for the time, is a sort of unmanned when 
he tranquilly permits his hired clerk to dictate to him, and order him away from his own premises. 
Furthermore, I was full of uneasiness as to what Bartleby could possibly be doing in my office in 
his shirt sleeves, and in an otherwise dismantled condition of a Sunday morning. Was any thing 
amiss going on? Nay, that was out of the question. It was not to be thought of for a moment that 


## PDF page 30

30 
 
 
Bartleby was an immoral person. But what could he be doing there?—copying? Nay again, 
whatever might be his eccentricities, Bartleby was an eminently decorous person. He would be the 
last man to sit down to his desk in any state approaching to nudity. Besides, it was Sunday; and 
there was something about Bartleby that forbade the supposition that he would by any secular 
occupation violate the proprieties of the day. 
Nevertheless, my mind was not pacified; and full of a restless curiosity, at last I returned to the 
door. Without hindrance I inserted my key, opened it, and entered. Bartleby was not to be seen. I 
looked round anxiously, peeped behind his screen; but it was very plain that he was gone. Upon 
more closely examining the place, I surmised that for an indefinite period Bartleby must have ate, 
dressed, and slept in my office, and that too without plate, mirror, or bed. The cushioned seat of a 
rickety old sofa in one corner bore the faint impress of a lean, reclining form. Rolled away under 
his desk, I found a blanket; under the empty grate, a blacking box and brush; on a chair, a tin 
basin, with soap and a ragged towel; in a newspaper a few crumbs of ginger-nuts and a morsel of 
cheese. Yes, thought I, it is evident enough that Bartleby has been making his home here, keeping 
bachelor's hall all by himself. Immediately then the thought came sweeping across me, What 
miserable friendlessness and loneliness are here revealed! His poverty is great; but his solitude, 
how horrible! Think of it. Of a Sunday, Wall-street is deserted as Petra; and every night of every 
day it is an emptiness. This building too, which of week-days hums with industry and life, at 
nightfall echoes with sheer vacancy, and all through Sunday is forlorn. And here Bartleby makes 
his home; sole spectator of a solitude which he has seen all populous—a sort of innocent and 
transformed Marius brooding among the ruins of Carthage! 
For the first time in my life a feeling of overpowering stinging melancholy seized me. Before, I 
had never experienced aught but a not-unpleasing sadness. The bond of a common humanity now 
drew me irresistibly to gloom. A fraternal melancholy! For both I and Bartleby were sons of 
Adam. I remembered the bright silks and sparkling faces I had seen that day, in gala trim, swan-
like sailing down the Mississippi of Broadway; and I contrasted them with the pallid copyist, and 
thought to myself, Ah, happiness courts the light, so we deem the world is gay; but misery hides 
aloof, so we deem that misery there is none. These sad fancyings—chimeras, doubtless, of a sick 
and silly brain—led on to other and more special thoughts, concerning the eccentricities of 
Bartleby. Presentiments of strange discoveries hovered round me. The scrivener's pale form 
appeared to me laid out, among uncaring strangers, in its shivering winding sheet. 
Suddenly I was attracted by Bartleby's closed desk, the key in open sight left in the lock. 
I mean no mischief, seek the gratification of no heartless curiosity, thought I; besides, the desk is 
mine, and its contents too, so I will make bold to look within. Every thing was methodically 
arranged, the papers smoothly placed. The pigeon holes were deep, and removing the files of 
documents, I groped into their recesses. Presently I felt something there, and dragged it out. It was 
an old bandanna handkerchief, heavy and knotted. I opened it, and saw it was a savings' bank. 
I now recalled all the quiet mysteries which I had noted in the man. I remembered that he never 
spoke but to answer; that though at intervals he had considerable time to himself, yet I had never 
seen him reading—no, not even a newspaper; that for long periods he would stand looking out, at 
his pale window behind the screen, upon the dead brick wall; I was quite sure he never visited any 
refectory or eating house; while his pale face clearly indicated that he never drank beer like 
Turkey, or tea and coffee even, like other men; that he never went any where in particular that I 
could learn; never went out for a walk, unless indeed that was the case at present; that he had 
declined telling who he was, or whence he came, or whether he had any relatives in the world; that 
though so thin and pale, he never complained of ill health. And more than all, I remembered a 
certain unconscious air of pallid—how shall I call it?—of pallid haughtiness, say, or rather an 
austere reserve about him, which had positively awed me into my tame compliance with his 
eccentricities, when I had feared to ask him to do the slightest incidental thing for me, even though 


## PDF page 31

31 
 
 
I might know, from his long-continued motionlessness, that behind his screen he must be standing 
in one of those dead-wall reveries of his. 
Revolving all these things, and coupling them with the recently discovered fact that he made my 
office his constant abiding place and home, and not forgetful of his morbid moodiness; revolving 
all these things, a prudential feeling began to steal over me. My first emotions had been those of 
pure melancholy and sincerest pity; but just in proportion as the forlornness of Bartleby grew and 
grew to my imagination, did that same melancholy merge into fear, that pity into repulsion. So true 
it is, and so terrible too, that up to a certain point the thought or sight of misery enlists our best 
affections; but, in certain special cases, beyond that point it does not. They err who would assert 
that invariably this is owing to the inherent selfishness of the human heart. It rather proceeds from 
a certain hopelessness of remedying excessive and organic ill. To a sensitive being, pity is not 
seldom pain. And when at last it is perceived that such pity cannot lead to effectual succor, 
common sense bids the soul rid of it. What I saw that morning persuaded me that the scrivener was 
the victim of innate and incurable disorder. I might give alms to his body; but his body did not 
pain him; it was his soul that suffered, and his soul I could not reach. 
I did not accomplish the purpose of going to Trinity Church that morning. Somehow, the things I 
had seen disqualified me for the time from church-going. I walked homeward, thinking what I 
would do with Bartleby. Finally, I resolved upon this;—I would put certain calm questions to him 
the next morning, touching his history, etc., and if he declined to answer them openly and 
unreservedly (and I supposed he would prefer not), then to give him a twenty dollar bill over and 
above whatever I might owe him, and tell him his services were no longer required; but that if in 
any other way I could assist him, I would be happy to do so, especially if he desired to return to his 
native place, wherever that might be, I would willingly help to defray the expenses. Moreover, if, 
after reaching home, he found himself at any time in want of aid, a letter from him would be sure 
of a reply. 
The next morning came. 
"Bartleby," said I, gently calling to him behind his screen. 
No reply. 
"Bartleby," said I, in a still gentler tone, "come here; I am not going to ask you to do any thing you 
would prefer not to do—I simply wish to speak to you." 
Upon this he noiselessly slid into view. 
"Will you tell me, Bartleby, where you were born?" 
"I would prefer not to." 
"Will you tell me any thing about yourself?" 
"I would prefer not to." 
"But what reasonable objection can you have to speak to me? I feel friendly towards you." 
He did not look at me while I spoke, but kept his glance fixed upon my bust of Cicero, which as I 
then sat, was directly behind me, some six inches above my head. 
"What is your answer, Bartleby?" said I, after waiting a considerable time for a reply, during 
which his countenance remained immovable, only there was the faintest conceivable tremor of the 
white attenuated mouth. 
"At present I prefer to give no answer," he said, and retired into his hermitage. 
It was rather weak in me I confess, but his manner on this occasion nettled me. Not only did there 
seem to lurk in it a certain calm disdain, but his perverseness seemed ungrateful, considering the 
undeniable good usage and indulgence he had received from me. 


## PDF page 32

32 
 
 
Again I sat ruminating what I should do. Mortified as I was at his behavior, and resolved as I had 
been to dismiss him when I entered my offices, nevertheless I strangely felt something 
superstitious knocking at my heart, and forbidding me to carry out my purpose, and denouncing 
me for a villain if I dared to breathe one bitter word against this forlornest of mankind. At last, 
familiarly drawing my chair behind his screen, I sat down and said: "Bartleby, never mind then 
about revealing your history; but let me entreat you, as a friend, to comply as far as may be with 
the usages of this office. Say now you will help to examine papers to-morrow or next day: in short, 
say now that in a day or two you will begin to be a little reasonable:—say so, Bartleby." 
"At present I would prefer not to be a little reasonable," was his mildly cadaverous reply. 
Just then the folding-doors opened, and Nippers approached. He seemed suffering from an 
unusually bad night's rest, induced by severer indigestion than common. He overheard those final 
words of Bartleby. 
"Prefer not, eh?" gritted Nippers—"I'd prefer him, if I were you, sir," addressing me—
"I'd prefer him; I'd give him preferences, the stubborn mule! What is it, sir, pray, that 
he prefers not to do now?" 
Bartleby moved not a limb. 
"Mr. Nippers," said I, "I'd prefer that you would withdraw for the present." 
Somehow, of late I had got into the way of involuntarily using this word "prefer" upon all sorts of 
not exactly suitable occasions. And I trembled to think that my contact with the scrivener had 
already and seriously affected me in a mental way. And what further and deeper aberration might 
it not yet produce? This apprehension had not been without efficacy in determining me to 
summary means. 
As Nippers, looking very sour and sulky, was departing, Turkey blandly and deferentially 
approached. 
"With submission, sir," said he, "yesterday I was thinking about Bartleby here, and I think that if 
he would but prefer to take a quart of good ale every day, it would do much towards mending him, 
and enabling him to assist in examining his papers." 
"So you have got the word too," said I, slightly excited. 
"With submission, what word, sir," asked Turkey, respectfully crowding himself into the 
contracted space behind the screen, and by so doing, making me jostle the scrivener. "What word, 
sir?" 
"I would prefer to be left alone here," said Bartleby, as if offended at being mobbed in his privacy. 
"That's the word, Turkey," said I—"that's it." 
"Oh, prefer? oh yes—queer word. I never use it myself. But, sir, as I was saying, if he would but 
prefer—" 
"Turkey," interrupted I, "you will please withdraw." 
"Oh certainly, sir, if you prefer that I should." 
As he opened the folding-door to retire, Nippers at his desk caught a glimpse of me, and asked 
whether I would prefer to have a certain paper copied on blue paper or white. He did not in the 
least roguishly accent the word prefer. It was plain that it involuntarily rolled from his tongue. I 
thought to myself, surely I must get rid of a demented man, who already has in some degree turned 
the tongues, if not the heads of myself and clerks. But I thought it prudent not to break the 
dismission at once. 
The next day I noticed that Bartleby did nothing but stand at his window in his dead-wall revery. 
Upon asking him why he did not write, he said that he had decided upon doing no more writing. 
"Why, how now? what next?" exclaimed I, "do no more writing?" 


## PDF page 33

33 
 
 
"No more." 
"And what is the reason?" 
"Do you not see the reason for yourself," he indifferently replied. 
I looked steadfastly at him, and perceived that his eyes looked dull and glazed. Instantly it 
occurred to me, that his unexampled diligence in copying by his dim window for the first few 
weeks of his stay with me might have temporarily impaired his vision. 
I was touched. I said something in condolence with him. I hinted that of course he did wisely in 
abstaining from writing for a while; and urged him to embrace that opportunity of taking 
wholesome exercise in the open air. This, however, he did not do. A few days after this, my other 
clerks being absent, and being in a great hurry to dispatch certain letters by the mail, I thought that, 
having nothing else earthly to do, Bartleby would surely be less inflexible than usual, and carry 
these letters to the post-office. But he blankly declined. So, much to my inconvenience, I went 
myself. 
Still added days went by. Whether Bartleby's eyes improved or not, I could not say. To all 
appearance, I thought they did. But when I asked him if they did, he vouchsafed no answer. At all 
events, he would do no copying. At last, in reply to my urgings, he informed me that he had 
permanently given up copying. 
"What!" exclaimed I; "suppose your eyes should get entirely well—better than ever before—
would you not copy then?" 
"I have given up copying," he answered, and slid aside. 
He remained as ever, a fixture in my chamber. Nay—if that were possible—he became still more 
of a fixture than before. What was to be done? He would do nothing in the office: why should he 
stay there? In plain fact, he had now become a millstone to me, not only useless as a necklace, but 
afflictive to bear. Yet I was sorry for him. I speak less than truth when I say that, on his own 
account, he occasioned me uneasiness. If he would but have named a single relative or friend, I 
would instantly have written, and urged their taking the poor fellow away to some convenient 
retreat. But he seemed alone, absolutely alone in the universe. A bit of wreck in the mid Atlantic. 
At length, necessities connected with my business tyrannized over all other considerations. 
Decently as I could, I told Bartleby that in six days' time he must unconditionally leave the office. 
I warned him to take measures, in the interval, for procuring some other abode. I offered to assist 
him in this endeavor, if he himself would but take the first step towards a removal. "And when you 
finally quit me, Bartleby," added I, "I shall see that you go not away entirely unprovided. Six days 
from this hour, remember." 
At the expiration of that period, I peeped behind the screen, and lo! Bartleby was there. 
I buttoned up my coat, balanced myself; advanced slowly towards him, touched his shoulder, and 
said, "The time has come; you must quit this place; I am sorry for you; here is money; but you 
must go." 
"I would prefer not," he replied, with his back still towards me. 
"You must." 
He remained silent. 
Now I had an unbounded confidence in this man's common honesty. He had frequently restored to 
me sixpences and shillings carelessly dropped upon the floor, for I am apt to be very reckless in 
such shirt-button affairs. The proceeding then which followed will not be deemed extraordinary. 
"Bartleby," said I, "I owe you twelve dollars on account; here are thirty-two; the odd twenty are 
yours.—Will you take it?" and I handed the bills towards him. 
But he made no motion. 


## PDF page 34

34 
 
 
"I will leave them here then," putting them under a weight on the table. Then taking my hat and 
cane and going to the door I tranquilly turned and added—"After you have removed your things 
from these offices, Bartleby, you will of course lock the door—since every one is now gone for the 
day but you—and if you please, slip your key underneath the mat, so that I may have it in the 
morning. I shall not see you again; so good-bye to you. If hereafter in your new place of abode I 
can be of any service to you, do not fail to advise me by letter. Good-bye, Bartleby, and fare you 
well." 
But he answered not a word; like the last column of some ruined temple, he remained standing 
mute and solitary in the middle of the otherwise deserted room. 
As I walked home in a pensive mood, my vanity got the better of my pity. I could not but highly 
plume myself on my masterly management in getting rid of Bartleby. Masterly I call it, and such it 
must appear to any dispassionate thinker. The beauty of my procedure seemed to consist in its 
perfect quietness. There was no vulgar bullying, no bravado of any sort, no choleric hectoring, and 
striding to and fro across the apartment, jerking out vehement commands for Bartleby to bundle 
himself off with his beggarly traps. Nothing of the kind. Without loudly bidding Bartleby depart—
as an inferior genius might have done—I assumed the ground that depart he must; and upon that 
assumption built all I had to say. The more I thought over my procedure, the more I was charmed 
with it. Nevertheless, next morning, upon awakening, I had my doubts,—I had somehow slept off 
the fumes of vanity. One of the coolest and wisest hours a man has, is just after he awakes in the 
morning. My procedure seemed as sagacious as ever.—but only in theory. How it would prove in 
practice—there was the rub. It was truly a beautiful thought to have assumed Bartleby's departure; 
but, after all, that assumption was simply my own, and none of Bartleby's. The great point was, not 
whether I had assumed that he would quit me, but whether he would prefer so to do. He was more 
a man of preferences than assumptions. 
After breakfast, I walked down town, arguing the probabilities pro and con. One moment I thought 
it would prove a miserable failure, and Bartleby would be found all alive at my office as usual; the 
next moment it seemed certain that I should see his chair empty. And so I kept veering about. At 
the corner of Broadway and Canal-street, I saw quite an excited group of people standing in 
earnest conversation. 
"I'll take odds he doesn't," said a voice as I passed. 
"Doesn't go?—done!" said I, "put up your money." 
I was instinctively putting my hand in my pocket to produce my own, when I remembered that this 
was an election day. The words I had overheard bore no reference to Bartleby, but to the success 
or non-success of some candidate for the mayoralty. In my intent frame of mind, I had, as it were, 
imagined that all Broadway shared in my excitement, and were debating the same question with 
me. I passed on, very thankful that the uproar of the street screened my momentary absent-
mindedness. 
As I had intended, I was earlier than usual at my office door. I stood listening for a moment. All 
was still. He must be gone. I tried the knob. The door was locked. Yes, my procedure had worked 
to a charm; he indeed must be vanished. Yet a certain melancholy mixed with this: I was almost 
sorry for my brilliant success. I was fumbling under the door mat for the key, which Bartleby was 
to have left there for me, when accidentally my knee knocked against a panel, producing a 
summoning sound, and in response a voice came to me from within—"Not yet; I am occupied." 
It was Bartleby. 
I was thunderstruck. For an instant I stood like the man who, pipe in mouth, was killed one 
cloudless afternoon long ago in Virginia, by a summer lightning; at his own warm open window 
he was killed, and remained leaning out there upon the dreamy afternoon, till some one touched 
him, when he fell. 


## PDF page 35

35 
 
 
"Not gone!" I murmured at last. But again obeying that wondrous ascendancy which the 
inscrutable scrivener had over me, and from which ascendancy, for all my chafing, I could not 
completely escape, I slowly went down stairs and out into the street, and while walking round the 
block, considered what I should next do in this unheard-of perplexity. Turn the man out by an 
actual thrusting I could not; to drive him away by calling him hard names would not do; calling in 
the police was an unpleasant idea; and yet, permit him to enjoy his cadaverous triumph over me,—
this too I could not think of. What was to be done? or, if nothing could be done, was there any 
thing further that I could assume in the matter? Yes, as before I had prospectively assumed that 
Bartleby would depart, so now I might retrospectively assume that departed he was. In the 
legitimate carrying out of this assumption, I might enter my office in a great hurry, and pretending 
not to see Bartleby at all, walk straight against him as if he were air. Such a proceeding would in a 
singular degree have the appearance of a home-thrust. It was hardly possible that Bartleby could 
withstand such an application of the doctrine of assumptions. But upon second thoughts the 
success of the plan seemed rather dubious. I resolved to argue the matter over with him again. 
"Bartleby," said I, entering the office, with a quietly severe expression, "I am seriously displeased. 
I am pained, Bartleby. I had thought better of you. I had imagined you of such a gentlemanly 
organization, that in any delicate dilemma a slight hint would have suffice—in short, an 
assumption. But it appears I am deceived. Why," I added, unaffectedly starting, "you have not 
even touched that money yet," pointing to it, just where I had left it the evening previous. 
He answered nothing. 
"Will you, or will you not, quit me?" I now demanded in a sudden passion, advancing close to 
him. 
"I would prefer not to quit you," he replied, gently emphasizing the not. 
"What earthly right have you to stay here? Do you pay any rent? Do you pay my taxes? Or is this 
property yours?" 
He answered nothing. 
"Are you ready to go on and write now? Are your eyes recovered? Could you copy a small paper 
for me this morning? or help examine a few lines? or step round to the post-office? In a word, will 
you do any thing at all, to give a coloring to your refusal to depart the premises?" 
He silently retired into his hermitage. 
I was now in such a state of nervous resentment that I thought it but prudent to check myself at 
present from further demonstrations. Bartleby and I were alone. I remembered the tragedy of the 
unfortunate Adams and the still more unfortunate Colt in the solitary office of the latter; and how 
poor Colt, being dreadfully incensed by Adams, and imprudently permitting himself to get wildly 
excited, was at unawares hurried into his fatal act—an act which certainly no man could possibly 
deplore more than the actor himself. Often it had occurred to me in my ponderings upon the 
subject, that had that altercation taken place in the public street, or at a private residence, it would 
not have terminated as it did. It was the circumstance of being alone in a solitary office, up stairs, 
of a building entirely unhallowed by humanizing domestic associations—an uncarpeted office, 
doubtless, of a dusty, haggard sort of appearance;—this it must have been, which greatly helped to 
enhance the irritable desperation of the hapless Colt. 
But when this old Adam of resentment rose in me and tempted me concerning Bartleby, I grappled 
him and threw him. How? Why, simply by recalling the divine injunction: "A new commandment 
give I unto you, that ye love one another." Yes, this it was that saved me. Aside from higher 
considerations, charity often operates as a vastly wise and prudent principle—a great safeguard to 
its possessor. Men have committed murder for jealousy's sake, and anger's sake, and hatred's sake, 
and selfishness' sake, and spiritual pride's sake; but no man that ever I heard of, ever committed a 
diabolical murder for sweet charity's sake. Mere self-interest, then, if no better motive can be 


## PDF page 36

36 
 
 
enlisted, should, especially with high-tempered men, prompt all beings to charity and 
philanthropy. At any rate, upon the occasion in question, I strove to drown my exasperated 
feelings towards the scrivener by benevolently construing his conduct. Poor fellow, poor fellow! 
thought I, he don't mean any thing; and besides, he has seen hard times, and ought to be indulged. 
I endeavored also immediately to occupy myself, and at the same time to comfort my 
despondency. I tried to fancy that in the course of the morning, at such time as might prove 
agreeable to him, Bartleby, of his own free accord, would emerge from his hermitage, and take up 
some decided line of march in the direction of the door. But no. Half-past twelve o'clock came; 
Turkey began to glow in the face, overturn his inkstand, and become generally obstreperous; 
Nippers abated down into quietude and courtesy; Ginger Nut munched his noon apple; and 
Bartleby remained standing at his window in one of his profoundest dead-wall reveries. Will it be 
credited? Ought I to acknowledge it? That afternoon I left the office without saying one further 
word to him. 
Some days now passed, during which, at leisure intervals I looked a little into "Edwards on the 
Will," and "Priestly on Necessity." Under the circumstances, those books induced a salutary 
feeling. Gradually I slid into the persuasion that these troubles of mine touching the scrivener, had 
been all predestinated from eternity, and Bartleby was billeted upon me for some mysterious 
purpose of an all-wise Providence, which it was not for a mere mortal like me to fathom. Yes, 
Bartleby, stay there behind your screen, thought I; I shall persecute you no more; you are harmless 
and noiseless as any of these old chairs; in short, I never feel so private as when I know you are 
here. At last I see it, I feel it; I penetrate to the predestinated purpose of my life. I am content. 
Others may have loftier parts to enact; but my mission in this world, Bartleby, is to furnish you 
with office-room for such period as you may see fit to remain. 
I believe that this wise and blessed frame of mind would have continued with me, had it not been 
for the unsolicited and uncharitable remarks obtruded upon me by my professional friends who 
visited the rooms. But thus it often is, that the constant friction of illiberal minds wears out at last 
the best resolves of the more generous. Though to be sure, when I reflected upon it, it was not 
strange that people entering my office should be struck by the peculiar aspect of the unaccountable 
Bartleby, and so be tempted to throw out some sinister observations concerning him. Sometimes 
an attorney having business with me, and calling at my office and finding no one but the scrivener 
there, would undertake to obtain some sort of precise information from him touching my 
whereabouts; but without heeding his idle talk, Bartleby would remain standing immovable in the 
middle of the room. So after contemplating him in that position for a time, the attorney would 
depart, no wiser than he came. 
Also, when a Reference was going on, and the room full of lawyers and witnesses and business 
was driving fast; some deeply occupied legal gentleman present, seeing Bartleby wholly 
unemployed, would request him to run round to his (the legal gentleman's) office and fetch some 
papers for him. Thereupon, Bartleby would tranquilly decline, and yet remain idle as before. Then 
the lawyer would give a great stare, and turn to me. And what could I say? At last I was made 
aware that all through the circle of my professional acquaintance, a whisper of wonder was 
running round, having reference to the strange creature I kept at my office. This worried me very 
much. And as the idea came upon me of his possibly turning out a long-lived man, and keep 
occupying my chambers, and denying my authority; and perplexing my visitors; and scandalizing 
my professional reputation; and casting a general gloom over the premises; keeping soul and body 
together to the last upon his savings (for doubtless he spent but half a dime a day), and in the end 
perhaps outlive me, and claim possession of my office by right of his perpetual occupancy: as all 
these dark anticipations crowded upon me more and more, and my friends continually intruded 
their relentless remarks upon the apparition in my room; a great change was wrought in me. I 
resolved to gather all my faculties together, and forever rid me of this intolerable incubus. 


## PDF page 37

37 
 
 
Ere revolving any complicated project, however, adapted to this end, I first simply suggested to 
Bartleby the propriety of his permanent departure. In a calm and serious tone, I commended the 
idea to his careful and mature consideration. But having taken three days to meditate upon it, he 
apprised me that his original determination remained the same; in short, that he still preferred to 
abide with me. 
What shall I do? I now said to myself, buttoning up my coat to the last button. What shall I do? 
what ought I to do? what does conscience say I should do with this man, or rather ghost. Rid 
myself of him, I must; go, he shall. But how? You will not thrust him, the poor, pale, passive 
mortal,—you will not thrust such a helpless creature out of your door? you will not dishonor 
yourself by such cruelty? No, I will not, I cannot do that. Rather would I let him live and die here, 
and then mason up his remains in the wall. What then will you do? For all your coaxing, he will 
not budge. Bribes he leaves under your own paperweight on your table; in short, it is quite plain 
that he prefers to cling to you. 
Then something severe, something unusual must be done. What! surely you will not have him 
collared by a constable, and commit his innocent pallor to the common jail? And upon what 
ground could you procure such a thing to be done?—a vagrant, is he? What! he a vagrant, a 
wanderer, who refuses to budge? It is because he will not be a vagrant, then, that you seek to count 
him as a vagrant. That is too absurd. No visible means of support: there I have him. Wrong again: 
for indubitably he does support himself, and that is the only unanswerable proof that any man can 
show of his possessing the means so to do. No more then. Since he will not quit me, I must quit 
him. I will change my offices; I will move elsewhere; and give him fair notice, that if I find him on 
my new premises I will then proceed against him as a common trespasser. 
Acting accordingly, next day I thus addressed him: "I find these chambers too far from the City 
Hall; the air is unwholesome. In a word, I propose to remove my offices next week, and shall no 
longer require your services. I tell you this now, in order that you may seek another place." 
He made no reply, and nothing more was said. 
On the appointed day I engaged carts and men, proceeded to my chambers, and having but little 
furniture, every thing was removed in a few hours. Throughout, the scrivener remained standing 
behind the screen, which I directed to be removed the last thing. It was withdrawn; and being 
folded up like a huge folio, left him the motionless occupant of a naked room. I stood in the entry 
watching him a moment, while something from within me upbraided me. 
I re-entered, with my hand in my pocket—and—and my heart in my mouth. 
"Good-bye, Bartleby; I am going—good-bye, and God some way bless you; and take that," 
slipping something in his hand. But it dropped upon the floor, and then,—strange to say—I tore 
myself from him whom I had so longed to be rid of. 
Established in my new quarters, for a day or two I kept the door locked, and started at every 
footfall in the passages. When I returned to my rooms after any little absence, I would pause at the 
threshold for an instant, and attentively listen, ere applying my key. But these fears were needless. 
Bartleby never came nigh me. 
I thought all was going well, when a perturbed looking stranger visited me, inquiring whether I 
was the person who had recently occupied rooms at No.—Wall-street. 
Full of forebodings, I replied that I was. 
"Then sir," said the stranger, who proved a lawyer, "you are responsible for the man you left there. 
He refuses to do any copying; he refuses to do any thing; he says he prefers not to; and he refuses 
to quit the premises." 


## PDF page 38

38 
 
 
"I am very sorry, sir," said I, with assumed tranquility, but an inward tremor, "but, really, the man 
you allude to is nothing to me—he is no relation or apprentice of mine, that you should hold me 
responsible for him." 
"In mercy's name, who is he?" 
"I certainly cannot inform you. I know nothing about him. Formerly I employed him as a copyist; 
but he has done nothing for me now for some time past." 
"I shall settle him then,—good morning, sir." 
Several days passed, and I heard nothing more; and though I often felt a charitable prompting to 
call at the place and see poor Bartleby, yet a certain squeamishness of I know not what withheld 
me. 
All is over with him, by this time, thought I at last, when through another week no further 
intelligence reached me. But coming to my room the day after, I found several persons waiting at 
my door in a high state of nervous excitement. 
"That's the man—here he comes," cried the foremost one, whom I recognized as the lawyer who 
had previously called upon me alone. 
"You must take him away, sir, at once," cried a portly person among them, advancing upon me, 
and whom I knew to be the landlord of No.—Wall-street. "These gentlemen, my tenants, cannot 
stand it any longer; Mr. B—" pointing to the lawyer, "has turned him out of his room, and he now 
persists in haunting the building generally, sitting upon the banisters of the stairs by day, and 
sleeping in the entry by night. Every body is concerned; clients are leaving the offices; some fears 
are entertained of a mob; something you must do, and that without delay." 
Aghast at this torrent, I fell back before it, and would fain have locked myself in my new quarters. 
In vain I persisted that Bartleby was nothing to me—no more than to any one else. In vain:—I was 
the last person known to have any thing to do with him, and they held me to the terrible account. 
Fearful then of being exposed in the papers (as one person present obscurely threatened) I 
considered the matter, and at length said, that if the lawyer would give me a confidential interview 
with the scrivener, in his (the lawyer's) own room, I would that afternoon strive my best to rid 
them of the nuisance they complained of. 
Going up stairs to my old haunt, there was Bartleby silently sitting upon the banister at the 
landing. 
"What are you doing here, Bartleby?" said I. 
"Sitting upon the banister," he mildly replied. 
I motioned him into the lawyer's room, who then left us. 
"Bartleby," said I, "are you aware that you are the cause of great tribulation to me, by persisting in 
occupying the entry after being dismissed from the office?" 
No answer. 
"Now one of two things must take place. Either you must do something, or something must be 
done to you. Now what sort of business would you like to engage in? Would you like to re-engage 
in copying for some one?" 
"No; I would prefer not to make any change." 
"Would you like a clerkship in a dry-goods store?" 
"There is too much confinement about that. No, I would not like a clerkship; but I am not 
particular." 
"Too much confinement," I cried, "why you keep yourself confined all the time!" 
"I would prefer not to take a clerkship," he rejoined, as if to settle that little item at once. 
"How would a bar-tender's business suit you? There is no trying of the eyesight in that." 


## PDF page 39

39 
 
 
"I would not like it at all; though, as I said before, I am not particular." 
His unwonted wordiness inspirited me. I returned to the charge. 
"Well then, would you like to travel through the country collecting bills for the merchants? That 
would improve your health." 
"No, I would prefer to be doing something else." 
"How then would going as a companion to Europe, to entertain some young gentleman with your 
conversation,—how would that suit you?" 
"Not at all. It does not strike me that there is any thing definite about that. I like to be stationary. 
But I am not particular." 
"Stationary you shall be then," I cried, now losing all patience, and for the first time in all my 
exasperating connection with him fairly flying into a passion. "If you do not go away from these 
premises before night, I shall feel bound—indeed Iam bound—to—to—to quit the premises 
myself!" I rather absurdly concluded, knowing not with what possible threat to try to frighten his 
immobility into compliance. Despairing of all further efforts, I was precipitately leaving him, 
when a final thought occurred to me—one which had not been wholly unindulged before. 
"Bartleby," said I, in the kindest tone I could assume under such exciting circumstances, "will you 
go home with me now—not to my office, but my dwelling—and remain there till we can conclude 
upon some convenient arrangement for you at our leisure? Come, let us start now, right away." 
"No: at present I would prefer not to make any change at all." 
I answered nothing; but effectually dodging every one by the suddenness and rapidity of my flight, 
rushed from the building, ran up Wall-street towards Broadway, and jumping into the first 
omnibus was soon removed from pursuit. As soon as tranquility returned I distinctly perceived that 
I had now done all that I possibly could, both in respect to the demands of the landlord and his 
tenants, and with regard to my own desire and sense of duty, to benefit Bartleby, and shield him 
from rude persecution. I now strove to be entirely care-free and quiescent; and my conscience 
justified me in the attempt; though indeed it was not so successful as I could have wished. So 
fearful was I of being again hunted out by the incensed landlord and his exasperated tenants, that, 
surrendering my business to Nippers, for a few days I drove about the upper part of the town and 
through the suburbs, in my rockaway; crossed over to Jersey City and Hoboken, and paid fugitive 
visits to Manhattanville and Astoria. In fact I almost lived in my rockaway for the time. 
When again I entered my office, lo, a note from the landlord lay upon the desk. I opened it with 
trembling hands. It informed me that the writer had sent to the police, and had Bartleby removed 
to the Tombs as a vagrant. Moreover, since I knew more about him than any one else, he wished 
me to appear at that place, and make a suitable statement of the facts. These tidings had a 
conflicting effect upon me. At first I was indignant; but at last almost approved. The landlord's 
energetic, summary disposition had led him to adopt a procedure which I do not think I would 
have decided upon myself; and yet as a last resort, under such peculiar circumstances, it seemed 
the only plan. 
As I afterwards learned, the poor scrivener, when told that he must be conducted to the Tombs, 
offered not the slightest obstacle, but in his pale unmoving way, silently acquiesced. 
Some of the compassionate and curious bystanders joined the party; and headed by one of the 
constables arm in arm with Bartleby, the silent procession filed its way through all the noise, and 
heat, and joy of the roaring thoroughfares at noon. 
The same day I received the note I went to the Tombs, or to speak more properly, the Halls of 
Justice. Seeking the right officer, I stated the purpose of my call, and was informed that the 
individual I described was indeed within. I then assured the functionary that Bartleby was a 
perfectly honest man, and greatly to be compassionated, however unaccountably eccentric. I 


## PDF page 40

40 
 
 
narrated all I knew, and closed by suggesting the idea of letting him remain in as indulgent 
confinement as possible till something less harsh might be done—though indeed I hardly knew 
what. At all events, if nothing else could be decided upon, the alms-house must receive him. I then 
begged to have an interview. 
Being under no disgraceful charge, and quite serene and harmless in all his ways, they had 
permitted him freely to wander about the prison, and especially in the inclosed grass-platted yard 
thereof. And so I found him there, standing all alone in the quietest of the yards, his face towards a 
high wall, while all around, from the narrow slits of the jail windows, I thought I saw peering out 
upon him the eyes of murderers and thieves. 
"Bartleby!" 
"I know you," he said, without looking round,—"and I want nothing to say to you." 
"It was not I that brought you here, Bartleby," said I, keenly pained at his implied suspicion. "And 
to you, this should not be so vile a place. Nothing reproachful attaches to you by being here. And 
see, it is not so sad a place as one might think. Look, there is the sky, and here is the grass." 
"I know where I am," he replied, but would say nothing more, and so I left him. 
As I entered the corridor again, a broad meat-like man, in an apron, accosted me, and jerking his 
thumb over his shoulder said—"Is that your friend?" 
"Yes." 
"Does he want to starve? If he does, let him live on the prison fare, that's all." 
"Who are you?" asked I, not knowing what to make of such an unofficially speaking person in 
such a place. 
"I am the grub-man. Such gentlemen as have friends here, hire me to provide them with something 
good to eat." 
"Is this so?" said I, turning to the turnkey. 
He said it was. 
"Well then," said I, slipping some silver into the grub-man's hands (for so they called him). "I want 
you to give particular attention to my friend there; let him have the best dinner you can get. And 
you must be as polite to him as possible." 
"Introduce me, will you?" said the grub-man, looking at me with an expression which seem to say 
he was all impatience for an opportunity to give a specimen of his breeding. 
Thinking it would prove of benefit to the scrivener, I acquiesced; and asking the grub-man his 
name, went up with him to Bartleby. 
"Bartleby, this is Mr. Cutlets; you will find him very useful to you." 
"Your sarvant, sir, your sarvant," said the grub-man, making a low salutation behind his apron. 
"Hope you find it pleasant here, sir;—spacious grounds—cool apartments, sir—hope you'll stay 
with us some time—try to make it agreeable. May Mrs. Cutlets and I have the pleasure of your 
company to dinner, sir, in Mrs. Cutlets' private room?" 
"I prefer not to dine to-day," said Bartleby, turning away. "It would disagree with me; I am unused 
to dinners." So saying he slowly moved to the other side of the inclosure, and took up a position 
fronting the dead-wall. 
"How's this?" said the grub-man, addressing me with a stare of astonishment. "He's odd, aint he?" 
"I think he is a little deranged," said I, sadly. 
"Deranged? deranged is it? Well now, upon my word, I thought that friend of yourn was a 
gentleman forger; they are always pale and genteel-like, them forgers. I can't pity'em—can't help 
it, sir. Did you know Monroe Edwards?" he added touchingly, and paused. Then, laying his hand 


## PDF page 41

41 
 
 
pityingly on my shoulder, sighed, "he died of consumption at Sing-Sing. So you weren't 
acquainted with Monroe?" 
"No, I was never socially acquainted with any forgers. But I cannot stop longer. Look to my friend 
yonder. You will not lose by it. I will see you again." 
Some few days after this, I again obtained admission to the Tombs, and went through the corridors 
in quest of Bartleby; but without finding him. 
"I saw him coming from his cell not long ago," said a turnkey, "may be he's gone to loiter in the 
yards." 
So I went in that direction. 
"Are you looking for the silent man?" said another turnkey passing me. "Yonder he lies—sleeping 
in the yard there. 'Tis not twenty minutes since I saw him lie down." 
The yard was entirely quiet. It was not accessible to the common prisoners. The surrounding walls, 
of amazing thickness, kept off all sounds behind them. The Egyptian character of the masonry 
weighed upon me with its gloom. But a soft imprisoned turf grew under foot. The heart of the 
eternal pyramids, it seemed, wherein, by some strange magic, through the clefts, grass-seed, 
dropped by birds, had sprung. 
Strangely huddled at the base of the wall, his knees drawn up, and lying on his side, his head 
touching the cold stones, I saw the wasted Bartleby. But nothing stirred. I paused; then went close 
up to him; stooped over, and saw that his dim eyes were open; otherwise he seemed profoundly 
sleeping. Something prompted me to touch him. I felt his hand, when a tingling shiver ran up my 
arm and down my spine to my feet. 
The round face of the grub-man peered upon me now. "His dinner is ready. Won't he dine to-day, 
either? Or does he live without dining?" 
"Lives without dining," said I, and closed his eyes. 
"Eh!—He's asleep, aint he?" 
"With kings and counselors," murmured I. 
 
* * * * * * * * 
There would seem little need for proceeding further in this history. Imagination will readily supply 
the meager recital of poor Bartleby's interment. But ere parting with the reader, let me say, that if 
this little narrative has sufficiently interested him, to awaken curiosity as to who Bartleby was, and 
what manner of life he led prior to the present narrator's making his acquaintance, I can only reply, 
that in such curiosity I fully share, but am wholly unable to gratify it. Yet here I hardly know 
whether I should divulge one little item of rumor, which came to my ear a few months after the 
scrivener's decease. Upon what basis it rested, I could never ascertain; and hence, how true it is I 
cannot now tell. But inasmuch as this vague report has not been without certain strange suggestive 
interest to me, however sad, it may prove the same with some others; and so I will briefly mention 
it. The report was this: that Bartleby had been a subordinate clerk in the Dead Letter Office at 
Washington, from which he had been suddenly removed by a change in the administration. When I 
think over this rumor, I cannot adequately express the emotions which seize me. Dead letters! does 
it not sound like dead men? Conceive a man by nature and misfortune prone to a pallid 
hopelessness, can any business seem more fitted to heighten it than that of continually handling 
these dead letters, and assorting them for the flames? For by the cart-load they are annually 
burned. Sometimes from out the folded paper the pale clerk takes a ring:—the finger it was meant 
for, perhaps, moulders in the grave; a bank-note sent in swiftest charity:—he whom it would 
relieve, nor eats nor hungers any more; pardon for those who died despairing; hope for those who 


## PDF page 42

42 
 
 
died unhoping; good tidings for those who died stifled by unrelieved calamities. On errands of life, 
these letters speed to death. 
Ah Bartleby! Ah humanity! 
 
 


## PDF page 43

43 
 
 
“The Yellow Wallpaper” (1892), by Charlotte Perkins Gilman 
 
Charlotte Perkins Gilman (1860-1935) was an important figure in turn-of-the-century 
American feminism. In addition to fiction, she also wrote poetry, sociological studies and 
essays. She was lecturing on social change and women’s rights long before the 20th-
century feminist movement had even taken hold, and she was a role model for women of 
future generations. She is best remembered today for the 1892 story below, “The Yellow 
Wallpaper”. 
 
 
 
 
It is very seldom that mere ordinary people like John and myself secure ancestral halls for the summer. 
     A colonial mansion, a hereditary estate, I would say a haunted house, and reach the height of romantic 
felicity--but that would be asking too much of fate! 
     Still I will proudly declare that there is something queer about it. 
     Else, why should it be let so cheaply? And why have stood so long untenanted? 
     John laughs at me, of course, but one expects that in marriage. 
     John is practical in the extreme. He has no patience with faith, an intense horror of superstition, and he 
scoffs openly at any talk of things not to be felt and seen and put down in figures. 
     John is a physician, and perhaps--(I would not say it to a living soul, of course, but this is dead paper 
and a great relief to my mind)--perhaps that is one reason I do not get well faster. 
     You see he does not believe I am sick! 
     And what can one do? 
     If a physician of high standing, and one's own husband, assures friends and relatives that there is really 
nothing the matter with one but temporary nervous depression--a slight hysterical tendency-- what is one 
to do? 
     My brother is also a physician, and also of high standing, and he says the same thing. 
     So I take phosphates or phosphites--whichever it is, and tonics, and journeys, and air, and exercise, 
and am absolutely forbidden to "work" until I am well again. 
     Personally, I disagree with their ideas. 
     Personally, I believe that congenial work, with excitement and change, would do me good. 
     But what is one to do? 
     I did write for a while in spite of them; but it does exhaust me a good deal--having to be so sly about it, 
or else meet with heavy opposition. 
     I sometimes fancy that in my condition if I had less opposition and more society and stimulus--but 
John says the very worst thing I can do is to think about my condition, and I confess it always makes me 
feel bad. 
     So I will let it alone and talk about the house. 
     The most beautiful place! It is quite alone standing well back from the road, quite three miles from the 
village. It makes me think of English places that you read about, for there are hedges and walls and gates 
that lock, and lots of separate little houses for the gardeners and people. 
     There is a delicious garden! I never saw such a garden--large and shady, full of box-bordered paths, 
and lined with long grape-covered arbors with seats under them. 
     There were greenhouses, too, but they are all broken now. 
     There was some legal trouble, I believe, something about the heirs and coheirs; anyhow, the place has 
been empty for years. 
     That spoils my ghostliness, I am afraid, but I don't care--there is something strange about the house--I 
can feel it. 
     I even said so to John one moonlight evening but he said what I felt was a draught, and shut the 
window. 
     I get unreasonably angry with John sometimes I'm sure I never used to be so sensitive. I think it is due 
to this nervous condition. 
     But John says if I feel so, I shall neglect proper self-control; so I take pains to control myself-- before 


## PDF page 44

44 
 
 
him, at least, and that makes me very tired. 
     I don't like our room a bit. I wanted one downstairs that opened on the piazza and had roses all over 
the window, and such pretty old-fashioned chintz hangings! but John would not hear of it. 
     He said there was only one window and not room for two beds, and no near room for him if he took 
another. 
     He is very careful and loving, and hardly lets me stir without special direction. 
     I have a schedule prescription for each hour in the day; he takes all care from me, and so I feel basely 
ungrateful not to value it more. 
     He said we came here solely on my account, that I was to have perfect rest and all the air I could get. 
"Your exercise depends on your strength, my dear," said he, "and your food somewhat on your appetite; 
but air you can absorb all the time. ' So we took the nursery at the top of the house. 
     It is a big, airy room, the whole floor nearly, with windows that look all ways, and air and sunshine 
galore. It was nursery first and then playroom and gymnasium, I should judge; for the windows are barred 
for little children, and there are rings and things in the walls. 
     The paint and paper look as if a boys' school had used it. It is stripped off--the paper in great patches 
all around the head of my bed, about as far as I can reach, and in a great place on the other side of the 
room low down. I never saw a worse paper in my life. 
     One of those sprawling flamboyant patterns committing every artistic sin. 
     It is dull enough to confuse the eye in following, pronounced enough to constantly irritate and provoke 
study, and when you follow the lame uncertain curves for a little distance they suddenly commit suicide--
plunge off at outrageous angles, destroy themselves in unheard of contradictions. 
     The color is repellent, almost revolting; a smouldering unclean yellow, strangely faded by the slow-
turning sunlight. 
     It is a dull yet lurid orange in some places, a sickly sulphur tint in others. 
     No wonder the children hated it! I should hate it myself if I had to live in this room long. 
     There comes John, and I must put this away,--he hates to have me write a word. 
---------- 
 
We have been here two weeks, and I haven't felt like writing before, since that first day. 
     I am sitting by the window now, up in this atrocious nursery, and there is nothing to hinder my writing 
as much as I please, save lack of strength. 
     John is away all day, and even some nights when his cases are serious. 
     I am glad my case is not serious! 
     But these nervous troubles are dreadfully depressing. 
     John does not know how much I really suffer. He knows there is no reason to suffer, and that satisfies 
him. 
     Of course it is only nervousness. It does weigh on me so not to do my duty in any way! 
     I meant to be such a help to John, such a real rest and comfort, and here I am a comparative burden 
already! 
     Nobody would believe what an effort it is to do what little I am able,--to dress and entertain, and order 
things. 
     It is fortunate Mary is so good with the baby. Such a dear baby! 
     And yet I cannot be with him, it makes me so nervous. 
     I suppose John never was nervous in his life. He laughs at me so about this wall-paper! 
     At first he meant to repaper the room, but afterwards he said that I was letting it get the better of me, 
and that nothing was worse for a nervous patient than to give way to such fancies. 
     He said that after the wall-paper was changed it would be the heavy bedstead, and then the barred 
windows, and then that gate at the head of the stairs, and so on. 
     "You know the place is doing you good," he said, "and really, dear, I don't care to renovate the house 
just for a three months' rental." 
     "Then do let us go downstairs," I said, "there are such pretty rooms there." 
     Then he took me in his arms and called me a blessed little goose, and said he would go down to the 
cellar, if I wished, and have it whitewashed into the bargain. 
     But he is right enough about the beds and windows and things. 


## PDF page 45

45 
 
 
     It is an airy and comfortable room as any one need wish, and, of course, I would not be so silly as to 
make him uncomfortable just for a whim. 
     I'm really getting quite fond of the big room, all but that horrid paper. 
     Out of one window I can see the garden, those mysterious deepshaded arbors, the riotous old-
fashioned flowers, and bushes and gnarly trees. 
     Out of another I get a lovely view of the bay and a little private wharf belonging to the estate. There is 
a beautiful shaded lane that runs down there from the house. I always fancy I see people walking in these 
numerous paths and arbors, but John has cautioned me not to give way to fancy in the least. He says that 
with my imaginative power and habit of story-making, a nervous weakness like mine is sure to lead to all 
manner of excited fancies, and that I ought to use my will and good sense to check the tendency. So I try. 
     I think sometimes that if I were only well enough to write a little it would relieve the press of ideas and 
rest me. 
     But I find I get pretty tired when I try. 
     It is so discouraging not to have any advice and companionship about my work. When I get really 
well, John says we will ask Cousin Henry and Julia down for a long visit; but he says he would as soon 
put fireworks in my pillow-case as to let me have those stimulating people about now. 
     I wish I could get well faster. 
     But I must not think about that. This paper looks to me as if it knew what a vicious influence it had! 
     There is a recurrent spot where the pattern lolls like a broken neck and two bulbous eyes stare at you 
upside down. 
     I get positively angry with the impertinence of it and the everlastingness. Up and down and sideways 
they crawl, and those absurd, unblinking eyes are everywhere There is one place where two breaths didn't 
match, and the eyes go all up and down the line, one a little higher than the other. 
     I never saw so much expression in an inanimate thing before, and we all know how much expression 
they have! I used to lie awake as a child and get more entertainment and terror out of blank walls and 
plain furniture than most children could find in a toy-store. 
     I remember what a kindly wink the knobs of our big, old bureau used to have, and there was one chair 
that always seemed like a strong friend. 
     I used to feel that if any of the other things looked too fierce I could always hop into that chair and be 
safe. 
     The furniture in this room is no worse than inharmonious, however, for we had to bring it all from 
downstairs. I suppose when this was used as a playroom they had to take the nursery things out, and no 
wonder! I never saw such ravages as the children have made here. 
     The wall-paper, as I said before, is torn off in spots, and it sticketh closer than a brother--they must 
have had perseverance as well as hatred. 
     Then the floor is scratched and gouged and splintered, the plaster itself is dug out here and there, and 
this great heavy bed which is all we found in the room, looks as if it had been through the wars. 
     But I don't mind it a bit--only the paper. 
     There comes John's sister. Such a dear girl as she is, and so careful of me! I must not let her find me 
writing. 
     She is a perfect and enthusiastic housekeeper, and hopes for no better profession. I verily believe she 
thinks it is the writing which made me sick! 
     But I can write when she is out, and see her a long way off from these windows. 
     There is one that commands the road, a lovely shaded winding road, and one that just looks off over 
the country. A lovely country, too, full of great elms and velvet meadows. 
     This wall-paper has a kind of sub-pattern in a, different shade, a particularly irritating one, for you can 
only see it in certain lights, and not clearly then. 
     But in the places where it isn't faded and where the sun is just so--I can see a strange, provoking, 
formless sort of figure, that seems to skulk about behind that silly and conspicuous front design. 
     There's sister on the stairs! 
---------- 
 
Well, the Fourth of July is over! The people are all gone and I am tired out. John thought it might do 
me good to see a little company, so we just had mother and Nellie and the children down for a week. 


## PDF page 46

46 
 
 
     Of course I didn't do a thing. Jennie sees to everything now. 
     But it tired me all the same. 
     John says if I don't pick up faster he shall send me to Weir Mitchell in the fall. 
     But I don't want to go there at all. I had a friend who was in his hands once, and she says he is just like 
John and my brother, only more so! 
     Besides, it is such an undertaking to go so far. 
     I don't feel as if it was worth while to turn my hand over for anything, and I'm getting dreadfully 
fretful and querulous. 
     I cry at nothing, and cry most of the time. 
     Of course I don't when John is here, or anybody else, but when I am alone. 
     And I am alone a good deal just now. John is kept in town very often by serious cases, and Jennie is 
good and lets me alone when I want her to. 
     So I walk a little in the garden or down that lovely lane, sit on the porch under the roses, and lie down 
up here a good deal. 
     I'm getting really fond of the room in spite of the wall-paper. Perhaps because of the wall-paper. 
     It dwells in my mind so! 
     I lie here on this great immovable bed--it is nailed down, I believe--and follow that pattern about by 
the hour. It is as good as gymnastics, I assure you. I start, we'll say, at the bottom, down in the corner over 
there where it has not been touched, and I determine for the thousandth time that I will follow that 
pointless pattern to some sort of a conclusion. 
     I know a little of the principle of design, and I know this thing was not arranged on any laws of 
radiation, or alternation, or repetition, or symmetry, or anything else that I ever heard of. 
     It is repeated, of course, by the breadths, but not otherwise. 
     Looked at in one way each breadth stands alone, the bloated curves and flourishes--a kind of "debased 
Romanesque" with delirium tremens--go waddling up and down in isolated columns of fatuity. 
     But, on the other hand, they connect diagonally, and the sprawling outlines run off in great slanting 
waves of optic horror, like a lot of wallowing seaweeds in full chase. 
     The whole thing goes horizontally, too, at least it seems so, and I exhaust myself in trying to 
distinguish the order of its going in that direction. 
     They have used a horizontal breadth for a frieze, and that adds wonderfully to the confusion. 
     There is one end of the room where it is almost intact, and there, when the crosslights fade and the low 
sun shines directly upon it, I can almost fancy radiation after all,--the interminable grotesques seem to 
form around a common centre and rush off in headlong plunges of equal distraction. 
     It makes me tired to follow it. I will take a nap I guess. 
---------- 
I don't know why I should write this. 
     I don't want to. 
     I don't feel able. And I know John would think it absurd. But I must say what I feel and think in some 
way--it is such a relief! 
     But the effort is getting to be greater than the relief. 
     Half the time now I am awfully lazy, and lie down ever so much. 
     John says I mustn't lose my strength, and has me take cod liver oil and lots of tonics and things, to say 
nothing of ale and wine and rare meat. 
     Dear John! He loves me very dearly, and hates to have me sick. I tried to have a real earnest 
reasonable talk with him the other day, and tell him how I wish he would let me go and make a visit to 
Cousin Henry and Julia. 
     But he said I wasn't able to go, nor able to stand it after I got there; and I did not make out a very good 
case for myself, for I was crying before I had finished . 
     It is getting to be a great effort for me to think straight. Just this nervous weakness I suppose. 
     And dear John gathered me up in his arms, and just carried me upstairs and laid me on the bed, and sat 
by me and read to me till it tired my head. 
     He said I was his darling and his comfort and all he had, and that I must take care of myself for his 
sake, and keep well. 
     He says no one but myself can help me out of it, that I must use my will and self-control and not let 


## PDF page 47

47 
 
 
any silly fancies run away with me. 
     There's one comfort, the baby is well and happy, and does not have to occupy this nursery with the 
horrid wall-paper. 
     If we had not used it, that blessed child would have! What a fortunate escape! Why, I wouldn't have a 
child of mine, an impressionable little thing, live in such a room for worlds. 
     I never thought of it before, but it is lucky that John kept me here after all, I can stand it so much easier 
than a baby, you see. 
     Of course I never mention it to them any more--I am too wise,--but I keep watch of it all the same. 
     There are things in that paper that nobody knows but me, or ever will. 
     Behind that outside pattern the dim shapes get clearer every day. 
     It is always the same shape, only very numerous. 
     And it is like a woman stooping down and creeping about behind that pattern. I don't like it a bit. I 
wonder--I begin to think--I wish John would take me away from here! 
---------- 
 
It is so hard to talk with John about my case, because he is so wise, and because he loves me so. 
     But I tried it last night. 
     It was moonlight. The moon shines in all around just as the sun does. 
     I hate to see it sometimes, it creeps so slowly, and always comes in by one window or another. 
     John was asleep and I hated to waken him, so I kept still and watched the moonlight on that undulating 
wall-paper till I felt creepy. 
     The faint figure behind seemed to shake the pattern, just as if she wanted to get out. 
     I got up softly and went to feel and see if the paper did move, and when I came back John was awake. 
     "What is it, little girl?" he said. "Don't go walking about like that--you'll get cold." 
      I thought it was a good time to talk, so I told him that I really was not gaining here, and that I wished 
he would take me away. 
     "Why darling!" said he, "our lease will be up in three weeks, and I can't see how to leave before. 
     "The repairs are not done at home, and I cannot possibly leave town just now. Of course if you were in 
any danger, I could and would, but you really are better, dear, whether you can see it or not. I am a 
doctor, dear, and I know. You are gaining flesh and color, your appetite is better, I feel really much easier 
about you." 
     "I don't weigh a bit more," said 1, "nor as much; and my appetite may be better in the evening when 
you are here, but it is worse in the morning when you are away!" 
     "Bless her little heart!" said he with a big hug, "she shall be as sick as she pleases! But now let's 
improve the shining hours by going to sleep, and talk about it in the morning!" 
     "And you won't go away?" I asked gloomily. 
     "Why, how can 1, dear? It is only three weeks more and then we will take a nice little trip of a few 
days while Jennie is getting the house ready. Really dear you are better!" 
     "Better in body perhaps--" I began, and stopped short, for he sat up straight and looked at me with 
such a stern, reproachful look that I could not say another word. 
     "My darling," said he, "I beg of you, for my sake and for our child's sake, as well as for your own, that 
you will never for one instant let that idea enter your mind! There is nothing so dangerous, so fascinating, 
to a temperament like yours. It is a false and foolish fancy. Can you not trust me as a physician when I tell 
you so?" 
     So of course I said no more on that score, and we went to sleep before long. He thought I was asleep 
first, but I wasn't, and lay there for hours trying to decide whether that front pattern and the back pattern 
really did move together or separately. 
---------- 
 
On a pattern like this, by daylight, there is a lack of sequence, a defiance of law, that is a constant 
irritant to a normal mind. 
     The color is hideous enough, and unreliable enough, and infuriating enough, but the pattern is 
torturing. 
     You think you have mastered it, but just as you get well underway in following, it turns a back 


## PDF page 48

48 
 
 
somersault and there you are. It slaps you in the face, knocks you down, and tramples upon you. It is like 
a bad dream. 
     The outside pattern is a florid arabesque, reminding one of a fungus. If you can imagine a toadstool in 
joints, an interminable string of toadstools, budding and sprouting in endless convolutions--why, that is 
something like it. 
     That is, sometimes! 
     There is one marked peculiarity about this paper, a thing nobody seems to notice but myself, and that 
is that it changes as the light changes. 
     When the sun shoots in through the east window--I always watch for that first long, straight ray--it 
changes so quickly that I never can quite believe it. 
     That is why I watch it always. 
     By moonlight--the moon shines in all night when there is a moon--I wouldn't know it was the same 
paper. 
     At night in any kind of light, in twilight, candlelight, lamplight, and worst of all by moonlight, it 
becomes bars! The outside pattern I mean, and the woman behind it is as plain as can be. 
     I didn't realize for a long time what the thing was that showed behind, that dim sub-pattern, but now I 
am quite sure it is a woman. 
     By daylight she is subdued, quiet. I fancy it is the pattern that keeps her so still. It is so puzzling. It 
keeps me quiet by the hour. 
     I lie down ever so much now. John says it is good for me, and to sleep all I can. 
     Indeed he started the habit by making me lie down for an hour after each meal. 
     It is a very bad habit I am convinced, for you see I don't sleep. 
     And that cultivates deceit, for I don't tell them I'm awake--O no! 
     The fact is I am getting a little afraid of John. 
     He seems very queer sometimes, and even Jennie has an inexplicable look. 
     It strikes me occasionally, just as a scientific hypothesis,--that perhaps it is the paper! 
     I have watched John when he did not know I was looking, and come into the room suddenly on the 
most innocent excuses, and I've caught him several times looking at the paper! And Jennie too. I caught 
Jennie with her hand on it once. 
     She didn't know I was in the room, and when I asked her in a quiet, a very quiet voice, with the most 
restrained manner possible, what she was doing with the paper--she turned around as if she had been 
caught stealing, and looked quite angry-- asked me why I should frighten her so! 
     Then she said that the paper stained everything it touched, that she had found yellow smooches on all 
my clothes and John's, and she wished we would be more careful! 
     Did not that sound innocent? But I know she was studying that pattern, and I am determined that 
nobody shall find it out but myself! 
---------- 
 
Life is very much more exciting now than it used to be. You see I have something more to expect, to 
look forward to, to watch. I really do eat better, and am more quiet than I was. 
John is so pleased to see me improve ! He laughed a little the other day, and said I seemed to be 
flourishing in spite of my wall-paper. 
     I turned it off with a laugh. I had no intention of telling him it was because of the wall-paper--he 
would make fun of me. He might even want to take me away. 
     I don't want to leave now until I have found it out. There is a week more, and I think that will be 
enough. 
---------- 
 
I'm feeling ever so much better! I don't sleep much at night, for it is so interesting to watch 
developments; but I sleep a good deal in the daytime. 
     In the daytime it is tiresome and perplexing. 
     There are always new shoots on the fungus, and new shades of yellow all over it. I cannot keep count 
of them, though I have tried conscientiously. 


## PDF page 49

49 
 
 
     It is the strangest yellow, that wall-paper! It makes me think of all the yellow things I ever saw--not 
beautiful ones like buttercups, but old foul, bad yellow things. 
     But there is something else about that paper-- the smell! I noticed it the moment we came into the 
room, but with so much air and sun it was not bad. Now we have had a week of fog and rain, and whether 
the windows are open or not, the smell is here. 
     It creeps all over the house. 
     I find it hovering in the dining-room, skulking in the parlor, hiding in the hall, lying in wait for me on 
the stairs. 
     It gets into my hair. 
     Even when I go to ride, if I turn my head suddenly and surprise it--there is that smell! 
     Such a peculiar odor, too! I have spent hours in trying to analyze it, to find what it smelled like. 
     It is not bad--at first, and very gentle, but quite the subtlest, most enduring odor I ever met. 
     In this damp weather it is awful, I wake up in the night and find it hanging over me. 
     It used to disturb me at first. I thought seriously of burning the house--to reach the smell. 
     But now I am used to it. The only thing I can think of that it is like is the color of the paper! A yellow 
smell. 
     There is a very funny mark on this wall, low down, near the mopboard. A streak that runs round the 
room. It goes behind every piece of furniture, except the bed, a long, straight, even smooch, as if it had 
been rubbed over and over. 
     I wonder how it was done and who did it, and what they did it for. Round and round and round--round 
and round and round--it makes me dizzy! 
---------- 
 
I really have discovered something at last. 
     Through watching so much at night, when it changes so, I have finally found out. 
     The front pattern does move--and no wonder! The woman behind shakes it! 
     Sometimes I think there are a great many women behind, and sometimes only one, and she crawls 
around fast, and her crawling shakes it all over. 
     Then in the very bright spots she keeps still, and in the very shady spots she just takes hold of the bars 
and shakes them hard. 
     And she is all the time trying to climb through. But nobody could climb through that pattern--it 
strangles so; I think that is why it has so many heads. 
     They get through, and then the pattern strangles them off and turns them upside down, and makes their 
eyes white! 
     If those heads were covered or taken off it would not be half so bad. 
---------- 
 
I think that woman gets out in the daytime! 
     And I'll tell you why--privately--I've seen her! 
     I can see her out of every one of my windows! 
     It is the same woman, I know, for she is always creeping, and most women do not creep by daylight. 
     I see her on that long road under the trees, creeping along, and when a carriage comes she hides under 
the blackberry vines. 
     I don't blame her a bit. It must be very humiliating to be caught creeping by daylight! 
     I always lock the door when I creep by daylight. I can't do it at night, for I know John would suspect 
something at once. 
     And John is so queer now, that I don't want to irritate him. I wish he would take another room! 
Besides, I don't want anybody to get that woman out at night but myself. 
     I often wonder if I could see her out of all the windows at once. 
     But, turn as fast as I can, I can only see out of one at one time. 
     And though I always see her, she may be able to creep faster than I can turn! 
     I have watched her sometimes away off in the open country, creeping as fast as a cloud shadow in a 
high wind. 


## PDF page 50

50 
 
 
---------- 
 
If only that top pattern could be gotten off from the under one! I mean to try it, little by little. 
     I have found out another funny thing, but I shan't tell it this time! It does not do to trust people too 
much. 
     There are only two more days to get this paper off, and I believe John is beginning to notice. I don't 
like the look in his eyes. 
     And I heard him ask Jennie a lot of professional questions about me. She had a very good report to 
give. 
     She said I slept a good deal in the daytime. 
     John knows I don't sleep very well at night, for all I'm so quiet! 
     He asked me all sorts of questions, too, and pretended to be very loving and kind. 
     As if I couldn't see through him! 
     Still, I don't wonder he acts so, sleeping under this paper for three months. 
     It only interests me, but I feel sure John and Jennie are secretly affected by it. 
---------- 
 
Hurrah! This is the last day, but it is enough. John to stay in town over night, and won't be out until 
this evening. 
     Jennie wanted to sleep with me--the sly thing! but I told her I should undoubtedly rest better for a 
night all alone. 
     That was clever, for really I wasn't alone a bit! As soon as it was moonlight and that poor thing began 
to crawl and shake the pattern, I got up and ran to help her. 
     I pulled and she shook, I shook and she pulled, and before morning we had peeled off yards of that 
paper. 
     A strip about as high as my head and half around the room. 
     And then when the sun came and that awful pattern began to laugh at me, I declared I would finish it 
to-day! 
     We go away to-morrow, and they are moving all my furniture down again to leave things as they were 
before. 
     Jennie looked at the wall in amazement, but I told her merrily that I did it out of pure spite at the 
vicious thing. 
     She laughed and said she wouldn't mind doing it herself, but I must not get tired. 
     How she betrayed herself that time! 
     But I am here, and no person touches this paper but me,--not alive ! 
     She tried to get me out of the room--it was too patent! But I said it was so quiet and empty and clean 
now that I believed I would lie down again and sleep all I could; and not to wake me even for dinner--I 
would call when I woke. 
     So now she is gone, and the servants are gone, and the things are gone, and there is nothing left but 
that great bedstead nailed down, with the canvas mattress we found on it. 
     We shall sleep downstairs to-night, and take the boat home to-morrow. 
     I quite enjoy the room, now it is bare again. 
     How those children did tear about here! 
     This bedstead is fairly gnawed! 
     But I must get to work. 
     I have locked the door and thrown the key down into the front path. 
     I don't want to go out, and I don't want to have anybody come in, till John comes. 
     I want to astonish him. 
     I've got a rope up here that even Jennie did not find. If that woman does get out, and tries to get away, 
I can tie her! 
     But I forgot I could not reach far without anything to stand on! 
     This bed will not move! 
     I tried to lift and push it until I was lame, and then I got so angry I bit off a little piece at one corner--
but it hurt my teeth. 


## PDF page 51

51 
 
 
     Then I peeled off all the paper I could reach standing on the floor. It sticks horribly and the pattern just 
enjoys it! All those strangled heads and bulbous eyes and waddling fungus growths just shriek with 
derision! 
      I am getting angry enough to do something desperate. To jump out of the window would be admirable 
exercise, but the bars are too strong even to try. 
     Besides I wouldn't do it. Of course not. I know well enough that a step like that is improper and might 
be misconstrued. 
     I don't like to look out of the windows even-- there are so many of those creeping women, and they 
creep so fast. 
     I wonder if they all come out of that wall-paper as I did? 
     But I am securely fastened now by my well-hidden rope--you don't get me out in the road there ! 
     I suppose I shall have to get back behind the pattern when it comes night, and that is hard! 
     It is so pleasant to be out in this great room and creep around as I please! 
     I don't want to go outside. I won't, even if Jennie asks me to. 
     For outside you have to creep on the ground, and everything is green instead of yellow. 
     But here I can creep smoothly on the floor, and my shoulder just fits in that long smooch around the 
wall, so I cannot lose my way. 
     Why there's John at the door! 
     It is no use, young man, you can't open it! 
     How he does call and pound! 
     Now he's crying for an axe. 
     It would be a shame to break down that beautiful door! 
     "John dear!" said I in the gentlest voice, "the key is down by the front steps, under a plantain leaf!" 
     That silenced him for a few moments. 
     Then he said--very quietly indeed, "Open the door, my darling!" 
     "I can't," said I. "The key is down by the front door under a plantain leaf!" 
     And then I said it again, several times, very gently and slowly, and said it so often that he had to go 
and see, and he got it of course, and came in. He stopped short by the door. 
     "What is the matter?" he cried. "For God's sake, what are you doing!" 
     I kept on creeping just the same, but I looked at him over my shoulder. 
     "I've got out at last," said I, "in spite of you and Jane. And I've pulled off most of the paper, so you 
can't put me back!" 
     Now why should that man have fainted? But he did, and right across my path by the wall, so that I had 
to creep over him every time! 


## PDF page 52

52 
 
 
“The Gift of the Magi” (1905), O. Henry (William Sydney Porter) 
 
The American writer O. Henry (1862-1910) will forever be associated with the popular and 
effective short story, particularly those with a well-prepared twist or ironic ending.   
Below is his well-known Christmas story, “The Gift of the Magi”, the touching story of a poor 
young couple who have no money with which to buy each other Christmas presents. Note the 
unusual stance that the narrator takes in this heart-warming but humorous Chrsitmas story. 
 
One dollar and eighty-seven cents. That was all. And sixty cents of it was in pennies. Pennies saved one 
and two at a time by bulldozing the grocer and the vegetable man and the butcher until one's cheeks 
burned with the silent imputation of parsimony that such close dealing implied. Three times Della 
counted it. One dollar and eighty-seven cents. And the next day would be Christmas. 
There was clearly nothing to do but flop down on the shabby little couch and howl. So Della did it. 
Which instigates the moral reflection that life is made up of sobs, sniffles, and smiles, with sniffles 
predominating. 
While the mistress of the home is gradually subsiding from the first stage to the second, take a look at 
the home. A furnished flat at $8 per week. It did not exactly beggar description, but it certainly had that 
word on the lookout for the mendicancy squad. 
In the vestibule below was a letter-box into which no letter would go, and an electric button from which 
no mortal finger could coax a ring. Also appertaining thereunto was a card bearing the name “Mr. James 
Dillingham Young.” The “Dillingham” had been flung to the breeze during a former period of prosperity 
when its possessor was being paid $30 per week. Now, when the income was shrunk to $20, the letters 
of “Dillingham” looked blurred, as though they were thinking seriously of contracting to a modest and 
unassuming D. But whenever Mr. James Dillingham Young came home and reached his flat above he 
was called “Jim” and greatly hugged by Mrs. James Dillingham Young, already introduced to you as 
Della. Which is all very good. 
Della finished her cry and attended to her cheeks with the powder rag. She stood by the window and 
looked out dully at a grey cat walking a grey fence in a grey backyard. Tomorrow would be Christmas 
Day, and she had only $1.87 with which to buy Jim a present. She had been saving every penny she 
could for months, with this result. Twenty dollars a week doesn't go far. Expenses had been greater than 
she had calculated. They always are. Only $1.87 to buy a present for Jim. Her Jim. Many a happy hour 
she had spent planning for something nice for him. Something fine and rare and sterling—something 
just a little bit near to being worthy of the honor of being owned by Jim. 
There was a pier-glass between the windows of the room. Perhaps you have seen a pier-glass in an $8 
flat. A very thin and very agile person may, by observing his reflection in a rapid sequence of 
longitudinal strips, obtain a fairly accurate conception of his looks. Della, being slender, had mastered 
the art. 
Suddenly she whirled from the window and stood before the glass. Her eyes were shining brilliantly, but 
her face had lost its color within twenty seconds. Rapidly she pulled down her hair and let it fall to its 
full length. 
Now, there were two possessions of the James Dillingham Youngs in which they both took a mighty 
pride. One was Jim's gold watch that had been his father's and his grandfather's. The other was Della's 
hair. Had the Queen of Sheba lived in the flat across the airshaft, Della would have let her hair hang out 
the window some day to dry just to depreciate Her Majesty's jewels and gifts. Had King Solomon been 
the janitor, with all his treasures piled up in the basement, Jim would have pulled out his watch every 
time he passed, just to see him pluck at his beard from envy. 
So now Della's beautiful hair fell about her, rippling and shining like a cascade of brown waters. It 
reached below her knee and made itself almost a garment for her. And then she did it up again nervously 
and quickly. Once she faltered for a minute and stood still while a tear or two splashed on the worn red 
carpet. 


## PDF page 53

53 
 
 
On went her old brown jacket; on went her old brown hat. With a whirl of skirts and with the brilliant 
sparkle still in her eyes, she fluttered out the door and down the stairs to the street. 
Where she stopped the sign read: “Mme. Sofronie. Hair Goods of All Kinds.” One flight up Della ran, 
and collected herself, panting. Madame, large, too white, chilly, hardly looked the “Sofronie.” 
“Will you buy my hair?” asked Della. 
“I buy hair,” said Madame. “Take yer hat off and let's have a sight at the looks of it.” 
Down rippled the brown cascade. “Twenty dollars,” said Madame, lifting the mass with a practised 
hand. 
“Give it to me quick,” said Della. 
Oh, and the next two hours tripped by on rosy wings. Forget the hashed metaphor. She was ransacking 
the stores for Jim's present. 
She found it at last. It surely had been made for Jim and no one else. There was no other like it in any of 
the stores, and she had turned all of them inside out. It was a platinum fob chain simple and chaste in 
design, properly proclaiming its value by substance alone and not by meretricious ornamentation—as all 
good things should do. It was even worthy of The Watch. As soon as she saw it she knew that it must be 
Jim's. It was like him. Quietness and value—the description applied to both. Twenty-one dollars they 
took from her for it, and she hurried home with the 87 cents. With that chain on his watch Jim might be 
properly anxious about the time in any company. Grand as the watch was, he sometimes looked at it on 
the sly on account of the old leather strap that he used in place of a chain. 
When Della reached home her intoxication gave way a little to prudence and reason. She got out her 
curling irons and lighted the gas and went to work repairing the ravages made by generosity added to 
love. Which is always a tremendous task, dear friends—a mammoth task. 
Within forty minutes her head was covered with tiny, close-lying curls that made her look wonderfully 
like a truant schoolboy. She looked at her reflection in the mirror long, carefully, and critically. 
“If Jim doesn't kill me,” she said to herself, “before he takes a second look at me, he'll say I look like a 
Coney Island chorus girl. But what could I do—oh! what could I do with a dollar and eighty-seven 
cents?” 
At 7 o'clock the coffee was made and the frying-pan was on the back of the stove hot and ready to cook 
the chops. 
Jim was never late. Della doubled the fob chain in her hand and sat on the corner of the table near the 
door that he always entered. Then she heard his step on the stair away down on the first flight, and she 
turned white for just a moment. She had a habit for saying little silent prayers about the simplest 
everyday things, and now she whispered: “Please God, make him think I am still pretty.” 
The door opened and Jim stepped in and closed it. He looked thin and very serious. Poor fellow, he was 
only twenty-two--and to be burdened with a family! He needed a new overcoat and he was without 
gloves. 
Jim stopped inside the door, as immovable as a setter at the scent of quail. His eyes were fixed upon 
Della, and there was an expression in them that she could not read, and it terrified her. It was not anger, 
nor surprise, nor disapproval, nor horror, nor any of the sentiments that she had been prepared for. He 
simply stared at her fixedly with that peculiar expression on his face. 
Della wriggled off the table and went for him. 
"Jim, darling," she cried, "don't look at me that way. I had my hair cut off and sold because I couldn't 
have lived through Christmas without giving you a present. It'll grow out again--you won't mind, will 
you? I just had to do it. My hair grows awfully fast. Say `Merry Christmas!' Jim, and let's be happy. You 
don't know what a nice-- what a beautiful, nice gift I've got for you." 
"You've cut off your hair?" asked Jim, laboriously, as if he had not arrived at that patent fact yet even 
after the hardest mental labor. 


## PDF page 54

54 
 
 
"Cut it off and sold it," said Della. "Don't you like me just as well, anyhow? I'm me without my hair, 
ain't I?" 
Jim looked about the room curiously. 
"You say your hair is gone?" he said, with an air almost of idiocy. 
"You needn't look for it," said Della. "It's sold, I tell you--sold and gone, too. It's Christmas Eve, boy. Be 
good to me, for it went for you. Maybe the hairs of my head were numbered," she went on with sudden 
serious sweetness, "but nobody could ever count my love for you. Shall I put the chops on, Jim?" 
Out of his trance Jim seemed quickly to wake. He enfolded his Della. For ten seconds let us regard with 
discreet scrutiny some inconsequential object in the other direction. Eight dollars a week or a million a 
year--what is the difference? A mathematician or a wit would give you the wrong answer.  
The magi brought valuable gifts, but that was not among them. This dark assertion will be illuminated 
later on. 
Jim drew a package from his overcoat pocket and threw it upon the table. 
"Don't make any mistake, Dell," he said, "about me. I don't think there's anything in the way of a haircut 
or a shave or a shampoo that could make me like my girl any less. But if you'll unwrap that package you 
may see why you had me going a while at first." 
White fingers and nimble tore at the string and paper. And then an ecstatic scream of joy; and then, alas! 
a quick feminine change to hysterical tears and wails, necessitating the immediate employment of all the 
comforting powers of the lord of the flat. 
For there lay The Combs--the set of combs, side and back, that Della had worshipped long in a 
Broadway window. Beautiful combs, pure tortoise shell, with jewelled rims--just the shade to wear in 
the beautiful vanished hair. They were expensive combs, she knew, and her heart had simply craved and 
yearned over them without the least hope of possession. And now, they were hers, but the tresses that 
should have adorned the coveted adornments were gone. 
But she hugged them to her bosom, and at length she was able to look up with dim eyes and a smile and 
say: "My hair grows so fast, Jim!" 
And them Della leaped up like a little singed cat and cried, "Oh, oh!" 
Jim had not yet seen his beautiful present. She held it out to him eagerly upon her open palm. The dull 
precious metal seemed to flash with a reflection of her bright and ardent spirit. 
"Isn't it a dandy, Jim? I hunted all over town to find it. You'll have to look at the time a hundred  times 
a day now. Give me your watch. I want to see how it looks on it." 
Instead of obeying, Jim tumbled down on the couch and put his hands under the back of his head and 
smiled. 
"Dell," said he, "let's put our Christmas presents away and keep 'em a while. They're too nice to use just 
at present. I sold the watch to get the money to buy your combs. And now suppose you put the chops 
on." 
The magi, as you know, were wise men--wonderfully wise men--who brought gifts to the Babe in the 
manger. They invented the art of giving Christmas presents. Being wise, their gifts were no doubt wise 
ones, possibly bearing the privilege of exchange in case of duplication. And here I have lamely related 
to you the uneventful chronicle of two foolish children in a flat who most unwisely sacrificed for each 
other the greatest treasures of their house. But in a last word to the wise of these days let it be said that 
of all who give gifts these two were the wisest. O all who give and receive gifts, such as they are wisest. 
Everywhere they are wisest. They are the magi. 
 


## PDF page 55

55 
 
 
 “The Open Window” (1914), Saki (H.H. Munro) 
 
 
Often compared to O.Henry, Saki (born Hector Hugh Monro, 1870-1916) was a British 
writer who wrote extremely popular short stories. His tales were often playful or even 
somewhat macabre, as is the case in the sample below. “The Open Window” is one of his 
most popular and most anthologized short stories. In spite of its brevity, it contains all the 
key plot elements of a longer piece of fiction and still has a carefully prepared ending.  
 
 
"MY aunt will be down presently, Mr. Nuttel," said a very self-possessed young lady of fifteen; "in the 
meantime you must try and put up with me." 
Framton Nuttel endeavoured to say the correct something which should duly flatter the niece of the 
moment without unduly discounting the aunt that was to come.  Privately he doubted more than ever 
whether these formal visits on a succession of total strangers would do much towards helping the nerve 
cure which he was supposed to be undergoing. 
"I know how it will be," his sister had said when he was preparing to migrate to this rural retreat; "you 
will bury yourself down there and not speak to a living soul, and your nerves will be worse than ever from 
moping.  I shall just give you letters of introduction to all the people I know there. Some of them, as far as I 
can remember, were quite nice." 
Framton wondered whether Mrs. Sappleton, the lady to whom he was presenting one of the letters of 
introduction, came into the nice division. 
"Do you know many of the people round here?" asked the niece, when she judged that they had had 
sufficient silent communion. 
"Hardly a soul," said Framton.  "My sister was staying here, at the rectory, you know, some four years 
ago, and she gave me letters of introduction to some of the people here." 
He made the last statement in a tone of distinct regret. 
"Then you know practically nothing about my aunt?" pursued the self-possessed young lady. 
"Only her name and address," admitted the caller.  He was wondering whether Mrs. Sappleton was in 
the married or widowed state.  An undefinable something about the room seemed to suggest masculine 
habitation. 
"Her great tragedy happened just three years ago," said the child; "that would be since your sister's 
time." 
"Her tragedy?" asked Framton; somehow in this restful country spot tragedies seemed out of place. 
"You may wonder why we keep that window wide open on an October afternoon," said the niece, 
indicating a large French window that opened on to a lawn. 
"It is quite warm for the time of the year," said Framton; "but has that window got anything to do with 
the tragedy?" 
"Out through that window, three years ago to a day, her husband and her two young brothers went off 
for their day's shooting.  They never came back.  In crossing the moor to their favourite snipe-shooting 
ground they were all three engulfed in a treacherous piece of bog.  It had been that dreadful wet summer, 
you know, and places that were safe in other years gave way suddenly without warning.   
Their bodies were never recovered.  That was the dreadful part of it."  Here the child's voice lost its self-
possessed note and became falteringly human.  "Poor aunt always thinks that they will come back some 
day, they and the little brown spaniel that was lost with them, and walk in at that window just as they used 
to do.  That is why the window is kept open every evening till it is quite dusk.  Poor dear aunt, she has often 
told me how they went out, her husband with his white waterproof coat over his arm, and Ronnie, her 
youngest brother, singing 'Bertie, why do you bound?' as he always did to tease her, because she said it got 
on her nerves.  Do you know, sometimes on still, quiet evenings like this, I almost get a creepy feeling that 
they will all walk in through that window – " 
She broke off with a little shudder.  It was a relief to Framton when the aunt bustled into the room with a 
whirl of apologies for being late in making her appearance. 


## PDF page 56

56 
 
 
"I hope Vera has been amusing you?" she said. 
"She has been very interesting," said Framton. 
"I hope you don't mind the open window," said Mrs. Sappleton briskly; "my husband and brothers will 
be home directly from shooting, and they always come in this way.  They've been out for snipe in the 
marshes to-day, so they'll make a fine mess over my poor carpets.  So like you men-folk, isn't it?" 
She rattled on cheerfully about the shooting and the scarcity of birds, and the prospects for duck in the 
winter.  To Framton it was all purely horrible.  He made a desperate but only partially successful effort to 
turn the talk on to a less ghastly topic; he was conscious that his hostess was giving him only a fragment of 
her attention, and her eyes were constantly straying past him to the open window and the lawn beyond.  It 
was certainly an unfortunate coincidence that he should have paid his visit on this tragic anniversary. 
"The doctors agree in ordering me complete rest, an absence of mental excitement, and avoidance of 
anything in the nature of violent physical exercise," announced Framton, who laboured under the tolerably 
wide-spread delusion that total strangers and chance acquaintances are hungry for the least detail of one's 
ailments and infirmities, their cause and cure.  "On the matter of diet they are not so much in agreement," 
he continued. 
"No?" said Mrs. Sappleton, in a voice which only replaced a yawn at the last moment.  Then she 
suddenly brightened into alert attention - but not to what Framton was saying. 
"Here they are at last!" she cried.  "Just in time for tea, and don't they look as if they were muddy up to 
the eyes!" 
Framton shivered slightly and turned towards the niece with a look intended to convey sympathetic 
comprehension.  The child was staring out through the open window with dazed horror in her eyes.   
In a chill shock of nameless fear Framton swung round in his seat and looked in the same direction. 
In the deepening twilight three figures were walking across the lawn towards the window; they all 
carried guns under their arms, and one of them was additionally burdened with a white coat hung over his 
shoulders.  A tired brown spaniel kept close at their heels.  Noiselessly they neared the house, and then a 
hoarse young voice chanted out of the dusk: "I said, Bertie, why do you bound?" 
Framton grabbed wildly at his stick and hat; the hall-door, the gravel-drive, and the front gate were 
dimly-noted stages in his headlong retreat.  A cyclist coming along the road had to run into the hedge to 
avoid an imminent collision. 
"Here we are, my dear," said the bearer of the white mackintosh, coming in through the window; "fairly 
muddy, but most of it's dry.  Who was that who bolted out as we came up?" 
"A most extraordinary man, a Mr. Nuttel," said Mrs. Sappleton; "could only talk about his illnesses, and 
dashed off without a word of good-bye or apology when you arrived.  One would think he had seen a 
ghost." 
"I expect it was the spaniel," said the niece calmly; "he told me he had a horror of dogs.  He was once 
hunted into a cemetery somewhere on the banks of the Ganges by a pack of pariah dogs, and had to spend 
the night in a newly dug grave with the creatures snarling and grinning and foaming just above him. 
Enough to make anyone their nerve." 
Romance at short notice was her speciality. 
  


## PDF page 57

57 
 
 
“Araby” (1914), James JOYCE 
 
 
In 1914, James Joyce (1882-1941) published a collection of short stories entitled Dubliners. 
Though each story deals with different characters, they are all set in Dublin and successively 
cover the different stages of life, from childhood to old age and death. Below is one of his 
most popular stories about childhood and a boy’s first crush. 
 
North Richmond Street, being blind, was a quiet street except at the hour when the Christian Brothers' 
School set the boys free. An uninhabited house of two storeys stood at the blind end, detached from its 
neighbours in a square ground. The other houses of the street, conscious of decent lives within them, 
gazed at one another with brown imperturbable faces. 
 
The former tenant of our house, a priest, had died in the back drawing-room. Air, musty from having been 
long enclosed, hung in all the rooms, and the waste room behind the kitchen was littered with old useless 
papers. Among these I found a few paper-covered books, the pages of which were curled and damp: The 
Abbot, by Walter Scott, The Devout Communicant, and The Memoirs of Vidocq. I liked the last best 
because its leaves were yellow. The wild garden behind the house contained a central apple-tree and a 
few straggling bushes, under one of which I found the late tenant's rusty bicycle-pump. He had been a 
very charitable priest; in his will he had left all his money to institutions and the furniture of his house to 
his sister. 
 
When the short days of winter came, dusk fell before we had well eaten our dinners. When we met in the 
street the houses had grown sombre. The space of sky above us was the colour of ever-changing violet 
and towards it the lamps of the street lifted their feeble lanterns. The cold air stung us and we played till 
our bodies glowed. Our shouts echoed in the silent street. The career of our play brought us through the 
dark muddy lanes behind the houses, where we ran the gauntlet of the rough tribes from the cottages, to 
the back doors of the dark dripping gardens where odours arose from the ashpits, to the dark odorous 
stables where a coachman smoothed and combed the horse or shook music from the buckled harness. 
When we returned to the street, light from the kitchen windows had filled the areas. If my uncle was seen 
turning the corner, we hid in the shadow until we had seen him safely housed. Or if Mangan's sister came 
out on the doorstep to call her brother in to his tea, we watched her from our shadow peer up and down 
the street. We waited to see whether she would remain or go in and, if she remained, we left our shadow 
and walked up to Mangan's steps resignedly. She was waiting for us, her figure defined by the light from 
the half-opened door. Her brother always teased her before he obeyed, and I stood by the railings looking 
at her. Her dress swung as she moved her body, and the soft rope of her hair tossed from side to side. 
 
Every morning I lay on the floor in the front parlour watching her door. The blind was pulled down to 
within an inch of the sash so that I could not be seen. When she came out on the doorstep my heart 
leaped. I ran to the hall, seized my books and followed her. I kept her brown figure always in my eye and, 
when we came near the point at which our ways diverged, I quickened my pace and passed her. This 
happened morning after morning. I had never spoken to her, except for a few casual words, and yet her 
name was like a summons to all my foolish blood. 
 
Her image accompanied me even in places the most hostile to romance. On Saturday evenings when my 
aunt went marketing I had to go to carry some of the parcels. We walked through the flaring streets, 
jostled by drunken men and bargaining women, amid the curses of labourers, the shrill litanies of shop-
boys who stood on guard by the barrels of pigs' cheeks, the nasal chanting of street-singers, who sang 
a come-all-you about O'Donovan Rossa, or a ballad about the troubles in our native land. These noises 
converged in a single sensation of life for me: I imagined that I bore my chalice safely through a throng of 
foes. Her name sprang to my lips at moments in strange prayers and praises which I myself did not 
understand. My eyes were often full of tears (I could not tell why) and at times a flood from my heart 
seemed to pour itself out into my bosom. I thought little of the future. I did not know whether I would 
ever speak to her or not or, if I spoke to her, how I could tell her of my confused adoration. But my body 
was like a harp and her words and gestures were like fingers running upon the wires. 
 


## PDF page 58

58 
 
 
One evening I went into the back drawing-room in which the priest had died. It was a dark rainy evening 
and there was no sound in the house. Through one of the broken panes I heard the rain impinge upon the 
earth, the fine incessant needles of water playing in the sodden beds. Some distant lamp or lighted 
window gleamed below me. I was thankful that I could see so little. All my senses seemed to desire to 
veil themselves and, feeling that I was about to slip from them, I pressed the palms of my hands together 
until they trembled, murmuring: 'O love! O love!' many times. 
 
At last she spoke to me. When she addressed the first words to me I was so confused that I did not know 
what to answer. She asked me was I going to Araby. I forgot whether I answered yes or no. It would be a 
splendid bazaar; she said she would love to go. 
 
'And why can't you?' I asked. 
 
While she spoke she turned a silver bracelet round and round her wrist. She could not go, she said, 
because there would be a retreat that week in her convent. Her brother and two other boys were fighting 
for their caps, and I was alone at the railings. She held one of the spikes, bowing her head towards me. 
The light from the lamp opposite our door caught the white curve of her neck, lit up her hair that rested 
there and, falling, lit up the hand upon the railing. It fell over one side of her dress and caught the white 
border of a petticoat, just visible as she stood at ease. 
 
'It's well for you,' she said. 
 
'If I go,' I said, 'I will bring you something.' 
 
What innumerable follies laid waste my waking and sleeping thoughts after that evening! I wished to 
annihilate the tedious intervening days. I chafed against the work of school. At night in my bedroom and 
by day in the classroom her image came between me and the page I strove to read. The syllables of the 
word Araby were called to me through the silence in which my soul luxuriated and cast an Eastern 
enchantment over me. I asked for leave to go to the bazaar on Saturday night. My aunt was surprised, and 
hoped it was not some Freemason affair. I answered few questions in class. I watched my master's face 
pass from amiability to sternness; he hoped I was not beginning to idle. I could not call my wandering 
thoughts together. I had hardly any patience with the serious work of life which, now that it stood 
between me and my desire, seemed to me child's play, ugly monotonous child's play. 
 
On Saturday morning I reminded my uncle that I wished to go to the bazaar in the evening. He was 
fussing at the hallstand, looking for the hat-brush, and answered me curtly: 
 
'Yes, boy, I know.' 
 
As he was in the hall I could not go into the front parlour and lie at the window. I felt the house in bad 
humour and walked slowly towards the school. The air was pitilessly raw and already my heart misgave 
me. 
 
When I came home to dinner my uncle had not yet been home. Still it was early. I sat staring at the clock 
for some time and, when its ticking began to irritate me, I left the room. I mounted the staircase and 
gained the upper part of the house. The high, cold, empty, gloomy rooms liberated me and I went from 
room to room singing. From the front window I saw my companions playing below in the street. Their 
cries reached me weakened and indistinct and, leaning my forehead against the cool glass, I looked over 
at the dark house where she lived. I may have stood there for an hour, seeing nothing but the brown-clad 
figure cast by my imagination, touched discreetly by the lamplight at the curved neck, at the hand upon 
the railings and at the border below the dress. 
 
When I came downstairs again I found Mrs Mercer sitting at the fire. She was an old, garrulous woman, a 
pawnbroker's widow, who collected used stamps for some pious purpose. I had to endure the gossip of the 
tea-table. The meal was prolonged beyond an hour and still my uncle did not come. Mrs Mercer stood up 
to go: she was sorry she couldn't wait any longer, but it was after eight o'clock and she did not like to be 
out late, as the night air was bad for her. When she had gone I began to walk up and down the room, 
clenching my fists. My aunt said: 


## PDF page 59

59 
 
 
 
'I'm afraid you may put off your bazaar for this night of Our Lord.' 
 
At nine o'clock I heard my uncle's latchkey in the hall door. I heard him talking to himself and heard the 
hallstand rocking when it had received the weight of his overcoat. I could interpret these signs. When he 
was midway through his dinner I asked him to give me the money to go to the bazaar. He had forgotten. 
 
'The people are in bed and after their first sleep now,' he said. 
 
I did not smile. My aunt said to him energetically: 
 
'Can't you give him the money and let him go? You've kept him late enough as it is.' 
 
My uncle said he was very sorry he had forgotten. He said he believed in the old saying: 'All work and no 
play makes Jack a dull boy.' He asked me where I was going and, when I told him a second time, he 
asked me did I know The Arab's Farewell to his Steed. When I left the kitchen he was about to recite the 
opening lines of the piece to my aunt. 
 
I held a florin tightly in my hand as I strode down Buckingham Street towards the station. The sight of the 
streets thronged with buyers and glaring with gas recalled to me the purpose of my journey. I took my 
seat in a third-class carriage of a deserted train. After an intolerable delay the train moved out of the 
station slowly. It crept onward among ruinous houses and over the twinkling river. At Westland Row 
Station a crowd of people pressed to the carriage doors; but the porters moved them back, saying that it 
was a special train for the bazaar. I remained alone in the bare carriage. In a few minutes the train drew up 
beside an improvised wooden platform. I passed out on to the road and saw by the lighted dial of a clock 
that it was ten minutes to ten. In front of me was a large building which displayed the magical name. 
 
I could not find any sixpenny entrance and, fearing that the bazaar would be closed, I passed in quickly 
through a turnstile, handing a shilling to a weary-looking man. I found myself in a big hall girded at half 
its height by a gallery. Nearly all the stalls were closed and the greater part of the hall was in darkness. I 
recognized a silence like that which pervades a church after a service. I walked into the centre of the 
bazaar timidly. A few people were gathered about the stalls which were still open. Before a curtain, over 
which the words Café Chantant were written in coloured lamps, two men were counting money on a 
salver. I listened to the fall of the coins. 
 
Remembering with difficulty why I had come, I went over to one of the stalls and examined porcelain 
vases and flowered tea-sets. At the door of the stall a young lady was talking and laughing with two 
young gentlemen. I remarked their English accents and listened vaguely to their conversation. 
 
'O, I never said such a thing!' 
 
'O, but you did!' 
 
'O, but I didn't!' 
 
'Didn't she say that?' 
 
'Yes. I heard her.' 
 
'O, there's a... fib!' 
 
Observing me, the young lady came over and asked me did I wish to buy anything. The tone of her voice 
was not encouraging; she seemed to have spoken to me out of a sense of duty. I looked humbly at the 
great jars that stood like eastern guards at either side of the dark entrance to the stall and murmured: 
 
'No, thank you.' 
 
The young lady changed the position of one of the vases and went back to the two young men. They 
began to talk of the same subject. Once or twice the young lady glanced at me over her shoulder. 
 


## PDF page 60

60 
 
 
I lingered before her stall, though I knew my stay was useless, to make my interest in her wares seem the 
more real. Then I turned away slowly and walked down the middle of the bazaar. I allowed the two 
pennies to fall against the sixpence in my pocket. I heard a voice call from one end of the gallery that the 
light was out. The upper part of the hall was now completely dark. 
 
Gazing up into the darkness I saw myself as a creature driven and derided by vanity; and my eyes burned 
with anguish and anger. 


## PDF page 61

61 
 
 
“The Garden Party” (1922) by Katherine Mansfield 
 
Katherine Mansfield (1888-1923) was born in New Zealand into a wealthy 
colonial family, but at age 19 she would head to the UK and experience a 
scandalous bohemian life among artists and fellow modernist writers, though a 
life cut tragically short by tuberculosis at age 34. Her works often demonstrate 
her rebellion against aristocracy and respressive notions of colonialism. “The 
Garden Party” below is not only one of her most popular stories, it is also one 
of the most autobiographical… 
 
 
And after all the weather was ideal. They could not have had a more perfect day for a garden-party if 
they had ordered it. Windless, warm, the sky without a cloud. Only the blue was veiled with a haze of 
light gold, as it is sometimes in early summer. The gardener had been up since dawn, mowing the 
lawns and sweeping them, until the grass and the dark flat rosettes where the daisy plants had been 
seemed to shine. As for the roses, you could not help feeling they understood that roses are the only 
flowers that impress people at garden-parties; the only flowers that everybody is certain of knowing. 
Hundreds, yes, literally hundreds, had come out in a single night; the green bushes bowed down as 
though they had been visited by archangels. 
Breakfast was not yet over before the men came to put up the marquee. 
"Where do you want the marquee put, mother?" 
"My dear child, it's no use asking me. I'm determined to leave everything to you children this year. 
Forget I am your mother. Treat me as an honoured guest." 
But Meg could not possibly go and supervise the men. She had washed her hair before breakfast, and 
she sat drinking her coffee in a green turban, with a dark wet curl stamped on each cheek. Jose, the 
butterfly, always came down in a silk petticoat and a kimono jacket. 
"You'll have to go, Laura; you're the artistic one." 
Away Laura flew, still holding her piece of bread-and-butter. It's so delicious to have an excuse for 
eating out of doors, and besides, she loved having to arrange things; she always felt she could do it so 
much better than anybody else. 
Four men in their shirt-sleeves stood grouped together on the garden path. They carried staves covered 
with rolls of canvas, and they had big tool-bags slung on their backs. They looked impressive. Laura 
wished now that she had not got the bread-and-butter, but there was nowhere to put it, and she couldn't 
possibly throw it away. She blushed and tried to look severe and even a little bit short-sighted as she 
came up to them. 
"Good morning," she said, copying her mother's voice. But that sounded so fearfully affected that she 
was ashamed, and stammered like a little girl, "Oh - er - have you come - is it about the marquee?" 
"That's right, miss," said the tallest of the men, a lanky, freckled fellow, and he shifted his tool-bag, 
knocked back his straw hat and smiled down at her. "That's about it." 
His smile was so easy, so friendly that Laura recovered. What nice eyes he had, small, but such a dark 
blue! And now she looked at the others, they were smiling too. "Cheer up, we won't bite," their smile 
seemed to say. How very nice workmen were! And what a beautiful morning! She mustn't mention the 
morning; she must be business-like. The marquee. 
"Well, what about the lily-lawn? Would that do?" 
And she pointed to the lily-lawn with the hand that didn't hold the bread-and-butter. They turned, they 
stared in the direction. A little fat chap thrust out his under-lip, and the tall fellow frowned. 
"I don't fancy it," said he. "Not conspicuous enough. You see, with a thing like a marquee," and he 
turned to Laura in his easy way, "you want to put it somewhere where it'll give you a bang slap in the 
eye, if you follow me." 


## PDF page 62

62 
 
 
Laura's upbringing made her wonder for a moment whether it was quite respectful of a workman to 
talk to her of bangs slap in the eye. But she did quite follow him. 
"A corner of the tennis-court," she suggested. "But the band's going to be in one corner." 
"H'm, going to have a band, are you?" said another of the workmen. He was pale. He had a haggard 
look as his dark eyes scanned the tennis-court. What was he thinking? 
"Only a very small band," said Laura gently. Perhaps he wouldn't mind so much if the band was quite 
small. But the tall fellow interrupted. 
"Look here, miss, that's the place. Against those trees. Over there. That'll do fine." 
Against the karakas. Then the karaka-trees would be hidden. And they were so lovely, with their 
broad, gleaming leaves, and their clusters of yellow fruit. They were like trees you imagined growing 
on a desert island, proud, solitary, lifting their leaves and fruits to the sun in a kind of silent splendour. 
Must they be hidden by a marquee? 
They must. Already the men had shouldered their staves and were making for the place. Only the tall 
fellow was left. He bent down, pinched a sprig of lavender, put his thumb and forefinger to his nose 
and snuffed up the smell. When Laura saw that gesture she forgot all about the karakas in her wonder 
at him caring for things like that - caring for the smell of lavender. How many men that she knew 
would have done such a thing? Oh, how extraordinarily nice workmen were, she thought. Why 
couldn't she have workmen for her friends rather than the silly boys she danced with and who came to 
Sunday night supper? She would get on much better with men like these. 
It's all the fault, she decided, as the tall fellow drew something on the back of an envelope, something 
that was to be looped up or left to hang, of these absurd class distinctions. Well, for her part, she didn't 
feel them. Not a bit, not an atom ... And now there came the chock-chock of wooden hammers. Some 
one whistled, some one sang out, "Are you right there, matey?" "Matey!" The friendliness of it, the - 
the - Just to prove how happy she was, just to show the tall fellow how at home she felt, and how she 
despised stupid conventions, Laura took a big bite of her bread-and-butter as she stared at the little 
drawing. She felt just like a work-girl. 
"Laura, Laura, where are you? Telephone, Laura!" a voice cried from the house. 
"Coming!" Away she skimmed, over the lawn, up the path, up the steps, across the veranda, and into 
the porch. In the hall her father and Laurie were brushing their hats ready to go to the office. 
"I say, Laura," said Laurie very fast, "you might just give a squiz at my coat before this afternoon. See 
if it wants pressing." 
"I will," said she. Suddenly she couldn't stop herself. She ran at Laurie and gave him a small, quick 
squeeze. "Oh, I do love parties, don't you?" gasped Laura. 
"Rather," said Laurie's warm, boyish voice, and he squeezed his sister too, and gave her a gentle push. 
"Dash off to the telephone, old girl." 
The telephone. "Yes, yes; oh yes. Kitty? Good morning, dear. Come to lunch? Do, dear. Delighted of 
course. It will only be a very scratch meal - just the sandwich crusts and broken meringue-shells and 
what's left over. Yes, isn't it a perfect morning? Your white? Oh, I certainly should. One moment - 
hold the line. Mother's calling." And Laura sat back. "What, mother? Can't hear." 
Mrs. Sheridan's voice floated down the stairs. "Tell her to wear that sweet hat she had on last Sunday." 
"Mother says you're to wear that sweet hat you had on last Sunday. Good. One o'clock. Bye-bye." 
Laura put back the receiver, flung her arms over her head, took a deep breath, stretched and let them 
fall. "Huh," she sighed, and the moment after the sigh she sat up quickly. She was still, listening. All 
the doors in the house seemed to be open. The house was alive with soft, quick steps and running 
voices. The green baize door that led to the kitchen regions swung open and shut with a muffled thud. 
And now there came a long, chuckling absurd sound. It was the heavy piano being moved on its stiff 
castors. But the air! If you stopped to notice, was the air always like this? Little faint winds were 
playing chase, in at the tops of the windows, out at the doors. And there were two tiny spots of sun, 
one on the inkpot, one on a silver photograph frame, playing too. Darling little spots. Especially the 
one on the inkpot lid. It was quite warm. A warm little silver star. She could have kissed it. 


## PDF page 63

63 
 
 
The front door bell pealed, and there sounded the rustle of Sadie's print skirt on the stairs. A man's 
voice murmured; Sadie answered, careless, "I'm sure I don't know. Wait. I'll ask Mrs Sheridan." 
"What is it, Sadie?" Laura came into the hall. 
"It's the florist, Miss Laura." 
It was, indeed. There, just inside the door, stood a wide, shallow tray full of pots of pink lilies. No 
other kind. Nothing but lilies - canna lilies, big pink flowers, wide open, radiant, almost frighteningly 
alive on bright crimson stems. 
"O-oh, Sadie!" said Laura, and the sound was like a little moan. She crouched down as if to warm 
herself at that blaze of lilies; she felt they were in her fingers, on her lips, growing in her breast. 
"It's some mistake," she said faintly. "Nobody ever ordered so many. Sadie, go and find mother." 
But at that moment Mrs. Sheridan joined them. 
"It's quite right," she said calmly. "Yes, I ordered them. Aren't they lovely?" She pressed Laura's arm. 
"I was passing the shop yesterday, and I saw them in the window. And I suddenly thought for once in 
my life I shall have enough canna lilies. The garden-party will be a good excuse." 
"But I thought you said you didn't mean to interfere," said Laura. Sadie had gone. The florist's man 
was still outside at his van. She put her arm round her mother's neck and gently, very gently, she bit 
her mother's ear. 
"My darling child, you wouldn't like a logical mother, would you? Don't do that. Here's the man." 
He carried more lilies still, another whole tray. 
"Bank them up, just inside the door, on both sides of the porch, please," said Mrs. Sheridan. "Don't 
you agree, Laura?" 
"Oh, I do, mother." 
In the drawing-room Meg, Jose and good little Hans had at last succeeded in moving the piano. 
"Now, if we put this chesterfield against the wall and move everything out of the room except the 
chairs, don't you think?" 
"Quite." 
"Hans, move these tables into the smoking-room, and bring a sweeper to take these marks off the 
carpet and - one moment, Hans - " Jose loved giving orders to the servants, and they loved obeying 
her. She always made them feel they were taking part in some drama. "Tell mother and Miss Laura to 
come here at once. 
"Very good, Miss Jose." 
She turned to Meg. "I want to hear what the piano sounds like, just in case I'm asked to sing this 
afternoon. Let's try over 'This life is Weary.'" 
Pom! Ta-ta-ta Tee-ta! The piano burst out so passionately that Jose's face changed. She clasped her 
hands. She looked mournfully and enigmatically at her mother and Laura as they came in. 
"This Life is Wee-ary, A Tear - a Sigh. A Love that Chan-ges, This Life is Wee-ary, A Tear - a Sigh. 
A Love that Chan-ges, And then ... Good-bye!" 
But at the word "Good-bye," and although the piano sounded more desperate than ever, her face broke 
into a brilliant, dreadfully unsympathetic smile. 
"Aren't I in good voice, mummy?" she beamed. 
"This Life is Wee-ary, Hope comes to Die. A Dream - a Wa-kening." 
But now Sadie interrupted them. "What is it, Sadie?" 
"If you please, m'm, cook says have you got the flags for the sandwiches?" 
"The flags for the sandwiches, Sadie?" echoed Mrs. Sheridan dreamily. And the children knew by her 
face that she hadn't got them. "Let me see." And she said to Sadie firmly, "Tell cook I'll let her have 
them in ten minutes. 
Sadie went. 


## PDF page 64

64 
 
 
"Now, Laura," said her mother quickly, "come with me into the smoking-room. I've got the names 
somewhere on the back of an envelope. You'll have to write them out for me. Meg, go upstairs this 
minute and take that wet thing off your head. Jose, run and finish dressing this instant. Do you hear 
me, children, or shall I have to tell your father when he comes home to-night? And - and, Jose, pacify 
cook if you do go into the kitchen, will you? I'm terrified of her this morning." 
The envelope was found at last behind the dining-room clock, though how it had got there Mrs. 
Sheridan could not imagine. 
"One of you children must have stolen it out of my bag, because I remember vividly - cream cheese 
and lemon-curd. Have you done that?" 
"Yes." 
"Egg and--" Mrs. Sheridan held the envelope away from her. "It looks like mice. It can't be mice, can 
it?" 
"Olive, pet," said Laura, looking over her shoulder. 
"Yes, of course, olive. What a horrible combination it sounds. Egg and olive." 
They were finished at last, and Laura took them off to the kitchen. She found Jose there pacifying the 
cook, who did not look at all terrifying. 
"I have never seen such exquisite sandwiches," said Jose's rapturous voice. "How many kinds did you 
say there were, cook? Fifteen?" 
"Fifteen, Miss Jose." 
"Well, cook, I congratulate you." 
Cook swept up crusts with the long sandwich knife, and smiled broadly. 
"Godber's has come," announced Sadie, issuing out of the pantry. She had seen the man pass the 
window. 
That meant the cream puffs had come. Godber's were famous for their cream puffs. Nobody ever 
thought of making them at home. 
"Bring them in and put them on the table, my girl," ordered cook. 
Sadie brought them in and went back to the door. Of course Laura and Jose were far too grown-up to 
really care about such things. All the same, they couldn't help agreeing that the puffs looked very 
attractive. Very. Cook began arranging them, shaking off the extra icing sugar. 
"Don't they carry one back to all one's parties?" said Laura. 
"I suppose they do," said practical Jose, who never liked to be carried back. "They look beautifully 
light and feathery, I must say." 
"Have one each, my dears," said cook in her comfortable voice. "Yer ma won't know." 
Oh, impossible. Fancy cream puffs so soon after breakfast. The very idea made one shudder. All the 
same, two minutes later Jose and Laura were licking their fingers with that absorbed inward look that 
only comes from whipped cream. 
"Let's go into the garden, out by the back way," suggested Laura. "I want to see how the men are 
getting on with the marquee. They're such awfully nice men." 
But the back door was blocked by cook, Sadie, Godber's man and Hans. 
Something had happened. 
"Tuk-tuk-tuk," clucked cook like an agitated hen. Sadie had her hand clapped to her cheek as though 
she had toothache. Hans's face was screwed up in the effort to understand. Only Godber's man seemed 
to be enjoying himself; it was his story. 
"What's the matter? What's happened?" 
"There's been a horrible accident," said Cook. "A man killed." 
"A man killed! Where? How? When?" 
But Godber's man wasn't going to have his story snatched from under his very nose. 


## PDF page 65

65 
 
 
"Know those little cottages just below here, miss?" Know them? Of course, she knew them. "Well, 
there's a young chap living there, name of Scott, a carter. His horse shied at a traction-engine, corner 
of Hawke Street this morning, and he was thrown out on the back of his head. Killed." 
"Dead!" Laura stared at Godber's man. 
"Dead when they picked him up," said Godber's man with relish. "They were taking the body home as 
I come up here." And he said to the cook, "He's left a wife and five little ones." 
"Jose, come here." Laura caught hold of her sister's sleeve and dragged her through the kitchen to the 
other side of the green baize door. There she paused and leaned against it. "Jose!" she said, horrified, 
"however are we going to stop everything?" 
"Stop everything, Laura!" cried Jose in astonishment. "What do you mean?" 
"Stop the garden-party, of course." Why did Jose pretend? 
But Jose was still more amazed. "Stop the garden-party? My dear Laura, don't be so absurd. Of course 
we can't do anything of the kind. Nobody expects us to. Don't be so extravagant." 
"But we can't possibly have a garden-party with a man dead just outside the front gate." 
That really was extravagant, for the little cottages were in a lane to themselves at the very bottom of a 
steep rise that led up to the house. A broad road ran between. True, they were far too near. They were 
the greatest possible eyesore, and they had no right to be in that neighbourhood at all. They were little 
mean dwellings painted a chocolate brown. In the garden patches there was nothing but cabbage 
stalks, sick hens and tomato cans. The very smoke coming out of their chimneys was poverty-stricken. 
Little rags and shreds of smoke, so unlike the great silvery plumes that uncurled from the Sheridans' 
chimneys. Washerwomen lived in the lane and sweeps and a cobbler, and a man whose house-front 
was studded all over with minute bird-cages. Children swarmed. When the Sheridans were little they 
were forbidden to set foot there because of the revolting language and of what they might catch. But 
since they were grown up, Laura and Laurie on their prowls sometimes walked through. It was 
disgusting and sordid. They came out with a shudder. But still one must go everywhere; one must see 
everything. So through they went. 
"And just think of what the band would sound like to that poor woman," said Laura. 
"Oh, Laura!" Jose began to be seriously annoyed. "If you're going to stop a band playing every time 
someone has an accident, you'll lead a very strenuous life. I'm every bit as sorry about it as you. I feel 
just as sympathetic." Her eyes hardened. She looked at her sister just as she used to when they were 
little and fighting together. "You won't bring a drunken workman back to life by being sentimental," 
she said softly. 
"Drunk! Who said he was drunk?" Laura turned furiously on Jose. She said, just as they had used to 
say on those occasions, "I'm going straight up to tell mother." 
"Do, dear," cooed Jose. 
"Mother, can I come into your room?" Laura turned the big glass door-knob. 
"Of course, child. Why, what's the matter? What's given you such a colour?" And Mrs. Sheridan 
turned round from her dressing-table. She was trying on a new hat. 
"Mother, a man's been killed," began Laura. 
"Not in the garden?" interrupted her mother. 
"No, no!" 
"Oh, what a fright you gave me!" Mrs. Sheridan sighed with relief, and took off the big hat and held it 
on her knees. 
"But listen, mother," said Laura. Breathless, half-choking, she told the dreadful story. "Of course, we 
can't have our party, can we?" she pleaded. "The band and everybody arriving. They'd hear us, mother; 
they're nearly neighbours!" 
To Laura's astonishment her mother behaved just like Jose; it was harder to bear because she seemed 
amused. She refused to take Laura seriously. 


## PDF page 66

66 
 
 
"But, my dear child, use your common sense. It's only by accident we've heard of it. If some one had 
died there normally - and I can't understand how they keep alive in those poky little holes - we should 
still be having our party, shouldn't we?" 
Laura had to say "yes" to that, but she felt it was all wrong. She sat down on her mother's sofa and 
pinched the cushion frill. 
"Mother, isn't it terribly heartless of us?" she asked. 
"Darling!" Mrs. Sheridan got up and came over to her, carrying the hat. Before Laura could stop her 
she had popped it on. "My child!" said her mother, "the hat is yours. It's made for you. It's much too 
young for me. I have never seen you look such a picture. Look at yourself!" And she held up her hand-
mirror. 
"But, mother," Laura began again. She couldn't look at herself; she turned aside. 
This time Mrs. Sheridan lost patience just as Jose had done. 
"You are being very absurd, Laura," she said coldly. "People like that don't expect sacrifices from us. 
And it's not very sympathetic to spoil everybody's enjoyment as you're doing now." 
"I don't understand," said Laura, and she walked quickly out of the room into her own bedroom. 
There, quite by chance, the first thing she saw was this charming girl in the mirror, in her black hat 
trimmed with gold daisies, and a long black velvet ribbon. Never had she imagined she could look like 
that. Is mother right? she thought. And now she hoped her mother was right. Am I being extravagant? 
Perhaps it was extravagant. Just for a moment she had another glimpse of that poor woman and those 
little children, and the body being carried into the house. But it all seemed blurred, unreal, like a 
picture in the newspaper. I'll remember it again after the party's over, she decided. And somehow that 
seemed quite the best plan ... 
Lunch was over by half-past one. By half-past two they were all ready for the fray. The green-coated 
band had arrived and was established in a corner of the tennis-court. 
"My dear!" trilled Kitty Maitland, "aren't they too like frogs for words? You ought to have arranged 
them round the pond with the conductor in the middle on a leaf." 
Laurie arrived and hailed them on his way to dress. At the sight of him Laura remembered the accident 
again. She wanted to tell him. If Laurie agreed with the others, then it was bound to be all right. And 
she followed him into the hall. 
"Laurie!" 
"Hallo!" He was half-way upstairs, but when he turned round and saw Laura he suddenly puffed out 
his cheeks and goggled his eyes at her. "My word, Laura! You do look stunning," said Laurie. "What 
an absolutely topping hat!" 
Laura said faintly "Is it?" and smiled up at Laurie, and didn't tell him after all. 
Soon after that people began coming in streams. The band struck up; the hired waiters ran from the 
house to the marquee. Wherever you looked there were couples strolling, bending to the flowers, 
greeting, moving on over the lawn. They were like bright birds that had alighted in the Sheridans' 
garden for this one afternoon, on their way to - where? Ah, what happiness it is to be with people who 
all are happy, to press hands, press cheeks, smile into eyes. 
"Darling Laura, how well you look!" 
"What a becoming hat, child!" 
"Laura, you look quite Spanish. I've never seen you look so striking." 
And Laura, glowing, answered softly, "Have you had tea? Won't you have an ice? The passion-fruit 
ices really are rather special." She ran to her father and begged him. "Daddy darling, can't the band 
have something to drink?" 
And the perfect afternoon slowly ripened, slowly faded, slowly its petals closed. 
"Never a more delightful garden-party ... " "The greatest success ... " "Quite the most ... " 
Laura helped her mother with the good-byes. They stood side by side in the porch till it was all over. 


## PDF page 67

67 
 
 
"All over, all over, thank heaven," said Mrs. Sheridan. "Round up the others, Laura. Let's go and have 
some fresh coffee. I'm exhausted. Yes, it's been very successful. But oh, these parties, these parties! 
Why will you children insist on giving parties!" And they all of them sat down in the deserted 
marquee. 
"Have a sandwich, daddy dear. I wrote the flag." 
"Thanks." Mr. Sheridan took a bite and the sandwich was gone. He took another. "I suppose you didn't 
hear of a beastly accident that happened to-day?" he said. 
"My dear," said Mrs. Sheridan, holding up her hand, "we did. It nearly ruined the party. Laura insisted 
we should put it off." 
"Oh, mother!" Laura didn't want to be teased about it. 
"It was a horrible affair all the same," said Mr. Sheridan. "The chap was married too. Lived just below 
in the lane, and leaves a wife and half a dozen kiddies, so they say." 
An awkward little silence fell. Mrs. Sheridan fidgeted with her cup. Really, it was very tactless of 
father... 
Suddenly she looked up. There on the table were all those sandwiches, cakes, puffs, all uneaten, all 
going to be wasted. She had one of her brilliant ideas. 
"I know," she said. "Let's make up a basket. Let's send that poor creature some of this perfectly good 
food. At any rate, it will be the greatest treat for the children. Don't you agree? And she's sure to have 
neighbours calling in and so on. What a point to have it all ready prepared. Laura!" She jumped up. 
"Get me the big basket out of the stairs cupboard." 
"But, mother, do you really think it's a good idea?" said Laura. 
Again, how curious, she seemed to be different from them all. To take scraps from their party. Would 
the poor woman really like that? 
"Of course! What's the matter with you to-day? An hour or two ago you were insisting on us being 
sympathetic, and now--" 
Oh well! Laura ran for the basket. It was filled, it was heaped by her mother. 
"Take it yourself, darling," said she. "Run down just as you are. No, wait, take the arum lilies too. 
People of that class are so impressed by arum lilies." 
"The stems will ruin her lace frock," said practical Jose. 
So they would. Just in time. "Only the basket, then. And, Laura!" - her mother followed her out of the 
marquee - "don't on any account--" 
"What mother?" 
No, better not put such ideas into the child's head! "Nothing! Run along." 
It was just growing dusky as Laura shut their garden gates. A big dog ran by like a shadow. The road 
gleamed white, and down below in the hollow the little cottages were in deep shade. How quiet it 
seemed after the afternoon. Here she was going down the hill to somewhere where a man lay dead, 
and she couldn't realize it. Why couldn't she? She stopped a minute. And it seemed to her that kisses, 
voices, tinkling spoons, laughter, the smell of crushed grass were somehow inside her. She had no 
room for anything else. How strange! She looked up at the pale sky, and all she thought was, "Yes, it 
was the most successful party." 
Now the broad road was crossed. The lane began, smoky and dark. Women in shawls and men's tweed 
caps hurried by. Men hung over the palings; the children played in the doorways. A low hum came 
from the mean little cottages. In some of them there was a flicker of light, and a shadow, crab-like, 
moved across the window. Laura bent her head and hurried on. She wished now she had put on a coat. 
How her frock shone! And the big hat with the velvet streamer - if only it was another hat! Were the 
people looking at her? They must be. It was a mistake to have come; she knew all along it was a 
mistake. Should she go back even now? 
No, too late. This was the house. It must be. A dark knot of people stood outside. Beside the gate an 
old, old woman with a crutch sat in a chair, watching. She had her feet on a newspaper. The voices 


## PDF page 68

68 
 
 
stopped as Laura drew near. The group parted. It was as though she was expected, as though they had 
known she was coming here. 
Laura was terribly nervous. Tossing the velvet ribbon over her shoulder, she said to a woman standing 
by, "Is this Mrs. Scott's house?" and the woman, smiling queerly, said, "It is, my lass." 
Oh, to be away from this! She actually said, "Help me, God," as she walked up the tiny path and 
knocked. To be away from those staring eyes, or to be covered up in anything, one of those women's 
shawls even. I'll just leave the basket and go, she decided. I shan't even wait for it to be emptied. 
Then the door opened. A little woman in black showed in the gloom. 
Laura said, "Are you Mrs. Scott?" But to her horror the woman answered, "Walk in please, miss," and 
she was shut in the passage. 
"No," said Laura, "I don't want to come in. I only want to leave this basket. Mother sent--" 
The little woman in the gloomy passage seemed not to have heard her. "Step this way, please, miss," 
she said in an oily voice, and Laura followed her. 
She found herself in a wretched little low kitchen, lighted by a smoky lamp. There was a woman 
sitting before the fire. 
"Em," said the little creature who had let her in. "Em! It's a young lady." She turned to Laura. She said 
meaningly, "I'm 'er sister, miss. You'll excuse 'er, won't you?" 
"Oh, but of course!" said Laura. "Please, please don't disturb her. I - I only want to leave--" 
But at that moment the woman at the fire turned round. Her face, puffed up, red, with swollen eyes 
and swollen lips, looked terrible. She seemed as though she couldn't understand why Laura was there. 
What did it mean? Why was this stranger standing in the kitchen with a basket? What was it all about? 
And the poor face puckered up again. 
"All right, my dear," said the other. "I'll thenk the young lady." 
And again she began, "You'll excuse her, miss, I'm sure," and her face, swollen too, tried an oily smile. 
Laura only wanted to get out, to get away. She was back in the passage. The door opened. She walked 
straight through into the bedroom, where the dead man was lying. 
"You'd like a look at 'im, wouldn't you?" said Em's sister, and she brushed past Laura over to the bed. 
"Don't be afraid, my lass," - and now her voice sounded fond and sly, and fondly she drew down the 
sheet--"'e looks a picture. There's nothing to show. Come along, my dear." 
Laura came. 
There lay a young man, fast asleep - sleeping so soundly, so deeply, that he was far, far away from 
them both. Oh, so remote, so peaceful. He was dreaming. Never wake him up again. His head was 
sunk in the pillow, his eyes were closed; they were blind under the closed eyelids. He was given up to 
his dream. What did garden-parties and baskets and lace frocks matter to him? He was far from all 
those things. He was wonderful, beautiful. While they were laughing and while the band was playing, 
this marvel had come to the lane. Happy ... happy ... All is well, said that sleeping face. This is just as 
it should be. I am content. 
But all the same you had to cry, and she couldn't go out of the room without saying something to him. 
Laura gave a loud childish sob. 
"Forgive my hat," she said. 
And this time she didn't wait for Em's sister. She found her way out of the door, down the path, past all 
those dark people. At the corner of the lane she met Laurie. 
He stepped out of the shadow. "Is that you, Laura?" 
"Yes." 
"Mother was getting anxious. Was it all right?" 
"Yes, quite. Oh, Laurie!" She took his arm, she pressed up against him. 
"I say, you're not crying, are you?" asked her brother. 
Laura shook her head. She was. 
Laurie put his arm round her shoulder. "Don't cry," he said in his warm, loving voice. "Was it awful?" 


## PDF page 69

69 
 
 
"No," sobbed Laura. "It was simply marvellous. But Laurie--" She stopped, she looked at her brother. 
"Isn't life," she stammered, "isn't life--" But what life was she couldn't explain. No matter. He quite 
understood. 
"Isn't it, darling?" said Laurie. 
 
 


## PDF page 70

70 
 
 
“A Clean, Well-Lighted Place” (1933) by Ernest Hemingway 
 
There a few writers as legendary as Ernest Hemingway (1899-1961), one of the 
strongest and starkest voices of the Lost Generation. An American novelist, short-
story writer, journalist, international war correspondent, big game hunter, ladies’ 
man, he was one of the most influential figures of the early tewentieth century. 
Below is a sample of his fiction. “A Clean Well-Lighted Place” is an excellent 
example of his direct and minimalist writing style, and it also shows the dark 
atmosphere and nihilism of the period.  
 
 
It was very late and everyone had left the cafe except an old man who sat in the shadow the leaves of the 
tree made against the electric light. In the day time the street was dusty, but at night the dew settled the 
dust and the old man liked to sit late because he was deaf and now at night it was quiet and he felt the 
difference. The two waiters inside the cafe knew that the old man was a little drunk, and while he was a 
good client they knew that if he became too drunk he would leave without paying, so they kept watch 
on him.  
"Last week he tried to commit suicide," one waiter said.  
"Why?"  
"He was in despair."  
"What about?"  
"Nothing."  
"How do you know it was nothing?"  
"He has plenty of money."  
They sat together at a table that was close against the wall near the door of the cafe and looked at the 
terrace where the tables were all empty except where the old man sat in the shadow of the leaves of the 
tree that moved slightly in the wind. A girl and a soldier went by in the street. The street light shone on 
the brass number on his collar. The girl wore no head covering and hurried beside him.  
"The guard will pick him up," one waiter said.  
"What does it matter if he gets what he's after?"  
"He had better get off the street now. The guard will get him. They went by five minutes ago."  
The old man sitting in the shadow rapped on his saucer with his glass. The younger waiter went over to 
him.  
"What do you want?"  
The old man looked at him. "Another brandy," he said.  
"You'll be drunk," the waiter said. The old man looked at him. The waiter went away.  
"He'll stay all night," he said to his colleague. "I'm sleepy now. I never get into bed before three o'clock. 
He should have killed himself last week."  
The waiter took the brandy bottle and another saucer from the counter inside the cafe and marched out 
to the old man's table. He put down the saucer and poured the glass full of brandy.  
"You should have killed yourself last week," he said to the deaf man. The old man motioned with his 
finger. "A little more," he said. The waiter poured on into the glass so that the brandy slopped over and 
ran down the stem into the top saucer of the pile. "Thank you," the old man said. The waiter took the 
bottle back inside the cafe. He sat down at the table with his colleague again. 
"He's drunk now," he said.  
"He's drunk every night."  
"What did he want to kill himself for?"  
"How should I know."  
"How did he do it?"  
"He hung himself with a rope."  
"Who cut him down?"  
"His niece."  
"Why did they do it?"  


## PDF page 71

71 
 
 
"Fear for his soul."  
"How much money has he got?" "He's got plenty."  
"He must be eighty years old."  
"Anyway I should say he was eighty."  
"I wish he would go home. I never get to bed before three o'clock. What kind of hour is that to go to 
bed?"  
"He stays up because he likes it."  
"He's lonely. I'm not lonely. I have a wife waiting in bed for me." 
"He had a wife once too."  
"A wife would be no good to him now."  
"You can't tell. He might be better with a wife."  
"His niece looks after him. You said she cut him down."  
"I know." "I wouldn't want to be that old. An old man is a nasty thing."  
"Not always. This old man is clean. He drinks without spilling. Even now, drunk. Look at him."  
"I don't want to look at him. I wish he would go home. He has no regard for those who must work."  
The old man looked from his glass across the square, then over at the waiters.  
"Another brandy," he said, pointing to his glass. The waiter who was in a hurry came over.  
"Finished," he said, speaking with that omission of syntax stupid people employ when talking to 
drunken people or foreigners. "No more tonight. Close now."  
"Another," said the old man.  
"No. Finished." The waiter wiped the edge of the table with a towel and shook his head.  
The old man stood up, slowly counted the saucers, took a leather coin purse from his pocket and paid 
for the drinks, leaving half a peseta tip. The waiter watched him go down the street, a very old man 
walking unsteadily but with dignity.  
"Why didn't you let him stay and drink?" the unhurried waiter asked. They were putting up the shutters. 
"It is not half-past two."  
"I want to go home to bed."  
"What is an hour?"  
"More to me than to him."  
"An hour is the same."  
"You talk like an old man yourself. He can buy a bottle and drink at home."  
"It's not the same."  
"No, it is not," agreed the waiter with a wife. He did not wish to be unjust. He was only in a hurry.  
"And you? You have no fear of going home before your usual hour?"  
"Are you trying to insult me?"  
"No, hombre, only to make a joke."  
"No," the waiter who was in a hurry said, rising from pulling down the metal shutters. "I have 
confidence. I am all confidence."  
"You have youth, confidence, and a job," the older waiter said. "You have everything."  
"And what do you lack?"  
"Everything but work."  
"You have everything I have."  
"No. I have never had confidence and I am not young."  
"Come on. Stop talking nonsense and lock up."  
"I am of those who like to stay late at the cafe," the older waiter said.  
"With all those who do not want to go to bed. With all those who need a light for the night."  
"I want to go home and into bed."  
"We are of two different kinds," the older waiter said. He was now dressed to go home. "It is not only a 
question of youth and confidence although those things are very beautiful. Each night I am reluctant to 
close up because there may be someone who needs the cafe."  
"Hombre, there are bodegas open all night long."  
"You do not understand. This is a clean and pleasant cafe. It is well lighted. The light is very good and 
also, now, there are shadows of the leaves."  
"Good night," said the younger waiter.  
"Good night," the other said. Turning off the electric light he continued the conversation with himself. It 


## PDF page 72

72 
 
 
was the light of course but it is necessary that the place be clean and pleasant. You do not want music. 
Certainly you do not want music. Nor can you stand before a bar with dignity although that is all that is 
provided for these hours. What did he fear? It was not a fear or dread. It was a nothing that he knew too 
well. It was all a nothing and a man was a nothing too. It was only that and light was all it needed and a 
certain cleanness and order. Some lived in it and never felt it but he knew it all was nada y pues nada y 
naday pues nada. Our nada who art in nada, nada be thy name thy kingdom nada thy will be nada in 
nada as it is in nada. Give us this nada our daily nada and nada us our nada as we nada our nadas and 
nada us not into nada but deliver us from nada; pues nada. Hail nothing full of nothing, nothing is with 
thee. He smiled and stood before a bar with a shining steam pressure coffee machine.  
"What's yours?" asked the barman.  
"Nada."  
"Otro loco mas," said the barman and turned away.  
"A little cup," said the waiter.  
The barman poured it for him.  
"The light is very bright and pleasant but the bar is unpolished," the waiter said.  
The barman looked at him but did not answer. It was too late at night for conversation.  
"You want another copita?" the barman asked.  
"No, thank you," said the waiter and went out. He disliked bars and bodegas. A clean, well-lighted cafe 
was a very different thing. Now, without thinking further, he would go home to his room. He would lie 
in the bed and finally, with daylight, he would go to sleep. After all, he said to himself, it's probably 
only insomnia. Many must have it.


## PDF page 73

73 
 
 
“The Lottery” (1948) by Shirley Jackson (1916-1965) 
 
Shirley Jackson (1916-1965) was a popular American short story writer during the mid-
twentieth century, but whose influence is still strongly felt today. Though she wrote a 
good number of rather conventional short stories for women’s magazines, she is most 
famous for her modern gothic tales, which have influenced many fantasy and horror 
writers, including Richard Matheson and Steven King. She also wrote a disturbing horror 
novel, The Haunting of Hill House (1959), which has been adapted several times to 
television and cinema. The short story below, “The Lottery” (1948) is the one that 
launched her career as a writer. 
 
 
The morning of June 27th was clear and sunny, with the fresh warmth of a full-summer day; the flowers 
were blossoming profusely and the grass was richly green. The people of the village began to gather in 
the square, between the post office and the bank, around ten o'clock; in some towns there were so many 
people that the lottery took two days and had to be started on June 27th, but in this village, where there 
were only about three hundred people, the whole lottery took less than two hours, so it could begin at 
ten o'clock in the morning and still be through in time to allow the villagers to get home for noon 
dinner. 
The children assembled first, of course. School was recently over for the summer, and the feeling of 
liberty sat uneasily on most of them; they tended to gather together quietly for a while before they broke 
into boisterous play, and their talk was still of the classroom and the teacher, of books and reprimands. 
Bobby Martin had already stuffed his pockets full of stones, and the other boys soon followed his 
example, selecting the smoothest and roundest stones; Bobby and Harry Jones and Dickie Delacroix-- 
the villagers pronounced this name 'Dellacroy'--eventually made a great pile of stones in one corner of 
the square and guarded it against the raids of the other boys. The girls stood aside, talking among 
themselves, looking over their shoulders at rolled in the dust or clung to the hands of their older brothers 
or sisters. 
Soon the men began to gather, surveying their own children, speaking of planting and rain, tractors and 
taxes. They stood together, away from the pile of stones in the corner, and their jokes were quiet and 
they smiled rather than laughed. The women, wearing faded house dresses and sweaters, came shortly 
after their menfolk. They greeted one another and exchanged bits of gossip as they went to join their 
husbands. Soon the women, standing by their husbands, began to call to their children, and the children 
came reluctantly, having to be called four or five times. Bobby Martin ducked under his mother's 
grasping hand and ran, laughing, back to the pile of stones. His father spoke up sharply, and Bobby 
came quickly and took his place between his father and his oldest brother. 
The lottery was conducted--as were the square dances, the teen club, the Halloween program--by Mr. 
Summers, who had time and energy to devote to civic activities. He was a round-faced, jovial man and 
he ran the coal business, and people were sorry for him, because he had no children and his wife was a 
scold. When he arrived in the square, carrying the black wooden box, there was a murmur of 
conversation among the villagers, and he waved and called. 'Little late today, folks.' The postmaster, 
Mr. Graves, followed him, carrying a three- legged stool, and the stool was put in the center of the 
square and Mr. Summers set the black box down on it. The villagers kept their distance, leaving a space 
between themselves and the stool, and when Mr. Summers said, 'Some of you fellows want to give me a 
hand?' there was a hesitation before two men. Mr. Martin and his oldest son, Baxter, came forward to 
hold the box steady on the stool while Mr. Summers stirred up the papers inside it. 
The original paraphernalia for the lottery had been lost long ago, and the black box now resting on the 
stool had been put into use even before Old Man Warner, the oldest man in town, was born. Mr. 


## PDF page 74

74 
 
 
Summers spoke frequently to the villagers about making a new box, but no one liked to upset even as 
much tradition as was represented by the black box. There was a story that the present box had been 
made with some pieces of the box that had preceded it, the one that had been constructed when the first 
people settled down to make a village here. Every year, after the lottery, Mr. Summers began talking 
again about a new box, but every year the subject was allowed to fade off without anything's being 
done. The black box grew shabbier each year: by now it was no longer completely black but splintered 
badly along one side to show the original wood color, and in some places faded or stained. 
Mr. Martin and his oldest son, Baxter, held the black box securely on the stool until Mr. Summers had 
stirred the papers thoroughly with his hand. Because so much of the ritual had been forgotten or 
discarded, Mr. Summers had been successful in having slips of paper substituted for the chips of wood 
that had been used for generations. Chips of wood, Mr. Summers had argued, had been all very well 
when the village was tiny, but now that the population was more than three hundred and likely to keep 
on growing, it was necessary to use something that would fit more easily into he black box. The night 
before the lottery, Mr. Summers and Mr. Graves made up the slips of paper and put them in the box, and 
it was then taken to the safe of Mr. Summers' coal company and locked up until Mr. Summers was 
ready to take it to the square next morning. The rest of the year, the box was put way, sometimes one 
place, sometimes another; it had spent one year in Mr. Graves's barn and another year underfoot in the 
post office. and sometimes it was set on a shelf in the Martin grocery and left there. 
There was a great deal of fussing to be done before Mr. Summers declared the lottery open. There were 
the lists to make up—of heads of families, heads of households in each family, members of each 
household in each family. There was the proper swearing-in of Mr. Summers by the postmaster, as the 
official of the lottery; at one time, some people remembered, there had been a recital of some sort, 
performed by the official of the lottery, a perfunctory. tuneless chant that had been rattled off duly each 
year; some people believed that the official of the lottery used to stand just so when he said or sang it, 
others believed that he was supposed to walk among the people, but years and years ago this p3rt of the 
ritual had been allowed to lapse. There had been, also, a ritual salute, which the official of the lottery 
had had to use in addressing each person who came up to draw from the box, but this also had changed 
with time, until now it was felt necessary only for the official to speak to each person approaching. Mr. 
Summers was very good at all this; in his clean white shirt and blue jeans, with one hand resting 
carelessly on the black box, he seemed very proper and important as he talked interminably to Mr. 
Graves and the Martins. 
Just as Mr. Summers finally left off talking and turned to the assembled villagers, Mrs. Hutchinson 
came hurriedly along the path to the square, her sweater thrown over her shoulders, and slid into place 
in the back of the crowd. 'Clean forgot what day it was,' she said to Mrs. Delacroix, who stood next to 
her, and they both laughed softly. 'Thought my old man was out back stacking wood,' Mrs. Hutchinson 
went on, 'and then I looked out the window and the kids was gone, and then I remembered it was the 
twenty-seventh and came a-running.' She dried her hands on her apron, and Mrs. Delacroix said, 'You're 
in time, though. They're still talking away up there.' 
Mrs. Hutchinson craned her neck to see through the crowd and found her husband and children standing 
near the front. She tapped Mrs. Delacroix on the arm as a farewell and began to make her way through 
the crowd. The people separated good-humoredly to let her through: two or three people said, in voices 
just loud enough to be heard across the crowd, 'Here comes your, Missus, Hutchinson,' and 'Bill, she 
made it after all.' Mrs. Hutchinson reached her husband, and Mr. Summers, who had been waiting, said 
cheerfully. 'Thought we were going to have to get on without you, Tessie.' Mrs. Hutchinson said, 
grinning, 'Wouldn't have me leave m'dishes in the sink, now, would you. Joe?' and soft laughter ran 
through the crowd as the people stirred back into position after Mrs. Hutchinson's arrival. 
'Well, now.' Mr. Summers said soberly, 'guess we better get started, get this over with, so's we can go 
back to work. Anybody ain't here?' 
'Dunbar.' several people said. 'Dunbar. Dunbar.' 


## PDF page 75

75 
 
 
Mr. Summers consulted his list. 'Clyde Dunbar.' he said. 'That's right. He's broke his leg, hasn't he? 
Who's drawing for him?' 
'Me. I guess,' a woman said, and Mr. Summers turned to look at her. 'Wife draws for her husband.' Mr. 
Summers said. 'Don't you have a grown boy to do it for you, Janey?' Although Mr. Summers and 
everyone else in the village knew the answer perfectly well, it was the business of the official of the 
lottery to ask such questions formally. Mr. Summers waited with an expression of polite interest while 
Mrs. Dunbar answered. 
'Horace's not but sixteen vet.' Mrs. Dunbar said regretfully. 'Guess I gotta fill in for the old man this 
year.' 
'Right.' Sr. Summers said. He made a note on the list he was holding. Then he asked, 'Watson boy 
drawing this year?' 
A tall boy in the crowd raised his hand. 'Here,' he said. 'I m drawing for my mother and me.' He blinked 
his eyes nervously and ducked his head as several voices in the crowd said thin#s like 'Good fellow, 
lack.' and 'Glad to see your mother's got a man to do it.' 
'Well,' Mr. Summers said, 'guess that's everyone. Old Man Warner make it?' 
'Here,' a voice said, and Mr. Summers nodded. 
A sudden hush fell on the crowd as Mr. Summers cleared his throat and looked at the list. 'All ready?' he 
called. 'Now, I'll read the names--heads of families first--and the men come up and take a paper out of 
the box. Keep the paper folded in your hand without looking at it until everyone has had a turn. 
Everything clear?' 
The people had done it so many times that they only half listened to the directions: most of them were 
quiet, wetting their lips, not looking around. Then Mr. Summers raised one hand high and said, 'Adams.' 
A man disengaged himself from the crowd and came forward. 'Hi. Steve.' Mr. Summers said, and Mr. 
Adams said. 'Hi. Joe.' They grinned at one another humorlessly and nervously. Then Mr. Adams 
reached into the black box and took out a folded paper. He held it firmly by one corner as he turned and 
went hastily back to his place in the crowd, where he stood a little apart from his family, not looking 
down at his hand. 
'Allen.' Mr. Summers said. 'Anderson.... Bentham.' 
'Seems like there's no time at all between lotteries any more.' Mrs. Delacroix said to Mrs. Graves in the 
back row. 
'Seems like we got through with the last one only last week.' 
'Time sure goes fast.-- Mrs. Graves said. 
'Clark.... Delacroix' 
'There goes my old man.' Mrs. Delacroix said. She held her breath while her husband went forward. 
'Dunbar,' Mr. Summers said, and Mrs. Dunbar went steadily to the box while one of the women said. 
'Go on. Janey,' and another said, 'There she goes.' 
'We're next.' Mrs. Graves said. She watched while Mr. Graves came around from the side of the box, 
greeted Mr. Summers gravely and selected a slip of paper from the box. By now, all through the crowd 
there were men holding the small folded papers in their large hand, turning them over and over 
nervously Mrs. Dunbar and her two sons stood together, Mrs. Dunbar holding the slip of paper. 
'Harburt.... Hutchinson.' 
'Get up there, Bill,' Mrs. Hutchinson said, and the people near her laughed. 
'Jones.' 
'They do say,' Mr. Adams said to Old Man Warner, who stood next to him, 'that over in the north village 
they're talking of giving up the lottery.' 


## PDF page 76

76 
 
 
Old Man Warner snorted. 'Pack of crazy fools,' he said. 'Listening to the young folks, nothing's good 
enough for them. Next thing you know, they'll be wanting to go back to living in caves, nobody work 
any more, live hat way for a while. Used to be a saying about 'Lottery in June, corn be heavy soon.' First 
thing you know, we'd all be eating stewed chickweed and acorns. There's always been a lottery,' he 
added petulantly. 'Bad enough to see young Joe Summers up there joking with everybody.' 
'Some places have already quit lotteries.' Mrs. Adams said. 
'Nothing but trouble in that,' Old Man Warner said stoutly. 'Pack of young fools.' 
'Martin.' And Bobby Martin watched his father go forward. 'Overdyke.... Percy.' 
'I wish they'd hurry,' Mrs. Dunbar said to her older son. 'I wish they'd hurry.' 
'They're almost through,' her son said. 
'You get ready to run tell Dad,' Mrs. Dunbar said. 
Mr. Summers called his own name and then stepped forward precisely and selected a slip from the box. 
Then he called, 'Warner.' 
'Seventy-seventh year I been in the lottery,' Old Man Warner said as he went through the crowd. 
'Seventy-seventh time.' 
'Watson' The tall boy came awkwardly through the crowd. Someone said, 'Don't be nervous, Jack,' and 
Mr. Summers said, 'Take your time, son.' 
'Zanini.' 
After that, there was a long pause, a breathless pause, until Mr. Summers, holding his slip of paper in 
the air, said, 'All right, fellows.' For a minute, no one moved, and then all the slips of paper were 
opened. Suddenly, all the women began to speak at once, saving. 'Who is it?,' 'Who's got it?,' 'Is it the 
Dunbars?,' 'Is it the Watsons?' Then the voices began to say, 'It's Hutchinson. It's Bill,' 'Bill Hutchinson's 
got it.' 
'Go tell your father,' Mrs. Dunbar said to her older son. 
People began to look around to see the Hutchinsons. Bill Hutchinson was standing quiet, staring down 
at the paper in his hand. Suddenly. Tessie Hutchinson shouted to Mr. Summers. 'You didn't give him 
time enough to take any paper he wanted. I saw you. It wasn't fair!' 
'Be a good sport, Tessie.' Mrs. Delacroix called, and Mrs. Graves said, 'All of us took the same chance.' 
'Shut up, Tessie,' Bill Hutchinson said. 
'Well, everyone,' Mr. Summers said, 'that was done pretty fast, and now we've got to be hurrying a little 
more to get done in time.' He consulted his next list. 'Bill,' he said, 'you draw for the Hutchinson family. 
You got any other households in the Hutchinsons?' 
'There's Don and Eva,' Mrs. Hutchinson yelled. 'Make them take their chance!' 
'Daughters draw with their husbands' families, Tessie,' Mr. Summers said gently. 'You know that as well 
as anyone else.' 
'It wasn't fair,' Tessie said. 
'I guess not, Joe.' Bill Hutchinson said regretfully. 'My daughter draws with her husband's family; that's 
only fair. And I've got no other family except the kids.' 
'Then, as far as drawing for families is concerned, it's you,' Mr. Summers said in explanation, 'and as far 
as drawing for households is concerned, that's you, too. Right?' 
'Right,' Bill Hutchinson said. 
'How many kids, Bill?' Mr. Summers asked formally. 
'Three,' Bill Hutchinson said. 
'There's Bill, Jr., and Nancy, and little Dave. And Tessie and me.' 


## PDF page 77

77 
 
 
'All right, then,' Mr. Summers said. 'Harry, you got their tickets back?' 
Mr. Graves nodded and held up the slips of paper. 'Put them in the box, then,' Mr. Summers directed. 
'Take Bill's and put it in.' 
'I think we ought to start over,' Mrs. Hutchinson said, as quietly as she could. 'I tell you it wasn't fair. 
You didn't give him time enough to choose. Everybody saw that.' 
Mr. Graves had selected the five slips and put them in the box, and he dropped all the papers but those 
onto the ground, where the breeze caught them and lifted them off. 
'Listen, everybody,' Mrs. Hutchinson was saying to the people around her. 
'Ready, Bill?' Mr. Summers asked, and Bill Hutchinson, with one quick glance around at his wife and 
children, nodded. 
'Remember,' Mr. Summers said, 'take the slips and keep them folded until each person has taken one. 
Harry, you help little Dave.' Mr. Graves took the hand of the little boy, who came willingly with him up 
to the box. 'Take a paper out of the box, Davy.' Mr. Summers said. Davy put his hand into the box and 
laughed. 'Take just one paper.' Mr. Summers said. 'Harry, you hold it for him.' Mr. Graves took the 
child's hand and removed the folded paper from the tight fist and held it while little Dave stood next to 
him and looked up at him wonderingly. 
'Nancy next,' Mr. Summers said. Nancy was twelve, and her school friends breathed heavily as she went 
forward switching her skirt, and took a slip daintily from the box 'Bill, Jr.,' Mr. Summers said, and Billy, 
his face red and his feet overlarge, near knocked the box over as he got a paper out. 'Tessie,' Mr. 
Summers said. She hesitated for a minute, looking around defiantly, and then set her lips and went up to 
the box. She snatched a paper out and held it behind her. 
'Bill,' Mr. Summers said, and Bill Hutchinson reached into the box and felt around, bringing his hand 
out at last with the slip of paper in it. 
The crowd was quiet. A girl whispered, 'I hope it's not Nancy,' and the sound of the whisper reached the 
edges of the crowd. 
'It's not the way it used to be.' Old Man Warner said clearly. 'People ain't the way they used to be.' 
'All right,' Mr. Summers said. 'Open the papers. Harry, you open little Dave's.' 
Mr. Graves opened the slip of paper and there was a general sigh through the crowd as he held it up and 
everyone could see that it was blank. Nancy and Bill. Jr. opened theirs at the same time, and both 
beamed and laughed, turning around to the crowd and holding their slips of paper above their heads. 
'Tessie,' Mr. Summers said. There was a pause, and then Mr. Summers looked at Bill Hutchinson, and 
Bill unfolded his paper and showed it. It was blank. 
'It's Tessie,' Mr. Summers said, and his voice was hushed. 'Show us her paper. Bill.' 
Bill Hutchinson went over to his wife and forced the slip of paper out of her hand. It had a black spot on 
it, the black spot Mr. Summers had made the night before with the heavy pencil in the coal company 
office. Bill Hutchinson held it up, and there was a stir in the crowd. 
'All right, folks.' Mr. Summers said. 'Let's finish quickly.' 
Although the villagers had forgotten the ritual and lost the original black box, they still remembered to 
use stones. The pile of stones the boys had made earlier was ready; there were stones on the ground with 
the blowing scraps of paper that had come out of the box Delacroix selected a stone so large she had to 
pick it up with both hands and turned to Mrs. Dunbar. 'Come on,' she said. 'Hurry up.' 
Mr. Dunbar had small stones in both hands, and she said, gasping for breath. 'I can't run at all. You'll 
have to go ahead and I'll catch up with you.' 
The children had stones already. And someone gave little Davy Hutchinson few pebbles. 


## PDF page 78

78 
 
 
Tessie Hutchinson was in the center of a cleared space by now, and she held her hands out desperately 
as the villagers moved in on her. 'It isn't fair,' she said. A stone hit her on the side of the head. Old Man 
Warner was saying, 'Come on, come on, everyone.' Steve Adams was in the front of the crowd of 
villagers, with Mrs. Graves beside him. 
'It isn't fair, it isn't right,' Mrs. Hutchinson screamed, and then they were upon her. 


## PDF page 79

79 
 
 
“A Good Man Is Hard to Find” (1953), by Flannery O’CONNOR (1925-1964)
 
Flannery O’Connor was born in 1925 in Savannah, Georgia, in a Catholic family. 
She died at 39 of a congenital disease, but by that time she was an established 
writer known for about thirty short stories and two novels, as well as speeches and 
letters. Along with writers like Carson McCullers and Eudora Welty, she belonged 
to the Southern Gothic tradition, which focused on the decaying south and its 
5 
people. “A Good Man Is Hard to Find” is one of her most famous stories, a 
disturbing tale about an encounter between a vacationing Southern family and an 
escaped murderer. 
 
THE GRANDMOTHER didn't want to go to Florida. She wanted to visit some of her connections in east 
Tennessee and she was seizing at every chance to change Bailey's mind. Bailey was the son she lived 
with, her only boy. He was sitting on the edge of his chair at the table, bent over the orange sports section 
of the Journal. "Now look here, Bailey," she said, "see here, read this," and she stood with one hand on 
her thin hip and the other rattling the newspaper at his bald head. "Here this fellow that calls himself The 
Misfit is aloose from the Federal Pen and headed toward Florida and you read here what it says he did to 
these people. Just you read it. I wouldn't take my children in any direction with a criminal like that aloose 
in it. I couldn't answer to my conscience if I did." 
Bailey didn't look up from his reading so she wheeled around then and faced the children's mother, a 
young woman in slacks, whose face was as broad and innocent as a cabbage and was tied around with a 
green head-kerchief that had two points on the top like rabbit's ears. She was sitting on the sofa, feeding 
the baby his apricots out of a jar. "The children have been to Florida before," the old lady said. "You all 
ought to take them somewhere else for a change so they would see different parts of the world and be 
broad. They never have been to east Tennessee." 
The children's mother didn't seem to hear her but the eight-year-old boy, John Wesley, a stocky child with 
glasses, said, "If you don't want to go to Florida, why dontcha stay at home?" He and the little girl, June 
Star, were reading the funny papers on the floor. 
"She wouldn't stay at home to be queen for a day," June Star said without raising her yellow head. 
"Yes and what would you do if this fellow, The Misfit, caught you?" the grandmother asked. 
"I'd smack his face," John Wesley said. 
"She wouldn't stay at home for a million bucks," June Star said. "Afraid she'd miss something. She has to 
go everywhere we go." 
"All right, Miss," the grandmother said. "Just remember that the next time you want me to curl your hair." 
June Star said her hair was naturally curly. 
The next morning the grandmother was the first one in the car, ready to go. She had her big black valise 
that looked like the head of a hippopotamus in one corner, and underneath it she was hiding a basket with 
Pitty Sing, the cat, in it. She didn't intend for the cat to be left alone in the house for three days because he 
would miss her too much and she was afraid he might brush against one of the gas burners and 
accidentally asphyxiate himself. Her son, Bailey, didn't like to arrive at a motel with a cat. 
She sat in the middle of the back seat with John Wesley and June Star on either side of her. Bailey and the 
children's mother and the baby sat in front and they left Atlanta at eight forty-five with the mileage on the 
car at 55890. The grandmother wrote this down because she thought it would be interesting to say how 
many miles they had been when they got back. It took them twenty minutes to reach the outskirts of the 
city. 


## PDF page 80

80 
 
 
The old lady settled herself comfortably, removing her white cotton gloves and putting them up with her 
purse on the shelf in front of the back window. The children's mother still had on slacks and still had her 
head tied up in a green kerchief, but the grandmother had on a navy blue straw sailor hat with a bunch of 
white violets on the brim and a navy blue dress with a small white dot in the print. Her collars and cuffs 
were white organdy trimmed with lace and at her neckline she had pinned a purple spray of cloth violets 
containing a sachet. In case of an accident, anyone seeing her dead on the highway would know at once 
that she was a lady. 
She said she thought it was going to be a good day for driving, neither too hot nor too cold, and she 
cautioned Bailey that the speed limit was fifty-five miles an hour and that the patrolmen hid themselves 
behind billboards and small clumps of trees and sped out after you before you had a chance to slow down. 
She pointed out interesting details of the scenery: Stone Mountain; the blue granite that in some places 
came up to both sides of the highway; the brilliant red clay banks slightly streaked with purple; and the 
various crops that made rows of green lace-work on the ground. The trees were full of silver-white 
sunlight and the meanest of them sparkled. The children were reading comic magazines and their mother 
had gone back to sleep. 
"Let's go through Georgia fast so we won't have to look at it much," John Wesley said. 
"If I were a little boy," said the grandmother, "I wouldn't talk about my native state that way. Tennessee 
has the mountains and Georgia has the hills." 
"Tennessee is just a hillbilly dumping ground," John Wesley said, "and Georgia is a lousy state too." 
"You said it," June Star said. 
"In my time," said the grandmother, folding her thin veined fingers, "children were more respectful of 
their native states and their parents and everything else. People did right then. Oh look at the cute little 
pickaninny!" she said and pointed to a Negro child standing in the door of a shack. "Wouldn't that make a 
picture, now?" she asked and they all turned and looked at the little Negro out of the back window. He 
waved. 
"He didn't have any britches on," June Star said. 
"He probably didn't have any," the grandmother explained. "Little niggers in the country don't have things 
like we do. If I could paint, I'd paint that picture," she said. 
The children exchanged comic books. 
The grandmother offered to hold the baby and the children's mother passed him over the front seat to her. 
She set him on her knee and bounced him and told him about the things they were passing. She rolled her 
eyes and screwed up her mouth and stuck her leathery thin face into his smooth bland one. Occasionally 
he gave her a faraway smile. They passed a large cotton field with five or six graves fenced in the middle 
of it, like a small island. "Look at the graveyard!" the grandmother said, pointing it out. "That was the old 
family burying ground. That belonged to the plantation." 
"Where's the plantation?" John Wesley asked. 
"Gone With the Wind," said the grandmother. "Ha. Ha." 
When the children finished all the comic books they had brought, they opened the lunch and ate it. The 
grandmother ate a peanut butter sandwich and an olive and would not let the children throw the box and 
the paper napkins out the window. When there was nothing else to do they played a game by choosing a 
cloud and making the other two guess what shape it suggested. John Wesley took one the shape of a cow 
and June Star guessed a cow and John Wesley said, no, an automobile, and June Star said he didn't play 
fair, and they began to slap each other over the grandmother. 
The grandmother said she would tell them a story if they would keep quiet. When she told a story, she 
rolled her eyes and waved her head and was very dramatic. She said once when she was a maiden lady 


## PDF page 81

81 
 
 
she had been courted by a Mr. Edgar Atkins Teagarden from Jasper, Georgia. She said he was a very 
good-looking man and a gentleman and that he brought her a watermelon every Saturday afternoon with 
his initials cut in it, E. A. T. Well, one Saturday, she said, Mr. Teagarden brought the watermelon and 
there was nobody at home and he left it on the front porch and returned in his buggy to Jasper, but she 
never got the watermelon, she said, because a nigger boy ate it when he saw the initials, E. A. T.! This 
story tickled John Wesley's funny bone and he giggled and giggled but June Star didn't think it was any 
good. She said she wouldn't marry a man that just brought her a watermelon on Saturday. The 
grandmother said she would have done well to marry Mr. Teagarden because he was a gentleman and had 
bought Coca-Cola stock when it first came out and that he had died only a few years ago, a very wealthy 
man. 
They stopped at The Tower for barbecued sandwiches. The Tower was a part stucco and part wood filling 
station and dance hall set in a clearing outside of Timothy. A fat man named Red Sammy Butts ran it and 
there were signs stuck here and there on the building and for miles up and down the highway saying, 
TRY RED SAMMY'S FAMOUS BARBECUE. NONE LIKE FAMOUS RED SAMMY'S! RED SAM! 
THE FAT BOY WITH THE HAPPY LAUGH. A VETERAN! RED SAMMY'S YOUR MAN! 
Red Sammy was lying on the bare ground outside The Tower with his head under a truck while a gray 
monkey about a foot high, chained to a small chinaberry tree, chattered nearby. The monkey sprang back 
into the tree and got on the highest limb as soon as he saw the children jump out of the car and run toward 
him. 
Inside, The Tower was a long dark room with a counter at one end and tables at the other and dancing 
space in the middle. They all sat down at a board table next to the nickelodeon and Red Sam's wife, a tall 
burnt-brown woman with hair and eyes lighter than her skin, came and took their order. The children's 
mother put a dime in the machine and played "The Tennessee Waltz," and the grandmother said that tune 
always made her want to dance. She asked Bailey if he would like to dance but he only glared at her. He 
didn't have a naturally sunny disposition like she did and trips made him nervous. The grandmother's 
brown eyes were very bright. She swayed her head from side to side and pretended she was dancing in 
her chair. June Star said play something she could tap to so the children's mother put in another dime and 
played a fast number and June Star stepped out onto the dance floor and did her tap routine. 
"Ain't she cute?" Red Sam's wife said, leaning over the counter. "Would you like to come be my little 
girl?" 
"No I certainly wouldn't," June Star said. "I wouldn't live in a broken-down place like this for a minion 
bucks!" and she ran back to the table. 
"Ain't she cute?" the woman repeated, stretching her mouth politely. 
"Arn't you ashamed?" hissed the grandmother. 
Red Sam came in and told his wife to quit lounging on the counter and hurry up with these people's order. 
His khaki trousers reached just to his hip bones and his stomach hung over them like a sack of meal 
swaying under his shirt. He came over and sat down at a table nearby and let out a combination sigh and 
yodel. "You can't win," he said. "You can't win," and he wiped his sweating red face off with a gray 
handkerchief. "These days you don't know who to trust," he said. "Ain't that the truth?" 
"People are certainly not nice like they used to be," said the grandmother. 
"Two fellers come in here last week," Red Sammy said, "driving a Chrysler. It was a old beat-up car but it 
was a good one and these boys looked all right to me. Said they worked at the mill and you know I let 
them fellers charge the gas they bought? Now why did I do that?" 
"Because you're a good man!" the grandmother said at once. 
"Yes'm, I suppose so," Red Sam said as if he were struck with this answer. 


## PDF page 82

82 
 
 
His wife brought the orders, carrying the five plates all at once without a tray, two in each hand and one 
balanced on her arm. "It isn't a soul in this green world of God's that you can trust," she said. "And I don't 
count nobody out of that, not nobody," she repeated, looking at Red Sammy. 
"Did you read about that criminal, The Misfit, that's escaped?" asked the grandmother. 
"I wouldn't be a bit surprised if he didn't attact this place right here," said the woman. "If he hears about it 
being here,I wouldn't be none surprised to see him. If he hears it's two cent in the cash register, I wouldn't 
be a tall surprised if he . . ." 
"That'll do," Red Sam said. "Go bring these people their Co'-Colas," and the woman went off to get the 
rest of the order. 
"A good man is hard to find," Red Sammy said. "Every- thing is getting terrible. I remember the day you 
could go off and leave your screen door unlatched. Not no more." 
He and the grandmother discussed better times. The old lady said that in her opinion Europe was entirely 
to blame for the way things were now. She said the way Europe acted you would think we were made of 
money and Red Sam said it was no use talking about it, she was exactly right. The children ran outside 
into the white sunlight and looked at the monkey in the lacy chinaberry tree. He was busy catching fleas 
on himself and biting each one carefully between his teeth as if it were a delicacy. 
They drove off again into the hot afternoon. The grand- mother took cat naps and woke up every few 
minutes with her own snoring. Outside of Toombsboro she woke up and recalled an old plantation that 
she had visited in this neighborhood once when she was a young lady. She said the house had six white 
columns across the front and that there was an avenue of oaks leading up to it and two little wooden trellis 
arbors on either side in front where you sat down with your suitor after a stroll in the garden. She recalled 
exactly which road to turn off to get to it. She knew that Bailey would not be willing to lose any time 
looking at an old house, but the more she talked about it, the more she wanted to see it once again and 
find out if the little twin arbors were still standing. "There was a secret panel in this house," she said 
craftily, not telling the truth but wishing that she were, "and the story went that all the family silver was 
hidden in it when Sherman came through but it was never found . . ." 
"Hey!" John Wesley said. "Let's go see it! We'll find it! We'll poke all the woodwork and find it! Who 
lives there? Where do you turn off at? Hey Pop, can't we turn off there?" 
"We never have seen a house with a secret panel!" June Star shrieked. "Let's go to the house with the 
secret panel! Hey Pop, can't we go see the house with the secret panel!" 
"It's not far from here, I know," the grandmother said. "It wouldn't take over twenty minutes." 
Bailey was looking straight ahead. His jaw was as rigid as a horseshoe. "No," he said. 
The children began to yell and scream that they wanted to see the house with the secret panel. John 
Wesley kicked the back of the front seat and June Star hung over her mother's shoulder and whined 
desperately into her ear that they never had any fun even on their vacation, that they could never do what 
THEY wanted to do. The baby began to scream and John Wesley kicked the back of the seat so hard that 
his father could feel the blows in his kidney. 
"All right!" he shouted and drew the car to a stop at the side of the road. "Will you all shut up? Will you 
all just shut up for one second? If you don't shut up, we won't go anywhere. 
"It would be very educational for them," the grandmother murmured. 
"All right," Bailey said, "but get this: this is the only time we're going to stop for anything like this. This 
is the one and only time." 
"The dirt road that you have to turn down is about a mile back," the grandmother directed. "I marked it 
when we passed." 


## PDF page 83

83 
 
 
"A dirt road," Bailey groaned. 
After they had turned around and were headed toward the dirt road, the grandmother recalled other points 
about the house, the beautiful glass over the front doorway and the candle-lamp in the hall. John Wesley 
said that the secret panel was probably in the fireplace. 
"You can't go inside this house," Bailey said. "You don't know who lives there." 
"While you all talk to the people in front, I'll run around behind and get in a window," John Wesley 
suggested. 
"We'll all stay in the car," his mother said. They turned onto the dirt road and the car raced roughly along 
in a swirl of pink dust. The grandmother recalled the times when there were no paved roads and thirty 
miles was a day's journey. The dirt road was hilly and there were sudden washes in it and sharp curves on 
dangerous embankments. All at once they would be on a hill, looking down over the blue tops of trees for 
miles around, then the next minute, they would be in a red depression with the dust-coated trees looking 
down on them. 
"This place had better turn up in a minute," Bailey said, "or I'm going to turn around." 
The road looked as if no one had traveled on it in months. 
"It's not much farther," the grandmother said and just as she said it, a horrible thought came to her. The 
thought was so embarrassing that she turned red in the face and her eyes dilated and her feet jumped up, 
upsetting her valise in the corner. The instant the valise moved, the newspaper top she had over the basket 
under it rose with a snarl and Pitty Sing,the cat, sprang onto Bailey's shoulder. 
The children were thrown to the floor and their mother, clutching the baby, was thrown out the door onto 
the ground; the old lady was thrown into the front seat. The car turned over once and landed right-side-up 
in a gulch off the side of the road. Bailey remained in the driver's seat with the cat-gray-striped with a 
broad white face and an orange nose-clinging to his neck like a caterpillar. 
As soon as the children saw they could move their arms and legs, they scrambled out of the car, shouting, 
"We've had an ACCIDENT!" The grandmother was curled up under the dashboard, hoping she was 
injured so that Bailey's wrath would not come down on her all at once. The horrible thought she had had 
before the accident was that the house she had remembered so vividly was not in Georgia but in 
Tennessee. 
Bailey removed the cat from his neck with both hands and flung it out the window against the side of a 
pine tree. Then he got out of the car and started looking for the children's mother. She was sitting against 
the side of the red gutted ditch, holding the screaming baby, but she only had a cut down her face and a 
broken shoulder. "We've had an ACCIDENT!" the children screamed in a frenzy of delight. 
"But nobody's killed," June Star said with disappointment as the grandmother limped out of the car, her 
hat still pinned to her head but the broken front brim standing up at a jaunty angle and the violet spray 
hanging off the side. They all sat down in the ditch, except the children, to recover from the shock. They 
were all shaking. 
"Maybe a car will come along," said the children's mother hoarsely. 
"I believe I have injured an organ," said the grandmother, pressing her side, but no one answered her. 
Bailey's teeth were clattering. He had on a yellow sport shirt with bright blue parrots designed in it and 
his face was as yellow as the l shirt. The grandmother decided that she would not mention that the house 
was in Tennessee. 
The road was about ten feet above and they could see only the tops of the trees on the other side of it. 
Behind the ditch they were sitting in there were more woods, tall and dark and deep. In a few minutes 
they saw a car some distance away on top of a hill, coming slowly as if the occupants were watching 
them. The grandmother stood up and waved both arms dramatically to attract their attention. The car 


## PDF page 84

84 
 
 
continued to come on slowly, disappeared around a bend and appeared again, moving even slower, on top 
of the hill they had gone over. It was a big black battered hearse-like automobile. There were three men in 
it. 
It came to a stop just over them and for some minutes, the driver looked down with a steady 
expressionless gaze to where they were sitting, and didn't speak. Then he turned his head and muttered 
something to the other two and they got out. One was a fat boy in black trousers and a red sweat shirt with 
a silver stallion embossed on the front of it. He moved around on the right side of them and stood staring, 
his mouth partly open in a kind of loose grin. The other had on khaki pants and a blue striped coat and a 
gray hat pulled down very low, hiding most of his face. He came around slowly on the left side. Neither 
spoke. 
The driver got out of the car and stood by the side of it, looking down at them. He was an older man than 
the other two. His hair was just beginning to gray and he wore silver- rimmed spectacles that gave him a 
scholarly look. He had a long creased face and didn't have on any shirt or undershirt. He had on blue jeans 
that were too tight for him and was holding a black hat and a gun. The two boys also had guns. 
"We've had an ACCIDENT!" the children screamed. 
The grandmother had the peculiar feeling that the bespectacled man was someone she knew. His face was 
as familiar to her as if she had known him au her life but she could not recall who he was. He moved 
away from the car and began to come down the embankment, placing his feet carefully so that he 
wouldn't slip. He had on tan and white shoes and no socks, and his ankles were red and thin. "Good 
afternoon," he said. "I see you all had you a little spill." 
"We turned over twice!" said the grandmother. 
"Once"," he corrected. "We seen it happen. Try their car and see will it run, Hiram," he said quietly to the 
boy with the gray hat. 
"What you got that gun for?" John Wesley asked. "Whatcha gonna do with that gun?" 
"Lady," the man said to the children's mother, "would you mind calling them children to sit down by you? 
Children make me nervous. I want all you all to sit down right together there where you're at." 
"What are you telling US what to do for?" June Star asked. 
Behind them the line of woods gaped like a dark open mouth. "Come here," said their mother. 
"Look here now," Bailey began suddenly, "we're in a predicament! We're in . . ." 
The grandmother shrieked. She scrambled to her feet and stood staring. "You're The Misfit!" she said. "I 
recognized you at once!" 
"Yes'm," the man said, smiling slightly as if he were pleased in spite of himself to be known, "but it 
would have been better for all of you, lady, if you hadn't of reckernized me." 
Bailey turned his head sharply and said something to his mother that shocked even the children. The old 
lady began to cry and The Misfit reddened. 
"Lady," he said, "don't you get upset. Sometimes a man says things he don't mean. I don't reckon he 
meant to talk to you thataway." 
"You wouldn't shoot a lady, would you?" the grandmother said and removed a clean handkerchief from 
her cuff and began to slap at her eyes with it. 
The Misfit pointed the toe of his shoe into the ground and made a little hole and then covered it up again. 
"I would hate to have to," he said. 
"Listen," the grandmother almost screamed, "I know you're a good man. You don't look a bit like you 
have common blood. I know you must come from nice people!" 


## PDF page 85

85 
 
 
"Yes mam," he said, "finest people in the world." When he smiled he showed a row of strong white teeth. 
"God never made a finer woman than my mother and my daddy's heart was pure gold," he said. The boy 
with the red sweat shirt had come around behind them and was standing with his gun at his hip. The 
Misfit squatted down on the ground. "Watch them children, Bobby Lee," he said. "You know they make 
me nervous." He looked at the six of them huddled together in front of him and he seemed to be 
embarrassed as if he couldn't think of anything to say. "Ain't a cloud in the sky," he remarked, looking up 
at it. "Don't see no sun but don't see no cloud neither." 
"Yes, it's a beautiful day," said the grandmother. "Listen," she said, "you shouldn't call yourself The 
Misfit because I know you're a good man at heart. I can just look at you and tell " 
"Hush!" Bailey yelled. "Hush! Everybody shut up and let me handle this!" He was squatting in the 
position of a runner about to sprint forward but he didn't move. 
"I prechate that, lady," The Misfit said and drew a little circle in the ground with the butt of his gun. 
"It'll take a half a hour to fix this here car," Hiram called, looking over the raised hood of it. 
"Well, first you and Bobby Lee get him and that little boy to step over yonder with you," The Misfit said, 
pointing to Bailey and John Wesley. "The boys want to ast you some- thing," he said to Bailey. "Would 
you mind stepping back in them woods there with them?" 
"Listen," Bailey began, "we're in a terrible predicament! Nobody realizes what this is," and his voice 
cracked. His eyes were as blue and intense as the parrots in his shirt and he remained perfectly still. 
The grandmother reached up to adjust her hat brim as if she were going to the woods with him but it came 
off in her hand. She stood staring at it and after a second she let it fall on the ground. Hiram pulled Bailey 
up by the arm as if he were assisting an old man. John Wesley caught hold of his father's hand and Bobby 
Lee followed. They went off toward the woods and just as they reached the dark edge, Bailey turned and 
supporting himself against a gray naked pine trunk, he shouted, "I'll be back in a minute, Mamma, wait on 
me!" 
"Come back this instant!" his mother shrilled but they all disappeared into the woods. 
"Bailey Boy!" the grandmother called in a tragic voice but she found she was looking at The Misfit 
squatting on the ground in front of her. "I just know you're a good man," she said desperately. "You're not a 
bit common!" 
"Nome, I ain't a good man," The Misfit said after a second as if he had considered her statement carefully, 
"but I ain't the worst in the world neither. My daddy said I was a different breed of dog from my brothers 
and sisters. 'You know,' Daddy said, 'it's some that can live their whole life out without asking about it and 
it's others has to know why it is, and this boy is one of the latters. He's going to be into every- thing!'" He 
put on his black hat and looked up suddenly and then away deep into the woods as if he were embarrassed 
again. "I'm sorry I don't have on a shirt before you ladies," he said, hunching his shoulders slightly. "We 
buried our clothes that we had on when we escaped and we're just making do until we can get better. We 
borrowed these from some folks we met," he explained. 
"That's perfectly all right," the grandmother said. "Maybe Bailey has an extra shirt in his suitcase." 
"I'll look and see terrectly," The Misfit said. 
"Where are they taking him?" the children's mother screamed. 
"Daddy was a card himself," The Misfit said. "You couldn't put anything over on him. He never got in 
trouble with the Authorities though. Just had the knack of handling them." 
"You could be honest too if you'd only try," said the grandmother. "Think how wonderful it would be to 
settle down and live a comfortable life and not have to think about some- body chasing you all the time." 


## PDF page 86

86 
 
 
The Misfit kept scratching in the ground with the butt of his gun as if he were thinking about it. "Yes'm, 
somebody is always after you," he murmured. 
The grandmother noticed how thin his shoulder blades were just behind-his hat because she was standing up 
looking down on him. "Do you ever pray?" she asked. 
He shook his head. All she saw was the black hat wiggle between his shoulder blades. "Nome," he said. 
There was a pistol shot from the woods, followed closely by another. Then silence. The old lady's head 
jerked around. She could hear the wind move through the tree tops like a long satisfied insuck of breath. 
"Bailey Boy!" she called. 
"I was a gospel singer for a while," The Misfit said. "I been most everything. Been in the arm service, both 
land and sea, at home and abroad, been twict married, been an undertaker, been with the railroads, plowed 
Mother Earth, been in a tornado, seen a man burnt alive oncet," and he looked up at the children's mother 
and the little girl who were sitting close together, their faces white and their eyes glassy; "I even seen a 
woman flogged," he said. 
"Pray, pray," the grandmother began, "pray, pray . . ." 
"I never was a bad boy that I remember of," The Misfit said in an almost dreamy voice, "but somewheres 
along the line I done something wrong and got sent to the penitentiary. I was buried alive," and he looked 
up and held her attention to him by a steady stare. 
"That's when you should have started to pray," she said "What did you do to get sent to the penitentiary that 
first time?" 
"Turn to the right, it was a wall," The Misfit said, looking up again at the cloudless sky. "Turn to the left, it 
was a wall. Look up it was a ceiling, look down it was a floor. I forget what I done, lady. I set there and set 
there, trying to remember what it was I done and I ain't recalled it to this day. Oncet in a while, I would 
think it was coming to me, but it never come." 
"Maybe they put you in by mistake," the old lady said vaguely. 
"Nome," he said. "It wasn't no mistake. They had the papers on me." 
"You must have stolen something," she said. 
The Misfit sneered slightly. "Nobody had nothing I wanted," he said. "It was a head-doctor at the 
penitentiary said what I had done was kill my daddy but I known that for a lie. My daddy died in nineteen 
ought nineteen of the epidemic flu and I never had a thing to do with it. He was buried in the Mount 
Hopewell Baptist churchyard and you can go there and see for yourself." 
"If you would pray," the old lady said, "Jesus would help you." 
"That's right," The Misfit said. 
"Well then, why don't you pray?" she asked trembling with delight suddenly. 
"I don't want no hep," he said. "I'm doing all right by myself." 
Bobby Lee and Hiram came ambling back from the woods. Bobby Lee was dragging a yellow shirt with 
bright blue parrots in it. 
"Thow me that shirt, Bobby Lee," The Misfit said. The shirt came flying at him and landed on his shoulder 
and he put it on. The grandmother couldn't name what the shirt reminded her of. "No, lady," The Misfit said 
while he was buttoning it up, "I found out the crime don't matter. You can do one thing or you can do 
another, kill a man or take a tire off his car, because sooner or later you're going to forget what it was you 
done and just be punished for it." 
The children's mother had begun to make heaving noises as if she couldn't get her breath. "Lady," he asked, 
"would you and that little girl like to step off yonder with Bobby Lee and Hiram and join your husband?" 


## PDF page 87

87 
 
 
"Yes, thank you," the mother said faintly. Her left arm dangled helplessly and she was holding the baby, 
who had gone to sleep, in the other. "Hep that lady up, Hiram," The Misfit said as she struggled to climb out 
of the ditch, "and Bobby Lee, you hold onto that little girl's hand." 
"I don't want to hold hands with him," June Star said. "He reminds me of a pig." 
The fat boy blushed and laughed and caught her by the arm and pulled her off into the woods after Hiram 
and her mother. 
Alone with The Misfit, the grandmother found that she had lost her voice. There was not a cloud in the sky 
nor any sun. There was nothing around her but woods. She wanted to tell him that he must pray. She opened 
and closed her mouth several times before anything came out. Finally she found herself saying, "Jesus. 
Jesus," meaning, Jesus will help you, but the way she was saying it, it sounded as if she might be cursing. 
"Yes'm," The Misfit said as if he agreed. "Jesus shown everything off balance. It was the same case with 
Him as with me except He hadn't committed any crime and they could prove I had committed one because 
they had the papers on me. Of course," he said, "they never shown me my papers. That's why I sign myself 
now. I said long ago, you get you a signature and sign everything you do and keep a copy of it. Then you'll 
know what you done and you can hold up the crime to the punishment and see do they match and in the end 
you'll have something to prove you ain't been treated right. I call myself The Misfit," he said, "because I 
can't make what all I done wrong fit what all I gone through in punishment." 
There was a piercing scream from the woods, followed closely by a pistol report. "Does it seem right to 
you, lady, that one is punished a heap and another ain't punished at all?" 
"Jesus!" the old lady cried. "You've got good blood! I know you wouldn't shoot a lady! I know you come 
from nice people! Pray! Jesus, you ought not to shoot a lady. I'll give you all the money I've got!" 
"Lady," The Misfit said, looking beyond her far into the woods, "there never was a body that give the 
undertaker a tip." 
There were two more pistol reports and the grandmother raised her head like a parched old turkey hen 
crying for water and called, "Bailey Boy, Bailey Boy!" as if her heart would break. 
"Jesus was the only One that ever raised the dead," The Misfit continued, "and He shouldn't have done it. 
He shown everything off balance. If He did what He said, then it's nothing for you to do but thow away 
everything and follow Him, and if He didn't, then it's nothing for you to do but enjoy the few minutes you 
got left the best way you can-by killing somebody or burning down his house or doing some other meanness 
to him. No pleasure but meanness," he said and his voice had become almost a snarl. 
"Maybe He didn't raise the dead," the old lady mumbled, not knowing what she was saying and feeling so 
dizzy that she sank down in the ditch with her legs twisted under her. 
"I wasn't there so I can't say He didn't," The Misfit said. "I wisht I had of been there," he said, hitting the 
ground with his fist. "It ain't right I wasn't there because if I had of been there I would of known. Listen 
lady," he said in a high voice, "if I had of been there I would of known and I wouldn't be like I am now." 
His voice seemed about to crack and the grandmother's head cleared for an instant. She saw the man's face 
twisted close to her own as if he were going to cry and she murmured, "Why you're one of my babies. 
You're one of my own children!" She reached out and touched him on the shoulder. The Misfit sprang back 
as if a snake had bitten him and shot her three times through the chest. Then he put his gun down on the 
ground and took off his glasses and began to clean them. 
Hiram and Bobby Lee returned from the woods and stood over the ditch, looking down at the grandmother 
who half sat and half lay in a puddle of blood with her legs crossed under her like a child's and her face 
smiling up at the cloudless sky. 
Without his glasses, The Misfit's eyes were red-rimmed and pale and defenseless-looking. "Take her off and 
thow her where you shown the others," he said, picking up the cat that was rubbing itself against his leg. 


## PDF page 88

88 
 
 
"She was a talker, wasn't she?" Bobby Lee said, sliding down the ditch with a yodel. 
"She would of been a good woman," The Misfit said, "if it had been somebody there to shoot her every 
minute of her life." 
"Some fun!" Bobby Lee said. 
"Shut up, Bobby Lee" The Misfit said. "It's no real pleasure in life." 


## PDF page 89

89 
 
 
“The A & P” (1961), by John Updike 
 
The novelist, short-story writer and poet John Updike (1932-2009) is one of the 
most prolific American writers to have ever lived, and is one of only three authors 
in history to win the Pulitzer Prize more than once. He wrote several popular 
‘series’ of novels, including the award-winning Rabbit Run series, the Bech series, 
and the Witches of Eastwick series. Below is one of his most popular short stories, 
one that is often compared to J.D. Salinger’s The Catcher in the Rye (1951) for its 
startling use of teenage skaz & mastery of teenage vernacular and point of view.  
 
 
 
In walks these three girls in nothing but bathing suits. I'm in the third check-out slot, with my back to 
the door, so I don't see them until they're over by the bread. The one that caught my eye first was the 
one in the plaid green two-piece. She was a chunky kid, with a good tan and a sweet broad soft-looking 
can with those two crescents of white just under it, where the sun never seems to hit, at the top of the 
backs of her legs. I stood there with my hand on a box of HiHo crackers trying to remember if I rang it 
up or not. I ring it up again and the customer starts giving me hell. She's one of these cash-register-
watchers, a witch about fifty with rouge on her cheekbones and no eyebrows, and I know it made her 
day to trip me up. She'd been watching cash registers forty years and probably never seen a mistake 
before. 
 
By the time I got her feathers smoothed and her goodies into a bag—she gives me a little snort in 
passing, if she'd been born at the right time they would have burned her over in Salem—by the time I 
get her on her way the girls had circled around the bread and were coming back, without a pushcart, 
back my way along the counters, in the aisle between the check-outs and the Special bins. They didn't 
even have shoes on. There was this chunky one, with the two-piece—It was bright green and the seams 
on the bra were still sharp and her belly was still pretty pale so I guessed she just got it (the suit)—there 
was this one, with one of those chubby berry-faces, the lips all bunched together under her nose, this 
one, and a tall one, with black hair that hadn't quite frizzed right, and one of these sunburns right across 
under the eyes, and a chin that was too long—you know, the kind of girl other girls think is very 
"striking" and "attractive" but never quite makes it, as they very well know, which is why they like 
her so much—and then the third one, that wasn't quite so tall. She was the queen. She kind of led them, 
the other two peeking around and making their shoulders round. She didn't look around, not this queen, 
she just walked straight on slowly, on these long white prima donna legs. She came down a little hard 
on her heels, as if she didn't walk in her bare feet that much, putting down her heels and then letting the 
weight move along to her toes as if she was testing the floor with every step, putting a little deliberate 
extra action into it. You never know for sure how girls' minds work (do you really think it's a mind in 
there or just a little buzz like a bee in a glassjar?) but you got the idea she had talked the other two into 
coming in here with her, and now she was showing them how to do it, walk slow and hold yourself 
straight. 
 
She had on a kind of dirty-pink—beige maybe, I don't know—bathing suit with a little nubble all over it 
and, what got me, the straps were down. They were off her shoulders looped loose around the cool tops 
of her arms, and I guess as a result the suit had slipped a little on her, so all around the top of the cloth 
there was this shining rim. If it hadn't been there you wouldn't have known there could have been 
anything whiter than those shoulders. With the straps pushed off, there was nothing between the top of 
the suit and the top of her head except just her, this clean bare plane of the top of her chest down from 
the shoulder bones like a dented sheet of metal tilted in the light. I mean, it was more than pretty. 


## PDF page 90

90 
 
 
 
She had sort of oaky hair that the sun and salt had bleached, done up in a bun that was unravelling, and a 
kind of prim face. Walking into the A & P with your straps down, I suppose it's the only kind of face 
you can have. She held her head so high her neck, coming up out of those white shoulders, looked kind 
of stretched, but I didn't mind. The longer her neck was, the more of her there was. 
 
She must have felt in the corner of her eye me and over my shoulder Stokesie in the second slot 
watching, but she didn't tip. Not this queen. She kept her eyes moving across the racks, and stopped, and 
turned so slow it made my stomach rub the inside of my apron, and buzzed to the other two, who kind 
of huddled against her for relief, and they all three of them went up the cat-and-dog-food-breakfast-
cereal-macaroni-ri ce-raisins-seasonings-spreads-spaghetti-soft drinks-crackers-and- cookies aisle. From 
the third slot I look straight up this aisle to the meat counter, and I watched them all the way. The fat 
one with the tan sort of fumbled with the cookies, but on second thought she put the packages back. The 
sheep pushing their carts down the aisle—the girls were walking against the usual traffic (not that we 
have one-way signs or anything)—were pretty hilarious. You could see them, when Queenie's white 
shoulders dawned on them, kind of jerk, or hop, or hiccup, but their eyes snapped back to their own 
baskets and on they pushed. I bet you could set off dynamite in an A & P and the people would by and 
large keep reaching and checking oatmeal off their lists and muttering "Let me see, there was a third 
thing, began with A, asparagus, no, ah, yes, applesauce!" or whatever it is they do mutter. But there was 
no doubt, this jiggled them. A few house-slaves in pin curlers even looked around after pushing their 
carts past to make sure what they had seen was correct. 
 
You know, it's one thing to have a girl in a bathing suit down on the beach, where what with the glare 
nobody can look at each other much anyway, and another thing in the cool of the A & P, under the 
fluorescent lights, against all those stacked packages, with her feet paddling along naked over our 
checkerboard green-and-cream rubber-tile floor. 
 
"Oh Daddy," Stokesie said beside me. "I feel so faint." 
 
"Darling," I said. "Hold me tight." Stokesie's married, with two babies chalked up on his fuselage 
already, but as far as I can tell that's the only difference. He's twenty-two, and I was nineteen this April. 
 
"Is it done?" he asks, the responsible married man finding his voice. I forgot to say he thinks he's going 
to be manager some sunny day, maybe in 1990 when it's called the Great Alexandrov and Petrooshki 
Tea Company or something. 
 
What he meant was, our town is five miles from a beach, with a big summer colony out on the Point, but 
we're right in the middle of town, and the women generally put on a shirt or shorts or something before 
they get out of the car into the street. And anyway these are usually women with six children and 
varicose veins mapping their legs and nobody, including them, could care less. As I say, we're right in 
the middle of town, and if you stand at our front doors you can see two banks and the Congregational 
church and the newspaper store and three real-estate offices and about twenty-seven old free-loaders 
tearing up Central Street because the sewer broke again. It's not as if we're on the Cape; we're north of 
Boston and there's people in this town haven't seen the ocean for twenty years. 
 
The girls had reached the meat counter and were asking McMahon something. He pointed, they pointed, 
and they shuffled out of sight behind a pyramid of Diet Delight peaches. All that was left for us to see 
was old McMahon patting his mouth and looking after them sizing up their joints. Poor kids, I began to 
feel sorry for them, they couldn't help it.  
 


## PDF page 91

91 
 
 
Now here comes the sad part of the story, at least my family says it's sad but I don't think it's sad myself. 
The store's pretty empty, it being Thursday afternoon, so there was nothing much to do except lean on 
the register and wait for the girls to show up again. The whole store was like a pinball machine and I 
didn't know which tunnel they'd come out of. After a while they come around out of the far aisle, around 
the light bulbs, records at discount of the Caribbean Six or Tony Martin Sings or some such gunk you 
wonder they waste the wax on, six-packs of candy bars, and plastic toys done up in cellophane that fall 
apart when a kid looks at them anyway. Around they come, Queenie still leading the way, and holding a 
little gray jar in her hand. Slots Three through Seven are unmanned and I could see her wondering 
between Stokes and me, but Stokesie with his usual luck draws an old party in baggy gray pants who 
stumbles up with four giant cans of pineapple juice (what do these bums do with all that pineapple juice' 
I've often asked myself) so the girls come to me. Queenie puts down the jar and I take it into my fingers 
icy cold. Kingfish Fancy Herring Snacks in Pure Sour Cream: 49¢. Now her hands are empty, not a ring 
or a bracelet, bare as God made them, and I wonder where the money's coming from. Still with that 
prim look she lifts a folded dollar bill out of the hollow at the center of her nubbled pink top. The jar 
went heavy in my hand. Really, I thought that was so cute. 
 
Then everybody's luck begins to run out. Lengel comes in from haggling with a truck full of cabbages 
on the lot and is about to scuttle into that door marked MANAGER behind which he hides all day when 
the girls touch his eye. Lengel's pretty dreary, teaches Sunday school and the rest, but he doesn't miss 
that much. He comes over and says, "Girls, this isn't the beach." 
 
Queenie blushes, though maybe it's just a brush of sunburn I was noticing for the first time, now that she 
was so close. "My mother asked me to pick up a jar of herring snacks." Her voice kind of startled me, 
the way voices do when you see the people first, coming out so flat and dumb yet kind of tony, too, the 
way it ticked over "pick up" and "snacks." All of a sudden I slid right down her voice into her living 
room. Her father and the other men were standing around in ice-cream coats and bow ties and the 
women were in sandals picking up herring snacks on toothpicks off a big plate and they were all holding 
drinks the color of water with olives and sprigs of mint in them. When my parents have somebody over 
they get lemonade and if it's a real racy affair Schlitz in tall glasses with "They'll Do It Every Time" 
cartoons stencilled on. 
 
"That's all right," Lengel said. "But this isn't the beach." His repeating this struck me as funny, as if it 
hadjust occurred to him, and he had been thinking all these years the A & P was a great big dune and he 
was the head lifeguard. He didn't like my smiling—as I say he doesn't miss much—but he 
concentrates on giving the girls that sad Sunday- school-superintendent stare. 
 
Queenie's blush is no sunburn now, and the plump one in plaid, that I liked better from the back—a 
really sweet can—pipes up, "We weren't doing any shopping. We just came in for the one thing." 
 
"That makes no difference," Lengel tells her, and I could see from the way his eyes went that he hadn't 
noticed she was wearing a two-piece before. "We want you decently dressed when you come in here." 
 
"We are decent," Queenie says suddenly, her lower lip pushing, getting sore now that she remembers 
her place, a place from which the crowd that runs the A & P must look pretty crummy. Fancy Herring 
Snacks flashed in her very blue eyes. 
 
"Girls, I don't want to argue with you. After this come in here with your shoulders covered. It's our 
policy." He turns his back. That's policy for you. Policy is what the kingpins want. What the others want 
is juvenile delinquency. 
 


## PDF page 92

92 
 
 
All this while, the customers had been showing up with their carts but, you know, sheep, seeing a scene, 
they had all bunched up on Stokesie, who shook open a paper bag as gently as peeling a peach, not 
wanting to miss a word. I could feel in the silence everybody getting nervous, most of all Lengel, who 
asks me, "Sammy, have you rung up this purchase?" 
 
I thought and said "No" but it wasn't about that I was thinking. I go through the punches, 4, 9, GROC, 
TOT—it's more complicated than you think, and after you do it often enough, it begins to make a lttle 
song, that you hear words to, in my case "Hello (bing) there, you (gung) hap-py pee-pul (splat)"-the 
splat being the drawer flying out. I uncrease the bill, tenderly as you may imagine, it just having come 
from between the two smoothest scoops of vanilla I had ever known were there, and pass a half and a 
penny into her narrow pink palm, and nestle the herrings in a bag and twist its neck and hand it over, all 
the time thinking. 
 
The girls, and who'd blame them, are in a hurry to get out, so I say "I quit" to Lengel quick enough for 
them to hear, hoping they'll stop and watch me, their unsuspected hero. They keep right on going, into 
the electric eye; the door flies open and they flicker across the lot to their car, Queenie and Plaid and 
Big Tall Goony-Goony (not that as raw material she was so bad), leaving me with Lengel and a kink in 
his eyebrow. 
 
"Did you say something, Sammy?" 
 
"I said I quit." 
 
"I thought you did." 
 
"You didn't have to embarrass them." 
 
"It was they who were embarrassing us." 
 
I started to say something that came out "Fiddle-de-doo." It's a saying of my grand- mother's, and I 
know she would have been pleased. 
 
"I don't think you know what you're saying," Lengel said. 
 
"I know you don't," I said. "But I do." I pull the bow at the back of my apron and start shrugging it off 
my shoulders. A couple customers that had been heading for my slot begin to knock against each other, 
like scared pigs in a chute. 
 
Lengel sighs and begins to look very patient and old and gray. He's been a friend of my parents for 
years. "Sammy, you don't want to do this to your Mom and Dad," he tells me. It's true, I don't.  
 
But it seems to me that once you begin a gesture it's fatal not to go through with it. I fold the apron, 
"Sammy" stitched in red on the pocket, and put it on the counter, and drop the bow tie on top of it. The 
bow tie is theirs, if you've ever wondered. "You'll feel this for the rest of your life," Lengel says, and I 
know that's true, too, but remembering how he made that pretty girl blush makes me so scrunchy inside 
I punch the No Sale tab and the machine whirs "pee-pul" and the drawer splats out. One advantage to 
this scene taking place in summer, I can follow this up with a clean exit, there's no fumbling around 
getting your coat and galoshes, I just saunter into the electric eye in my white shirt that my mother 
ironed the night before, and the door heaves itself open, and outside the sunshine is skating around on 
the asphalt. 


## PDF page 93

93 
 
 
 
I look around for my girls, but they're gone, of course. There wasn't anybody but some young married 
screaming with her children about some candy they didn't get by the door of a powder-blue Falcon 
station wagon. Looking back in the big windows, over the bags of peat moss and aluminum lawn 
furniture stacked on the pavement, I could see Lengel in my place in the slot, checking the sheep 
through. His face was dark gray and his back stiff, as if he'd just had an injection of iron, and my 
stomach kind of fell as I felt how hard the world was going to be to me hereafter. 
 


## PDF page 94

94 
 
 
“I Used to Live Here Once” in Sleep It Off Lady (1976), by Jean Rhys 
 
Jean Rhys (1890-1979) was born in the West Indies but resided in England from 
age sixteen and went on to become an important transcultural British novelist and 
short-story writer. Her most famous work is her 1966 novel Wide Sargasso Sea, 
an imagined prequel to Charlotte Brontë’s Jane Eyre. Many of her stories, like 
the brief ghost story below that was written just before her death, reflect her 
themes of alienation and lack of belonging, something she experienced in life, as 
she felt she was never fully a part of West Indies culture or of white British 
culture because of her bi-national identity. 
 
 
She was standing by the river looking at the stepping stones and remembering each one. There 
was the round unsteady stone, the pointed one, the flat one in the middle – the safe stone where 
you could stand and look round. The next wasn’t so safe, for when the river was full the water 
flowed over it and even when it showed dry it was slippery. But after that it was easy and soon 
she was standing on the other side. 
The road was much wider than it used to be but the work had been done carelessly. The felled 
trees had not been cleared away and the bushes looked trampled. Yet it was the same road and 
she walked along feeling extraordinarily happy. 
It was a fine day, a blue day. The only thing was that the sky had a glassy look that she didn’t 
remember. That was the only word she could think of. Glassy. She turned the corner, saw that 
what had been the old pavé had been taken up, and there too the road was much wider, but it had 
the same unfinished look. 
She came to the worn stone steps that led up to the house and her heart began to beat. The screw 
pine was gone, so was the mock summer house called the ajoupa, but the clove tree was still 
there and at the top of the steps the rough lawn stretched away, just as she remembered it. She 
stopped and looked towards the house that had been added to and painted white. It was strange to 
see a car standing in front of it. 
There were two children under the big mango tree, a boy and a little girl, and she waved to them 
and called ‘Hello’ but they didn’t answer her or turn their heads. Very fair children, as 
Europeans born in the West Indies so often are: as if the white blood is asserting itself against all 
odds. 
The grass was yellow in the hot sunlight as she walked towards them. When she was quite close 
she called again shyly: ‘Hello.’ Then, ‘I used to live here once,’ she said. 
Still they didn’t answer. When she said for the third time ‘Hello’ she was quite near them. Her 
arms went out instinctively with the longing to touch them. 
It was the boy who turned. His grey eyes looked straight into hers. His expression didn’t change. 
He said: ‘Hasn’t it gone cold all of a sudden. D’you notice? Let’s go in.’ ‘Yes let’s,’ said the girl. 
Her arms fell to her sides as she watched them running across the grass to the house. That was 
the first time she knew.


## PDF page 95

95 
 
 
“The Werewolf,” in The Bloody Chamber (1978), Angela CARTER (1940-1992) 
 
Angela Carter was born Angela Olive Stalker in Sussex, England, on 8 May, 1940. She was 
raised in Yorkshire by her maternal grandmother, an ageing but indomitable feminist who told 
her stories by the fire. In the late 1970’s, after translating a series of Perrault’s fairy tales into 
English, Carter decided to give a feminist and politically incorrect twist to a number of 
traditional tales in her collection The Bloody Chamber, from which this story is taken. Notice 
especially Carter’s remarkable use of intertextuality in her retelling of “Little Red Riding 
Hood”. 
 
 
It is a northern country; they have cold weather, they have cold hearts. 
Cold; tempest; wild beasts in the forest. It is a hard life. Their houses are built of logs, dark and 
smoky within. There will be a crude icon of the virgin behind a guttering candle, the leg of a 
pig hung up to cure, a string of drying mushrooms. A bed, a stool, a table.  Harsh, poor lives. 
To these upland woodsmen, the Devil is as real as you or I. More so; they have not seen us nor 
even know we exist, but the Devil they glimpse often in the graveyards, those bleak and 
touching townships of the dead where graves are marked with portraits of the deceased in the 
naïf style and there are no flowers to put in front of them, no flowers grow there, so they put 
out small, votive offerings, little loaves, sometimes a cake that bears come lumbering from the 
margins of the forest to snatch away. At midnight especially on Walpurgisnacht, the Devil 
holds picnics in the graveyards and invites witches; then they dig up fresh corpses and eat 
them. Anyone will tell you that. 
Wreaths of garlic on the doors keep out the vampires. A blue-eyed child born feet first on the 
night of St. John’s Eve will have second sight. When they discover a witch—some old woman 
whose cheeses ripen when her neighbour’s do not, another old woman whose black cat, oh 
sinister! Follows her about all the time, they strip the crone, search for her marks, for the 
supernumerary nipple her familiar sucks. They soon find it. They stone her to death. 
Winter and cold weather. 
Go and visit grandmother, who has been sick. Take her the oatcakes I’ve baked for her on the 
hearthstone and a little pot of butter. 
The good child does as her mother bids—five miles’ trudge through the forest; do not leave the 
path because of the bears, the wild boar, the starving wolves. Here, take your father’s hunting 
knife; you know how to use it. 
The child has a scabby coat of sheepskin to keep out the cold, she knew the forest too well to 
fear it but she must always be on her guard. When she heard the freezing howl of a wolf, she 
dropped her gifts, seized her knife and turned on the beast. 
It was a huge one, with red eyes and running, grizzled chops; any but a mountaineer’s child 
would have died of fright at the sight of it. It went for her throat as wolves do, but she made a 
great swipe at it with her father’s knife and slashed off its right paw. 
The wolf let out a gulp, almost a sob, when it saw what had happened to it; wolves are less 
brave than they seem. It went lolloping off disconsolately between the trees as well as it could 
on three legs, leaving a trail of blood behind it. The child wiped the blade of her knife clean on 


## PDF page 96

96 
 
 
her apron, wrapped the wolf’s paw in the cloth in which her mother had packed the oatcakes 
and went on to her grandmother’s house. Soon it came on to snow so thick that the pat and any 
footsteps, tracks or spoor that might have been upon it were obscured. 
She found her grandmother was so sick she had taken to her bed and fallen into a fretful sleep, 
moaning and shaking so that the child guessed she had a fever. She felt the forehead, it burned. 
She shook out the cloth from her basket, to use it to make the old woman a cold compress, and 
the wolf’s paw fell to the ground. 
But it was no longer a wolf’s paw. It was a hand, chopped off at the wrist, a hand toughened 
with work and freckled with age. There was a wedding ring on the third finger and a wart on 
the indew finger. By the wart, she knew it for her grandmother’s hand. 
She pulled back the sheet but the old woman woke up, at that, and began to struggle, 
squawking, and shrieking like a thing possessed. But the child was strong, and armed with her 
father’s hunting knife, she managed to hold her grandmother down long enough to see the 
cause of her fever. There was a bloody stump where her right hand should have been, festering 
already. 
The child crossed herself and cried out so loud the neighbours heard her and came rushing in. 
They knew the wart on the hand at once for a witch’s nipple; they drove the old woman, in her 
shift as she was, out into the snow with sticks, beating her old carcass as far as the edge of the 
forest, and pelted her with stones until she fell down dead. 
Now the child lived on in her grandmother’s house; she prospered. 


## PDF page 97

97 
 
 
“I Could See the Smallest Things” (1981), by Raymond Carver 
 
Raymond Carver (1938-1988) received great acclaim as a short story writer and poet 
from the publication of his first collection of stories in 1976 until his death at age 50 
only twelve years later, and he was nominated for the Pulitzer Prise for fiction in 
1989. In the Preface to his last collection, he claimed that he was “inclined toward 
brevity and intensity” and thus the short story and poetry, and stressed the 
importance, as Poe had, of his works being read in one sitting. Though some called 
him a ‘minimalist’ (for a style that can remind us of Hemingway) and others a ‘dirty 
realist’ (for focusing on the sadness and loss of everyday people), Carver rejected 
those labels, as he did labels in general. This story is from his landmark 1981 
collection What We Talk about When We Talk about Love. 
 
I was in bed when I heard the gate. I listened carefully. I didn’t hear anything else. But I heard 
that. I tried to wake Cliff. He was passed out. So I got up and went to the window. A big moon 
was laid over the mountains that went around the city. It was a white moon and covered with stars. 
Any damn fool could imagine a face there. 
There was light enough so that I could see everything in the yard – lawn chairs, the willow tree, 
clothesline strung between the poles, the petunias, the fences, the gate standing wide open. 
But nobody was moving around. There were no scary shadows. Everything lay in moonlight, and I 
could see the smallest things. The clothespins on the line for instance. 
I put my hands on the glass to block out the moon. I looked some more. I listened. Then I went 
back to bed.But I couldn’t get to sleep. I kept turning over. I thought about the gate standing open. 
It was like a dare. Cliff’s breathing was awful to listen to. His mouth gaped open and his arms 
hugged his pale chest. He was taking up his side of the bed and most of mine. 
I pushed and pushed on him. But he just groaned. 
I stayed a while longer until I decided it was no use. I got up and got my slippers. I went to the 
kitchen and made tea and sat with it at the kitchen table. I smoked one of Cliff’s unfiltered 
cigarettes. 
It was late. I didn’t want to look at the time. I drank the tea and smoked another cigarette. After a 
while I decided I’d go out and fasten up the gate. 
So I got my robe. 
The moon lighted up everything – houses and trees, poles and power lines, the whole world. I 
peered around the backyard before I stepped off the porch. A little breeze came along that made 
me close the robe. 
I started for the gate. 
There was a noise at the fences that separated our place from Sam Lawton’s place. I took a sharp 
look. Sam was leaning with his arms on his fence, there being two fences to lean on. He raised his 
fist to his mouth and gave a dry cough. 
‘Evening Nancy’, Sam Lawton said. 


## PDF page 98

98 
 
 
I said, ‘Sam you scared me.’ I said, ‘What are you doing up?’ ‘Did you hear something?’ I said. ‘I 
heard the gate unlatch.’ 
He said, ‘I didn’t hear anything. Haven’t seen anything, either. It might have been the wind.’ 
He was chewing something. He looked at the open gate and shrugged. His hair was silvery in the 
moonlight and stood up on his head. I could see his long nose, the lines in his big sad face. 
I said, ‘What are you doing up, Sam? and moved closer to the fence. ‘Want to see something?’ he 
said. 
‘I’ll come 'round’, I said. 
I let myself out and went along the walk. It felt funny walking around outside in my nightgown 
and my robe. I thought to myself that I should try to remember this, walking around outside like 
this. 
Sam was standing over by the side of his house, his pyjamas way up high over his tan-and-white 
shoes. He was holding a flashlight in one hand and a can of something in the other. 
Sam and Cliff used to be friends. Then one night they got to drinking. They had words. The next 
thing, Sam had built a fence and then Cliff built one too. 
That was after Sam had lost Mille, gotten married again, and become a father again all in the space 
of no time at all. Millie had been a good friend until she died. She was only forty-five when she 
did it. Heart failure. It hit her just as she was coming into their drive. The car kept going and went 
through the back of the carport. 
‘Look at this,’ Sam said, hitching his pyjama trousers and squatting down. He pointed his light at 
the ground. I looked and saw some wormy things curled on a patch of dirt. 
‘Slugs,’ he said. ‘I just gave them a dose of this’, he said, raising a can of something that looked 
like Ajax. ‘They’re taking over,’ he said, and worked whatever it was that he had in his mouth. He 
turned his head to one side and spit what could have been tobacco. ‘I have to keep at this to just 
come close to staying up with them.’ He turned his light on a jar that was filled with the things. ‘I 
put the bait out, and then every chance I get I come out here with this stuff. Bastards are all over. 
A crime what they can do. Look here,’ he said. He got up. He took my arm and moved me over to his 
rosebushes. He showed me the little holes in the leaves. 
‘Slugs’, he said. ‘Everywhere you look around here at night. I lay out bait and then I come out and 
get them,’ he said. ‘An awful invention, the slug. I save them up in that jar over there.’ He moved 
his light to under the rosebush. 
A plane passed overhead. I imagined the people on it staring down at the ground. ‘Sam’, I said, 
‘how’s everybody?’ 
‘They’re fine,’ he said, and shrugged. 
He chewed on whatever it was he was chewing. ‘How’s Clifford?’ he said. I said, ‘Same as ever.’ 
Sam said, ‘Sometimes when I’m out here after the slugs, I’ll look over in your direction.’ He said, ‘I 
wish me and Cliff were friends again. Look there now,’ he said, and drew a sharp ‘There’s one 
there. See him? Right there where my light is.’ He had the beam directed onto the dirt under the 
rosebush. ‘Watch this,’ Sam said. 


## PDF page 99

99 
 
 
I closed my arms under my breasts and bent over to where he was shining his light. The thing 
stopped moving and turned its head from side to side. Then Sam was over it with his can of powder, 
sprinkling the powder down. 
‘Slimy things’, he said. 
The slug was twisting this way and that. Then it curled and straightened out. Sam picked up a toy 
shovel, and scooped the slug into it, and dumped it out in the jar. 
‘I quit you know,’ Sam said. ‘Had to. For a while it was getting so I didn’t know up 
from down. We still keep it around the house but I don’t have much to do with it anymore.’ 
I nodded. He looked at me and he kept looking. ‘I’d better get back,’ I said. 
‘Sure,’ he said. ‘I’ll continue with what I’m doing and then when I’m finished, I’ll head in too.’ I 
said, ‘Good night, Sam. 
He said, ‘Listen.’ He stopped chewing. With his tongue, he pushed whatever it was behind his 
lower lip. ‘Tell Cliff I said hello.’ 
I said, ‘I’ll tell him you said so, Sam.’ 
Sam ran his hand through his silvery hair as if he was going to make it sit down once and for all, 
and then he used his hand to wave. 
In the bedroom, I took off the robe, folded it, put it within reach. Without looking at the time, I 
checked to make sure the stem was out on the clock. Then I got into bed, pulled the covers up, and 
closed my eyes. It was then that I remembered I’d forgotten to latch the gate. 
I opened my eyes and lay there. I gave Cliff a little shake. He cleared his throat. He swallowed. 
Something caught and dribbled in his chest. 
I don’t know. It made me think of those things that Sam Lawton was dumping powder on. 
I thought for a minute of the world outside my house, and then didn’t have any more thoughts 
except the thought that I had to hurry up and sleep. 


## PDF page 100

100 
 
 
“A Family Supper” (1982), by Kazuo Ishiguro 
Kazuo Ishiguo was born in 1954 in Nagasaki, Japan, and moved to Britain with his family 
when he was five years old. He has gone on to become one of the most important novelists 
and short-story writers of our time, winning the Booker Prize in 1989 and the Nobel Prize 
for Literature in 2017. His story "A Family Supper" is a poignant narrative that explores 
themes of family dynamics, loss, and cultural disconnection. The story unfolds during a 
dinner in Tokyo, where a young man, recently returned from California, reunites with his 
father and sister after their mother's death. 
 
Fugu is a fish caught off the Pacific shores of Japan. The fish has held a special significance for me 
ever since my mother died through eating one. The poison resides in the sexual glands of the fish, 
inside two fragile bags. When preparing the fish, these bags must be removed with caution, for any 
clumsiness will result in the poison leaking into the veins. Regrettably, it is not easy to tell whether 
or not this operation has been carried out successfully. The proof is, as it were, in the eating. 
Fugu poisoning is hideously painful and almost always fatal. If the fish has been eaten during the 
evening, the victim is usually overtaken by pain during his sleep. He rolls about in agony for a few 
hours and is dead by morning. The fish became extremely popular in Japan after the war. Until 
stricter regulations were imposed, it was all the rage to perform the hazardous gutting operation in 
one's own kitchen, then to invite neighbours and friends round for the feast. 
At the time of my mother's death, I was living in California. My relationship with my parents had 
become somewhat strained around that period, and consequently I did not learn of the 
circumstances surrounding her death until I returned to Tokyo two years later. Apparently, my 
mother had always refused to eat fugu, but on this particular occasion she had made an exception, 
having been invited by an old schoolfriend whom she was anxious not to offend. It was my father 
who supplied me with the details as we drove from the airport to his house in the Kamakura district. 
When we finally arrived, it was nearing the end of a sunny autumn day, 
'Did you eat on the plane?' my father asked. We were sitting on the tatami floor of his tea-room. 
'They gave me a light snack.' 
'You must be hungry. We'll eat as soon as Kikuko arrives.' 
 
My father was a formidable-looking man with a large stony jaw and furious black eyebrows. I think 
now in retrospect that he much resembled Chou En-lai, although he would not have cherished such 
a comparison, being particularly proud of the pure samurai blood that ran in the family. His general 
presence was not one which encouraged relaxed conversation; neither were things helped much by 
his odd way of stating each remark as if it were the concluding one. In fact, as I sat opposite him 
that afternoon, a boyhood memory came back to me of the time he had struck me several times 
around the head for 'chattering like an old woman'. Inevitably, our conversation since my arrival at 
the airport had been punctuated by long pauses. 
 
'I'm sorry to hear about the firm,' I said when neither of us had spoken for some time. 
He nodded gravely. 
'In fact the story didn't end there,' he said. 'After the firm's collapse, Watanabe killed himself. He 
didn't wish to live with the disgrace.' 
'I see.' 
'We were partners for seventeen years. A man of principle and honour. I respected him very much.' 
'Will you go into business again?' I asked. 


## PDF page 101

101 
 
 
'I am - in retirement. I'm too old to involve myself in new ventures now. Business these days has 
become so different. Dealing with foreigners. Doing things their way. I don't understand how we've 
come to this. Neither did Watanabe.' He sighed. 'A fine man. A man of principle.' 
 
The tea-room looked out over the garden. From where I sat I could make out the ancient well which 
as a child I had believed haunted. It was just visible now through the thick foliage. The sun had 
sunk low and much of the garden had fallen into shadow. 
'I'm glad in any case that you've decided to come back,' my father said. 'More than a short visit, I 
hope.' 
'I'm not sure what my plans will be.' 
'I for one am prepared to forget the past. Your mother too was always ready to welcome you 
back - upset as she was by your behaviour.' 
'I appreciate your sympathy. As I say, I'm not sure what my plans are.' 
'I've come to believe now that there were no evil intentions in your mind,' my father continued. 
'You were swayed by certain- influences. Like so many others.' 
'Perhaps we should forget it, as you suggest.' 'As you will. More tea?' 
 
Just then a girl's voice came echoing through the house. 
'At last.' My father rose to his feet. 'Kikuko has arrived.' 
 
Despite our difference in years, my sister and I had always been close. Seeing me again seemed to 
make her excessively excited and for a while she did nothing but giggle nervously. But she calmed 
down somewhat when my father started to question her about Osaka and her university. She 
answered him with short formal replies. She in turn asked me a few questions, but she seemed 
inhibited by the fear that her questions might lead to awkward topics. After a while, the 
conversation had become even sparser than prior to Kikuko's arrival. Then my father stood up, 
saying: 'I must attend to the supper. Please excuse me for being burdened down by such matters. 
Kikuko will look after you.' 
My sister relaxed quite visibly once he had left the room. Within a few minutes, she was chatting 
freely about her friends in Osaka and about her classes at university. Then quite suddenly she 
decided we should walk in the garden and went striding out onto the veranda. We put on some 
straw sandals that had been left along the veranda rail and stepped out into the garden. The daylight 
had almost gone. 
'I've been dying for a smoke for the last half-hour,' she said, lighting a cigarette. 'Then why didn't 
you smoke?' 
She made a furtive gesture back towards the house, then grinned mischievously. 'Oh I see,'I said. 
'Guess what? I've got a boyfriend now.' 'Oh yes?' 
'Except I'm wondering what to do. I haven't made up my mind yet.' 'Quite understandable.' 
'You see, he's making plans to go to America. He wants me to go with him as soon as I finish 
studying.' 
‘I see. And you want to go to America?' 
'If we go, we're going to hitch-hike.' Kikuko waved a thumb in front of my face. 'People say it's 
dangerous, but I've done it in Osaka and it's fine.' 
'I see. So what is it you're unsure about?' 
 


## PDF page 102

102 
 
 
We were following a narrow path that wound through the shrubs and finished by the old well. As 
we walked, Kikuko persisted in taking unnecessarily theatrical puffs on her cigarette. 'Well. I've got 
lots of friends now in Osaka. I like it there. I'm not sure I want to leave them all behind just yet. 
And Suichi – I like him, but I'm not sure I want to spend so much time with him. 
 
Do you understand?' 'Oh perfectly.' 
 
She grinned again, then skipped on ahead of me until she had reached the well. 'Do you 
remember,' she said, as I came walking up to her, 'how you used to say this well was haunted?' 
 
'Yes, I remember.' We both peered over the side. 
'Mother always told me it was the old woman from the vegetable store you'd seen that night,' she 
said. 'But I never believed her and never came out here alone.' 
'Mother used to tell me that too. She even told me once the old woman had confessed to being the 
ghost. Apparently she'd been taking a short cut through our garden. I imagine she had some trouble 
clambering over these walls.' 
Kikuko gave a giggle; She then turned her back to the well, casting her gaze about the garden. 
'Mother never really blamed you, you know,' she said, in a new voice. I remained silent. 
'She always used to say to me how it was then-fault, hers and Father's, for not bringing you up 
correctly. She used to tell me how much more careful they'd been with me, and that's why I was so 
good.' 
She looked up and the mischievous grin had returned to her face. 
 
'Poor Mother,' she said. 'Yes. Poor Mother.' 
'Are you going back to California?' 'I don't know. I'll have to see.' 
'What happened to - to her? To Vicki?' 
'That's all finished with,' I said. 'There's nothing much left for me now in California.' 'Do you think I 
ought to go there?' 
'Why not? I don't know. You'll probably like it.' I glanced towards the house. 'Perhaps we'd better 
go in soon. Father might need a hand with the supper.' 
 
But my sister was once more peering down into the well. 'I can't see any ghosts,' she said. Her voice 
echoed a little. 
'Is Father very upset about his firm collapsing?' 
'Don't know. You can never tell with Father.' Then suddenly she straightened up and turned to me. 
'Did he tell you about old Watanabe? What he did?' 
'I heard he committed suicide.' 
'Well, that wasn't all. He took his whole family with him. His wife and his two little girls.' 'Oh yes?' 
'Those two beautiful little girls. He turned on the gas while they were all asleep. Then he cut his 
stomach with a meat knife.' 
'Yes, Father was just telling me how Watanabe was a man of principle.' 'Sick.' My sister turned back 
to the well. 
'Careful. You'll fall right in.' 
'I can't see any ghost,' she said. 'You were lying to me all that time.' 'But I never said it lived down 
the well.' 
'Where is it, then?' 


## PDF page 103

103 
 
 
 
We both looked around at the trees and shrubs. The light in the garden had grown very dim. 
Eventually I pointed to a small clearing some ten yards away. 
 
'Just there I saw it. Just there.' We stared at the spot. 
'What did it look like?' 
'I couldn't see very well. It was dark.' 'But you must have seen something.' 
'It was an old woman. She was just standing there, watching me.' We kept staring at the spot as if 
mesmerized. 
'She was wearing a white kimono,' I said. 'Some of her hair had come undone. It was blowing 
around a little.' 
 
Kikuko pushed her elbow against my arm. 
'Oh be quiet. You're trying to frighten me all over again.' 
She trod on the remains of her cigarette, then for a brief moment stood regarding it with a perplexed 
expression. She kicked some pine needles over it, then once more displayed her grin. 
'Let's see if supper's ready,' she said. 
 
We found my father in the kitchen. He gave us a quick glance, then carried on with what he was 
doing. 
'Father's become quite a chef Since he's had to manage on his own,' Kikuko said with a laugh. He 
turned and looked at my sister coldly. 
'Hardly a skill I'm proud of,' he said. 'Kikuko, come here and help.' 
 
For some moments my sister did not move. Then she stepped forward and took an apron hanging 
from a drawer. 
'Just these vegetables need cooking now,' he said to her. 'The rest just needs watching.' Then he 
looked up and regarded me strangely for some seconds. 'I expect you want to look around the 
house,' he said eventually. He put down the chopsticks he had been holding. 'It's a long time since 
you've seen it.' 
 
As we left the kitchen I glanced back towards Kikuko, but her back was turned. 'She's a good girl,' 
my father said quietly. 
 
I followed my father from room to room. I had forgotten how large the house was. A panel would 
slide open and another room would appear. But the rooms were all startlingly empty. In one of the 
rooms the lights did not come on, and we stared at the stark walls and tatami in the pale light that 
came from the windows. 
'This house is too large for a man to live in alone,' my father said. 'I don't have much use for most of 
these rooms now.' 
 
But eventually my father opened the door to a room packed full of books and papers. There were 
flowers in vases and pictures on the walls. Then I noticed something on a low table in the corner of 
the room. I came nearer and saw it was a plastic model of a battleship, the kind constructed by 
children. It had been placed on some newspaper; scattered around it were assorted pieces of grey 
plastic. 


## PDF page 104

104 
 
 
My father gave a laugh. He came up to the table and picked up the model. 'Since the firm folded,' he 
said, 'I have a little more time on my hands.' 
He laughed again, rather strangely. For a moment his face looked almost gentle. 'A little more time.' 
'That seems odd,' I said. 'You were always so busy.' 
'Too busy perhaps.' He looked at me with a small smile. 'Perhaps I should have been a more 
attentive father.' 
 
I laughed. He went on contemplating his battleship. Then he looked up. 
'I hadn't meant to tell you this, but perhaps it's best that I do. It's my belief that your mother's 
death was no accident. She had many worries. And some disappointments.' 
 
We both gazed at the plastic battleship. 
 
'Surely,' I said eventually, 'my mother didn't expect me to live here forever.' 
'Obviously you don't see. You don't see how it is for some parents. Not only must they lose their 
children, they must lose them to things they don't understand.' He spun the battleship in his fingers. 
'These little gunboats here could have been better glued, don't you think?' 
'Perhaps. I think it looks fine.' 
'During the war I spent some time on a ship rather like this. But my 
ambition was always the air force. I figured it like this. If your ship was struck by the enemy, all 
you could do was struggle in the water hoping for a lifeline. But in an aeroplane - well - there was 
always the final weapon.' He put the model back onto the table. 'I don't suppose you believe in war.' 
'Not particularly.' 
He cast an eye around the room. 
'Supper should be ready by now,' he said. 'You must be hungry.' 
 
Supper was waiting in a dimly lit room next to the kitchen. The only source of light was a big 
lantern that hung over the table, casting the rest of the room into shadow. We bowed to each other 
before starting the meal. 
There was little conversation. When I made some polite comment about the food, Kikuko giggled a 
little. Her earlier nervousness seemed to have returned to her. My father did not speak for several 
minutes. Finally he said: 
'It must feel strange for you, being back in Japan.' 'Yes, it is a little strange.' 
'Already, perhaps, you regret leaving America.' 
'A little. Not so much. I didn't leave behind much. Just some empty rooms.' 'I see.' 
 
I glanced across the table. My father's face looked stony and forbidding in the half-light. We ate on 
in silence. 
Then my eye caught something at the back of the room. At first I continued eating, then my hands 
became still. The others noticed and looked at me. I went on gazing into the darkness past my 
father's shoulder. 
'Who is that? In that photograph there?' 
'Which photograph?' My father turned slightly, trying to follow my gaze. 'The lowest one. The old 
woman in the white kimono.' 
 
My father put down his chopsticks. He looked first at the photograph, then at me. 


## PDF page 105

105 
 
 
'Your mother.' His voice had become very hard. 'Can't you recognize your own mother?' 
'My mother. You see, it's dark. I can't see it very well.' 
 
No one spoke for a few seconds, then Kikuko rose to her feet. She took the photograph down from 
the wall, came back to the table and gave it to me. 
'She looks a lot older,' I said. 
'It was taken shortly before her death,' said my father. 'It was the dark. I couldn't see very well.' 
 
I looked up and noticed my father holding out a hand. I gave him the photograph. He looked at it 
intently, then held it towards Kikuko. Obediently, my sister rose to her feet once more and returned 
the picture to the wall. 
 
There was a large pot left unopened at the centre of the table. When Kikuko had seated herself 
again, my father reached forward and lifted the lid. A cloud of steam rose up and curled towards the 
lantern. He pushed the pot a little towards me. 
'You must be hungry,' he said. One side of his face had fallen into shadow. 
'Thank you.' I reached forward with my chopsticks. The steam was almost scalding. 'What is it?' 
'Fish.' 
'It smells very good.' 
 
In amidst soup were strips of fish that had curled almost into balls. I picked one out and 
brought it to my bowl. 
'Help yourself. There's plenty.' 
'Thank you.' I took a little more, then pushed the pot towards my father. I watched him take several 
pieces to his bowl. Then we both watched as Kikuko served herself. 
 
My father bowed slightly. 'You must be hungry,' he said again. 
He took some fish to his mouth and started to eat. Then I too chose a piece and put it in my 
mouth. It felt soft, quite fleshy against my tongue. 
'Very good,' I said. 'What is it?' 'Just fish.' 
'It's very good.' 
 
The three of us ate on in silence. Several minutes went by. 'Some more?' 
'Is there enough?' 
'There's plenty for all of us.' My father lifted the lid and once more steam rose up. We all reached 
forward and helped ourselves. 
'Here,' I said to my father, 'you have this last piece.' 'Thank you.' 
 
When we had finished the meal, my father stretched out his arms and yawned with an air of 
satisfaction. 
'Kikuko,' he said. 'Prepare a pot of tea, please.' 
 
My sister looked at him, then left the room without comment. My father stood up. 'Let's retire to the 
other room. It's rather warm in here. 
 


## PDF page 106

106 
 
 
I got to my feet and followed him into the tea-room. The large sliding windows had been left open, 
bringing in a breeze from the garden. For a while we sat in silence. 
 
'Father,' I said, finally. 'Yes?' 
'Kikuko tells me Watanabe-San took his whole family with him.' 
 
My father lowered his eyes and nodded. For some moments he seemed deep in thought. 'Watanabe 
was very devoted to his work,' he said at last. 'The collapse of the firm was a great blow to him. I 
fear it must have weakened his judgement.' 
 
'You think what he did - it was a mistake?' 'Why, of course. Do you see it otherwise?' 'No, no. Of 
course not.' 
'There are other things besides work.' 'Yes.' 
 
We fell silent again. The sound of locusts came in from the garden. I looked out into the 
darkness. The well was no longer visible. 
'What do you think you will do now?' my father asked. 'Will you stay in Japan for a while?' 
'To be honest, I hadn't thought that far ahead.' 
'If you wish to stay here, I mean here in this house, you would be very welcome. That is, if you 
don't mind living with an old man.' 
'Thank you. I'll have to think about it.' 
 
I gazed out once more into the darkness. 
'But of course,' said my father, 'this house is so dreary now. You'll no doubt return to America 
before long.' 
'Perhaps. I don't know yet.' 'No doubt you will.' 
 
For some time my father seemed to be studying the back of his hands. Then he looked up and 
sighed. 
'Kikuko is due to complete her studies next spring,' he said. 'Perhaps she will want to come home 
then. She's a good girl.' 
'Perhaps she will.' 'Things will improve then.' 'Yes, I'm sure they will.' 
 
We fell silent once more, waiting for Kikuko to bring the tea. 
 


## PDF page 107

107 
 
 
 
 
 
 
 
Excerpts from 
a few key novels 


## PDF page 108

108 
 
 
 
Pride and Prejudice (1813), Jane AUSTEN 
 
Austen’s gently satirical novels depict the gentry of small country villages. They often focus on the need for a young 
woman to find a husband. The following excerpt is the beginning of Pride and Prejudice, a work that is still immensely 
popular today. 
 
 
 
IT is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife. 
However little known the feelings or views of such a man may be on his first entering a neighbourhood, this truth is so well fixed in 
the minds of the surrounding families, that he is considered as the rightful property of some one or other of their daughters. 
 
 
‘My dear Mr Bennet,’ said his lady to him one day, ‘have you heard that Netherfield Park is let at last?’ 
5 
 
Mr Bennet replied that he had not. 
 
‘But it is,’ returned she; ‘for Mrs Long has just been here, and she told me all about it.’ 
 
 
Mr Bennet made no answer. 
 
‘Do not you want to know who has taken it?’ cried his wife impatiently. 
 
 
‘You want to tell me, and I have no objection to hearing it.’ This was invitation enough. 
10  
‘Why, my dear, you must know, Mrs Long says that Netherfield is taken by a young man of large fortune from the north of  
 
England; that he came down on Monday in a chaise and four to see the place, and was so much delighted with it that he agreed with  
 
Mr Morris immediately; that he is to take possession before Michaelmas, and some of his servants are to be in the house by the end of  
 
next week.’ 
 
 
‘What is his name?’ 
15  
‘Bingley.’ 
 
 
‘Is he married or single?’ 
 
 
‘Oh! single, my dear, to be sure! A single man of large fortune; four or five thousand a year. What a fine thing for our girls!’ 
 
 
‘How so? how can it affect them?’ 
 
 
‘My dear Mr Bennet,’ replied his wife, ‘how can you be so tiresome! You must know that I am thinking of his marrying one of  
20 them.’ 
 
 
‘Is that his design in settling here?’ 
   
‘Design! nonsense, how can you talk so! But it is very likely that he may fall in love with one of them, and therefore you must  
  visit him as soon as he comes.’ 
   
‘I see no occasion for that. You and the girls may go, or you may send them by themselves, which perhaps will be still better, for  
25 as you are as handsome as any of them, Mr Bingley might like you the best of the party.’ 
   
‘My dear, you flatter me. I certainly have had my share of beauty, but I do not pretend to be any thing extraordinary now. When a  
  woman has five grown up daughters, she ought to give over thinking of her own beauty. 
   
‘In such cases, a woman has not often much beauty to think of.’ 
  
‘But, my dear, you must indeed go and see Mr Bingley when he comes into the neighbourhood.’ 
30  
‘It is more than I engage for, I assure you.’ 
  
‘But consider your daughters. Only think what an establishment it would be for one of them. Sir William and Lady Lucas are  
 determined to go, merely on that account, for in general you know they visit no new comers. Indeed you must go, for it will be  
 impossible for us to visit him, if you do not. 
  
‘You are over scrupulous surely. I dare say Mr Bingley will be very glad to see you; and I will send a few lines by you to assure  
35  him of my hearty consent to his marrying which ever he chuses of the girls; though I must throw in a good word for my little Lizzy. 
  
‘I desire you will do no such thing. Lizzy is not a bit better than the others; and I am sure she is not half so handsome as Jane, nor  
 half so good humoured as Lydia. But you are always giving her the preference.’ 
  
‘They have none of them much to recommend them,’ replied he; ‘they are all silly and ignorant like other girls; but Lizzy has  
 something more of quickness than her sisters.’ 
40  
‘Mr Bennet, how can you abuse your own children in such a way? You take delight in vexing me. You have no compassion on  
 my poor nerves.’ 
  
‘You mistake me, my dear. I have a high respect for your nerves. They are my old friends. I have heard you mention them with  
 consideration these twenty years at least.’ 
  
‘Ah! you do not know what I suffer.’ 
45  
‘But I hope you will get over it, and live to see many young men of four thousand a year come into the neighbourhood.’ 
  
‘It will be no use to us, if twenty such should come since you will not visit them.’ 
  
‘Depend upon it, my dear, that when there are twenty, I will visit them all.’ 
  
Mr Bennet was so odd a mixture of quick parts, sarcastic humour, reserve, and caprice, that the experience of three and twenty  
 years had been insufficient to make his wife understand his character. Her mind was less difficult to develope. She was a woman of  
50 mean understanding, little information, and uncertain temper. When she was discontented she fancied herself nervous. The business  
 of her life was to get her daughters married; its solace was visiting and news. 


## PDF page 109

109 
 
 
The Scarlet Letter (1850), Nathaniel HAWTHORNE 
 
The title of Hawthorne’s most famous novel refers to the red letter that Hester Prynne has to wear as a 
punishment for having committed adultery in the Puritan society of colonial America. In the following 
passage, as Hester comes out of prison, her feelings of guilt and sin and her moral conflicts are exposed. 
 
 
Nathaniel Hawthorne (1804-1864) 
Hester Prynne’s term of confinement was now at an end. Her prison-door was thrown open, and she came 
forth into the sunshine, which, falling on all alike, seemed, to her sick and morbid heart, as if meant for no 
other purpose than to reveal the scarlet letter on her breast. Perhaps there was a more real torture in her first unattended footsteps 
from the threshold of the prison, than even in the procession and spectacle that have been described, where she was made the 
common infamy, at which all mankind was summoned to point its finger. Then, she was supported by an unnatural tension of the 
nerves, and by all the combative energy of her character, which enabled her to convert the scene into a kind of lurid triumph. It 
was, moreover, a separate and insulated event, to occur but once in her lifetime, and to meet which, therefore, reckless of 
economy, she might call up the vital strength that would have sufficed for many quiet years. The very law that condemned her—a 
giant of stern features, but with vigor to support, as well as to annihilate, in his iron arm—had held her up, through the terrible 
ordeal of her ignominy. But now, with this unattended walk from her prison-door, began the daily custom, and she must either 
sustain and carry it forward by the ordinary resources of her nature, or sink beneath it. She could no longer borrow from the 
future, to help her through the present grief. To-morrow would bring its own trial with it; so would the next day, and so would the 
next; each its own trial, and yet the very same that was now so unutterably grievous to be borne. The days of the far-off future 
would toil onward, still with the same burden for her to take up, and bear along with her, but never to fling down; for the 
accumulating days, and added years, would pile up their misery upon the heap of shame. Throughout them all, giving up her 
individuality, she would become the general symbol at which the preacher and moralist might point, and in which they might 
vivify and embody their images of woman’s frailty and sinful passion. Thus the young and pure would be taught to look at her, 
with the scarlet letter flaming on her breast,—at her, the child of honorable parents,—at her, the mother of a babe, that would 
hereafter be a woman,—at her, who had once been innocent,—as the figure, the body, the reality of sin. And over her grave, the 
infamy that she must carry thither would be her only monument. 
It may seem marvellous, that, with the world before her,—kept by no restrictive clause of her condemnation within the limits 
of the Puritan settlement, so remote and so obscure,—free to return to her birthplace, or to any other European land, and there 
hide her character and identity under a new exterior, as completely as if emerging into another state of being, and having also the 
passes of the dark, inscrutable forest open to her, where the wildness of her nature might assimilate itself with a people whose 
customs and life were alien from the law that had condemned her, it may seem marvellous, that this woman should still call that 
place her home, where, and where only, she must needs be the type of shame. But there is a fatality, a feeling so irresistible and 
inevitable that it has the force of doom, which almost invariably compels human beings to linger around and haunt, ghost-like, 
the spot where some great and marked event has given the color to their lifetime; and still the more irresistibly, the darker the 
tinge that saddens it. Her sin, her ignominy, were the roots which she had struck into the soil. It was as if a new birth, with 
stronger assimilations than the first, had converted the forest-land, still so uncongenial to every other pilgrim and wanderer, into 
Hester Prynne’s wild and dreary, but life-long home. All other scenes of earth—even that village of rural England, where happy 
infancy and stainless maidenhood seemed yet to be in her mother’s keeping, like garments put off long ago—were foreign to her, 
in comparison. The chain that bound her here was of iron links, and galling to her inmost soul, but never could be broken. 
It might be, too,—doubtless it was so, although she hid the secret from herself, and grew pale whenever it struggled out of her 
heart, like a serpent from its hole,—it might be that another feeling kept her within the scene and pathway that had been so fatal. 
There dwelt, there trode the feet of one with whom she deemed herself connected in a union, that, unrecognized on earth, would 
bring them together before the bar of final judgment, and make that their marriage-altar, for a joint futurity of endless retribution. 
Over and over again, the tempter of souls had thrust this idea upon Hester’s contemplation, and laughed at the passionate and 
desperate joy with which she seized, and then strove to cast it from her. She barely looked the idea in the face, and hastened to 
bar it in its dungeon. What she compelled herself to believe,—what, finally, she reasoned upon, as her motive for continuing a 
resident of New England,—was half a truth, and half a self-delusion. Here, she said to herself, had been the scene of her guilt, 
and here should be the scene of her earthly punishment; and so, perchance, the torture of her daily shame would at length purge 
her soul, and work out another purity than that which she had lost; more saint-like, because the result of martyrdom.  


## PDF page 110

110 
 
 
To the Lighthouse (1927), Virginia WOOLF 
 
 
  
Virginia Woolf, 1882-1941 
 
Fleeting sensations, confused thoughts, obscure impressions—Virginia Woolf 
tried to capture all the imperceptible elements of one’s inner life, thus bringing 
to a new - very feminine - perfection Henry James’ technique of the “stream of 
consciousness”. In the novel To the Lighthouse, Mrs Ramsay represents “Life”, 
in opposition to Lily Brisco, the painter, who represents “Art”. Yet Lily herself 
fails to express in paint the poignant ideal she has of her own work. Woolf 
analyses her dilemma in front of her white canvas here. 
 
 
Part III, chapter 3 
 
 
 
She saw her canvas as if it had floated up and placed itself white and uncompromising  
 
directly before her. It seemed to rebuke her with its cold stare for all this hurry and  
 
agitation; this folly and waste of emotion; it drastically recalled her and spread through her  
 
mind first a peace, as her disorderly sensations (he had gone and she had been so sorry for  
5 
him and she had said nothing) trooped off the field; and then, emptiness. She looked  
 
blankly at the canvas, with its uncompromising white stare; from the canvas to the garden.  
 
There was something (she stood screwing up her little Chinese eyes in her small puckered  
 
face), something she remembered in the relations of those lines cutting across, slicing  
 
down, and in the mass of the hedge with its green cave of blues and browns, which had  
10 
stayed in her mind; which had tied a knot in her mind so that at odds and ends of time,  
 
involuntarily, as she walked along the Brompton Road, as she brushed her hair, she found  
 
herself painting that picture, passing her eye over it, and untying the knot in imagination.  
 
But there was all the difference in the world between this planning airily away from the  
 
canvas and actually taking her brush and making the first mark. 
15 
 She had taken the wrong brush in her agitation at Mr Ramsay’s presence, and her easel,  
 
rammed into the earth so nervously, was at the wrong angle. And now that she had put that  
 
right, and in so doing had subdued the impertinences and irrelevances that plucked her  
 
attention and made her remember how she was such and such a person, had such and such  
 
relations to people, she took her hand and raised her brush. For a moment it stayed  
20 
trembling in a painful but exciting ecstasy in the air. Where to begin?—that was the  
 
question; at what point to make the first mark? One line placed on the canvas committed  
 
her to innumerable risks, to frequent and irrevocable decisions. All that in idea seemed  
 
simple became in practice immediately complex; as the waves shape themselves  
 
symmetrically from the cliff top, but to the swimmer among them are divided by steep  
25 
gulfs, and foaming crests. Still the risk must be run; the mark made. 
 
 With a curious physical sensation, as if she were urged forward and at the same time  
 
must hold herself back, she made her first quick decisive stroke. The brush descended. It  
 
flickered brown over the white canvas; it left a running mark. A second time she did it—a  
 
third time. And so pausing and so flickering, she attained a dancing rhythmical movement,  
30 
as if the pauses were one part of the rhythm and the strokes another, and all were related;  
 
and so, lightly and swiftly pausing, striking, she scored her canvas with brown running  
 
nervous lines which had no sooner settled there than they enclosed (she felt it looming out  
 
at her) a space. Down in the hollow of one wave she saw the next wave towering higher  
 
and higher above her. For what could be more formidable than that space? Here she was  


## PDF page 111

111 
 
 
35 
again, she thought, stepping back to look at it, drawn out of gossip, out of living, out of  
 
community with people into the presence of this formidable ancient enemy of hers—this  
 
other thing, this truth, this reality, which suddenly laid hands on her, emerged stark at the  
 
back of appearances and commanded reluctant. Why always be drawn out and haled away?  
 
 [... ] Why then did she do it?  She looked at the canvas, lightly scored with running lines.  
40 
It would be hung in the servants’ bedrooms. It would be rolled up and stuffed under a sofa.  
 
What was the good of doing it then, and she heard some voice saying she couldn’t paint,  
 
saying she couldn’t create, as if she were caught up in one of those habitual currents in  
 
which after a certain time experience forms in the mind, so that one repeats words without  
 
being aware any longer who originally spoke them. 
45 
 Can’t paint, can’t write, she murmured monotonously, anxiously considering what her  
 
plan of attack should be. For the mass loomed before her; it protruded, she felt it pressing  
 
on her eyeballs. Then, as if some juice necessary for the lubrication of her faculties were  
 
spontaneously squirted, she began precariously dipping among the blues and umbers,  
 
moving her brush hither and thither, but it was now heavier and went slower, as if it had  
50 
fallen in with some rhythm which was dictated to her (she kept looking at the hedge, at the  
 
canvas) by what she saw, so that while her hand quivered with life, this rhythm was strong  
 
enough to bear her along with it on its current. Certainly she was losing consciousness of  
 
outer things. And as she lost consciousness of outer things, and her name and her  
 
personality and her appearance, and whether Mr Carmichael was there or not, her mind  
 
kept throwing up from its depths, scenes, and names, and sayings, and memories and ideas,  
 
like a fountain spurting over that glaring, hideously difficult white space, while she  
 
modelled it with greens and blues. 
 


## PDF page 112

112 
 
 
Lolita (1955), Vladimir NABOKOV 
 
 
 
Vladimir Nabokov, 1899-1977 
 
 
 
This short, poetic text is the entire first chapter of 
Vladimir Nabokov's controversial 1955 novel, Lolita. 
The opening reads like a heart-felt ode to the girl 
Lolita on the part of ther narrator, Humbert Humbert.  
Yet, if you know Edgar Allan Poe's poem 'Annabel 
Lee', which is a clear subtext to this passage, you 
might wonder whether the narrator is playing some 
literary game with us. Can we trust such a narrator, 
especially when we consider the fact that we are 
reading the memoirs of a pedophile and a murderer… 
 
 
Part I 
 
 
   Lolita, light of my life, fire of my loins. My sin, my soul. Lo-lee-ta: the tip of the tongue taking a trip  
 
of three steps down the palate to tap, at three, on the teeth. Lo. Lee. Ta.  
 
   She was Lo, plain Lo, in the morning, standing four feet ten in one sock. She was Lola in slacks. She  
 
was Dolly at school. She was Dolores on the dotted line. But in my arms she was always Lolita.  
5 
   Did she have a precursor? She did, indeed she did. In point of fact, there might have been no Lolita 
at all had I not loved, one summer, a certain initial girl-child. In a princedom by the sea. Oh when? 
About as many years before Lolita was born as my age was that summer. You can always count on a 
murderer for a fancy prose style.  
 
   Ladies and gentlemen of the jury, exhibit number one is what the seraphs, the misinformed, simple,  
10 noble-winged seraphs, envied. Look at this tangle of thorns. 
 


## PDF page 113

113 
 
 
The Handmaid’s Tale (1985), Margaret ATWOOD 
Margaret Atwood (1939-) 
 
 
The Handmaid’s Tale is a dystopia in which Canadian writer Margaret Atwood imagines the 
futuristic republic of Gilead, an oppressive, hierarchized regime of the future, in which 
procreation is the sole role of a certain group of women, the handmaids. In this scene, the 
Commander, who regularly sees his handmaid Offred in secret, teases her with a women’s 
magazine, a relic of the old days that is strictly forbidden by Gilead. 
 
 
I have a little present for you, he said. 
He smiled a little. Then he pulled open the top drawer of his desk and took something out. He held it a moment, casually 
enough, between thumb and finger, as if deciding whether or not to give it to me. Although it was upside-down from where I was 
sitting, I recognized it. They were once common enough. It was a magazine, a women’s magazine it looked like from the picture, a 
model on glossy paper, hair blown, neck scarfed, mouth lipsticked; the fall fashions. I thought such magazines had all been 
5 
destroyed, but here was one, left over, in a Commander’s private study, where you’d least expect to find such a thing. He looked 
down at the model, who was right-side-up to him; he was still smiling, that wistful smile of his. It was a look you’d give to an 
almost extinct animal, at the zoo. 
Staring at the magazine, as he dangled it before me like fishbait, I wanted it. I wanted it with a force that made the ends of my 
fingers ache. At the same time I saw this longing of mine as trivial and absurd, because I’d taken such magazines lightly enough 
10 
once. I’d read them in dentists’ offices, and sometimes on planes; I’d bought them to take to hotel rooms, a device to fill in empty 
time while I was waiting for Luke. After I’d leafed through them I would throw them away, for they were infinitely discardable, and 
a day or two later I wouldn’t be able to remember what had been in them. 
Though I remembered now. What was in them was promise. They dealt in transformations; they suggested an endless series of 
possibilities, extending like the reflections in two mirrors set facing one another, stretching on, replica after replica, to the vanishing 
15 
point. They suggested one adventure after another, one wardrobe after another, one improvement after another, one man after 
another. They suggested rejuvenation, pain overcome and transcended, endless love. The real promise in them was immortality. 
This was what he was holding, without knowing it. He riffled the pages. I felt myself leaning forward. 
It’s an old one, he said, a curio of sorts. From the seventies, I think. A Vogue. This like a wine connoisseur dropping a name. I 
thought you might like to look at it. 
20 
I hung back. He might be testing me, to see how deep my indoctrination had really gone. It’s not permitted, I said. 
In here, it is, he said quietly. I saw the point. Having broken the main taboo, why should I hesitate over another one, something 
minor? Or another, or another; who could tell where it might stop? Behind this particular door, taboo dissolved. 
I took the magazine from him and turned it the right way round. There they were again, the images of my childhood: bold, 
striding, confident, their arms flung out as if to claim space, their legs apart, feet planted squarely on the earth. There was something 
25 
Renaissance about the pose, but it was princes I thought of, not coiffed and ringleted maidens. Those candid eyes, shadowed with 
makeup, yes, but like the eyes of cats, fixed for the pounce. No quailing, no clinging there, not in those capes and rough tweeds, 
those boots that came to the knee. Pirates, these women, with their ladylike briefcases for the loot and their horsy, acquisitive teeth. 
I felt the Commander watching me as I turned the pages. I knew I was doing something I shouldn’t have been doing, and that he 
found pleasure in seeing me do it. I should have felt evil; by Aunt Lydia’s lights, I was evil. But I didn’t feel evil. Instead I felt like 
30 
an old Edwardian seaside postcard: naughty. What was he going to give me next? A girdle? 
Why do you have this? I asked him. 
Some of us, he said, retain an appreciation for the old things. 
But these were supposed to have been burned, I said. There were house-to-house searches, bonfires . . . 
What’s dangerous in the hands of the multitudes, he said, with what may or may not have been irony, is safe enough for those 
35 
whose motives are . . . 
Beyond reproach, I said. 
He nodded gravely. Impossible to tell whether or not he meant it. 
But why show it to me? I said, and then felt stupid. What could he possibly say? That he was amusing himself, at my expense? 
For he must have known how painful it was to me, to be reminded of the former time. 
40 
I wasn’t prepared for what he actually did say. Who else could I show it to? he said, and there it was again, that sadness. 
Should I go further? I thought. I didn’t want to push him, too far, too fast. I knew I was dispensable. Nevertheless I said, too 
softly, How about your Wife? 
He seemed to think about that. No, he said. She wouldn’t understand. Anyway, she won’t talk to me much any more. We don’t 
seem to have much in common, these days. 
45 
So there it was, out in the open: his wife didn’t understand him. 
That’s what I was there for, then. The same old thing. It was too banal to be true. 


## PDF page 114

114 
 
 
Edition de référence des pages reproduites : 
 
 
Virago, Margaret ATWOOD, The Handmaid’s Tale, pp. 164-166. 
Penguin, Jane AUSTEN, Chapter 1, Pride and Prejudice, pp. 51-53. 
Penguin, Angela CARTER, ‘The Bloody Chamber’ and Other Stories, pp. 108-110. 
Vintage Classics, Raymond CARVER, What We Talk about When We Talk about Love (1981), pp.31-36. 
Penguin Classics, Charlotte Perkins GILMAN, “The Yellow Wallpaper”, The Yellow Wallpaper, Herland 
and Selected Writings, pp.166-82. 
Norton, Nathaniel HAWTHORNE, “V. Hester at her Needle”, The Scarlet Letter, pp. 55-57. 
Scribner, Finc Vig la Ed Edition, Ernest HEMINGWAY, “A Clean Well-Lighted Place”, The Complete 
Short Stories of Ernest Hemingway, pp.288-91. 
Prestwick House, O. HENRY, “The Gift of the Magi”, The Best of O. Henry, pp. 24-25. 
Penguin Books Ltd., Kazuo ISHIGURO, “A Family Supper”, in Firebird 2: Writing Today (1983), T.J. 
Binding and R. Robertson (ed), pp.121-131. 
Farrar, Straus & Giroux, S. JACKSON, “The Lottery”, The Lottery and Other Stories, pp.291-303. 
Penguin, James JOYCE, “Araby”, Dubliners, pp. 223-225. 
WW. Norton & Co., K. MANSFIELD, “The Garden Party”, Katherine Mansfield’s Short Stories, pp. 33-
44. 
WW. Norton & Co. Herman MELVILLE, “Bartleby, the Scrivener”, Melville’s Short Stories, pp. 7-38. 
Penguin, Vladimir NABOKOV, Part One, Book I, Lolita, p. 9. 
Farrar, Strauss & Giroux, Flannery O’CONNOR, “A God Man Is Hard to Find”, The Complete Stories of 
Flannery O’Connor, pp. 117-34. 
Penguin Classics, Edgar Allan POE, “The Tell-Tale Heart”, The Fall of the House of Usher and Other 
Writings, pp. 281-82. 
Harper-Collins, Jean RHYS, Sleep It Off Lady (1976), pp.174-176. 
Digireads, SAKI (HH Munro), “The Open Window”, The Complete Short Stories of Saki, pp. 167-70. 
Random House, J. UPDIKE, “A & P”, John Updike: The Early Stories, 1953-1975.  5p. 
Grafton, Virginia WOOLF, “III. The Lighthouse – 3”, To the Lighthouse, pp. 147-149. 
 
 
 
 
 
 
 

