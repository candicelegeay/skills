# Week 3.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: Week 3 (February 2nd-6th): Short stories / -
- PDF page 2: In this passage, Laura has gone to pay her respect to the man’s family and is discovering his / dead body lying on the bed. After being caug
- PDF page 3: a. Discovering the reality of death, Laura has come to leave the superficial reality / of the preparations for the garden party and entered 
- PDF page 4: Jean Rhys, “I Used to Live Here Once” (1976): whole story / This is a very compact story which manages to transport us in a world of sensati
- PDF page 5: - / All the memories referred to in the text are always followed by a perception of the

## PDF page 1

Week 3 (February 2nd-6th): Short stories 
- 
Katherine Mansfield, “The Garden Party” (1922): from “There lay a young man – end of the 
short story” 
- 
Jean Rhys, “I Used to Live Here Once” (1976): whole story 
 
Katherine Mansfield. “The Garden Party” (1922) 
This story follows a very intricate plot structure which correspond to Aristotle’s dramatic art 
(p. 17). The climax happens with the news of the man’s death. At the bottom of p. 99, the text 
operates a shift with the word “But”: “But the back door was blocked by cook, Sadie, Godber’s 
man and Hans”. This irruption of a difficulty in this day of easiness and happiness for Laura 
marks the beginning of the text’s crisis, which will lead to her learning of the man’s death which 
will in turn be followed by her turmoil as to whether to hold the party or not. 
 
The external narrator focalizes mostly on Laura’s point of view, but sometimes shares the 
perspective of other characters. The text is saturated with impressions and feelings, allowing 
the readers to feel great proximity with the characters and in particular with Laura, the story’s 
main focalizer.  
 
We are plunged inside Laura’s mind and perception. This underlines the contrast between her 
reaction to the man’s death and the absence of feelings of her family members who cannot 
conceive why they should not hold the garden party. This opposition appears in the opposition 
between dialogue and narrative moments with Laura’s interior monologue and free indirect 
speech (see p. 24), where we are given to hear exactly what Laura is thinking inside her head. 
This is called “stream of consciousness”, which means that we follow the free flow of her 
disordered thoughts as they appear in her mind. This technique was used by several modernist 
writers, such as Virginia Woolf who was a friend of Katherine Mansfield, or James Joyce 
(whose story “Araby” is in the brochure), see pages 15-16 on “The Rise of Modernism”.  
We follow Laura’s thoughts through unexpected comparisons or unusual metaphors and 
similes, following her random associations of ideas. We can see in this the impact of the 
landscape opened up by psychology and psychoanalysis on modernist writers who were 
interested in trying to capture the workings of the mind of their characters. It is important to 
note that Mansfield was trying to find absolute precisions in her texts: she wrote in a letter 
“there mustn’t be one single word out of place, or one word that can be taken out”. The text is 
chiseled like a piece of jewelry, it is a very precise and minute record of the character’s thoughts 
and their evolution in face of the story’s events. Modernist writers repudiated traditional third-
person omniscient narration, they preferred to represent characters through their shifting 
thoughts, memories and sensations. 
Reading exercise: 
Mansfield explained how the visual arts impacted her prose technique, declaring that Vincent 
Van Gogh’s paintings “taught me something about writing which was queer – a kind of freedom 
– or rather, a shaking free”. Do you find a visual dimension to the text? Look for clues that 
make this text at times feel almost like a visual composition. 
 
Textual commentary: from “There lay a young man – end of the short story” 
 
These last lines of the story are very different from the happy careless atmosphere of its 
beginning. What separates the opening and ending of the story is the irruption on death on the 
scene of the party. Narrated through Laura’s eyes, the story plunges into a reflection about the 
contrast between the carefree life of her family and the hardships endured by the people working 
for them, this coming to a climax with the death of the man. 


## PDF page 2

In this passage, Laura has gone to pay her respect to the man’s family and is discovering his 
dead body lying on the bed. After being caught in a revery about the dead man, she comes back 
to reality and runs out of the house. On her way back, she meets her brother to whom she tries 
to express what she is feeling, but finds herself unable to find the right words. 
This scene shows how much Laura has changed and grown since the opening lines of the story, 
she has now confronted death and has come to realize something, even if she is not quite sure 
what it is she has come to realize. 
We will see how this passage underlines the intensity of Laura’s emotions and her inability to 
share them with the people around her. 
 
1. The text emphasizes the space that separates what goes on inside Laura’s mind from the 
world outside.  
a. We see this through the long and detailed description of the man’s face where 
the text presents what Laura imagines to be the man’s thoughts (“I am content”), 
which is abruptly interrupted by a return back to reality (“But all the same, you 
had to cry”). She finds incongruous words to leave the room “Forgive my hat”, 
which underline the discrepancy between the depth of her earlier reflection on 
death and the superficiality of social conventions. 
b. Laurie also brings her back to reality “Is that you, Laura?”, but here again, she 
is separated from him in the sense that she cannot express to him what it is she 
is feeling: “Isn’t life, she stammered, “isn’t life –””: she interrupts herself 
because she is at a loss to find the right word to express her feelings which have 
to do with the realization of death. 
c. In this passage, Laura is caught between her mind’s world and the real world. 
Whether it is her thoughts in front of the dead man or her thoughts in front of 
Laurie, she is caught in very intense emotions. 
 
2. How does the text convey the intensity of Laura’s emotions?  
a. Narrated through free indirect discourse where we follow Laura’s thoughts 
without the narrator’s intervention (see p. 24), the text is made of repetitions and 
interruptions which capture the free flow of her thoughts: “fast asleep – sleeping 
so soundly, so deeply” or “far, far away” or again “Happy… Happy…” are but 
a few examples which show how her mind is taking time to process her 
perceptions and impressions. 
b. The use of free indirect discourse allows the readers to feel exactly what the 
character feels, which add intensity to our reading experience where we feel the 
changes in emotions and the shifts between her reverie and her return to reality 
as abruptly in the text as suggested in the pivotal “But” line 7, as abruptly as the 
character does.  
c. Laura is going through an intense emotional revelation, even if she is not quite 
able to put words on it. This is called an “epiphany”: a sudden moment of 
realization and insight. The experience of an epiphany is a key aspect of 
modernist writing: Virginia Woolf and James Joyce also tried to articulate 
flashes of realization, revelation, insight and understanding. Woolf described 
these as ‘moments of being’. Here Laura is experiencing an epiphany, a glimpse 
of something beyond her everyday life, that has to do with life and death, but 
that she is unable to fully comprehend.  
 
3. How has Laura’s character been transformed since the beginning of the short story 


## PDF page 3

a. Discovering the reality of death, Laura has come to leave the superficial reality 
of the preparations for the garden party and entered another reality marked by 
the possibility of death. The irruption on death in the short story makes her 
become conscious of the frailty of life. As she tries to explain to her brother at 
the end, what she has realized concerns “life” (“Isn’t life?”) 
b. This transformation leads her from innocence to experience: she has experienced 
the vision of a dead man which seems to change her radically as the text suggests 
with her abrupt departure from the scene and excitement when she meets Laurie. 
c. The text presents a moment of realization for Laura, an epiphany, even though 
she is not quite certain what it is she is thinking. What remains is the sense of a 
change, an impression of what the character is going through, but the text 
remains undetermined on what it is she has understood. The short story indeed 
ends on intense emotions which are intense that they cannot quite be 
characterized but only experienced. This goes along a style which focuses on 
trying to make the readers perceive the impressions of the characters, rather than 
having a full rational knowledge of what these impressions actually stand for. 
 
Conclusion 
Katherine Mansfield’s artistry comes to a beautiful conclusion at the end of the short story, 
where the readers have been made to feel the sense of realization of the character without this 
realization ever being quite defined for us. We see how the author was interested in capturing 
fluctuating emotions on paper, conveying a sense of being to the readers rather than 
constructing the story on intellectual knowledge. 
 
 
 
 


## PDF page 4

Jean Rhys, “I Used to Live Here Once” (1976): whole story  
This is a very compact story which manages to transport us in a world of sensations and 
emotions based on a strong sense of nostalgia. It is very interesting in this respect to read the 
story after having read “the Garden Party” which is also focused on the emotions of the central 
character.  
How does the story create these impressions in the reader? 
 
What is the story about? 
How is it organized? It’s worth noting that the story is built around 9 short paragraphs, the last 
ones become shorter. This gives a sense of discarded impressions. There is a clear narrative arc 
to the story, but it also gives an impression of moving from one thing to the next (focusing on 
the river, then the road, then the “glassy” weather, then the house, then the children, then the 
woman, alone in the garden). 
The narrative moves thus from a snippets, short memories. We could argue it zooms closer and 
closer to the woman: it first looks at the wider landscape, before focusing on the house, then 
the children, then herself. The text thus operates as with a camera: moving from a wider angle 
to a focus on smaller and smaller images. 
Who narrates the story? An unidentified third person narrator, who is exterior to the story (i.e., 
an extradiegetic narrator), telling the story of an unnamed woman, referred to as “she” 
throughout the story. She is the focalizer of the story, the character whose point of view (or 
center of consciousness) is conveyed to us throughout the story. As the story unfolds, we realize 
that the woman is an internal focalizer. 
What do we know about the main character? Very little and a lot at the same time! We know 
very little about her circumstances, though we can infer that she lives in the West Indies, that 
she used to live in the house. But what we mostly know are her sensations and emotions. What 
do we learn in the last sentence? She is most likely a ghost: the children can’t hear her, they can 
only feel her presence through the cold. 
ð These elements all have in common that this is a story where we are presented a lot of 
emotions and sensations, but very little facts. Our understanding of what is happening, as 
well as our response to the story all have to rely on what we infer from the little facts given 
to us. This is a story where the reader is made to feel, much more than to know. 
 
How is does the text bring forward a strong emotional situation? 
- 
The text opens on memories => What are memories? Elements from the past recalled 
by a person, they therefore have a strong subjective dimension.  
- 
What are the memories that the text focuses on? Memories of “each one” of the stepping 
stones in the first paragraph: memories of physical sensations (“the safe stone where 
you could stand and look round” / “it was a blue day” / the sky had a glassy look”), of 
emotions (“Yet it was the same road and she walked along feeling extraordinarily 
happy”, in the second paragraph). Note that we are also presented with the character’s 
emotions in the present moment “Yet it was the same road and she walked along feeling 
extraordinarily happy”. In the third paragraph, the adjectives “blue” and “glassy” are 
emotional markers. “A blue day” refers to a feeling, but the reader is not able to know 
exactly what the adjective entails (blue seems to refer to the colour of the sky on this 
“fine day” and good weather). The word “glassy” is emphasized since the narrator 
repeats it and focuses on how the character can’t think of another word. But we don’t 
really know what it means. These two adjectives are interesting because they both 
suggest a sensation, or an emotion, but one that remains blurry for the reader (as well as 
the character “that was the only word she could think of”). 


## PDF page 5

- 
All the memories referred to in the text are always followed by a perception of the 
objects of the memory in the present moment: the memory of the stone and the 
experience of crossing the river in the present / the memory of the road and the 
experience of walking along it in the present, which emphasizes the separation between 
past and present, between part sensations and present sensations.  
- 
When the narrator stops and reflects on the use of the adjective “glassy” to refer to the 
impression given by the weather, we realize that the woman is indeed the focalizer of 
the story, the narrator follows the exact train of her thoughts. 
 
The end: open and mysterious 
We understand that there is a gap between the character and the two children who do not react 
to her words. We are made to infer that this is because they don’t see her and that she is therefore 
a ghost. This is the most likely explanation of the story’s ending. We could therefore explain 
the enigmatic last sentence as meaning that “this was the first time she knew” that she was a 
ghost.  
The text remains very subtle and doesn’t tell us for sure that this is a ghost story, but it gives us 
a number of clue which point in this direction: the children not hearing her, not seeing her, the 
cold they feel when she approaches them which evokes folk narratives of ghostly presences 
being felt through cold. 
One could decide to have another reading of the ending as the text does not explicitly say it is 
a ghost story (despite the many elements pointing in this direction). In that case, we would have 
to explain why the children are not reacting to her presence, this could be explained through the 
fact that they don’t know her and are trying to avoid her. I am mentioning this in order to show 
you that the text remains a little open. But it is important to note the elements in it that point in 
the direction of a ghost story. 
 
The role of the reader in this story based on inference (inference: “a conclusion or opinion that 
is formed because of known facts or evidence” Webster’s dictionary) 
What happens in the story is very subtle and relies on the readers inference about the elements 
of the text. We are given mostly sensations and emotions which makes the fabric of the text 
very elusive, almost as elusive as the figure of the ghost we discover in the woman at the end 
of the story. We are therefore put in a very active position, having to decide for ourselves what 
actually happens in the story. This type of reading situation is one which one finds in a lot of 
modernist fiction, a literary style Jean Rhys draws from in the story.  
 
Conclusion 
This story plunges us in a woman’s subjective memories and emotions. The world outside is 
described through her perceptions, apart from a few factual elements (the house had been 
painted on, the car parked in front of it). We are plunged in a character’s mind as we follow her 
movements across a river, along a road, all the way to a house she used to know (and live in, 
presumably). But most of the story’s action is concerned with her sensations and perceptions 
so that the reader is put in the position of the character, feeling her emotions and sensations 
along with her. The final sentence “That was the first time she knew” also applies to the readers: 
this is the first time in the story that we know that the woman is a ghost. We are made to follow 
her evolution, from sensations to understanding she is dead.  
 
 
For next time: speech representation in the narrative p. 11-13 
Read the two short stories, work on writing a summary which brings out its main features 
Try and find an outline for at least one of the passages. 

