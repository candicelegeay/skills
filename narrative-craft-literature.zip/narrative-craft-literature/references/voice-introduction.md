# Week 1. Introduction and Narrative Voice.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: 1 / Week 1: Introduction to the course: understanding the importance of narrative voice
- PDF page 2: 2 / Writers paid greater attention to self-consciousness and the process of thought. As a result,
- PDF page 3: 3 / 19th century novels and Jane Austen’s third-person narrator in Pride and Prejudice (1813)
- PDF page 4: 4 / In the extract from Nathaniel Hawthorne’s The Scarlet Letter, we can see from the very

## PDF page 1

 
1 
Week 1: Introduction to the course: understanding the importance of narrative voice  
 
The question of narrative voice and point of view is presented on pages 5, 7 and 8 on the 
class brochure (starting with “C. Narration and Point of View”). 
 
To begin the semester, and before you have time to read the texts assigned for each session, I 
would to start by looking at the importance of narrative voice in fiction. I will refer here to 
several of the novel excerpts from the brochure. I strongly recommend you read the texts after 
reading this introduction, paying particular attention to the way the story is told in each text.  
The object of this first session is to see how essential it is to understand and define the narrative 
voice in fiction. Indeed, the narrator is the filter through which we learn the story. In other 
words, it is absolutely essential to understand who is narrating the story and from what 
perspective before delving into a textual analysis. 
The novel excerpts from the brochure cover a long period, from the early 19th century to the 
late 20th century. As the history of the novel evolved, narrators and their voices also changed, 
thus leading to different experiences for the reader. 
 
ð One very important note before beginning: narrators and authors are very different 
people! The narrator is the person who tells us the story we read. And, as such, the 
narrator (or this narrative voice), is always a fictional voice, that we must not confuse 
with the author. A striking example showing this is the narrator of Lolita (excerpt p. 
112). As the introduction note to the excerpt explains it: Lolita is the story of memoirs 
of a pedophile and a murderer, Humbert Humbert – this character is very different from 
Vladimir Nabokov who shared none of his characters’s deviances.  
The voice we hear, the person telling the story is a first-person narrator. His name 
appears later in the novel: Humbert Humbert. The name (we see humour also in his very 
name) gives him a different identity from the author. The paragraph on p. 112 underlines 
his flamboyant style and total absence of remorse. As the sentence line 9 “Ladies and 
gentlemen of the jury” indicates: he is talking at this trial. We can see how wrong it 
would be to consider that the narrator is the same person as the author. This is an extreme 
example that I am using as caution, at the onset of the semester: it is absolutely essential 
to know that the narrator is always a fictional person and that we should never confuse 
him (or her) with the author. Sometimes author and narrator look very similar, but this 
should not lead us to a wrong idea: even when the narrator looks a lot like the author of 
the text, we must remember that the narrator is fictional. 
 
 
For a bit of history: early novels and first-person narrators: fiction with an air of reality, 
the case of Robinson Crusoe 
 
The Birth of the British Novel 
The British novel was born out of the desire to show the life of the present day versus life as it 
was in the past as had been the case in earlier literary genres such as legends, epic poems or 
narratives of chivalrous medieval adventures. Characters and events were made to be 
believable, as if to mirror the people and events in the everyday world of the time, lending the 
novels credibility. Indeed, the new middle-class readers who appeared in the 18th century 
wished to read about themselves and the world they lived in. Characters within the stories were 
presented in a manner similar in social rank to the people reading the novels, not as kings or 
queens; this afforded a level of familiarity with the readers. With familiarity, readers were able 
to identify and empathize with characters in the novel.  


## PDF page 2

 
2 
Writers paid greater attention to self-consciousness and the process of thought. As a result, 
stories reflected more of their individualism and subjectivity.  
 
Daniel Defoe’s Robinson Crusoe 
Daniel Defoe’s novel Robinson Crusoe, published in 1719 does not present itself as fictional. 
Indeed, everything is put into place in order to give the readers the impression that they are 
reading an actual “true-life” narrative about a real young man, Robinson Crusoe, who was lost 
at sea for 28 years. These markers pointing in the direction of real life can be found both inside 
the text (we will come to this in a little bit) and outside the text, in what is also called the paratext 
(para-text: what is outside the text, such as for example a novel’s title page). Let’s look at the 
novel’s title page when it was first published, in 1719. We can read:  
The Life and Strange Surprizing Adventures of Robinson Crusoe, of York, Mariner 
Who lived Eight and Twenty Years, all alone in an un-inhabited Island on the Coast of America, 
near the Mouth of the Great River of Oroonoque 
Having been cast on Shore by Shipwreck, wherein all the Men perished but himself.  
With An Account how he was at last as strangely deliver'd by Pyrates.  
Written by Himself. 
 
                                              
 
 
All the elements on this title page suggest to the readers, even before we start reading the story, 
that this is the “real” story, of a “real” man, this Robinson Crusoe who was born in York. The 
most striking feature of the title page is its insistence on the reality of the story to come, the 
fictional status of the text seems to be erased and replaced by a supposedly “true” account of 
the life of a real person. The title page indeed offers factual elements which seem to ground the 
narrative in reality: geographical information (“in an uninhabited island on the coast of 
America, near the mouth of the great river of Oroonoque”), biographical information (the 
character’s name, his occupation, his hometown). However, these elements come into contrast 
with the use of adjectives which suggest the “unreal” quality of the story to come: we are told 
these are “strange and surprising adventures”, and the strangeness of the account is underlined 
by the last piece of information: “an account how he was at last strangely delivered by pirates”. 
One could also argue that the factual information also creates a feeling of strangeness: the 
geographical names are factual but also rely on exoticism; the island is said to be “uninhabited’ 
which creates a sense of mystery. The novel therefore seems to rely on known, realistic facts 
while creating a sense of mystery belonging more to a fictional narrative.  
The title page ends with the essential information “written by himself” which points at the fact 
that the pages to come will sound. The novel thus refuses its status as fiction and points at its 
very opposite: the real account of a real experience. Entering the novel will therefore mean 
entering an ambiguous territory, where fiction hides behind apparent reality.  


## PDF page 3

 
3 
 
19th century novels and Jane Austen’s third-person narrator in Pride and Prejudice (1813) 
Moving to the 19th century, two excerpts show a similar desire to give a sense that what is 
described on the page is real, but rather than using a first-person narrator, Jane Austen uses an 
unknown narrator. Whereas in the Defoe and Swift the narrator was the character himself, 
telling the story he lived through, here the narrator is outside the story, telling the readers about 
a story he does not participate in.  
The narrator does not participate in the events of the story, but he does participate in giving us 
a particular impression about the events presented to us. Indeed, the narrator’s way of telling 
the story will imprint a particular impression about the story in the reader’s mind. This is called 
“point of view”: all narrators give us their point of view and it is the task of the reader to 
determine how the narrator's point of view colours our perception of the story. 
 
Janes Austen wrote novels of manners (comédies de moeurs): she wanted to present the 
customs, conventions, manners, and habits of a definite social class at a particular time and 
place. The novels seek to expose the failings of her society (this is called “social satire”). To 
this end, characterization and plot are very important in her novels to show the shortcomings of 
the people the novels seek to satirize.  
The excerpt is the incipit (beginning) of the novel, it opens on a “general truth”, the fact that, 
according to the narrator “It is a truth universally acknowledged that a single man in possession 
of a good fortune, must be in want of a wife”. This opening gives the impression that the narrator 
will share “objective” information with the reader, and this is reinforced by the fact that the 
narrator is not part of the story and that we don’t have any information as to his identity. In the 
second sentence of the text, we can see that the narrator has a specific point of view in the ironic 
perspective given on the fact that eligible bachelors are considered as potential “property” by 
young women in search of a husband. The narrator adopts here an ironic perspective on the 
social conventions of this society, creating social satire. 
 
This narrator seems to know everything, he is an “omniscient” narrator, one who is supposed 
to know everything about the story he tells. 
 
We see that the passage is made both of narrative parts (where we hear the voice of the narrator) 
and of dialogue, where we get to hear the voices of the characters. This contrast allows to know 
the characters through their own words, but also to see how the narrator perceives them, which 
influences the reader in perceiving the characters in a certain way.  
It is important to see that the narrator who seems at first to be imparting general information to 
his reader is actually presenting a satirical point of view as suggest the way he comments on 
the dialogue between Mrs Bennett and her husband at the beginning of the text. The narrative 
voice disappears behind the dialogue but reappears at the end of the text (on line 48) where the 
narrator offers a summary of the characters. 
 
As literary critic David Lodge has explained in The Art of Fiction: “The choice of the point(s) 
of view from which the story is told fundamentally affects the way readers will respond, 
emotionally and morally, to the fictional character and their actions.” The narrator’s point of 
view appears quite subtly in this exract from Pride and Prejudice, but we see after having read 
the whole passage that the first sentence was meant as an ironic comment on the part of the 
narrator about the social mores of this social class and the narrator was making a comment very 
close to what Mrs Bennett believes about marriage and relationships and that the comment is 
ironic, pushing the reader to question it. 


## PDF page 4

 
4 
In the extract from Nathaniel Hawthorne’s The Scarlet Letter, we can see from the very 
beginning that the narrator does not belong to the story (he is a third-person narrator), but that 
he adopts the point of view of his character, Hester Prynne. On line 3, the phrase “seemed, to 
her sick and morbid heart” shows that the narrator is able to know what the character’s inner 
thoughts as shows the verb “seemed” which refers to the character’s impression. Also, the 
adjectives “sick” and “morbid” give an opinion about her “heart” (her thoughts), thus showing 
that the narrator is speaking from the perspective of how his character feels.  
Conclusion 
In the excerpts we have seen, the narrative voice is the main device used to give a sense of 
reality. How indeed not to trust the “I” talking to us on the pages of Robinson Crusoe and 
Gulliver’s Travels? The identity of the narrator, his personality, way of seeing things and 
presenting the characters can be felt in the narrator’s words, ways of expressing himself. In 
other words, we read a story that is never a set of facts but facts told in a certain way. 
Understanding who the narrator is, his point of view is therefore essential to understand how a 
text works in conveying specific impressions to the readers. 
Fiction (novels, short stories) is never “true”: it may look like a real story, it may sometimes be 
adapted from a real story, but it is always invented and never real or true.  
This fact is the cornerstone of literary analysis, because it shows that the task of the reader will 
be, when a story feels “true” or “real” to explain how the narrator manages to give us this 
impression. In other words, what are the devices, the tools the narrator uses to make us believe 
that the story invented by the author, the narrator invented by the author sounds like a real 
person telling us a real story. 
 
Take-home points from this first session: 
• Determining who the narrator is in a fictional narrative is essential to be able to 
understand the text and to show how the narrative voice manages to give the readers 
certain impressions. 
• The narrator is a creation of the author, they should never be confused 
• The narrator can: 
• 
Comment and judge 
• 
Directly address the reader 
• 
Be a detached observer 
• 
Be ‘transparent’, appearing to speak with the voice of the author. 
• Once you have determined the identity of the narrator, work on finding what is his 
point of view on the story he tells (how does he present the characters and the action?) 
 
 
Your work for next week: 
ð Read Charlotte Perkins Gilman’s “The Yellow Wallpaper” and answer these two 
questions: 
- identify the narrator 
- underline all the adjectives in the text: what do they tell us about the 
narrator? 
 
ð Read Saki’s “The Open Window”, summarize it and present its narrative arc 
(use the literary vocabulary on the brochure pages 4 to 5) 
 

