# A2FLT11 12 CM - Lecture 5  The_Novel_Comes_of_Age PDF.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: A2FLT11/12 CM with M. Tredy - First Half of the Semester / Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
- PDF page 2: The Coming of Age of the Novel: Early 19th Century / Essentially involved three types of novels:
- PDF page 3: The Coming of Age of the Novel: / The Gothic Novel
- PDF page 4: The Coming of Age of the Novel: / The Gothic Novel
- PDF page 5: The Coming of Age of the Novel: / The Gothic Novel
- PDF page 6: 2. Mary Shelley (1797-1851): / -father William Godwin a famous philosopher on
- PDF page 7: Frankenstein has had quite a legacy…
- PDF page 8: Frankenstein has had quite a legacy…
- PDF page 9: That fateful summer… / -One rainy summer in 1816…  (NB: ‘It was a dark and stormy night…’ is not Shelley but
- PDF page 10: The Coming of Age of the Novel: / The Early Novel of Manners
- PDF page 11: ¨Popular / adaptations
- PDF page 12: ¨Popular / adaptations
- PDF page 13: Pride and Prejudice / Ah… July 2013…
- PDF page 14: 1995 film, 2008 miniseries, / two 2011 films
- PDF page 15: Emma  (1816) / -a different trajectory, as Emma Woodhouse starts out at
- PDF page 16: (Patricia Rozema, 1999)              (2007)                           (2008)                           (2013) / (bio + novel)
- PDF page 17: The Coming of Age of the Novel: / The Early Novel of Manners
- PDF page 18: The Coming of Age of the Novel: / The Early Novel of Manners
- PDF page 19: The Coming of Age of the Novel: / The Early Novel of Manners
- PDF page 20: The Coming of Age of the Novel: / The Early Novel of Manners
- PDF page 21: The Coming of Age of the Novel: / The Early Novel of Manners
- PDF page 22: The Coming of Age of the Novel: / ‘Histories’  (Great Britain)
- PDF page 23: The Coming of Age of the Novel: / ‘Histories’  (Great Britain)
- PDF page 24: The Coming of Age of the Novel: / ‘Histories’  (U.S.A.!)
- PDF page 25: Recap of main figures in Lesson V: / The Coming of Age of the Novel:

## PDF page 1

A2FLT11/12 CM with M. Tredy - First Half of the Semester
Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
Lecture 2:  Lesson on Narration, Focalization & Narrative Distance 
Lecture 3:  Timeline 1: The Rise of the Novel in the 18th Century 
Practice TEST #1 
Lecture 4: Speech Representations, Skaz & Characterization
Lecture 5: Timeline 2: The Novel Comes of Age 
Lecture 6:  Timeline 3: The American Renaissance 
Practice Test #2 
WEEK 7: Online MIDTERM (available Monday March 9th to Wednesday March 11th at midnight)
---
A2FLT11/12 CM - Today’s Class (Week 5)
The Novel Comes of Age (British literature in the early to mid-19th century)


## PDF page 2

The Coming of Age of the Novel: Early 19th Century
Essentially involved three types of novels:
The Gothic Novel, the early Novel of Manners and the Historical Novel
-The novel continued to develop after a pause during the revolutionary period
-Some genres more influenced than others by the Romantics; all paved way to 
the Victorian novel
-There was a major split between more factual ‘historical’ novels (male writers, 
mostly a male readership) and what were called ‘Romances’ – admittedly 
fictional stories dealing with great imagination or emotions (mostly female 
authors, mostly a female readership)
A. The Gothic Novel
-The genre most influenced by the Romantic Poetry movement
-Often set amid wild nature, in Gothic castles or convents
-Emphasizes the mysterious and the supernatural
-Stresses emotions and the imaginative representation of the psyche.


## PDF page 3

The Coming of Age of the Novel: 
The Gothic Novel
1. Anne Radcliffe (1764-1823): 
The Mysteries of Udolpho (1794)
-More control of the devices of horror, mystery and 
suspense than her contemporaries; early examples 
of ‘page-turners’
-What we consider today to be the epitome of the early Gothic novel
-Story of a heroic woman (Emily) in danger and held against her will in a 
mysterious castle in the wilderness (a plot Radcliffe used repeatedly)
-Her novels were especially popular with middle-class women
-All of her works, including her first success A Sicilian Romance (1790), A 
Romance of the Forest (1791) and The Mysteries of Udolpho (1794) show a 
mastery of depicting both human emotions and natural (or gloomy) landscapes 


## PDF page 4

The Coming of Age of the Novel: 
The Gothic Novel
1. Anne Radcliffe (1764-1823): 
The Mysteries of Udolpho (1794)
-More control of the devices of horror, mystery and 
suspense than her contemporaries; early examples 
of ‘page-turners’
-What we consider today to be the epitome of the early Gothic novel
-Story of a heroic woman (Emily) in danger and held against her will in a 
mysterious castle in the wilderness (a plot Radcliffe used repeatedly)
-Her novels were especially popular with middle-class women
-All of her works, including her first success A Sicilian Romance (1790), A 
Romance of the Forest (1791) and The Mysteries of Udolpho (1794) show a 
mastery of depicting both human emotions and natural (or gloomy) landscapes 


## PDF page 5

The Coming of Age of the Novel: 
The Gothic Novel
1. Anne Radcliffe (1764-1823): 
The Mysteries of Udolpho (1794)
-More control of the devices of horror, mystery and 
suspense than her contemporaries; early examples 
of ‘page-turners’
-What we consider today to be the epitome of the early Gothic novel
-Story of a heroic woman (Emily) in danger and held against her will in a 
mysterious castle in the wilderness (a plot Radcliffe used repeatedly)
-Her novels were especially popular with middle-class women
-All of her works, including her first success A Sicilian Romance (1790), A 
Romance of the Forest (1791) and The Mysteries of Udolpho (1794) show a 
mastery of depicting both human emotions and natural (or gloomy) landscapes 
Really invented
the horror trope 
of the woman in 
a haunted
house…


## PDF page 6

2. Mary Shelley (1797-1851):   
-father William Godwin a famous philosopher on
class struggles, mother Mary Wollestonecraft 
a feminist writer (A Vindication of the Rights of 
Women, 1792).
-eloped with (married) Percy Shelley in 1814,
married when he widowed in 1816, several 
Miscarriages, stillborn children and children who 
died young. 
Her second most famous novel was already ground-breaking: 
The Last Man (1826) (post-apocalyptic science fiction, how a plague wipes out 
the planet)
But her most famous novel was the most successful gothic novel of the century, 
with a political message on the dangers of science supplanting Godliness, 
goodness and morality. 
(In fact, it dealt so much with ‘science’ that many assumed Percy had written it)
 
The Coming of Age of the Novel: 
The Gothic Novel


## PDF page 7

Frankenstein has had quite a legacy…


## PDF page 8

Frankenstein has had quite a legacy…


## PDF page 9

That fateful summer…
-One rainy summer in 1816…  (NB: ‘It was a dark and stormy night…’ is not Shelley but 
1830 novel Paul Clifford by George Bulwer-Lytton)
-toured Europe with her stepsister Claire Clairmont and Percy Shelley, 
stayed with fellow Romantic poet Lord Byron and his physician John William 
Polidori.
-A contest: who could write the best ghost story…
-Mary’s first draft of Frankenstein only a few pages long, but the best of the 
batch, Byron said it had him “shrieking in horror”, and Percy pushed her to 
develop it into a full novel, which would be published in 1818. 
-Polidori got an ‘honorable mention’ for his scary story…. (80 years before 
an Irish author would make it a true legend…)
1986 re-
imagining
2017
+ lots of TV-
movies, plays & a 
musical!


## PDF page 10

The Coming of Age of the Novel: 
The Early Novel of Manners
 
1. Jane Austen (1775-1817): Sense and Sensibility (1811), 
Pride and Prejudice (1813), Emma (1816), Persuasion (1818), 
Northanger Abbey (1818)
-Died at age 42 (unmarried) but a HUGE influence then & now
-Nearly all works published anonymously 
(early ones simply ‘By a Lady’)
-Focused on human interactions among English country gentry
-Nearly every novel a bildungsroman (story of initiation, coming of age) 
on young women entering society and finding a husband 
(which mirrored her main readership, cf. Richardson)
-Witty dialogue, clever use of situational irony, masterful plot 
manipulation, open mockery of snobs and fools
-First major woman novelist; also parodied the Gothic 
style of Radcliffe in Northanger Abbey.
Still incredibly popular today….
1995, 
Austen-
mania 
begins


## PDF page 11

¨Popular
adaptations 
in 
1995 (BBC), 
2001, 
2003, 
2004,
2005…
P&P&Z in ‘16 
Pride and Prejudice (1813)
-most popular of her novels (and of any English novel)
Key themes found in Austen through…
The Bennet girls: Jane, Elizabeth, Mary, Kitty & Lydia
Mr. And Mrs. Bennet
brooding Mr. Darcy, Charles & Caroline Bingley, 
Mr. Collins & his Lady Catherine De Bourg, etc.
-most famous opening passage…
-A BBC miniseries in 1995 helped launch current
Austen mania…
Jennifer Ehle and 
Colin Firth


## PDF page 12

¨Popular
adaptations 
in 
1995 (BBC), 
2001, 
2003, 
2004,
2005…
P&P&Z in ‘16 
Pride and Prejudice (1813)
-most popular of her novels (and of any English novel)
Key themes found in Austen through…
The Bennet girls: Jane, Elizabeth, Mary, Kitty & Lydia
Mr. And Mrs. Bennet
brooding Mr. Darcy, Charles & Caroline Bingley, 
Mr. Collins & his Lady Catherine De Bourg, etc.
-most famous opening passage…
-A BBC miniseries in 1995 helped launch current
Austen mania…


## PDF page 13

Pride and Prejudice
Ah… July 2013…


## PDF page 14

1995 film, 2008 miniseries, 
two 2011 films 
Sense and Sensibility (1811)
The Dashwood girls [Elinor (‘sense’), Mariane (‘sensibility’), 
Margaret), their widowed mother
Their half-brother John & his wife Fanny
Losing estate & moving from Norland Park to humble 
Barton Cottage
2 Triangles: Elinor & Edward & fiancée Lucy
Marianne & Col. Brandon & wild Willoughby
Ends in a glorious double wedding!


## PDF page 15

Emma  (1816)
-a different trajectory, as Emma Woodhouse starts out at 
the top—rich, spoiled, headstrong, meddling—and 
doesn’t even need a husband.
-Emma plays match-maker to poorer Harriet Smith & vicar
Mr. Elton (instead of farmer Robert Martin)
-She dismisses advice of her sister’s brother-in-law, Mr. 
Knightley.
She’s taken down a notch & it ends in a double wedding! 
Kate
Beckinsale
Three successful adaptations in 1995-1996, miniseries in 2009.


## PDF page 16

(Patricia Rozema, 1999)              (2007)                           (2008)                           (2013)     
(bio + novel)
(fictional biopic)       (time travel switch)      (on Austen-mania)
A final word on today’s Austen-mania…
Over 50 film and TV adaptations in past 25 years, including hybrids like….
Her books are still best-sellers and since 2017 she has appeared on the £10 
banknote (replacing Charles Darwin).
Question:
Why do you think her works are still
so popular?


## PDF page 17

The Coming of Age of the Novel: 
The Early Novel of Manners
 
The Brontë Sisters: 
                                    Charlotte (1816-1855), Emily (1818-1848) & Anne (1820-1849)
-daughters of a poor Irish clergyman who left their mark on English literature
-all died very young (ages 39, 30 and 29, respectively) 
-On the frontier between Romantic influence and Victorian novel
-Charlotte reworks the Gothic genre into a more modern love story 
-Emily shows early use of time-shifts and embedded narratives, anticipating the 
technical work of Conrad
-Anne wrote a shocking feminist novel on spousal abuse


## PDF page 18

The Coming of Age of the Novel: 
The Early Novel of Manners
 
a. Emily Brontë’s Wuthering Heights (1847, under 
     pseudonym ‘Ellis Bell’) 
-Emotional story of ill-fated romance of Catherine 
& adopted step-brother Heathcliff (young love, 
betrayal when Catherine marries someone else, 
Growing bitterness and revenge with next generation)
-Passions/Immorality dominate the characters in 
their drive to self-destruction; controversial at time
 
 
 
 
           -Confrontation of two classes, two principles, two views 
 
 
 
 
   
 
 of love & faithfulness, etc.
                                          -Borrows heavily from Gothic tradition (nature, emotions)


## PDF page 19

The Coming of Age of the Novel: 
The Early Novel of Manners
 
a. Emily Brontë’s Wuthering Heights (1847, under 
     pseudonym ‘Ellis Bell’) 
-Emotional story of ill-fated romance of Catherine 
& adopted step-brother Heathcliff (young love, 
betrayal when Catherine marries someone else, 
Growing bitterness and revenge with next generation)
-Passions/Immorality dominate the characters in 
their drive to self-destruction; controversial at time
 
 
 
 
           -Confrontation of two classes, two principles, two views 
 
 
 
 
   
 
 of love & faithfulness, etc.
                                          -Borrows heavily from Gothic tradition (nature, emotions)
And Kate Bush’s 1978 hit…


## PDF page 20

The Coming of Age of the Novel: 
The Early Novel of Manners
 
b. Charlotte Brontë’s Jane Eyre (1847, under ‘Currer Bell’)
-Romantic story of an abused orphan, adopted into a cruel 
family and mistreated at school, who later becomes a 
teacher and then a governess in a country estate, falling 
in love with her brooding master, Edward Rochester…   
-Much like Austen, a bildungsroman where a good marriage 
(though not a typical one) is seen as the ideal ending for a woman’s story, though 
she is independent and has some feminist qualities.  (cf. Pamela)
-Also famous for its ‘madwoman
in the attic’ trope 
(for mistreatment of women)
-a hybrid of Gothic fiction & Novel 
of Manners
-Also – first major work of non-
epistolary fiction in the first 
person, allowing for more 
psychological depth


## PDF page 21

The Coming of Age of the Novel: 
The Early Novel of Manners
 
c. Anne Brontë’s The Tenant of Wildfell Hall 
(1848, under pseudonym ‘Acton Bell’)
-Her second and last novel as she died of tuberculosis in 
1849, at age 29.
-A then-shocking novel on the mistreatment of women, 
marital betrayal and flight from an abusive husband; 
it is often considered the first sustained feminist novel.
(An independent young single mother, Helen, who makes 
a living through painting and is 
the victim of rumors in her new 
village; her letters and diary 
reveal she escaped a brutal, 
wife-beating alcoholic).
-The novel was both successful
and scandalous, and her sisters
prevented its re-publishing for 
several years.


## PDF page 22

The Coming of Age of the Novel: 
‘Histories’  (Great Britain) 
Sir Walter Scott (1771-1832)
-shifted from poetry (already focused on history & folklore) to 
Histories such as Waverley (1814), Ivanhoe (1819), 
-Fascination with Scottish past, its folklore, historical figures
-Masterful recreation of atmosphere of the past, of scenery 
and language
-Remarkable characterization and verisimilitude, wanted to 
portray both the public and private sides of great figures
-Waverley (1814): on an honest and well-read English gentleman caught up 
in the 1745 Jacobite Rebellion in Scotland. (cf. ‘author of  Waverley’ fame) 
-Old Mortality (1816): set in 1679-89 and on the religious factions after the 
return of Charles II.
-Ivan Hoe (1819): battles and rivalry in England between the Saxons and 
the Normans under Richard I.


## PDF page 23

The Coming of Age of the Novel: 
‘Histories’  (Great Britain) 
Sir Walter Scott (1771-1832)
Waverley
Tredy
23


## PDF page 24

The Coming of Age of the Novel: 
‘Histories’  (U.S.A.!)
The Frontier Adventure…
 
James Fenimore Cooper (1789-1851): The 5 Leatherstocking Tales,
including The Last of the Mohicans (1826) and The Deerslayer (1841)
-First professional writer in the US, aka “the American Scott” for 
his focus on colonial and frontier history
-Adventure novels on the exploration of the frontier
-Key works: Five Leatherstocking Tales starring frontiersman Natty Bumppo, 
including 
The Last of the Mohicans (1826) - set during the 1757 French and Indian War 
when both British and French were using Native American mercenaries
The Deerslayer (1841) – set in upstate New York, on Bumppo trying to reason 
warring settlers and Native Americans in 1740s
-Focused on conflicts with Native Americans, with settlements destroying the 
prairie; works showed an envious oneness with Nature in Native Americans but an 
unsympathetic savagery 
-His heroes were forerunners to the lonely, adventurous and virile American hero, 
the ‘Maverick’…


## PDF page 25

Recap of main figures in Lesson V:
The Coming of Age of the Novel: 
3 subgenres, a gendered division (Romance vs Histories)
The Gothic Novel
Anne Radcliffe (1764-1823)
Mary Shelley (1797-1851)
(links to Percy Shelley, Lord Byron, Claire Clairemont & John Polidori)
The Novel of Manners
Jane Austen (1775-1817)
Charlotte Brontë (1816-1855)
Emily Brontë (1818-1848) 
Anne Brontë (1820-1849)
Histories /Historical Fiction                                                              (cf. non-fiction as well)
In Scotland: Sir Walter Scott (1771-1832, poet and then novelist)
cf. Robert Burns (1759-1796, poet)
In the U.S.: James Fenimore Cooper (1789-1851, novelist)
(Next lesson will focus on contemporaries in the U.S. as American Literature is born).

