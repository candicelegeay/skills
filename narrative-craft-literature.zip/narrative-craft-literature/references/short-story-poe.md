# short story overview  poe sample PDF A2FLT11  12.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: Literature 2: Writing Fiction (The Short Story & the Novel)                             CM - A2FLT11 – D. Tredy / Lecture Class (CM) = Ten o
- PDF page 2: In Introduction to the Short Story…                                          A2FLT11 – D. Tredy / (This lesson corresponds to pages 16-17 of
- PDF page 3: Some Notes on the Short Story / A Brief History of the Short Story:
- PDF page 4: Some Notes on the Short Story / However, there was a more prominent rise of the short story in American
- PDF page 5: Edgar Allan Poe / -Though Poe wrote poetry (‘The Raven’, poems used for locution exercises), he is
- PDF page 6: -Late 19th Century: / -The short story grew with the rise of magazines and newspapers, which
- PDF page 7: -Early 20th century: / -The Modernists experimented with the short story as much as with the
- PDF page 8: -Mid- to Late 20th century / Though the form was still common in Great Britain, it was more prominent in
- PDF page 9: The 15 short stories in your A2FLT11 brochure:
- PDF page 10: The 15 short stories in your A2FLT11 brochure:
- PDF page 11: http://1.bp.blogspot.com/-aBo0zvLDEGQ/Twib5hElRUI/AAAAAAAABk4/j7anvN7ONes/s640/harry-clarke-the-tell-tale-heart.jpg / Harry Clarke 1933 illu
- PDF page 12: “The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849) / The incipit…
- PDF page 13: “The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849) / The ending, in (a second) crescendo…
- PDF page 14: “The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849) / […] A shriek had been heard by a neighbour during the night; suspicion of foul p
- PDF page 15: “The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849) / No doubt I now grew very pale; --but I talked more fluently, and with a heighten

## PDF page 1

Literature 2: Writing Fiction (The Short Story & the Novel)                             CM - A2FLT11 – D. Tredy
Lecture Class (CM) = Ten one-hour sessions
Focus of Lecture Class:
-Historical Overviews of Key Movements, Authors and Works
-Literary Notions and Terms (with examples from the brochure and elsewhere)
-Background on the novel you will read later in the semester (Stevenson)
Note: the CM is an ‘inclusive class’
Practice Tests every 3 lectures
An online midterm just on the CM content (worth 20% of your grade)
An online final exam just on the CM content (worth 20% of your grade)
In your tutorial (TD), your in-class/homework grades will be worth 30% of your grade, and
the written final exam for the TD (during the week of ‘épreuves longues’ after the 
semester ends) will be worth 30% as well.
Today’s CM: Timeline for the Development of the Short Story & a sample


## PDF page 2

In Introduction to the Short Story…                                          A2FLT11 – D. Tredy
(This lesson corresponds to pages 16-17 of your A2FLT11 brochure)
Definition: a ‘short’ narrative format in prose
But how short is ‘short’?   Lengths can vary…
anecdotes, vignettes and ‘flash fiction’ / the short story  /  the novella  / the 
novel
Some specific features (compared to novels):
-It is usually more pointed and direct
-It is usually more end-oriented, has a ‘point’ or comes to a denouement
-It has roots in oral story-telling and anecdote sharing
   (e.g., “You won’t believe what happened to me the other day…”)
-It usually has a limited number of characters, settings and incidents
-It can have a complete dramatic arc (see p. 14) in spite of its size, but it can 
also be truncated or incomplete, or start in medias res, etc. The Modernists in 
particular experimented with variations on the format.


## PDF page 3

Some Notes on the Short Story
A Brief History of the Short Story:
-It originally comes from a long tradition of oral story-telling and fables.
-14th century: “collected” and related tales (such as Chaucer’s The Canterbury 
Tales), which were often read aloud.
-17th and 18th century: biblical parables and children’s fairy tales (e.g. Charles 
Perrault in the 17th century, the Brothers Grimm and Hans Christian Andersen 
in the 19th century, etc.)
-Early 19th century: 
Even if novel was dominant, many English authors wrote short stories 
(e.g., Walter Scott, Charles Dickens)


## PDF page 4

Some Notes on the Short Story
However, there was a more prominent rise of the short story in American 
literature:
Washington Irving (“Rip Van Winkle”, “The Legend o Sleepy Hollow”)
Nathaniel Hawthorne (Twice-Told Tales, “Young Goodman Brown”, etc.)
And especially Edgar Allan Poe…
http://socialpsychol.files.wordpress.com/2012/04/washington-irving-7.jpg?w=127h=150
Nathaniel Hawthorne by Brady, 1860-65.jpg
Washington Irving        Nathaniel Hawthorne       Edgar Allan Poe


## PDF page 5

Edgar Allan Poe
-Though Poe wrote poetry (‘The Raven’, poems used for locution exercises), he is 
most remembered today for his many fantastic ‘tales’ and for popularizing the 
short story.
-His main sub-genre was horror/fantastic (eg, “The Tell-Tale Heart”, “The Black 
Cat”, “Ligeia”)
-They featured Poe’s unreliable “fancy-me-mad” narrator. The reader doesn’t 
know if the supernatural events are really occurring (cf. ‘the Marvellous’) or if 
they can be explained by the narrator’s hallucinations, madness or opium use (cf. 
‘the Uncanny’). This hesitation between two readings is the very definition of ‘the 
Fantastic’ (according to Tzvetan Todorov).
-In addition, Poe was also a pioneer in early detective fiction, which he called 
‘tales of ratiocination’ (e.g., “Murders in the Rue Morgue”), but he also dabbled in 
early science fiction (e.g., “The Balloon Hoax”).
-In his essay A Philosophy of Composition, he explained that to “hold’ the readers, 
they must be able to read the work in one sitting.
-Poe wrote his shocking endings first, and then sought the best way to build 
tension ‘by degrees’ to that ending. 
-Also note that Poe was a journalist by profession, and thus had a knack for the 
short form. 


## PDF page 6

-Late 19th Century:
-The short story grew with the rise of magazines and newspapers, which 
often needed 3000- to 5000-word stories rather than just ‘instalments’ of 
novels. Serialization of novels soon became the norm.
-Many novelists of the period would write a great number of short stories as 
well. For example:
Britain: Thomas Hardy, Rudyard Kipling, Sir Arthur Conan Doyle, H.G. Wells, 
and others.
France: Guy de Maupassant, among others; Russia: Ivan Turgenev, Fyodor 
Dostoyevski
U.S.:  Mark Twain, Henry James (125 short stories as well as 22 novels)
Henry James used Maupassant as his model for what he called “the belle and 
blest nouvelle”, “the small, perfect frame” that was the short story. In his 
notebooks, James repeatedly claims he wanted to do in English what 
Maupassant was doing so remarkably well in French.


## PDF page 7

-Early 20th century:
-The Modernists experimented with the short story as much as with the 
novel. Take for example the short works of Virginia Woolf, or James Joyce’s 
1916 collection of short stories, Dubliners.
Among American modernists working on the short story, there was F. Scott 
Fitzgerald, Ernest Hemingway, and William Faulkner (who wrote over 100 
short stories).
-The form was becoming so popular that there were many popular writers 
who focused exclusively or nearly exclusively on writing short stories, such as 
William Somerset Maugham and Saki (H.H. Munro) in Britain, and O. Henry 
(William Sydney Porter) in the United States. Note that the last two authors 
mentioned (Saki and O. Henry) were perhaps far less ‘literary’ than the 
others, but they were widely read and perfected the use of the surprise or 
ironic ending in such short works of fiction. Also note that in the U.S. today, 
the national award given every year for the best short story is called The O. 
Henry Prize.


## PDF page 8

-Mid- to Late 20th century 
Though the form was still common in Great Britain, it was more prominent in 
the U.S., with   authors such as Flannery O’Connor (e.g., “A Good Man Is Hard 
to Find”), J.D. Salinger, John Cheever and Shirley Jackson (e.g., “The Lottery”) 
at mid-century. Later generations included John Updike, Joyce Carol Oates, 
Raymond Carver, Alice Munro (Canadian, Nobel Prize 2013), or the extremely 
popular Stephen King. Today, short stories are truly a part of U.S. literary 
culture and identity, with short story collections that can always be found on 
current best-seller lists.   
Now let’s look over the short stories in your A2FLT11 brochure:


## PDF page 9

The 15 short stories in your A2FLT11 brochure:


## PDF page 10

The 15 short stories in your A2FLT11 brochure:


## PDF page 11

http://1.bp.blogspot.com/-aBo0zvLDEGQ/Twib5hElRUI/AAAAAAAABk4/j7anvN7ONes/s640/harry-clarke-the-tell-tale-heart.jpg
Harry Clarke 1933 illustration
Now let’s look at ‘’The Tell-Tale Heart’’,
the most widely read Poe story in school
Written in 1843 as a variation on an idea
he used in ‘’The Black Cat’’ (also 1843).


## PDF page 12

“The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849)
The incipit…
TRUE! --nervous --very, very dreadfully nervous I had been and am; but why will you 
say that I am mad? The disease had sharpened my senses --not destroyed --not dulled 
them. Above all was the sense of hearing acute. I heard all things in the heaven and in 
the earth. I heard many things in hell. How, then, am I mad? Hearken! and observe how 
healthily --how calmly I can tell you the whole story.
It is impossible to say how first the idea entered my brain; but once conceived, it 
haunted me day and night. Object there was none. Passion there was none. I loved the 
old man. He had never wronged me. He had never given me insult. For his gold I had 
no desire. I think it was his eye! yes, it was this! He had the eye of a vulture --a pale 
blue eye, with a film over it. Whenever it fell upon me, my blood ran cold; and so by 
degrees --very gradually --I made up my mind to take the life of the old man, and thus 
rid myself of the eye forever.
Now this is the point. You fancy me mad. Madmen know nothing. But you should have 
seen me. You should have seen how wisely I proceeded --with what caution --with what 
foresight --with what dissimulation I went to work! I was never kinder to the old man 
than during the whole week before I killed him. […]


## PDF page 13

“The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849)
The ending, in (a second) crescendo…
[…] The old man was dead. I removed the bed and examined the corpse. Yes, he was 
stone, stone dead. I placed my hand upon the heart and held it there many minutes. 
There was no pulsation. He was stone dead. His eye would trouble me no more.
If still you think me mad, you will think so no longer when I describe the wise 
precautions I took for the concealment of the body. The night waned, and I worked 
hastily, but in silence. First of all I dismembered the corpse. I cut off the head and the 
arms and the legs.
I then took up three planks from the flooring of the chamber, and deposited all between 
the scantlings. I then replaced the boards so cleverly, so cunningly, that no human eye --
not even his --could have detected any thing wrong. There was nothing to wash out --no 
stain of any kind --no blood-spot whatever. I had been too wary for that. A tub had 
caught all --ha! ha!
When I had made an end of these labors, it was four o'clock --still dark as midnight. As 
the bell sounded the hour, there came a knocking at the street door. I went down to open 
it with a light heart, --for what had I now to fear? There entered three men, who 
introduced themselves, with perfect suavity, as officers of the police. […]


## PDF page 14

“The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849)
[…] A shriek had been heard by a neighbour during the night; suspicion of foul play 
had been aroused; information had been lodged at the police office, and they (the 
officers) had been deputed to search the premises.
I smiled, --for what had I to fear? I bade the gentlemen welcome. The shriek, I said, was 
my own in a dream. The old man, I mentioned, was absent in the country. I took my 
visitors all over the house. I bade them search --search well. I led them, at length, to his 
chamber. I showed them his treasures, secure, undisturbed. In the enthusiasm of my 
confidence, I brought chairs into the room, and desired them here to rest from their 
fatigues, while I myself, in the wild audacity of my perfect triumph, placed my own seat 
upon the very spot beneath which reposed the corpse of the victim.
The officers were satisfied. My manner had convinced them. I was singularly at ease. 
They sat, and while I answered cheerily, they chatted of familiar things. But, ere long, I 
felt myself getting pale and wished them gone. My head ached, and I fancied a ringing 
in my ears: but still they sat and still chatted. The ringing became more distinct: --It 
continued and became more distinct: I talked more freely to get rid of the feeling: but it 
continued and gained definiteness --until, at length, I found that the noise was not 
within my ears.


## PDF page 15

“The Tell-Tale Heart” (1843), Edgar Allan Poe (1809-1849)
No doubt I now grew very pale; --but I talked more fluently, and with a heightened 
voice. Yet the sound increased --and what could I do? It was a low, dull, quick sound --
much such a sound as a watch makes when enveloped in cotton. I gasped for breath --
and yet the officers heard it not. I talked more quickly --more vehemently; but the noise 
steadily increased. I arose and argued about trifles, in a high key and with violent 
gesticulations; but the noise steadily increased. Why would they not be gone? I paced 
the floor to and fro with heavy strides, as if excited to fury by the observations of the 
men --but the noise steadily increased. Oh God! what could I do? I foamed --I raved --I 
swore! I swung the chair upon which I had been sitting, and grated it upon the boards, 
but the noise arose over all and continually increased. It grew louder --louder --louder! 
And still the men chatted pleasantly, and smiled. Was it possible they heard not? 
Almighty God! --no, no! They heard! --they suspected! --they knew! --they were 
making a mockery of my horror!-this I thought, and this I think. But anything was 
better than this agony! Anything was more tolerable than this derision! I could bear 
those hypocritical smiles no longer! I felt that I must scream or die! and now --again! --
hark! louder! louder! louder! louder!
"Villains!" I shrieked, "dissemble no more! I admit the deed! --tear up the planks! here, 
here! --It is the beating of his hideous heart!"

