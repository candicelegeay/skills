# Narrative toolkit shared by literature and writing

## Contents
- Voice and viewpoint
- Time, movement and information
- Speech, character and style
- Applying narrative techniques to nonfiction

This operational synthesis draws on A2FLT11/A2FLT12, especially narration-focalization, speech-characterization and anthology pp. 4–14. The applications and safeguards are editorial additions. Consult source-index.md for corrections to simplified terminology.

## Voice and viewpoint

Separate these questions before choosing a label:
1. Who speaks? Establish narrator participation, level, visibility and the narrating situation.
2. Who perceives or has access to information? Locate focalization from what is reported, perceived, inferred and withheld, not from pronouns alone.
3. Who is addressed? Identify a narratee when textual markers support one; distinguish that construct from actual readership.
4. From when is the story told? Distinguish the experiencing self from the later narrating self, including hindsight and evaluative distance.
5. How far does the voice stand from events or consciousness? Assess distance, commentary, irony and access without equating greater intimacy with better writing.

For viewpoint changes, locate the transition and ask whether it is deliberate, intelligible and productive. Variable internal focalization can be coherent. Do not label every shift head-hopping or prescribe one POV per chapter.

Evaluate reliability only when relevant, specifying what can be trusted and where evidence challenges it. Moral disagreement with a narrator does not prove factual inaccuracy. Do not infer the author shares the narrator's attitudes.

## Time, movement and information

Distinguish story chronology from narrative order. Analepsis returns to an earlier event; prolepsis narrates a later event in advance. Foreshadowing signals a possibility without necessarily narrating a future event. Distinguish repetition of an event from iterative narration of recurring events.

Treat scene, summary, pause and ellipsis as pacing choices. Scene is useful for consequential interactions; summary can establish patterns and bridge time; pause can charge a detail; ellipsis can concentrate attention. None is inherently superior.

Map reader information against character information. Suspense, curiosity, surprise and dramatic irony can emerge from different distributions, not just withholding. Ask whether a delayed disclosure creates productive uncertainty or merely conceals essential orientation. Ground a proposed twist in prior material rather than forcing a reversal.

Treat exposition, crisis, turning point, climax, epiphany and ending as analytical possibilities. A story can be episodic, circular, quiet or unresolved; do not force a three-act arc or hero's journey. An open ending can be precise rather than unfinished.

## Speech, character and style

Distinguish summarized speech, indirect speech, free indirect speech/thought, direct and free direct representation. Diagnose free indirect discourse through a combination of grammatical framing, deictic orientation, evaluative diction, exclamations and character idiom; one missing thought tag is insufficient proof. A short sentence such as 'She was late' may be ambiguous without context.

Original contrasting examples:
- Indirect thought: She thought that the room was too quiet.
- Free indirect thought: The room was too quiet. Why had he stopped the clock?
- Direct thought: “Why has he stopped the clock?” she thought.
These are teaching examples, not quotations or airtight classifications independent of context.

Examine characterization through description, action, dialogue, thought, other characters, objects and setting. Distinguish what a character says about another from what the text establishes. Do not demand a transformation arc or psychological explanation of every gesture.

Examine voice through syntax, cadence, lexicon, address, digression, idiolect and speech rhythms. Preserve deliberate dialect, fragments, repetition and tense effects. Do not standardize fictional speech into professional prose. Distinguish expressive texture from accidental obscurity by testing the requested effect.

Discuss metaphor, metonymy, repetition, gradation, alliteration, assonance and irony through what they do in this passage. Avoid a device inventory without an interpretive claim. Do not assign symbolism to every object automatically.

## Applying narrative techniques to nonfiction

Use these as tactical options within a factual and argumentative structure:

| Technique | Possible use | Boundary |
|---|---|---|
| Scene followed by analytical widening | Make a documented incident concrete, then establish its larger significance. | Never invent an observed scene, dialogue or personal experience. Label hypothetical examples. |
| Controlled perspective | Follow a user's, operator's or institution's observable situation before expanding the analysis. | Do not invent private thoughts or conceal material facts to manufacture a viewpoint. |
| Distance and scale | Move between a local interaction and a system-level explanation. | Mark changes in scope; do not generalize a single episode without support. |
| Order and disclosure | Begin with an outcome, then explain how it occurred; defer a secondary detail until useful. | Do not withhold essential qualifications or manufacture certainty for suspense. |
| Scene/summary alternation | Slow down a decisive interaction and compress routine stages. | Preserve chronology and causal relationships; do not fictionalize missing steps. |
| Motif or return to opening | Revisit a concrete detail after the analysis changes its meaning. | Avoid ornamental callbacks or false closure. |
| Voice and cadence | Vary sentence form, repetition and emphasis to clarify a central distinction. | Preserve technical nuance; no rhetorical flourish that overstates the evidence. |

In nonfiction, do not import unreliable narration as a tactic for misleading readers. Do not use free indirect discourse to assert an actual person's unreported thoughts. Suggest at most two techniques that solve a specific problem; do not literary-ize every paragraph.
