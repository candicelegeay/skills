# Literature corpus index

User-supplied A2FLT11/A2FLT12 university materials. Sources identify Dennis Tredy and Antonia Rigaud among course instructors; do not attribute every document to one person. These files contain course instruction, interpretive examples, anthology texts, historical surveys and assessment requirements. They are not interchangeable kinds of authority.

## Inventory
- `narration-focalization.md`: A2FLT11 12 Lecture 2 PDF.pdf; 7 pages.
- `speech-characterization.md`: A2FLT12 Lecture 4 Speech Representations et al PDF.pdf; 15 pages.
- `voice-introduction.md`: Week 1. Introduction and Narrative Voice.pdf; 4 pages.
- `readings-week-2.md`: Week 2.pdf; 4 pages.
- `readings-week-3.md`: Week 3.pdf; 5 pages.
- `readings-week-4.md`: Week 4.pdf; 7 pages.
- `readings-week-5.md`: A2FLT12_ Week 5.pdf; 5 pages.
- `commentary-method.md`: Fiche méthodologique pour le commentaire de texte littéraire.pdf; 2 pages.
- `commentary-introduction.md`: Comment présenter un texte et sa problématique dans un commentaire de texte.pdf; 2 pages.
- `exam-guidance.md`: CR Visio du 17 février 2026_Recommandations pour lexamen.pdf; 2 pages.
- `short-story-poe.md`: short story overview  poe sample PDF A2FLT11  12.pdf; 15 pages.
- short story overview  poe sample PDF A2FLT11  12 (1).pdf: identical extracted text to `short-story-poe.md`; use that reference.
- `novel-history.md`: A2FLT11 12 CM - Lecture 5  The_Novel_Comes_of_Age PDF.pdf; 25 pages.
- `american-renaissance.md`: A2FLT11 12 CM - Lecture 6 The American Renaissance PDF.pdf; 31 pages.
- `anthology.md`: A2FLT12 Brochure Literature short stories.pdf; 114 pages.
- `anthology-extracted.md`: A2FLT12 Brochure Literature short stories-extracted.pdf; 11 pages.
- `syllabus.md`: A2FLT12_Syllabus_.pdf; 3 pages.

## Reading routes
- Narrator, focalizer, narratee and retrospective distance: narration-focalization pp. 2–7; voice-introduction pp. 1–4.
- Core terminology: anthology pp. 4–14 (plot, time, voice, characterization, speech, tone, figures).
- Speech and thought representation, skaz, characterization: speech-characterization; consult its page headings.
- Close-reading models: readings-week-2 through readings-week-5. Treat them as argued interpretations, not the only possible answers.
- Literary commentary method: commentary-method and commentary-introduction; exam-guidance and syllabus only for course-specific assessment requests.
- Short-story form and Poe: short-story-poe. Historical context: novel-history and american-renaissance.
- Primary literary examples: anthology; use its table of contents to locate a story. anthology-extracted may be a partial variant, not a separate work.

## Terminological safeguards
These corrections are supplemental methodological safeguards, not claims that the course states them.
- Narrative level (extra-/intra-/meta- or hypodiegetic) and participation (hetero-/homo-/autodiegetic) are distinct axes. A first-level narrator can be extradiegetic AND homodiegetic. Do not equate third person with extradiegetic, or first person with intradiegetic.
- Focalization is information/perception restriction. Internal focalization can be fixed, variable or multiple. A shift among internal focalizers does not alone establish zero focalization. “External focalizer” in the course is not synonymous with Genette’s external focalization; zero focalization is a separate category.
- Limited knowledge, mistaken perception, distress or a diagnosis does not alone prove narrative unreliability. Ground reliability claims in contradictions, omissions, interpretive gaps or other textual evidence; distinguish reporting, interpretation and evaluation.
- Overt/covert refers to perceptible narratorial presence, not simply whether the narrator has a name.
- Dramatic irony, situational irony and verbal irony are distinguishable; avoid collapsing their classifications.
- Flat/round and static/dynamic are different distinctions. A flat character need not be artistically unsuccessful.
- Interior monologue, narrated monologue/free indirect thought and stream of consciousness overlap in some frameworks but are not interchangeable universal synonyms. State the framework where needed.
- Duration: scene approximates story time; summary compresses it; ellipsis omits narrated time; descriptive pause suspends story progression. The course’s inequality notation for pause is simplified: prefer the verbal account.
- The five-part dramatic pyramid is conventionally associated with Freytag; do not attribute that exact diagram to Aristotle or impose it on all narratives.
- “Show, don’t tell” is an optional craft heuristic. Summary, commentary and deliberate distance can be effective.
- Distinguish narrator from author in fiction. Do not mechanically call the narrator fictional in memoir or documentary prose. A rhetorical narratee is not simply the actual reader.
- Respect textual ambiguity; do not turn an interpretation into authorial intention or psychological diagnosis. Historical surveys and example claims may be dated or contestable; verify specific factual claims when relevant.