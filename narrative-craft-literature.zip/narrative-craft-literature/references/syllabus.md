# A2FLT12_Syllabus_.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: A2FLT12 TD: SYLLABUS / Antonia Rigaud (Antonia.rigaud@sorbonne-nouvelle.fr)
- PDF page 2: - / Chapter 6 “Remarkable Incident of Doctor Lanyon”: “A week afterwards Dr Lanyon took to
- PDF page 3: For the short stories, read the story in full at least twice, summarize the story, keep a record of the story / from the perspective of the 

## PDF page 1

A2FLT12 TD: SYLLABUS 
Antonia Rigaud (Antonia.rigaud@sorbonne-nouvelle.fr) 
 
This schedule is organized around weekly activities which will help you organize yourself.  
Weekly lectures are organized for you to be able to schedule your work and work regularly – doing a 
little bit every week will help you to learn and process all you have to learn this semester. 
I strongly suggest you try and work on a regular basis.  
 
Week 1 (January 19h-23th): Introduction to the course: narrative voice  
 
Week 2 (January 26th- 30th): Short stories 
- 
Charlotte Perkins Gilman, “The Yellow Wallpaper” (1892): excerpt from “On a pattern like 
this” to “I am determined that nobody shall find it out by myself!” 
- 
Saki (H.H. Munro), “The Open Window” (1914): excerpt from line 55 “The doctors agree” to 
the end of the story 
Note: Wednesday January 28th, 6-7 pm: video chat: meet.google.com/afo-dgsp-wkq 
 
Week 3 (February 2nd-6th): Short stories 
- 
Katherine Mansfield, “The Garden Party” (1922): from “There lay a young man – end of the 
short story” 
- 
Jean Rhys, “I Used to Live Here Once” (1976): whole story 
 
Week 4 (February 9th-13th): Short stories  
- 
Angela Carter, “The Werewolf” (1978): excerpt from the beginning to line 15, “stone her to 
death” 
- 
O. Henry, “The Gift of the Magi” (1905): excerpt from line 23 “Out of his trance” to the end 
of the story 
 
Week 5 (February 16th-20th): Methodology session on literary commentaries 
- 
John Updike, “The A&P” (1961): excerpt from “The girls, and who’d blame them” to the end 
of the story 
- 
Kazuo Ishiguro, “A Family Supper” (1982): excerpt from “There was a large pot” to the end 
of the story 
Note: Tuesday, February 17th, 6-7 pm: video chat: meet.google.com/afo-dgsp-wkq 
 
Week 6 (February 23rd-27th): Mid-term: the exam will be available online between February 23rd 
and 25th 
 
Winter break 
 
Week 7 (March 9th-13th): Strange Case of Dr Jekyll and Mr Hyde, chapters 1 and 2 
- 
Chapter 1 “Story of the Door”: “‘I see you feel as I do’” to the end of the chapter (pp. 9-10) 
- 
Chapter 2 “Search for Mr Hyde”: “Mr Utterson stepped out and touched him on the shoulder” 
to “and disappeared into the house” (pp. 14-15) 
 
Week 8 (March 16th-20th): Strange Case of Dr Jekyll and Mr Hyde, chapters 3 and 4 
- 
Chapter 3 “Dr Jekkyll Was Quite at Ease”: “‘My good Utterson’, said the doctor” to “’well’, 
said he, ‘I promise’ (p. 20) 
- 
Chapter 4 “The Carew Murder Case”: “It was by this time about nine” to “since she had seen 
him till yesterday” (pp. 23-24) 
 
Week 9 (March 23rd-27th): Strange Case of Dr Jekyll and Mr Hyde, chapters 5 and 6 
- 
Chapter 5 “Incident of the Letter”: “‘Utterson, I swear to God’, cried the doctor” to “And he 
covered his face for moment with his hands” (pp. 26-28) 


## PDF page 2

- 
Chapter 6 “Remarkable Incident of Doctor Lanyon”: “A week afterwards Dr Lanyon took to 
his beed” to the end of the chapter (pp. 33-34) 
 
Week 10 (March 30th-April 3rd): Strange Case of Dr Jekyll and Mr Hyde, chapters 7 and 8 
- 
Chapter 7 “Incident at the Window”: “‘That is just what I was about to venture” to the end of 
the chapter (p. 36) 
- 
Chapter 8 “The Last Night” Right in the midst there lay the body of a man sorely” to Nowhere 
was there any trace of Henry Jekyll, dead or alive” (pp. 44-45) 
 
Week 11 (April 7th-10th): Strange Case of Dr Jekyll and Mr Hyde, chapters 9 and 10 
- 
Chapter 9 “Doctor Lanyon’s Narrative”: “He put the glass to his lips” to the end of the chapter 
(p. 54) 
- 
Chapter 10 “Henry Jekyll’s Full Statement of the Case”: “The pleasures which I made haste to 
seek in my disguise were” to “I thought I sat beyond the reach of fate” (pp. 60-61) 
 
Week 12 (April 13th-17th): Oral exam: 10mn individual sessions on Strange Case of Dr Jekyll and 
Mr Hyde. 
 
Final written exam during the “épreuves longues” (between april 27th and may 7th), the bureau 
des examens will post an exact date and time a few weeks beforehand. 
The exam will consist in a 2-hour written commentary on an excerpt from Strange Case of 
Dr Jekyll and Mr Hyde 
 
End of semester 
 
 
 
 
RECAP ON EXAMS AND GRADING FOR THE “TD” PART OF A2FLT12 
 
You will get three grades: 
- 
A midterm short written work which will be available online between February 23rd and 
25th  (15% of your grade) 
- 
A 10mn oral exam on the week of April 13-17 (15% of your grade) 
- 
A 2hour written exam during the “épreuves longues” (between april 27th and may 7th), 
the bureau des examens will post an exact date and time a few weeks beforehand. The 
exam will consist in a 2-hour written commentary on an excerpt from Strange Case of 
Dr Jekyll and Mr Hyde 
 
A note on plagiarism and artificial intelligence: As you know, plagiarism will be severely punished. 
Make sure to give credit when it is due (either by quoting or referring to authors and texts) and never, 
ever copy and paste from somebody else’s work. Using artificial intelligence would be completely 
counterproductive as AI does not know how to write a literary commentary. As we will see during the 
semester, literary commentaries rely on a very detailed and close reading of the way texts are written, 
something which AI does not know how to do. Plagiarism or using AI will result in a 0/20. 
 
HOW TO WORK FOR THIS COURSE? 
 
As you can see on the weekly breakdown of the semester, each week is organized around several short 
stories or extracts from Strange Case of Dr Jerkyll and Mr Hyde. It is very important that you keep a 
regular pace by doing the readings and preparations every week.  
Preparing for each weekly session:  
Read the texts: 


## PDF page 3

For the short stories, read the story in full at least twice, summarize the story, keep a record of the story 
from the perspective of the 7 literary topics in the brochure: 
o 
Plot 
o 
Time elements 
o 
Narration and point of view 
o 
Characterization and speech representation 
o 
Speech representation in the narration 
o 
Tone and Style 
o 
Main rhetorical effects 
 
For Strange Case of Dr Jerkyll and Mr Hyde read the novel in full once before the first session we will 
be working on it. Then read it at least once more during the course of the semester. 
Prepare the excerpts we will be working on 
Focus on the excerpts listed on the syllabus for each week. Analyze the way each excerpt is organized 
and underline what you find to be its key elements. 
§ 
Summarize the excerpt 
§ 
Take down three important questions/notions developed in the text 
§ 
Post on the forum any questions you might have on the texts 
 
Make sure to take notes every week about what you have learned: literary vocabulary, textual analysis, 
literary history etc. 
 
 

