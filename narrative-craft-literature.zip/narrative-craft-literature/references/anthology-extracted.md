# A2FLT12 Brochure Literature short stories-extracted.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: 4 / Some Literary Terms and Notions to Help with Textual Commentaries
- PDF page 2: 5 / Key Moments in the Plot:
- PDF page 3: 6
- PDF page 4: 7 / 1. Narrator  (more than simple 1st person or 3rd person split)
- PDF page 5: 8
- PDF page 6: 9 / b. Round Characters vs. Flat Characters
- PDF page 7: 10
- PDF page 8: 11 / E. Speech Representation in the Narration:
- PDF page 9: 12
- PDF page 10: 13 / F. Tone and Style
- PDF page 11: 14 / RHETORICAL EFFECTS / FIGURES OF SPEECH:                      C. Dauphin

## PDF page 1

4 
 
 
Some Literary Terms and Notions to Help with Textual Commentaries 
 
mimesis vs diegesis  (showing vs. telling) 
(cf. Aristotle’s Poetics, Plato’s The Republic, Book III; Genette, Rimmon-Kenan, et al.) 
 
A. Plot 
 
 
 
 
Plot vs. Story:  
-“‘The king died and then the queen died’ is a story. ‘The king died and then the queen died of grief’ 
is a plot.” (E.M. Forster, 1927) 
 
-a causal chain : “For want of a nail, the shoe was lost; for want of a shoe, the horse was lost; for 
want of a horse, a knight was lost; for want of a knight, the battle was lost; for want of a battle, the 
kingdom was lost—all for the want of a nail.”   (cf. “a chain of events”) 
 
-a plot-line, a story-line 
 
Key moments in the plot: 
In Poetics (4th century BC), Aristotle had already discussed the basic elements of a plot, explaining 
that there were three key parts to every story-line (beginning, middle & end), but that between them 
there were important stages of development.  His ‘dramatic arc’ would look like this: 
 
NB: This arc accurately corresponds to the traditional 5-act structure of classical Greek drama and 
notably Elizabethan drama, in which the main plot was divided into five acts. 
 
Example:   
Basic Plot of Shakespeare‘s Julius Caesar (1599):  
Act I – the murder plot is hatched and Caesar‘s friend Brutus accepts to be a part of it (exposition & 
complication) 
Act II – Brutus becomes more involved in the plot and warning signs to Caesar go unheeded (rising action) 
Act III –the murder of Caesar; Brutus‘s speech to justify it; Antony‘s speech that turns the people against 
Brutus and the other conspirators (climax and turning point) 
Act IV – Brutus and the conspirators are on the run; they begin turning against each other (falling action)  
Act V – Battles between Antony‘s and Brutus‘s forces.  The ‘Honorable‘ Brutus, the last of the conspirators, 
falls on his sword and kills himself  (denouement/catastrophe) 
 
NB: It is by breaking down the plot like this that we clearly see that the main character of the play is not in 
fact Julius Caesar, but Brutus.    
 


## PDF page 2

5 
 
 
Key Moments in the Plot: 
 
INCIPIT : 
 
 
 
TURNING POINTS : 
 
ENDINGS : 
-exposition 
 
 
 
-crisis  
 
 
 
-denouement 
   -background  
 
 
-anagnorisis (revelation) 
 
-catastrophe 
   -orientation   
  
 
-peripeteia / reversal of fortune 
-deus ex machina 
   -setting, mood, tone  
 
-a twist / -coup de théâtre  
 
-open-endedness 
   (creating an initial ‘tableau’) 
-crux (pl. cruces) 
 
 
   vs. closure 
   -adding a preface or a prologue 
-climax / anticlimax  
 
-to tie up loose ends 
-in medias res  
 
 
-epiphany / catharsis  
 
-a circular plot 
 
Multiple Plots: 
 
-Combining the main plot (main story-line) and one or more subplots  
 
 
 
-Interweaving several main plots or story-lines 
 
-Metadiegesis / mise-en-abime (a tale within a tale, a play within a play, etc.) 
A frame narrative and its embedded narrative(s) 
 
Pattern of Plot: 
linear / non-linear (cf. anachronies – flashbacks, flashforwards) 
episodic (e.g. Candide, Don Quixote)  
a tightly knit, a well-wrought plot vs. a loose plot 
 
 
B. Time Elements 
(most terms from Gérard Genette, Figures III) 
 
Genette’s notion of story-time vs. text-time 
 
ORDER : 
-linear vs. non-linear time 
-digressions from the plot  
[e.g., Salinger’s The Catcher in the Rye (1951), Laurence Stern’s Tristram Shandy (1760)] 
-anachronies : 
flashback (analepsis) & flashforward (prolepsis)   
(compare to echo, foreshadowing & amorce or snares) 
 
PACE / DURATION :   acceleration vs. deceleration 
scene (TT=ST) 
summary (TT<ST) 
(descriptive) pause  (TT>ST)        ellipsis (TT=0) 
         
 
FREQUENCY : 
singulative 
iterative (told once, happened x times)     repetitive (told x times, happened once) 
 
C. Narration and Point of View: 
(most terms from Genette’s Figures III) 
 
Three main literary constructs: 
The narrator (who speaks?) 
The focalizer (who sees or feels?) 
The narratee (who is spoken to?) 


## PDF page 3

6 
 
 


## PDF page 4

7 
 
 
1. Narrator  (more than simple 1st person or 3rd person split) 
external (extradiegetic) narrator (outside the story) 
internal (intradiegetic)  (a character telling the tale) 
subordinate (hypodiegetic) (when characters tell a quick story to the protagonist, for example) 
 
an autodiegetic narrator (the main character – e.g., Jane Eyre in Brontë’s Jane Eyre) 
homodiegetic (part of the main group of characters – e.g., Nick in Fitzgerald’s The Great Gatsby) 
heterodiegetic (a fictional character but not part of main story –e.g., the unnamed narrator in  
    George Eliot’s Middlemarch)  
 
covert vs. overt narration (i.e., Is the narrator identified?) 
constant vs. shifting narration (i.e., Does the narrator ever change?) 
actional or explicative narration (i.e., Are events narrated, or is the focus more on  
     feelings/motivations/thoughts?) 
unintrusive or intrusive narration (i.e., Do we nearly forget we have a narrator or does the  
     narrator ‘interrupt’ the story?) 
reliable or unreliable/fallible (i.e., Can we trust what the narrator tells us?  e.g., Benjy in The  
     Sound & the Fury, Humbert Humbert in Lolita, Poe narrators) 
 
2. The Focalizer (term from Genette):  
also called ‘point of view character’ / reflector / mirror / centre of consciousness (Henry James) 
- focalization or point of view / perspective / angle of vision 
note :  focalization by someone—emphasis on who is perceiving 
 
focalization on someone—emphasis on who/what is being perceived 
 
3 main cases: 
A. EXTERNAL FOCALIZERS  (usually the narrator) 
1.  the detached observer / witness (restricted knowledge) 
2.  ‘zero-focalization’ / omniscience (unrestricted knowledge) 
B. INTERNAL FOCALIZERS (character-focalizers) 
 
Constant or shifting point of view? 
Covert or overt focalizers? 
Reliable or unreliable/fallible focalizers? 
 
3. The Narratee 
Who is being spoken to? 
Is it an extradiegetic narratee (outside the story) or an intradiegetic narratee (inside the story) 
Is it constant or shifting? 
Is it overt or covert? 
 
D. Characterization & Speech Representation 
 
Basic Character Types 
 
1. Types of Characters : 
a. Basic Types 
-The protagonist(s) / main character(s)  
(the eponymous hero/heroine, an anti-hero, a mouthpiece for the author’s views, etc.) 
-The antagonist(s)       
(the villain, a foil, an adversary or a competitor, etc.) 
-secondary characters  
(the love interest, the side-kick, the messenger, the confidant, etc.) 


## PDF page 5

8 
 
 


## PDF page 6

9 
 
 
b. Round Characters vs. Flat Characters  
(E. M. Forster-- Aspects of the Novel, 1927; read p. 94, 97) 
     Round Characters (well-developed and complex, surprising) 
     Flat Characters (simple and undeveloped or unchanging) 
 
-common types of flat characters: 
    -caricatures (the flattest; only show one apparent trait) 
    -stock characters [e.g., the Harlequin (buffoon, intriguing servant) and the Pantaloon (rich 
elderly merchant) in Italian drama, comedia dell’arte; a stock villain (like the mustache-twirling 
villain foreclosing on the heroine’s house in early silent films); the saucy maid in théâtre de 
boulevard; the hard-boiled detective (Sam Spade, Mike Hammer, etc.) in the early 20th century 
detective novel, etc.) 
    -archetypes (recurring, symbolic character types (e.g., Satan as archetype of Evil) 
    -stereotypes (conform to oversimplified mental images of what a certain person would be like) 
 
2. Character Development 
 
-Is a character dynamic or static? Is there steady development? 
-Are their traits consistent or inconsistent? 
-Are they well-rendered? Ill-rendered? Overdrawn? 
-Are they credible/believable/realistic/verisimilar?  Is there verisimilitude? 
 
3. Methods of Characterization 
 
-Is it more diegesis or mimesis? 
 
-direct characterization 
(description and exposition by the narrative voice, or perhaps by other characters) 
 
-indirect characterization 
(through what the character does, says, thinks) 
 
-symbolic characterization 
     -Symbolic names (onomastics): e.g., Sir Toby Belch, the drunkard in Shakespeare’s Twelfth 
Night, or Mr. Thwackum, the brutal tutor in Fielding’s Tom Jones, or Faith in Hawthorne’s 
“Young Goodman Brown”) 
     -Symbolic contrast or parallels with the landscape or setting (e.g.,the cold, brutal characters in 
a cold, brutal landscape in Wharton’s Ethan Frome) 
     -Symbolic contrast or parallels to other characters (e.g., George and Lenny in Steinbeck’s Of 
Mice and Men) 
 
Common form of indirect characterization: Speech Mannerisms 
 
-a character’s particular ‘idiolect’ (the specific manner of speech designed for a character) 
-this can include… 
   a ‘dialect’ (for a certain region or community) or an accent 
   a ‘sociolect’ (showing a certain social class) 
   (e.g., use of street slang, colloquialisms, substandard or very high-brow English, etc.) 
   jargon (for a certain profession) 
 
-special cases: 
    -the use of malapropisms to show a character’s lack of education  
      (e.g., Mrs. Malaprop in Sheridan’s The Rivals) 
    -eye-grammar (when words are purposely misspelled in order to recreate a character’s idiolect) 
    -SKAZ (when the narration by the character sounds more like a person talking—informal,  
     mistakes, colloquialisms—than someone writing. e.g., Huck in Twain’s Huck Finn) 


## PDF page 7

10 
 
 


## PDF page 8

11 
 
 
E. Speech Representation in the Narration: 
As with characterization, the spectrum of speech presentation spans from diegetic to mimetic 
forms: 
 
Telling  -----------------------------------------------------------------------------------------→ Showing 
 Narrative Summary / Indirect Speech / Free Indirect Speech/ Direct Speech / Free Direct Speech 
 
1. Summary of the words by the narrator: 
 
e.g., After the supper Mr. Maudsley made a speech. […] With what seemed to me consummate skill he  
 
contrived to bring in almost every player by name and find something noteworthy in his performance.  
      (L.P. Hartley, The Go-Between) 
 
2. Indirect Speech: (gets closer to “actual” words uttered by the character; uses verbs of 
saying/thinking plus a tag; spatial or time references change as well as verbs according to the 
formal sequence of tenses) 
 
e.g., Bill said that he was a quiet family man and would get him a flop and go to bed. (John Dos Passos, USA) 
 
3. Semi-Indirect Speech: (although it remains indirect speech, quotation marks are used) 
 
e.g., As soon as he entered the Room, he told Joseph, “he was come to pray by him, and to prepare him for 
another World: In the first place, therefore, he hope he had repented all of his Sins?” (Henry Fielding, Joseph 
Andrews) 
 
4. Free Indirect Speech / Free Indirect Thought: (allows us to follow character’s words or thoughts 
without the narrator’s interventions; often ambiguous blend of narrator’s voice and character’s 
words/thoughts) 
 
e.g., Soon, however, she began to reason with herself, and try to be feeling less.  Eight years, almost eight years 
had passed, since all had been given up.  How absurd to be resuming the agitation which such an interval had 
banished into distance and indistictness!  What might not eight years do?  Events of every description, changes, 
alienations, removals—all, all must be comprised in it; and the oblivion of the past—how natural, how certain too!  It 
included nearly a third part of her life.  Alas! With all her reasonings, she found, that to retentive feelings eight years 
may be little more than nothing. (Jane Austen, Persuasion) 
 
5. Direct Speech (straightforward reporting of lines, as if we were witnessing the scene) 
   e.g., “Who’s that?” I said, pretending I didn’t know. 
           “It’s the Dragon Lady,” Kitty said.  “She’s coming to get you.”   (Paul Auster, Moon Palace) 
 
6. Free Direct Speech (often used in first-person interior monologue; the character-narrator seems 
to be talking directly to you) 
 e.g., She looked like she might have a pretty damn good idea what a bastard she was the mother of.  But you can’t 
always tell—with somebody’s mother, I mean. Mothers are all slightly insane. (J.D. Salinger, The Catcher in the Rye) 
 
Three common techniques used in literature to present a character’s thoughts more vividly: 
1. Dramatic Monologue   (the speaker addresses someone whose responses are not given) 
   (e.g. Robert Browning, “Fra Lippo Lippi”, Holden in Salinger’s Catcher in the Rye) 
 
2. Interior Monologue / Narrated Monologue: (character is ‘thinking aloud’, often through Free 
Indirect Speech)    (e.g., long passages from Henry James’s The Portrait of a Lady: Ah! She had been immensely 
under the charm! It had not passed away; it was there still: she still knew perfectly what it was that made Osmond 
delightful when he chose to be.) 
    
3. Stream of Consciousness (cf. William James, Principles of Psychology, 1890)  
(an attempt to render a flow of thoughts—which aren’t always verbalized or coherent or 
developed or fully conscious.  It has more of a rambling and disjointed structure than Interior 
Monologue and has freer associations). 
(e.g., James Joyce, Ulysses: no that’s no way for him has he no manners nor no refinement nor no nothing in his 
nature slapping us behind like that on my bottom because I didn’t call him Hugh the ignoramus that doesn’t know 
poetry from cabbage thats what you get for not keeping them in their proper place… 
 
NB: This example is ‘direct’ stream of consciousness, in which even basic rules of sentence structure are 
disregarded.  With the ‘indirect’ form, we are conscious of a narrator carefully selecting information and 
controlling the narrative to focus on thoughts and impressions (e.g., Virginia Woolf, Mrs. Dalloway)  


## PDF page 9

12 
 
 


## PDF page 10

13 
 
 
F. Tone and Style 
 
1. Tone:  
The tone of a text may be, for example, humorous or witty, satirical (using humor to criticize and 
improve moral and social behavior); ironic / ironical (using words that express the opposite of 
what is meant);  parodic (parody) (an imitation of someone‘s work or style for satirical or 
humorous intention);  bathetic (bathos): the failure to reach a sublime or elevated tone, which 
results in the ridiculous), pathetic (pathos: extreme emotion evoking pity or sadness), etc. 
 
Related terms: 
 
humour vs. wit 
verbal irony (sarcasm, antiphrasis, accismus, apophasis, etc.) vs. 
situational irony (dramatic irony, tragic irony, comic irony, etc.) 
hyperbole (overstatement) vs. meiosis (understatement) 
euphemism (replacing possibly offensive words), litotes (negating the opposite) 
 
satire (imitation & criticism) 
parody (imitation & mockery) 
pastiche (imitation of the style, mixing elements of other works) 
 
low burlesque (treating a serious subject very lightly, for comic effect) 
high burlesque (treating a low or light subject far too seriously, for comic effect) 
travesty (a false, absurd or distorted representation of something) 
 
2. Style:  
The style is the particular manner of writing of a work or of a writer.  Style may be ornate and 
mannered: it may be highbrow (highly intellectual) or precious (refined, delicate, affected), 
bombastic (grandiloquent, inflated and verbose, which makes the speaker sound insincere and 
pretentious), archaic (using obsolete words or syntax, often to convey a sense of the past), 
hackneyed (using phrases used so often that they have become trite, dull, and stereotyped), 
lowbrow, informal or casual, etc.   
 
3. Varieties of language: Language can vary according to the context it is used in. Variations in 
register are often associated with different social situations or social classes (cf. sociolects). 
Register ranges from dignified, formal, to colloquial or informal, to slang. Dialects can be used or 
represented (See definitions of ‘idiolect‘ and ‘sociolect‘ above). 
 
4. Imagery and figurative language  
Imagery includes:    
1. literal imagery: the people, the setting, the action; all the objects and pictures described or 
alluded to in a text 
2. figurative imagery: images which may not be part of the fictional world, but are brought in by 
the narrator to metaphorically compare objects or qualities in that world, or to express ideas about 
that world.  
e.g., similes (comparisons), metaphors, analogies, metonymy, synecdoche, etc. 
 
When a literal image, by association, begins to take on meaning beyond itself, it becomes a 
symbol.   
 


## PDF page 11

14 
 
 
 
 
 
                                  RHETORICAL EFFECTS / FIGURES OF SPEECH:                      C. Dauphin 
 
1/ PATTERNS OF REPETITION 
Anaphora 
X ……………………….... ; X ……………………….... 
“It was a town of red brick… It was a town of unnatural red and black…”  
Epiphora 
……………………….... X ; ……………………….... X 
 “The Choakumchild School was all fact, and the school of design was all fact” 
Epizeuxis  
X, X, X 
“Fact, fact, fact, everywhere in the immaterial” 
Epanalepsis 
X ……………………….... X 
“Fact was everything, and the town was all about fact” 
Chiasmus 
 
XY – YX 
“The jail might have been the infirmary, the infirmary might have been the jail” 
2/ SOUND EFFECTS 
Alliteration 
 
The consonant is repeated. 
 “a state of melancholy madness” 
Assonance  
 
The same vowel sounds are used with different consonants. 
“Coketown was all coal and moans.” 
Internal rhyme  
The same word-endings are used. 
“Eating, drinking, working, sleeping was all they knew about life” 
3/ IMAGERY  
Simile 
A directly expressed comparison between two objects. 
“The piston worked monotonously up and down, like the head of an elephant” 
Metaphor 
An implied analogy between two objects or ideas. 
“Interminable serpents of smoke” 
Personification 
Endowing an object with human characteristics. 
“Night was falling; Coketown was gently dozing off...” 
Hypotyposis 
A vivid, picturesque, colourful description of scene and events. 
 “It had a black canal in it, and a river that ran purple with ill-smelling dye” 
4/ LISTING UP THINGS 
Enumeration  
Listing up words. 
“I saw three skulls, five hands, and the bones of three or four legs and feet” 
Gradation 
Listing up words with the idea of an increasing intensity. 
“Misery, degradation, death and everything that God or Satan could inflict” 
Polysyndeton 
Addition of conjunctions. 
 “Misery, and degradation, and death would not have parted us” 
Asyndeton 
Omission of conjunctions. 
“Misery, degradation, death would not have parted us” 
5/ FUNNY STUFF 
Hyperbole 
A deliberate exaggeration. 
“My blood ran chill and my heart sank at the very horror of the spectacle” 
Polyptoton 
A word is repeated in different forms, tenses, genders, numbers… 
“You broke it, and in breaking it, you have broken my heart” 
Hypallage  
Attributing to someone or something characteristics belonging to a related object 
or person. 
“A pious house”, “a solitary night”, “a painful field” 
 

