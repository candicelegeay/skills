# A2FLT11 12 CM - Lecture 6 The American Renaissance PDF.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: A2FLT11/12 CM with M. Tredy - First Half of the Semester / Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
- PDF page 2: The Rise of a National Literature in the United States I / -Part of the ‘American Renaissance’, with ties to the Romantic Movement in
- PDF page 3: Longfellow / Dickinson
- PDF page 4: The American Renaissance went beyond literature (especially from 1930s onwards) / Frontier mystique: We saw last week how an American author
- PDF page 5: The Coming of Age of the Novel: / ‘Histories’  (U.S.A.!)
- PDF page 6: Hawkeye / Tredy
- PDF page 7: Link to Lowbrow Trends in Mid- to Late 19th Century – / The Dime Novel (US, 1860s to late 1900s)
- PDF page 8: Washington Irving                    Nathaniel Hawthorne                       Edgar Allan Poe / An American Gothic…  (The First Waves of th
- PDF page 9: Washington Irving                    Nathaniel Hawthorne                       Edgar Allan Poe / A break with European trends and with Germa
- PDF page 10: Washington Irving (1783-1859): / -first American writer to gain international fame
- PDF page 11: “The Legend of Sleepy Hollow” (1820) / -Based on another legend from upstate New York (Tarrytown)
- PDF page 12: Nathaniel Hawthorne (1804-1864): / -romantic writer stressing imagination & emotion &
- PDF page 13: Nathaniel Hawthorne (1804-1864): / The Scarlet Letter (1850): Hester Prynne is sentenced to wear the scarlet letter ‘A’
- PDF page 14: Edgar Allan Poe (1809-1849): / -undervalued in the US throughout the 19th century
- PDF page 15: But today one of most popular ‘gothic’ authors & a real ‘pop icon’
- PDF page 16: Poe was a pioneer of many genres and sub-genres: / 1.
- PDF page 17: Poe was a pioneer of many genres and sub-genres of fiction: / 2. He wrote many tales rather than novels, and thus began
- PDF page 18: Poe was a pioneer of many genres and sub-genres: / 4. Poe also wrote 3 ‘tales of ratiocination’ in which French super sleuth
- PDF page 19: Poe was a pioneer of many genres and sub-genres: / 5. He was the father of the horror/fantastic sub-genre
- PDF page 20: http://1.bp.blogspot.com/-aBo0zvLDEGQ/Twib5hElRUI/AAAAAAAABk4/j7anvN7ONes/s640/harry-clarke-the-tell-tale-heart.jpg / “The Black Cat”       
- PDF page 21: “Ligeia”  (1838)                               “The Masque of the Red Death” (1842)
- PDF page 22: “The Pit and the Pendulum” (1842) / “The Fall of the House of Usher”(1839)
- PDF page 23: The second wave of the American Renaissance in Fiction: / (3 Key Novelists)
- PDF page 24: B. The Second Wave of the ‘American Renaissance’ / 1. Herman Melville (1819-1891): Moby Dick (1851)
- PDF page 25: Harriet Beecher Stowe (1811-1896): / Uncle Tom’s Cabin: Life among the Lowly (1852)
- PDF page 26: Harriet Beecher Stowe’s Uncle Tom’s Cabin: Life among the Lowly (1852) / Plot:
- PDF page 27: Harriet Beecher Stowe’s Uncle Tom’s Cabin: Life among the Lowly (1852) / Plot:
- PDF page 28: ‘Uncle Tom’s’ Legacy… / Negative aspects:
- PDF page 29: Louisa May Alcott (1832-1888): Little Women (1868-69) / -later American variation of the English coming of age novel /
- PDF page 30: Louisa May Alcott’s Little Women (1868-69) / Book I:
- PDF page 31: The First Waves of the American Renaissance: / A. Frontier Adventures

## PDF page 1

A2FLT11/12 CM with M. Tredy - First Half of the Semester
Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
Lecture 2:  Lesson on Narration, Focalization & Narrative Distance 
Lecture 3:  Timeline 1: The Rise of the Novel in the 18th Century 
Practice TEST #1 
Lecture 4: Speech Representations, Skaz & Characterization
Lecture 5: Timeline 2: The Novel Comes of Age 
Lecture 6:  Timeline 3: The American Renaissance 
Practice Test #2 
WEEK 7: Online MIDTERM (available Monday March 9th to Wednesday March 11th at midnight)
---
A2FLT11/12 CM - Today’s Class (Week 6)
The American Renaissance (The Rise of US Literature in the early to mid-19th century)


## PDF page 2

The Rise of a National Literature in the United States I
-Part of the ‘American Renaissance’, with ties to the Romantic Movement in 
England. Some would call it a ‘Naissance’…
-Sub-genres such as Histories and the Gothic novel were appropriated and 
modified by American writers. (eg, ‘The Frontier Adventure’)
Historical and social background: the US in the early 19th century
-A country in constant expansion; Louisiana Purchase in 1803, Louis & Clark 
expedition, the Gold Rush in 1849, constant immigration and migration, etc.
-The frontier wouldn’t be declared ‘closed’ and ‘settled’ until 1890
-By the mid-nineteenth century, cities would become the industrial centers, 
drawing many poor immigrants for labor and urbanizing the population; 
splitting the US into the rural South & Midwest and the urban North. 
-The spectacular development of the US and its vast natural landscapes 
inspired American thinkers and writers
-It was time to mark a cultural split from the mother country in language (cf. 
first American dictionary, Noah Webster’s A Compendious Dictionary of 
the English Language, 1806) as well as in poetry and fiction.


## PDF page 3

Longfellow    
Dickinson
The Transcendentalist School (1830s-1880s)
Reminder: The American Renaissance in Poetry (seen in A1FLT11 last semester)
Emerson        
Thoreau        
Whitman


## PDF page 4

The American Renaissance went beyond literature (especially from 1930s onwards)
Frontier mystique: We saw last week how an American author redefined the Historical Novel 
à la Scott…
The Second Great Awakening in American Religion (individual spiritual experience, 
democratic access to religion; link to Transcendentalism)
Webster’s dictionary established American spelling (color/colour, etc.) and definitions, just as 
schoolbooks now focused on American ‘history’ & culture. 
American Art & National Landscape Painting (e.g., The Hudson River School, depicting 
American landscapes as sublime and spiritually meaningful)
Expansion of Popular Democracy & ‘Jacksonian Democracy’ (celebrating common man & 
‘common sense’ solutions, suspicious of elites)
Rise of uniquely American music (informal: folk songs, frontier ballads, spirituals & minstrel 
songs (!)
In all walks of culture, these were the keys to cultural independence:
•
We will write our own stories.
•
We will define our own language.
•
We will ground identity in our own landscape, history and folklore.
•
We will trust individual conscience over European tradition.
e.g., Thomas Cole


## PDF page 5

The Coming of Age of the Novel: 
‘Histories’  (U.S.A.!)
The Frontier Adventure…
 
James Fenimore Cooper (1789-1851): 
-First professional writer in the US, aka “the American Scott” for 
his focus on colonial and frontier history
-Adventure novels on the exploration of the frontier
The 5 Leatherstocking Tales (1823-1841), starring the ranger/trapper Natty Bumpo:
The Pioneers (1823) – flashforward to 1793, old Bumpo, on changing life in NY 
wilderness, displacement of friendly but dying Indians, etc.
The Last of the Mohicans (1826) - set during the 1757 French and Indian War when 
both British and French were using Indian mercenaries
The Prairie (1827) – back to 1804 last year of his life, still helping frontierspeople in 
distress
The Pathfinder (1840) – (set in 1750s) Bumpo at middle age, nearly finds love but lets 
her go off with younger man…
The Deerslayer (1841) - set in 1740s in upstate New York, on Bumppo trying to reason 
warring settlers and Indians in 1740s
+/- views of Native Americans, prototype of Maverick frontiersman…


## PDF page 6

Hawkeye
Tredy
6


## PDF page 7

Link to Lowbrow Trends in Mid- to Late 19th Century – 
The Dime Novel (US, 1860s to late 1900s)
-forerunner to the paperback, focused on sensational frontier adventures
-started more on Far West bandits & frontier violence, then crime stories & 
would lead to 20th-century ‘pulp fiction’ of 1930s & 1940s.
Later…


## PDF page 8

Washington Irving                    Nathaniel Hawthorne                       Edgar Allan Poe
An American Gothic…  (The First Waves of the ‘American Renaissance’)
And the Gothic novel 
also had its American 
rendition…
(Grant Wood, 1930)


## PDF page 9

Washington Irving                    Nathaniel Hawthorne                       Edgar Allan Poe
A break with European trends and with German Gothic
-all three focus more on short stories than on novels
-Irving focused on supernatural folklore from American territories
-Hawthorne stressed the dark past of early colonies & witch hunts
-Unlike Irving & Hawthorne, Poe didn’t use specifically American settings, 
but he redefined horror as internal torment and madness: ‘’Terror is not of 
Germany, it is of the soul!’’
An American Gothic…  (The First Waves of the ‘American Renaissance’)


## PDF page 10

Washington Irving (1783-1859):
-first American writer to gain international fame
-works show passage from 18th century rationalism 
  to 19th century Romanticism
-attracted to folk stories and the supernatural
-founding member of the “Knickerbocker School” 
of wits who wrote satirical accounts of history and 
humorous essays
-wrote mainly short stories
-most famous tales show deep imagination and 
American reworking of Gothic tradition, or German 
folklore adapted to the New World:
-“Rip Van Winkle” (1819) 
(legend from the Catskills region of New York; Rip 
fell asleep at a picnic in the 1760s and woke up 20 
years later…)
(influenced by story of Epimenides of Knossos (Greece), 
The 7 Sleepers of Ephesius (Christian), Honi ha-M'agel 
(Judaism), etc.                     Irving’s other success was…


## PDF page 11

“The Legend of Sleepy Hollow” (1820)
-Based on another legend from upstate New York (Tarrytown)
-Superstitious schoolmaster Ichabod Crane is pranked by town bully & rival to his
love of Katrina Van Tassel. But the story of the headless horseman, the ghost of a 
dead Hessian soldier, is real…


## PDF page 12

Nathaniel Hawthorne (1804-1864):
-romantic writer stressing imagination & emotion &
sharp criticism of America’s Puritan heritage 
(cf. his forefather John Hathorne & Salem Witch Trials)
-romanticism stressing the supernatural & Gothic atmosphere
-unlike Poe, he used specifically American landscapes 
-helped forge an ‘American Gothic’
-tales often rely heavily on allegory, symbol
-many of his most famous works set in the time of the witch-trials:
“Young Goodman Brown” (from his short story collection Twice-Told Tales, 1837)
– a young Puritan leaves his wife Faith to meet with the devil in the woods…


## PDF page 13

Nathaniel Hawthorne (1804-1864):
The Scarlet Letter (1850): Hester Prynne is sentenced to wear the scarlet letter ‘A’ 
on her chest as she has had a child out of wedlock & will not reveal the father’s 
name… 


## PDF page 14

Edgar Allan Poe (1809-1849):
-undervalued in the US throughout the 19th century 
but praised abroad 
-during lifetime, more infamous for his bad temper, his 
alcoholism, his opium use and his scandalous marriage 
to his 13-year old cousin Virginia Clemm (who died at 24)
-made a scant living as a journalist, founded many failed 
newspapers and literary journals
-Oct. 1849 – found unconscious in the gutter outside of a pub in 
Baltimore; later died at hospital (mystery…  Alcohol? Poisoning? 
Rabies? Foul play?)
-His obituary in The New York Tribune: 
Edgar Allan Poe is dead. He died in Baltimore the day before yesterday. 
This announcement will startle many, but few will be grieved by it. The 
poet was well known, personally or by reputation, in all this country; he 
had readers in England, and in several of the States of Continental 
Europe, but he had no friends ...                   (Rufus Griswold)


## PDF page 15

But today one of most popular ‘gothic’ authors & a real ‘pop icon’


## PDF page 16

Poe was a pioneer of many genres and sub-genres:
1.
His poetry focused on sound (assonance, consonance, rhyme, 
repetition), often written as elocution exercises
-main theme: the death of a beautiful young maiden, “the most poetical 
subject in the world” (‘Philosophy of Composition’)
e.g., 
“The Raven”
(1845)
& 
“Annabel Lee”
(1849)
Tredy
16


## PDF page 17

Poe was a pioneer of many genres and sub-genres of fiction:
2. He wrote many tales rather than novels, and thus began 
the American tradition of short story writing.
-In his essay ‘’A Philosophy of Composition’’, he explained that to “hold’ 
the readers, they must be able to read the work in one sitting.
-Poe wrote his shocking endings first, and then sought the best way to 
build tension ‘by degrees’ to that ending. 
-Also note that Poe was a journalist by profession, and thus had a knack 
for the short form. 
3. Pioneer in science fiction (though really just ‘fake news’) 
For example, he wrote a fake article about a man
traveling around the world in a hot-air balloon in
3 days (“The Balloon Hoax” 1844) 
– long before a certain French author would 
develop this idea…


## PDF page 18

Poe was a pioneer of many genres and sub-genres:
4. Poe also wrote 3 ‘tales of ratiocination’ in which French super sleuth 
Auguste Dupin solved crimes that baffled the prefect of police – long 
before Sir Arthur Conan Doyle would perfect this set-up…
“Murders in the Rue Morgue” (1841), ‘’The Mystery of Marie Roget’’ (1842) 
and ‘‘The Purloined Letter” (1844).


## PDF page 19

Poe was a pioneer of many genres and sub-genres:
5. He was the father of the horror/fantastic sub-genre
-he used Gothic settings (castles, stairways, etc.) and devices (corpses, 
nightmares, gruesome & bloody killings), but focused on tropes of torment 
(madness, mourning, being walled up, being buried alive, etc.)
-The stories featured Poe’s unreliable “fancy-me-mad” narrator. The 
reader doesn’t know if the supernatural events are really occurring (cf. ‘the 
Marvellous’) or if they can be explained by the narrator’s hallucinations, 
madness or opium use (cf. ‘the Uncanny’). This hesitation between two 
readings is the very definition of ‘the Fantastic’ (according to Tzvetan 
Todorov).


## PDF page 20

http://1.bp.blogspot.com/-aBo0zvLDEGQ/Twib5hElRUI/AAAAAAAABk4/j7anvN7ONes/s640/harry-clarke-the-tell-tale-heart.jpg
“The Black Cat”                     (1843)                     “The Tell-Tale Heart”
Illustrations by Harry Clarke (1933)


## PDF page 21

“Ligeia”  (1838)                               “The Masque of the Red Death” (1842)                       


## PDF page 22

“The Pit and the Pendulum” (1842)
“The Fall of the House of Usher”(1839)


## PDF page 23

The second wave of the American Renaissance in Fiction:
(3 Key Novelists)
1. Herman Melville (1819-1891): Moby Dick (1851) 
-Early success of his sea adventures, turned down fame for                  
metaphysical meditation. 
-Moby Dick (1851): relied on author’s personal experience                                     
at sea as a cabin boy. A very complex novel, relying on myth                                        
and  symbolism. The confrontation of two points of view:                                         
Ahab, the captain of the whaling ship, who thinks the universe is dominated by 
evil, embodied in white whale (a revenge plot), and Ishmael, a sailor, who 
rejects this view and sees the whale, like the world, 
as mysterious and impenetrable.
-Greatly influenced by 
Transcendentalists, 
but more preoccupied 
with the dark side 
of the world that lies 
beneath its surface.


## PDF page 24

B. The Second Wave of the ‘American Renaissance’
1. Herman Melville (1819-1891): Moby Dick (1851) 
-later showed influence of realism (and less allegory) 
with “Bartleby, the Scrivener” (1853) in Putnam’s Monthly- 
showed humor and his increasing despair and contempt 
for human materialism and hypocrisy.
- Absurdist story of a scrivener who confounds his boss
by no longer working or leaving the premises: ‘’I would prefer not to.’’
-A statement about the dehumanization of the ‘modern’ workplace
There would also be two key women authors in a second wave
The first wrote the best-selling book of the 19th century after the Bible, and is
often seen as causing a controversy that will leads to Civil War?
Any idea?


## PDF page 25

Harriet Beecher Stowe (1811-1896):
Uncle Tom’s Cabin: Life among the Lowly (1852)
-Stowe was a white ‘abolitionist’ from a very religious family
-wrote 30 books (mostly non-fiction: essays, letters, studies)
-Stories revolve around Tom, an old black slave 
-focus on Christian love overcoming the horror of slavery’s dehumanization
-huge controversy: praised in the North & despised in the South, made slavery
issue a national conversation, which would lead to 
Civil War
-1861: She met Lincoln at the White House: 
‘’So this is the little lady that started the great war.’’


## PDF page 26

Harriet Beecher Stowe’s Uncle Tom’s Cabin: Life among the Lowly (1852)
Plot:
I- Indebted Shelby breaks up his slaves’ families, selling Uncle Tom away from wife
& children and maid Eliza’s son Harry (Shelby’s young son & wife against it).
Eliza & son escape; Tom sold but befriends new owner’s daughter Eva (Christian)
II- Eliza & son caught heading to Canada but shoot slave hunter & take him to 
Quakers for care (!). Dying Eva’s vision of heaven changes minds of several racists, 
including Tom’s owner.
III- Tom’s owner dies before freeing him & his wife sells
him to viscious Simon Legree, who hates Tom for refusing
to whip other slaves and using Bible to help them. Tom 
convinces some of the slaves to escape, refuses to tell 
where they went, and when dying forgives his killers, who
convert to Christianity. George Shelby (now an adult) 
too late to save him but frees all the slaves on his
father’s farm, in honor of Tom’s sacrifice.
Cf. Solomon Northup’s 1853 mémoire Twelve Years a Slave
was non-fictional confirmation of Stowe’s account.


## PDF page 27

Harriet Beecher Stowe’s Uncle Tom’s Cabin: Life among the Lowly (1852)
Plot:
I- Indebted Shelby breaks up his slaves’ families, selling Uncle Tom away from wife
& children and maid Eliza’s son Harry (Shelby’s young son & wife against it).
Eliza & son escape; Tom sold but befriends new owner’s daughter Eva (Christian)
II- Eliza & son caught heading to Canada but shoot slave hunter & take him to 
Quakers for care (!). Dying Eva’s vision of heaven changes minds of several racists, 
including Tom’s owner.
III- Tom’s owner dies before freeing him & his wife sells
him to viscious Simon Legree, who hates Tom for refusing
to whip other slaves and using Bible to help them. Tom 
convinces some of the slaves to escape, refuses to tell 
where they went, and when dying forgives his killers, who
convert to Christianity. George Shelby (now an adult) 
too late to save him but frees all the slaves on his
father’s farm, in honor of Tom’s sacrifice.
Cf. Solomon Northup’s 1853 mémoire Twelve Years a Slave
was non-fictional confirmation of Stowe’s account.


## PDF page 28

‘Uncle Tom’s’ Legacy…
Negative aspects:
-spread many stereotypical depictions of black slaves: the Uncle Tom, the Mammy, 
the ‘pickaninny’ children like girl Topsy, etc.  All became racial stereotypes.


## PDF page 29

Louisa May Alcott (1832-1888): Little Women (1868-69)
-later American variation of the English coming of age novel / 
comedy of manners
-Alcott’s family were transcendalists and friends with Emerson, 
Thoreau and Longfellow.
-She wrote many children’s stories & also spy novels under
pen name A.M. Bernard
-She was also an abolitionist and an early feminist who served
as a nurse during the Civil War and wrote about expériences.
-Little Women is bildungroman on 4 daughters (…of Dr. March), each
representing different facets of the ‘American girl’ of the time
-title: ‘Little Women’ a term from Dickens to refer to a period between girlhood
and young womanhood.
-Could it be ironic? Mockery of how women are treated/viewed…
-Novel seemed to stress the gender constraints they’re facing and their
awareness of them, and their ability to choose their fate & decline proposals
-each daughter’s innocence is challenged by a difficult experience


## PDF page 30

Louisa May Alcott’s Little Women (1868-69)
Book I: 
First Christmas for four teenage sisters and their mother without father, who is
working far away as a pastor (and will later go to war)
Meg- beautiful & traditional eldest, tutoring four children for money
Jo – the impulsive tomboy who writes, who cares for her rich widowed aunt
Beth – shy musician who stays home and does housework, but falls very ill
Amy – the artistic one, still in school
Main action involves young man named Laurie, Meg’s
preference for John over Laurie, Jo’s success as a writer
& her need to care for Beth, with Amy replacing her
with her aunt.
Book II: 3 years later (published in Britain as Little Wives)
-Meg and John married and have children, Jo works as
a governess and rejects Laurie’s proposal (‘friendzone’);
Laurie goes to Europe, meets and eventually marries 
Amy (‘friendzone’ first but brought together when Beth 
dies). Jo also finds an unexpected mate…


## PDF page 31

The First Waves of the American Renaissance:
A. Frontier Adventures
James Fenimore Cooper (1789-1851): His 5 Leatherstocking Tales (1823-1841)
The Pioneers (1823), The Last of the Mohicans (1826), The Prairie (1827), The Pathfinder (1840), The Deerslayer (1841)
B. An American Gothic
Washington Irving (1783-1859): “Rip Van Winkle” (1819) & “The Legend of Sleepy Hollow” (1820)
Nathaniel Hawthorne (1804-1864): Twice-Told Tales (1837) & The Scarlet Letter (1850)
Edgar Allan Poe (1809-1849) – tales of the 1830s & 1840s
C. (Poetry) The Transcendentalist Club
The Second Wave of the American Renaissance:
1. Herman Melville (1819-1891): Moby Dick (1851)
2. Harriet Beecher Stowe (1811-1896): Uncle Tom’s Cabin: Life among the Lowly (1852)
cf. Solomon Northup’s 1853 mémoire Twelve Years a Slave
3. Louisa May Alcott (1832-1888): Little Women (1868-69)

