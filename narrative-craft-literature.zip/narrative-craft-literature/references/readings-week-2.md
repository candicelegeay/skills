# Week 2.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: Week 2 / -
- PDF page 2: The text is made of 13 sections, of different lengths, which get shorter, perhaps to suggest her / growing nervousness. The narrator refers 
- PDF page 3: window” because it shows how stories can transform reality: here the window either stands as / a way of getting back into the house for the 
- PDF page 4: o Demonstrate how it works through the writing of the text / ð Make sure your analysis is about how the text is written, not just what it is

## PDF page 1

Week 2 
- 
Charlotte Perkins Gilman, “The Yellow Wallpaper” (1892): excerpt from “On a pattern like 
this” to “I am determined that nobody shall find it out by myself!” 
- 
Saki, “The Open Window” 
 
ð This is the first session organized around short stories which you are supposed to have 
read and worked on before reading this lecture. If you didn’t have time, I strongly advise 
you read the stories before the lecture. Also, you may need to stop reading the lecture 
to go back to the story at some points, please do so: a good understanding of a literary 
text, which is the fundamental step to a good literary analysis must be built around a 
solid reading of the text. 
 
Charlotte Perkins Gilman, “The Yellow Wallpaper” (1892) 
The first thing to do with studying a text is, once you have read it, to summarize the story. 
We are here going to summarize the elements of the stories based on these essential questions 
which you must always address about a text: what happens? Who tells the story? What is the 
effect the story has on the readers? 
 
Find as much information as possible about the narrator  
Our perceptions of the text are entirely subject to what the first-person narrator tells us, since 
we have no other source of information. We learn things about the narrator’s personality 
through what she writes, but also through the way she writes.  
Here are a few examples of the very specific way in which she writes taken from the first section 
of the text (up until the interruption I the middle of page 81), but make sure to add your own 
examples: 
- 
She uses certain adjectives which show us the impressions she has about the house: 
“ancestral”, “queer” 
- 
Statements “there is something strange about the house, I can feel it”: “I can feel it” 
shows that she is both immersed in her thoughts and also perhaps emphasizing this 
reality she feels.  
- 
Aesthetic comments about the house and its wallpaper: “One of those sprawling, 
flamboyant patterns committing every artistic sin”: this is a clear subjective judgement 
as show the adjectives “sprawling” and “flamboyant” through which she rejects the 
excess of the pattern and the phrase (a phrase = une expression) “every artistic sin” 
strongly rejects it by adding a moral dimension to the ugliness she sees in it. 
- 
Comments about her situation as she writes the story: “There comes John, and I must 
put this away, -- he hates to have me write a word” => this shows that she is writing in 
secret, creating a bond of secrecy with the reader and it emphasizes the sense of reality 
that we have when reading the text, as if we were reading a real journal (a journal = a 
diary). 
ð From these notes, we can already see that we are in front of a narrator who has very 
deep feelings about the house, who is deeply concerned with the way the house makes 
us feel and, finally, who is hiding this from her husband in her diary. 
 
What is the plot or story structure? (work on this with the brochure in hand, looking at 
the section dedicated to plot and narrative arc, pp. 4-6) 
The story present itself to us as a diary, it is written in the 1st person, it uses the present tense. 
On page 45, she writes “there comes John’s sister”, which gives a sense of immediacy, as if we 
were watching over her as she is writing. This gives a confessional tone to the text: she puts on 
paper her every thought.   


## PDF page 2

The text is made of 13 sections, of different lengths, which get shorter, perhaps to suggest her 
growing nervousness. The narrator refers to “a yellow smell” an image which brings together 
the senses of vision and of smell and which brings forward her extreme sensations. 
Her states and impressions about the figure in the wallpaper grows throughout the story, with 
perhaps a first climax when she describes clearly what she sees. 
Another element in the story is when the text transforms into a sort of detective story, from 
“Life is very much more exciting” to“until I have found out”. 
 
Excerpt from “On a pattern like this” to “I am determined that nobody shall find it out 
by myself!” 
Situating the passage within the short story: climax, clear presentation of what she sees in 
the yellow wallpaper 
Summarizing the passage: what happens, construction, narration. The passage is made of 2 
parts: a “scientific” analysis of the pattern, and a reflection on John and Jenny’ silent opposition 
over the wallpaper => the narrator is alone in her thought and cannot communicate, except to 
her diary (or to us). 
1. The narrator sees herself as a victim of the pattern 
2. The narrator’s “scientific” perspective (trying to convince us of her point of view) 
3. Uncertainty: it is hard for the reader to be certain of what is happening because we are 
relying on a first-person narrator who seems to be going through a nervous crisis. 
 
ð Work on trying to organize your own ideas on the text and keep your notes. I will 
organize a video chat in two weeks where we will go over your notes. You can also post 
your comments or questions on the class forum. 
 
 
Saki. “The Open Window” (1914) 
 
This short story is a perfect example of how the way of telling a story impacts the narratee, the 
person to whom the story is told. Here, Framton is told a story by the niece who plays with his 
nerves and invents a story of her uncle’s death to play with him. Up to line 78 when the niece 
starts telling an exotic story about Framton which we know she is probably making up since 
she only spoke to Framton about her aunt and the tragic hunting party that is supposed to have 
taken place “three years ago to a day (line 29), we do not realize that she is making things up. 
We only start realizing this line 78 and the narrator confirms this in the final revelation 
“Romance at short notice was her specialty” (82).  
This text is therefore particularly interesting for people who study fiction because it shows us a 
character who is told a tragic story, who believes it and who does not question the story he was 
told by the niece and who therefore immediately comes to the conclusion that the uncle coming 
back is a ghost. It must be noted that we are also fooled at the same time as Framton, we are 
lead to believe in the niece’s story within the story (an embedded story).  
 
In our extract, from line 55 to the end of the text, we are presented with the final twist to the 
story, the revelation that everything that the niece said was fiction, a “romance” invented on the 
spot (“at short notice”). 
The aunt is unaware of what was said before her arrival, she does not realize what Framton’s 
state of mind is after listening to the niece’s imaginary story. In other words, we could say that 
the aunt and Framton are in different realities: the aunt is waiting for her husband to come back 
from his hunting party while Framton believes the uncle is dead and believes he sees a ghost 
when he appears through the open window. It is interesting that the story’s title is “the open 


## PDF page 3

window” because it shows how stories can transform reality: here the window either stands as 
a way of getting back into the house for the uncle, or, for Framton, the windo stands for the 
intrusion of ghosts. 
Situated at the end of the story, the passage is the final revelation. We realize what was actually 
going on and we come to realize that the narrator participated in the niece’s story, he 
participated in misguiding us, before his final humorous last line where we learned we were as 
foolish as Framton in believing the story – but, how could we not believe in this story since the 
narrator added elements to sustain the niece’s story. 
Framton moves from a “sympathetic comprehension” (64) to “his headling retreat” (72) => the 
question of point of view on a story and discrepancies between characters who do not see or 
understand the same thing is at the heart of this story story. It is therefore a short story whose 
effects are grounded in point of view and characterization. It is also a story about how stories 
work. 
 
My angle of analysis for this passage: How does the text manage to trick Framton and the 
reader? Two stories are taking place at the same time: the realistic story of the aunt waiting for 
her husband and the story where Framton believes that the aunt is crazy. This passage presents 
the final revelation where we realize that we were fooled, like Framton, by the niece.  
1. The events seen through the aunt’s perspective 
a. Framton as a strange young man: “in a voice which only replaced a yawn at the last 
moment” (60): the narrator adopts the point of view of the aunt here which 
underlines their very different perspectives on the situation. 
b. The arrival of the men accompanied by the aunt’s cry “here thy are at last!” is ironic 
for who knows the end of the story, and it is interesting that it can be interpreted in 
two very different ways, thus illustrating how the story is concerned with point of 
view: from the aunt’s point of view, she is happy to see her husband and brothers 
come back, from Framton’s point of view, she is crying and seeing ghosts. 
2. Events seen through Framton’s perspective 
a. The narrator presents elements which underline the niece’s story as in line 65 where 
is described looking at the men’s arrival “with dazed horror in her eyes”. The niece 
is performing a role for Framton’s, benefit, but the narrator does not let the readers 
know that this is a performance, so that we are made to share his sense of horror. 
b. The text emphasizes his fear and horror through the description of his departure. 
3. The narrator participates in the niece’s story: the narrative passages underline what the 
niece had said in the dialogue. Indeed, the narrator refers to the uncle and the brothers 
as “three figures” (67), walking “noiselessly” (69) as ghosts would, the uncle is referred 
to as “the bearer of the coat” which could apply to a human character or a ghost. 
 
Conclusion 
The trick is done gradually, we only perceive the niece’s wild imagination with the tale she tells 
at the very end and this impression is emphasized by the last sentence which shows that the 
narrator and the niece share similar traits. The revelation concerns Framton, but also the readers 
who realize they have been fooled by the niece and the narrator. 
 
 
How to tackle a literary analysis? 
ð You should always look to have an angle on a text: a position about the text which the 
commentary will seek to demonstrate. In other words, the purpose of a textual commentary 
is to  
o Present your perspective (or angle, or line of reading) on the text 


## PDF page 4

o Demonstrate how it works through the writing of the text 
ð Make sure your analysis is about how the text is written, not just what it is about. This 
is absolutely essential: telling what the story is about is only the very beginning of a 
literary commentary. The point of a literary commentary is based on the idea that a text is 
a construction, it uses words and punctuations like building blocks, to create a certain effect 
on the reader. The point of a commentary is to show what these building blocks are and 
how they operate to create a certain impression on the reader. 
How to present an idea: it is very important to make your ideas as clear as possible (make sure 
that you explain, on paper, what is on your mind). Every idea should be presented in three steps: 
o Presenting the idea  
o Giving an example from the text to show that this idea is to be found in the text  
o Analyzing the idea   
 
 
Your work for next week 
Read the 2 stories on the syllabus “The Garden Party” and “I Used to Live Here Once” 
ð Pay particular attention to the way the text in “The Garden Party” focuses on the 
young girl’s impressions. 

