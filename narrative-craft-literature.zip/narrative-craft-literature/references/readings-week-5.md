# A2FLT12_ Week 5.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: Week 5 (February 16th-20th): Methodology session on literary commentaries / -
- PDF page 2: the grocery store underlines the gap between the situation and the way the narrator / perceives it. The adjective “unsuspected” concerns the
- PDF page 3: people around him whose lives he seems to despise (pigs, sheep, a married) and find himself / utterly alone and disappointed in not being he
- PDF page 4: Kazuo Ishiguro, “A Family Supper” (1982): excerpt from “There was a large pot” to the end of / the story
- PDF page 5: the moments of this section dedicated to direct discourse, we can see that the dinner is very / silent and marked by uncomfortable polite ex

## PDF page 1

Week 5 (February 16th-20th): Methodology session on literary commentaries 
- 
John Updike, “The A&P” (1961): excerpt from “The girls, and who’d blame them” to the end 
of the story 
- 
Kazuo Ishiguro, “A Family Supper” (1982): excerpt from “There was a large pot” to the end 
of the story 
 
John Updike, “The A&P” (1961): excerpt from “The girls, and who’d blame them” to the end of 
the story 
 
There is an interesting contrast between the apparent simplicity of the situation and the 
impact it has on the narrator’s life our passage which is situated at the very end of the short 
story presents the narrator quitting his job for no reason other than his fascination with the girls. 
The passage is made of direct dialogue between the narrator and his boss. In-between the 
dialogue there are comments by the narrator in the second half of the text is made of a narrative 
reflection on the narrator’s situation: this text is concerned with Sammy’s perceptions and 
interpretations of the situation as well as his participation in the scene and the chain of events 
this leads to. 
The narrator is one of the characters in the story, reporting the story in the first person 
as well as participating in it. We learn from his situation as a the clerk at the A&P store as well 
as from the way his boss talks to him referring to his parents that he is a young man probably 
not much older than the girls he watches and feels a closeness to, as  you watches throughout 
the story is therefore involved and has a subjective perspective what is the story about one could 
summarize the story as the arrival of teenage girls in this A&P store (A&P stores were a chain 
of grocery stores in the US). The story therefore is about the irruption on the scene of these girls 
who are not dressed properly for grocery shopping. But more than this event, the story is about 
the narrator’s perception of this intrusion, his surprise and admiration for these girls’ boldness 
The narrator comments on what happens as well as what he feels, until his downfall 
which is announced at the bottom of page 122 when he explains “here comes the sad part of the 
story at least my family says it's sad but I don't think it's sad myself”: in other words the story 
begins with an introduction, the arrival of these girls and then a turning point leading to the 
narrator’s downfall, the “sad part” of the story. What is really striking in this story is how the 
narrator involves himself in this scene that he was only a witness of at first and he involves 
himself to the point of quitting his job. This leads to a great contrast between the very mundane 
everyday dimension of the story and the its conclusion and effect on the narrator’s life. 
 
When writing a commentary on a text you must read the text carefully and underline all the 
elements that strike you. Striking elements in a literary text can have to do with certain choices 
of words, certain images, a certain tone – any element that is unusual, strange or surprising, or, 
simply, that strikes you. If I go through our passage here are the elements that I find striking 
and that I have underlined for a commentary on my brochure: 
• 
line one “the girls and who’s to blame them, are in a hurry to get out”: the parenthetical 
comment “and who would blame them” shows the narrator’s empathy with the girls, he 
considers their situation from their own perspective.  
• 
another interesting element about this for sentence is the connector “so” (“the girls, and 
who’s to blame them, are in a hurry to get out so I say I quit”). “So”, here, suggests a 
logical connection as if his quitting was the normal conclusion of the fact that the girls 
wanted to get out fast, or of the entire scene. However there is no logical connection and 
the rest of the sentence shows that he quit because he wanted them to hear him quitting.  
• 
“their unsuspected hero”: the phrase is very striking (note that a phrase is different from 
a sentence: it is not the same thing as the French word “phrase”, a phrase is an 
expression). The intrusion of the word hero on this very simple and every day scene at 


## PDF page 2

the grocery store underlines the gap between the situation and the way the narrator 
perceives it. The adjective “unsuspected” concerns the fact that indeed only the narrator 
sees himself as a hero,  the other characters don't see what he sees. Also, the use of the 
term hero situates the events narrated on a higher level: the clerk at his cash register is 
here a hero involved in a story with deep proportions the “sad story” he referred to on 
page 122 
• 
The simile “like scared pigs in a chute”: the simile shows the narrator’s critical 
perspective on the other customers and resonates with the word “sheep” further in our 
passage.  
• 
Another element is the use of the present tense which gives a sense of reality to the 
scene as if it was unfolding in front of our eyes. The text is indeed narrated in the present 
tense throughout until to the very last paragraph and the sentence “there wasn't anybody 
but some young married”. It's at this moment that the story becomes a story, until then 
the present tense suggests that these are events perceived by the narrator as they happen 
and so the text seems to be written as the events unfold in the present tense  
 
One of the striking features of the text is that it shows how the narrator is caught in his 
heroic action of quitting and cannot go back this is what we have in the paragraph before last 
when the narrator writes  but it seems to me that once you begin the gesture it's fatal not to go 
through with it this suggests that the narrator is cut in his spur-of-the-moment “I quit” and that 
he doesn't know how to go back. He finds himself forced to quit to continue what he started. 
The narrator uses a very important word here: “fatal” (“once you begin a gesture, it's fatal not 
to go through with it it”). If we remember the narrator presented himself as a hero earlier on 
and here he is talking about his actions using the vocabulary of tragedy (“it's fatal”). These two 
elements brought together transform the apparently simple and everyday situation into one that 
evokes classical tragedy. His boss tells him that this minor event is something he will feel for 
the rest of his life, so that here again, events are put in relation to his life not to this one day in 
his life but to his entire life. The narrator also refers to “this scene” as to underline the fact that 
this moment is a decisive moment, a scene evoking a theatrical scene, it is a scene that will 
mark a before and an after in the narrator’s life.  
This is underlined also by the last sentence when the narrator concludes the story with 
the sentence “I felt how hard the world was going to be to me thereafter”: the narrator knows 
that he will now after this scene feel the weight of the world. His life seems to have changed 
dramatically and the contrast between his life before the girls entered the shop and his life after 
they've left and after he's quit is a contrast between carefree youth and a moment of realization 
and recognition (anagnorisis). He is now entering a new state of his life, conscious of having 
done something that cannot be taken back.  
There is dramatic irony In this conclusion. Indeed, the end of the short story is a moment 
of recognition in realization for the hero but what he realizes is how insignificant he was to 
these girls for whom he gave his job. Another important element is the contrast between the 
simplicity of the scene and its tragic dimension. Does the “unsuspected hero” have the ability 
to change the course of things? The sentence “I started to say something that came out” shows 
he does not control the words that come out of his mouth; this goes along the idea that the 
narrator did not fully decide his fate but that he was the victim of a chain of events. 
This passage presents the end of the chain of events which led the narrator to quit his 
job, this is a closed ending as the narrator comes to an understanding of his situation and the 
irony of his actions in opposition to how the girls did not even notice him. This was prefigured 
in the sentence page 122 when the narrator announced what was going to happen in the 
conclusion. Sammy both triumphs by acting like a hero and separating himself from all the 


## PDF page 3

people around him whose lives he seems to despise (pigs, sheep, a married) and find himself 
utterly alone and disappointed in not being heard by the girls. 
 
The autodiegetic narrator is presented in radical opposition to all the other characters in the 
story: he quits because he wanted to be heard by the girls but they have disappeared. The 
separation between the narrator and the people around him aligns his loneliness and his inability 
to fit in the world he is in. He looks at the adults around him and does not understand them: the 
image of the young married screaming with her children illustrates the opposition between 
youth and adult life. Indeed, the narrator looks at at the customers and his boss as people whose 
lives are empty  
Yet his casual, simple and informal tone creates a sense of proximity and intimacy with the 
readers as show his direct addresses to the readers: “if you've ever wondered”.  
 
=> To organize an outline on this passage I would ground my analysis on the fact that this 
passage is a moment of recognition for Sammy, the narrator. I would ask how his recognition 
comes about and what it is that Sammy comes to recognise. 
The first part could show that Sammy is realizing that his actions were not recognised or seen 
by the girls this creates a sense of dramatic irony: the narrator’s grandiose actions are not even 
noticed by the girls who disappear into what he calls “the electric eye”. 
Having established the scene’s dramatic irony, it would be important in a second part to show 
how Sammy perceives himself: he sees himself as a hero caught in a tragic chain of events, 
almost as if the scene was that of a real tragedy. 
We could then wonder what it is that the narrator comes to realize in his conclusion. It seems 
that the narrator realizes how alone he is: he separates himself from the other clerk, his boss 
and the customers. He wanted to be on the side of the girls but they don't notice him and she 
understands that he is alone facing the consequences of his actions. 
 
 
(see next page for Ishiguro) 
 
 


## PDF page 4

Kazuo Ishiguro, “A Family Supper” (1982): excerpt from “There was a large pot” to the end of 
the story 
 
This short story creates an intense sense of ambiguity as to what actually happens at the end. 
The first-person narrative gives us only access to the narrator’s thoughts and we cannot know 
what the father is actually thinking, so we cannot be sure of his intentions. We are immediately 
plunged in his family and emotional life when the scientific information about fugu turns into 
the revelation that the narrator’s mother died from eating some. 
 
How is the scene and the atmosphere set in the short story? Information is given as to the 
traditional Japanese context: sitting on the tatami of the tea-room, the mother having died out 
of not wanting to offend the friend who invited her. The formal dimension of the relationship 
between the father and his children is also a cultural indication of the generational divide 
between the traditions of Japan and its new generation. The father expresses this divide when 
he tells his son that he understands his desire to go live in America: “'I've come to believe now 
that there were no evil intentions in your mind,' my father continued. 'You were swayed by 
certain- influences. Like so many others.' » 
The discussions between the narrator and his sister also strengthen the sense of a deep 
generational gap :  
'Don't know. You can never tell with Father.' Then suddenly she straightened up 
and turned to me. 'Did he tell you about old Watanabe? What he did?' 
 
 
This information suggests the difference between the generation of the father and Watanabe 
and that of their children, thus building the sense that the “family supper” might turn into a 
family tragedy. 
The short story unfolds a whole family’s life in a few pages: we learn of the mother’s death and 
of the father’s retirement. We learn about the narrator and his sister and how different and 
modern they are compared to their parents. In these small factual elements, we also learn about 
the cultural divide that separates two generations: that of the parents and that of their children. 
In the cultural background is the traditional culture of samurais and the younger generation’s 
focus on America and modernity. 
Outside of these facts which we learn through conversations between the characters, the text 
tells us very little, focusing on the silences between the characters, on the sense of 
incommunicability and on secrecy. It appears that what actually happens in the story is situated 
in the very minute and detailed glimpses and bits of conversation.  
 
In the final section of the short story, the narrator recounts the actual “family supper”: it is told 
in great detail and the focus is on the minute narrative about the dinner. The father has cooked 
the meal, but only answers that it is fish when asked what it is he cooked for his children. There 
is an aura of mystery in the whole story which takes on a particularly ominous dimension in the 
end of the story. But there is also a conversation between the father and his children which 
could be interpreted differently, whether we believe they are eating fugu or not. 
It is therefore important to see how the text creates an atmosphere of discomfort and strangeness 
which leaves the reader unable to be sure what actually happened.  
 
Discomfort 
The final part of the short story continues to present an atmosphere of intense discomfort as 
since the story’s opening lines.  
The description puts forwards the discomfort felt by the characters who have little to talk about. 
The dialogue is followed by narrative indications on the part of the narrator. If we only look at 


## PDF page 5

the moments of this section dedicated to direct discourse, we can see that the dinner is very 
silent and marked by uncomfortable polite exchanges.  
The dialogue repeats the same exchanges: “what is it?” “Fish” and “what is it?” “Just fish” 
The father’s very general answer, rather than telling his children what type of fish he prepared 
creates suspicion in the reader’s mind that this might be fugu, particularly as the father insists 
on his children eating a lot of it: “'Help yourself. There's plenty.' And 'There's plenty for all of 
us.'  
ð The economy of words between characters, along with the circular dialogue which repeats 
the exchanges participate to create a growing sense of discomfort in the reader. We don’t 
know if this is to build up tension or to show the communication difficulties between the 
characters 
 
Mystery 
The growing discomfort also comes from the unspoken conflict between the father and his 
children. We have to understand what lies between their words. We only have access to the 
son’s thoughts and can therefore only guess what the father’s intentions actually are.  We cannot 
know the father’s intentions: are they to follow in the footsteps of Watanabee and kill his whole 
family by serving them fugu? Or is it simply to feed his son and daughter a nice dish of fish for 
their reunion after a long time apart?  
There is one instance where we are made to believe that the father would never think of feeding 
fugu to his children, when he answers “'Why, of course. Do you see it otherwise?'  when his 
son asks him if he believes what Watanabe did was a mistake. But this answer can’t quite work 
as a final proof since silence and discomfort fall back (« we fell silent again »), suggesting 
hidden things behind the silence.  
 
« The proof is, as it were, in the eating » 
In the opening description of how dangerous fugu can be, the narrator concludes « The proof 
is, as it were, in the eating » which suggests that only the experience of eating fugu will reveal 
whether itw as well prepared or not. The sentence illustrates why we cannot be certain of what 
is actually happening during the dinner scene as the father doesn’t explain what they are eating. 
And, if it was fugu, the reader cannot know if it is was properly prepared (the sister explains to 
her brother « 'Father's become quite a chef Since he's had to manage on his own ») or not. 
But the story ends too early for the readers to know the ending. We are kept in the dark, 
oscillating between two opposed interpretations of what the father’s intentions might have been. 
This open ending invites us to go back to reading the story again and to look very closely at the 
words exhanged between the father and his children. We might say « the proof is in the 
reading », but our reading can take us in different interpretative directions which we can never 
decide for sure.  
 
 
Through a great economy of words, the text plunges the reader in a very uncomfortable and 
mysterious atmosphere. We cannot be certain what the story was actually about, apart from the 
experience of alienation between characters and the difficulty to communicate. 
 

