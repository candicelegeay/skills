# Comment présenter un texte et sa problématique dans un commentaire de texte.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: Comment présenter un texte et sa problématique dans un commentaire de texte ? / Attendus de l’examen final
- PDF page 2: - / Il faut absolument éviter les jugements sur les personnages ainsi que les explications

## PDF page 1

Comment présenter un texte et sa problématique dans un commentaire de texte ? 
 
Attendus de l’examen final 
- un commentaire de texte structuré autour d'une question/problématique clairement 
énoncée et analysée en plusieurs parties, avec une introduction et une conclusion 
- une présentation de ce qui se passe dans le passage au niveau de l'histoire (ce que l'on 
appelle la diégèse -- diegesis en anglais) et au niveau de l'écriture (une analyse de la 
manière dont le texte est écrit) 
- une analyse du point de vue narratif : comment le point de vue narratif impacte-t-il 
notre perception des éléments de la diégèse ? 
 
Comment faire pour trouver une problématique pour un commentaire de texte ? 
La présentation du texte marque le début de l’analyse, il ne s’agit donc pas d’un passage obligé, 
d’un résumé « tout fait » qui pourrait être utilisé pour commenter n’importe quel extrait, mais 
bien plutôt d’un résumé où vous installez déjà votre analyse. Le résumé varie suivant le passage 
proposé et suivant ce que vous allez démontrer ensuite. En d’autres termes, une présentation 
bien faite introduit l’analyse et vous permet de faire ressortir les points saillants du texte. C’est 
donc en prenant le temps de bien noter toutes les spécificités du texte que vous allez dégager 
les thèmes et les questions qui seront ensuite traités dans la problématique et le corps du texte. 
Une présentation bien faite permet de dégager naturellement les thèmes et les questions à traiter 
dans le reste du commentaire de texte. 
Vous pouvez donner quelques éléments biographiques sur l’auteur mais uniquement s’ils ont 
un lien avec la manière dont vous présentez le texte (par exemple, sur la nouvelle de Poe, inutile 
de détailler la vie de l’auteur, mais si vous présentez Poe comme un maître du gothique, cela 
peut servir une présentation du texte qui reposerait sur le gothique). 
ð La présentation du texte repose sur deux niveaux, comme toujours en littérature : 
l’histoire (ou la diégèse, en d’autres termes ce qu’il se passe dans la nouvelle) et le récit 
(c’est-à-dire la manière dont l’histoire est racontée). Il faut absolument prendre ces deux 
niveaux en compte dans toute analyse littéraire.  
ð Cette présentation doit être faite en prenant en compte les questions suivantes : 
o Comment l’histoire est-elle racontée ? 
o Quel effet ce récit produit-il sur le lecteur ? 
ð Le reste du commentaire, après l’introduction visera à montrer quelles sont les stratégies 
utilisées, les procédés littéraires utilisés, pour produire les effets présentés en 
introduction. 
N’oubliez pas de vous référer au document de méthodologie qui figure sur la section de la 
semaine 2, vous y trouverez le barême et une présentation détaillée de la méthodologie du 
commentaire de texte. 
 
Que doit-il y avoir dans la présentation d’un texte ? 
- 
Un résumé de l’histoire 
- 
Une présentation de la narration : comment le texte nous est-il présenté ? Selon quel 
point de vue ? Quelle est l’atmosphère générale du texte ? Dans quelle situation le 
lecteur est-il mis ? 
- 
Un court résumé de ce qui précède qui fasse ressortir les thèmes principaux. 
ð 10 ou 15 lignes suffisent largement pour cela. Il faut apprendre à aller à l’essentiel, à 
condenser la présentation en quelques phrases. 
 
Qu’est-ce qui ne doit pas figurer dans la présentation d’un texte ? 


## PDF page 2

- 
Il faut absolument éviter les jugements sur les personnages ainsi que les explications 
d’ordre psychologique sur leurs motivations, ce qui reviendrait à considérer les 
personnages de fiction comme des personnages réels.  
 
Il faut veiller à ne pas transformer l’analyse littéraire en une réflexion d’ordre philosophique 
sur les thèmes du texte.  
 

