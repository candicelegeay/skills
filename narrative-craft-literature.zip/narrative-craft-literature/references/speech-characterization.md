# A2FLT12 Lecture 4 Speech Representations et al PDF.pdf

Page numbers below are physical PDF pages. Text extraction may omit image-only content and visual emphasis.

## Contents
- PDF page 1: A2FLT12 CM with M. Tredy - First Half of the Semester / Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
- PDF page 2: A2FLT12 CM with M. Tredy - First Half of the Semester / Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
- PDF page 3: Mini-Lesson on Speech Representations (p. 11 of your brochure) / As with characterization, the spectrum of speech presentation spans from di
- PDF page 4: Mini-Lesson on Speech Representations (p. 11 of your brochure) / 4. Free Indirect Speech / Free Indirect Thought: (allows us to follow chara
- PDF page 5: Mini-Lesson on Speech Representations (p. 11 of your brochure) / 4. Free Indirect Speech / Free Indirect Thought: (allows us to follow chara
- PDF page 6: Mini-Lesson on Speech Representations (p. 11 of your brochure) / 4. Free Indirect Speech / Free Indirect Thought: (allows us to follow chara
- PDF page 7: Mini-Lesson on Speech Representations (p. 11 of your brochure) / Three common techniques used in literature to present a character’s thought
- PDF page 8: Mini-Lesson on Speech Representations (p. 11 of your brochure) / Three common techniques used in literature to present a character’s thought
- PDF page 9: Teenage Skaz: / (from Russian skazátʹ, "to tell", storytelling in oral form, in dialect, slang)
- PDF page 10: Teenage Skaz: / (from Russian skazátʹ, "to tell", storytelling in oral form, in dialect, slang)
- PDF page 11: “The A & P” (1961) by John Updike / (incipit)
- PDF page 12: Teenage SKAZ / dramatic monologue / grammatical errors (e.g., she “probably never seen”; switching past and present
- PDF page 13: direct address: e.g., “Do you really think…?”; “You know, it’s one thing…” , “The / bowties are theirs, if you’ve ever wondered.”
- PDF page 14: Mini-Lesson on Characterization / Round Characters vs. Flat Characters
- PDF page 15: Mini-Lesson on Characterization / Some key types of indirect means…

## PDF page 1

A2FLT12 CM with M. Tredy - First Half of the Semester
Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
Lecture 2:  Lesson on Narration, Focalization & Narrative Distance 
Lecture 3:  Timeline 1: The Rise of the Novel in the 18th Century 
Practice TEST #1 
Lecture 4: Speech Representations, Skaz & Characterization
Lecture 5: Timeline 2: The Novel Comes of Age 
Lecture 6:  Timeline 3: The American Renaissance 
Practice Test #2 
WEEK 7: Online MIDTERM (available Monday March 9th to Wednesday March 11th at midnight)
---
A2FLT12 Today’s Class (Week 4)
1. Mini-Lesson on Speech Representations
2. John Updike’s “The A & P” (focus on the beginning of the story)
3. Mini-Lesson on Characterization


## PDF page 2

A2FLT12 CM with M. Tredy - First Half of the Semester
Lecture 1: Introduction to the short story & Poe excerpt   (longer lesson)
Lecture 2:  Lesson on Narration, Focalization & Narrative Distance 
Lecture 3:  Timeline 1: The Rise of the Novel in the 18th Century 
Practice TEST #1 
Lecture 4: Speech Representations, Skaz & Characterization
Lecture 5: Timeline 2: The Novel Comes of Age 
Lecture 6:  Timeline 3: The American Renaissance 
Practice Test #2 
WEEK 7: Online MIDTERM (available Monday March 9th to Wednesday March 11th at midnight)
---
A2FLT12 Today’s Class (Week 4)
1. Mini-Lesson on Speech Representations
2. John Updike’s “The A & P” (focus on the beginning of the story)
3. Mini-Lesson on Characterization


## PDF page 3

Mini-Lesson on Speech Representations (p. 11 of your brochure)
As with characterization, the spectrum of speech presentation spans from diegetic to mimetic forms:
Telling  -----------------------------------------------------------------------------------------→ Showing
 Narrative Summary / Indirect Speech / Free Indirect Speech/ Direct Speech / Free Direct Speech
1. Summary of the words by the narrator:
 e.g., After the supper Mr. Maudsley made a speech. […] With what seemed to me consummate skill he 
 contrived to bring in almost every player by name and find something noteworthy in his performance. 
      (L.P. Hartley, The Go-Between)
2. Indirect Speech: (gets closer to “actual” words uttered by the character; uses verbs of saying/thinking plus 
a tag; spatial or time references change as well as verbs according to the formal sequence of tenses)
 e.g., Bill said that he was a quiet family man and would get him a flop and go to bed. (John Dos Passos, 
USA)
3. Semi-Indirect Speech: (although it remains indirect speech, quotation marks are used)
 e.g., As soon as he entered the Room, he told Joseph, “he was come to pray by him, 
and to prepare him for another World: In the first place, therefore, he hope he had 
repented all of his Sins?” (Henry Fielding, Joseph Andrews)


## PDF page 4

Mini-Lesson on Speech Representations (p. 11 of your brochure)
4. Free Indirect Speech / Free Indirect Thought: (allows us to follow character’s words or thoughts without the 
narrator’s interventions; often ambiguous blend of narrator’s voice and character’s words/thoughts)
 e.g., Soon, however, she began to reason with herself, and try to be feeling less.  Eight years, almost eight years had 
passed, since all had been given up.  How absurd to be resuming the agitation which such an interval had banished into 
distance and indistictness!  What might not eight years do?  Events of every description, changes, alienations, removals—
all, all must be comprised in it; and the oblivion of the past—how natural, how certain too!  It included nearly a third part 
of her life.  Alas! With all her reasonings, she found, that to retentive feelings eight years may be little more than nothing. 
(Jane Austen, Persuasion)
e.g., p. 61 of the brochure: His smile was so easy, so friendly that Laura recovered. What nice eyes he had, small, but such 
a dark blue! And now she looked at the others, they were smiling too. "Cheer up, we won't bite," their smile seemed to 
say. How very nice workmen were! And what a beautiful morning! She mustn't mention the morning; she must be 
business-like. The marquee. 
e.g., pp.71-72 of the brochure: "Good night," the other said. Turning off the electric light he continued 
the conversation with himself. It was the light of course but it is necessary that the place be clean 
and pleasant. You do not want music. Certainly you do not want music. Nor can you stand before 
a bar with dignity although that is all that is provided for these hours. What did he fear? It was not 
a fear or dread. It was a nothing that he knew too well. It was all a nothing and a man was a nothing 
too. It was only that and light was all it needed and a certain cleanness and order. Some lived in it 
and never felt it but he knew it all was nada y pues nada y naday pues nada.


## PDF page 5

Mini-Lesson on Speech Representations (p. 11 of your brochure)
4. Free Indirect Speech / Free Indirect Thought: (allows us to follow character’s words or thoughts without the 
narrator’s interventions; often ambiguous blend of narrator’s voice and character’s words/thoughts)
 e.g., Soon, however, she began to reason with herself, and try to be feeling less.  Eight years, almost eight years had 
passed, since all had been given up.  How absurd to be resuming the agitation which such an interval had banished into 
distance and indistictness!  What might not eight years do?  Events of every description, changes, alienations, removals—
all, all must be comprised in it; and the oblivion of the past—how natural, how certain too!  It included nearly a third part 
of her life.  Alas! With all her reasonings, she found, that to retentive feelings eight years may be little more than nothing. 
(Jane Austen, Persuasion)
e.g., p. 61 of the brochure: His smile was so easy, so friendly that Laura recovered. What nice eyes he had, small, but such 
a dark blue! And now she looked at the others, they were smiling too. "Cheer up, we won't bite," their smile seemed to 
say. How very nice workmen were! And what a beautiful morning! She mustn't mention the morning; she must be 
business-like. The marquee. 
e.g., pp.71-72 of the brochure: "Good night," the other said. Turning off the electric light he continued 
the conversation with himself. It was the light of course but it is necessary that the place be clean 
and pleasant. You do not want music. Certainly you do not want music. Nor can you stand before 
a bar with dignity although that is all that is provided for these hours. What did he fear? It was not 
a fear or dread. It was a nothing that he knew too well. It was all a nothing and a man was a nothing 
too. It was only that and light was all it needed and a certain cleanness and order. Some lived in it 
and never felt it but he knew it all was nada y pues nada y naday pues nada.


## PDF page 6

Mini-Lesson on Speech Representations (p. 11 of your brochure)
4. Free Indirect Speech / Free Indirect Thought: (allows us to follow character’s words or thoughts without 
the narrator’s interventions; often ambiguous blend of narrator’s voice and character’s words/thoughts)
 e.g., Soon, however, she began to reason with herself, and try to be feeling less.  Eight years, almost eight 
years had passed, since all had been given up.  How absurd to be resuming the agitation which such an 
interval had banished into distance and indistictness!  What might not eight years do?  Events of every 
description, changes, alienations, removals—all, all must be comprised in it; and the oblivion of the past—
how natural, how certain too!  It included nearly a third part of her life.  Alas! With all her reasonings, she 
found, that to retentive feelings eight years may be little more than nothing. (Jane Austen, Persuasion)
5. Direct Speech (straightforward reporting of lines, as if we were witnessing the scene)
   e.g., “Who’s that?” I said, pretending I didn’t know.
           “It’s the Dragon Lady,” Kitty said.  “She’s coming to get you.”   (Paul Auster, Moon Palace)
6. Free Direct Speech (often used in first-person interior or dramatic monologue; the character-narrator 
seems to be talking directly to you)
 e.g., She looked like she might have a pretty damn good idea what a bastard she was the mother of.  
But you can’t always tell—with somebody’s mother, I mean. Mothers are all slightly insane. 
(J.D. Salinger, The Catcher in the Rye)


## PDF page 7

Mini-Lesson on Speech Representations (p. 11 of your brochure)
Three common techniques used in literature to present a character’s thoughts more vividly:
1. Dramatic Monologue (the speaker addresses someone whose responses are not given)
   (e.g. Robert Browning, “Fra Lippo Lippi”, Holden in Salinger’s The Catcher in the Rye)
2. Interior Monologue / Narrated Monologue: (character is ‘thinking aloud’, often through Free 
Indirect Speech)    (e.g., long passages from Henry James’s The Portrait of a Lady: Ah! She had been 
immensely under the charm! It had not passed away; it was there still: she still knew perfectly what it 
was that made Osmond delightful when he chose to be.)
   
3. Stream of Consciousness (cf. William James, Principles of Psychology, 1890) 
(an attempt to render a flow of thoughts—which aren’t always verbalized or coherent or developed or 
fully conscious.  It has more of a rambling and disjointed structure than Interior Monologue and has 
freer associations). 
(e.g., James Joyce, Ulysses: no that’s no way for him has he no manners nor no refinement nor no 
nothing in his nature slapping us behind like that on my bottom because I didn’t call him Hugh the 
ignoramus that doesn’t know poetry from cabbage thats what you get for not keeping them in their 
proper place…
NB: This example is ‘direct’ stream of consciousness, in which even basic rules of sentence structure 
are disregarded.  With the ‘indirect’ form, we are conscious of a narrator carefully selecting information 
and controlling the narrative to focus on thoughts and impressions (e.g., Virginia Woolf, Mrs. 
Dalloway)


## PDF page 8

Mini-Lesson on Speech Representations (p. 11 of your brochure)
Three common techniques used in literature to present a character’s thoughts more vividly:
1. Dramatic Monologue (the speaker addresses someone whose responses are not given)
   (e.g. Robert Browning, “Fra Lippo Lippi”, Holden in Salinger’s The Catcher in the Rye)
2. Interior Monologue / Narrated Monologue: (character is ‘thinking aloud’, often through Free 
Indirect Speech)    (e.g., long passages from Henry James’s The Portrait of a Lady: Ah! She had been 
immensely under the charm! It had not passed away; it was there still: she still knew perfectly what it 
was that made Osmond delightful when he chose to be.)
   
3. Stream of Consciousness (cf. William James, Principles of Psychology, 1890) 
(an attempt to render a flow of thoughts—which aren’t always verbalized or coherent or developed or 
fully conscious.  It has more of a rambling and disjointed structure than Interior Monologue and has 
freer associations). 
(e.g., James Joyce, Ulysses: no that’s no way for him has he no manners nor no refinement nor no 
nothing in his nature slapping us behind like that on my bottom because I didn’t call him Hugh the 
ignoramus that doesn’t know poetry from cabbage thats what you get for not keeping them in their 
proper place…
e.g., […] standing and looking until Peter Walsh said, ‘Musing among the vegetables?’ — was 
that it? — ‘I prefer men to cauliflowers’ — was that it? He must have said it at breakfast one 
morning when she had gone out on to the terrace — Peter Walsh. He would be back from India 
one of these days, June or July, she forgot which, for his letters were awfully dull. 
(Virginia Woolf, Mrs. Dalloway)


## PDF page 9

Teenage Skaz:
(from Russian skazátʹ, "to tell", storytelling in oral form, in dialect, slang)  
“It didn't take me long to make up my mind that these liars warn't no kings nor dukes at all, but just low-down 
humbugs and frauds. But I never said nothing, never let on; kept it to myself; it's the best way; then you don't have 
no quarrels, and don't get into no trouble. If they wanted us to call them kings and dukes, I hadn't no objections, 
'long as it would keep peace in the family; and it warn't no use to tell Jim, so I didn't tell him. If I never learnt nothing 
else out of pap, I learnt that the best way to get along with his kind of people is to let them have their own way.”  
The Adventures of Huckleberry Finn, Ch. 19, Mark Twain
“That's the thing about girls. Every time they do something pretty, even if they're not much to look at, or even if 
they're sort of stupid, you fall in love with them, and then you never know where the hell you are. Girls. Jesus Christ. 
They can drive you crazy. They really can.”
The Catcher in the Rye (1951), J.D. Salinger
“I think he’s going to cut things off with me. He’s getting more involved with my mother again. 
They seem to be going out more and more. I just can’t take it. What if they got married or 
even if they just moved in together? I don’t want him to be sleeping with us both at the 
same time if we’re living under one roof as a family. It sounds crazy, but what if he started 
sleeping with Gretel too?”
Diary of a Teenage Girl (2002), Phoebe Gloeckner


## PDF page 10

Teenage Skaz:
(from Russian skazátʹ, "to tell", storytelling in oral form, in dialect, slang)  
“It didn't take me long to make up my mind that these liars warn't no kings nor dukes at all, but just low-down 
humbugs and frauds. But I never said nothing, never let on; kept it to myself; it's the best way; then you don't have 
no quarrels, and don't get into no trouble. If they wanted us to call them kings and dukes, I hadn't no objections, 
'long as it would keep peace in the family; and it warn't no use to tell Jim, so I didn't tell him. If I never learnt nothing 
else out of pap, I learnt that the best way to get along with his kind of people is to let them have their own way.”  
The Adventures of Huckleberry Finn, Ch. 19, Mark Twain
“That's the thing about girls. Every time they do something pretty, even if they're not much to look at, or even if 
they're sort of stupid, you fall in love with them, and then you never know where the hell you are. Girls. Jesus Christ. 
They can drive you crazy. They really can.”
The Catcher in the Rye (1951), J.D. Salinger
“I think he’s going to cut things off with me. He’s getting more involved with my mother again. 
They seem to be going out more and more. I just can’t take it. What if they got married or 
even if they just moved in together? I don’t want him to be sleeping with us both at the 
same time if we’re living under one roof as a family. It sounds crazy, but what if he started 
sleeping with Gretel too?”
Diary of a Teenage Girl (2002), Phoebe Gloeckner


## PDF page 11

“The A & P” (1961) by John Updike  
 
 
 
(incipit)
In walks these three girls in nothing but bathing suits. I'm in the third check-out slot, with my 
back to the door, so I don't see them until they're over by the bread. The one that caught my eye 
first was the one in the plaid green two-piece. She was a chunky kid, with a good tan and a sweet 
broad soft-looking can with those two crescents of white just under it, where the sun never seems 
to hit, at the top of the backs of her legs. I stood there with my hand on a box of HiHo crackers 
trying to remember if I rang it up or not. I ring it up again and the customer starts giving me hell. 
She's one of these cash-register-watchers, a witch about fifty with rouge on her cheekbones and 
no eyebrows, and I know it made her day to trip me up. She'd been watching cash registers forty 
years and probably never seen a mistake before.
By the time I got her feathers smoothed and her goodies into a bag—she gives me a little snort in 
passing, if she'd been born at the right time they would have burned her over in Salem—by the 
time I get her on her way the girls had circled around the bread and were coming back, without a 
pushcart, back my way along the counters, in the aisle between the check-outs and the Special 
bins. They didn't even have shoes on. There was this chunky one, with the two-piece—It was 
bright green and the seams on the bra were still sharp and her belly was still pretty pale so I 
guessed she just got it (the suit)—there was this one, with one of those chubby berry-faces, the 
lips all bunched together under her nose, this one, and a tall one, with black hair that hadn't quite 
frizzed right, and one of these sunburns right across under the eyes, and a chin that was too 
long—you know, the kind of girl other girls think is very "striking" and "attractive" but never 
quite makes it, as they very well know, which is why they like her so much—and then the third 
one, that wasn't quite so tall. She was the queen. […]


## PDF page 12

Teenage SKAZ / dramatic monologue
grammatical errors (e.g., she “probably never seen”; switching past and present 
tenses
syntactical errors (run-on sentences; fragments (“Not this queen.”), word 
order/sentence structure (e.g., “In walks these three girls…”)
slang or vulgarity (e.g., “She buzzed to the other two”: “a sweet broad soft-
looking can”
oral qualifications (e.g. “you know”; “my stomach kind of fell”)
hyperbole & exaggerated form (e.g., “the cat-and-dog-food-breakfast-cereal-
macaroni-rice-raisins-seasonings-spreads-spaghetti-soft-drinks-crackers-and-
cookies aisle”; “She’s been watching cash registers for fifty years”, Salem witch 
trials, etc.)
name-calling (in mind): “old witch”, “sheep”, “pigs in a shoot”, “Queenie”, 
“house slaves in pin-curlers”, “bums”, “Plaid”, “Big Tall Goony-Goon”, etc.
jokes / asides [e.g., “(Do you really think it’s a mind in there…?)”; “(What do 
these bums do with all that pineapple juice? I’ve often asked myself)”


## PDF page 13

direct address: e.g., “Do you really think…?”; “You know, it’s one thing…” , “The 
bowties are theirs, if you’ve ever wondered.”
narrative control and markers (e.g., “Now here comes the sad part of the story…” 
(232)
insistence (e.g., “Really, I thought that was so cute.”)
colorful metaphors/similes:
-Stokesie “with two babies chalked up on his fuselage already.”
-Stokesie may make manager by 1990, when Russians take over and it’s the 
“Great Alexandrov and Petrooshki Tea Company”
-how McManon from meat department eyed the girls, “sizing up their joints”
-store like a “pinball machine” and didn’t know which “funnel they’d shoot out of”
-the song the register makes when you ring things up
digressions- (cf. Holden Caulfield)
“All of a sudden I slid right down her voice into her living room” + digression: 
imagining her cocktail parties and his own parents’ idea of entertaining guests
(Schlitz beer & cartoon mustard jars for glasses)


## PDF page 14

Mini-Lesson on Characterization
Round Characters vs. Flat Characters  
(E. M. Forster-- Aspects of the Novel, 1927) 
     Round Characters (well-developed & complex, surprising) 
     Flat Characters (simple & undeveloped or unchanging) 
 (e.g., caricatures, stock characters, traditional archetypes, stereotypes, etc.) 
In addition to the usual ‘main’ & ‘secondary’ character distinction,
or that between protagonists/heroes/heroines 
                              and antagonists/villains/foils
Methods of Characterization 
-direct characterization 
(description and exposition by the narrator) 
-semi-direct characterization 
(description and exposition by characters in dialogue)
  (e.g., “You go, Laura. You’re the artistic one.”)
-indirect characterization 
(through what the character does, says, thinks, or by more symbolic means) 
  (a key device in all types of literature)


## PDF page 15

Mini-Lesson on Characterization
Some key types of indirect means…
 
-Idiolects and Speech 
-dialects, jargon, tics 
-sociolects (register, highbrow or informal style, references, 
   colloquialisms & malapropisms / eye-grammar & skaz, etc.) 
-Symbolic Characterization 
     -Symbolic names (onomastics & sounds) 
    (e.g., Blanche DuBois, Huckleberry Finn, Pip, Mr. Gradgrind)
     -Symbolic contrast or parallels with the landscape or setting
           (eg, the pathetic fallacy, gothic settings)  
     -Symbolic contrast or parallels to other characters
     (e.g., George & Lenny in Of Mice & Men, use of foils)  
     -Use of symbolic colors, costumes or props
      (e.g., clownish costume & make-up, a flipping coin, etc.) 
     -Associating characters with particular animals (zoomorphism) 
           (eg, with a donkey/ass, with a bull, a pig, etc.)  (cf. anthropomorphism)
-Subjective POV through a character, etc. (ie, What Peter says/thinks about 
Paul says more about Peter than about Paul!)

