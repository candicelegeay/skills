"""Local deterministic helpers for the voice-writer skill."""
