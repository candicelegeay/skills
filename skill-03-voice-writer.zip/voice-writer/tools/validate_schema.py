#!/usr/bin/env python3
import argparse
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator, FormatChecker


def load_yaml(path: str):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def validate(payload_path: str, schema_path: str):
    payload = load_yaml(payload_path)
    schema = load_yaml(schema_path)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(payload), key=lambda e: list(e.path))
    return [
        {
            "path": ".".join(str(x) for x in error.path),
            "message": error.message,
        }
        for error in errors
    ]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("payload")
    p.add_argument("schema")
    args = p.parse_args()
    errors = validate(args.payload, args.schema)
    if errors:
        print(yaml.safe_dump({"valid": False, "errors": errors}, sort_keys=False, allow_unicode=True))
        raise SystemExit(1)
    print(yaml.safe_dump({"valid": True, "errors": []}, sort_keys=False))


if __name__ == "__main__":
    main()
