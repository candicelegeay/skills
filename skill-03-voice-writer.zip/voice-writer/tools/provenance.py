ALLOWED_LABELS = {
    "USER_IDEA", "USER_WORDS", "USER_INFERENCE", "EXTERNAL_SOURCE",
    "SOCIAL_TREND", "AI_INFERENCE", "AI_GENERATION", "HUMAN_EDIT",
}


def claim(text: str, labels: list[str], source_ids: list[str] | None = None) -> dict:
    unknown = set(labels) - ALLOWED_LABELS
    if unknown:
        raise ValueError(f"Unknown provenance labels: {sorted(unknown)}")
    return {"text": text, "labels": labels, "source_ids": source_ids or []}
