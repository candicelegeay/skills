"""Mock runtime used for local tests. It does not call an LLM."""
from copy import deepcopy
import yaml
from pathlib import Path


def mock_write(payload: dict) -> dict:
    root = Path(__file__).resolve().parents[1]
    if payload.get("selected_angle"):
        path = root / "examples" / "output.example.yaml"
    else:
        path = root / "examples" / "awaiting-angle.example.yaml"
    return deepcopy(yaml.safe_load(path.read_text(encoding="utf-8")))
