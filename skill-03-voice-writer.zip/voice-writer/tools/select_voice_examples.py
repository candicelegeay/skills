#!/usr/bin/env python3
"""Small deterministic fallback selector. Replace with semantic retrieval when available."""
import re
from typing import Any

STOP = {
    "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with", "is", "are",
    "le", "la", "les", "un", "une", "des", "de", "du", "et", "ou", "dans", "pour", "avec",
}


def tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-zA-ZÀ-ÿ0-9_-]+", text.lower()) if len(t) > 2 and t not in STOP}


def idea_text(idea_brief: dict[str, Any]) -> str:
    parts = []
    for key in ("observation", "core_claim", "why_it_matters", "original_input"):
        value = idea_brief.get(key)
        if isinstance(value, str):
            parts.append(value)
    for key in ("reasoning", "concepts"):
        value = idea_brief.get(key, [])
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    parts.extend(str(v) for v in item.values() if isinstance(v, str))
                elif isinstance(item, str):
                    parts.append(item)
    return " ".join(parts)


def select_voice_examples(idea_brief: dict[str, Any], target_format: str, examples: list[dict[str, Any]], max_examples: int = 5):
    target = tokens(idea_text(idea_brief))
    scored = []
    for idx, ex in enumerate(examples):
        ex_tokens = tokens(str(ex.get("content", "")) + " " + " ".join(ex.get("tags", []) or []))
        overlap = len(target & ex_tokens) / max(1, len(target | ex_tokens))
        format_bonus = 1.0 if ex.get("format") == target_format else 0.0
        canonical_bonus = 0.35 if ex.get("canonical") else 0.0
        score = 2.0 * format_bonus + canonical_bonus + overlap
        scored.append((score, -idx, ex))
    scored.sort(reverse=True, key=lambda x: (x[0], x[1]))
    selected = [ex for _, _, ex in scored[: max(1, min(max_examples, 5))]]
    return selected
