# Draft prompt

Write the full draft in the target language and format.

Priority order:
1. fidelity to the IdeaBrief;
2. factual integrity and provenance;
3. selected angle and outline;
4. voice examples;
5. style preferences;
6. target length.

Use voice examples as behavioral demonstrations, never as text to copy or as factual evidence. If the target language differs from the IdeaBrief, rewrite natively rather than translating literally.
