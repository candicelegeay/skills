# Voice review prompt

Compare the draft with the selected VoiceExamples and StylePreferences. Identify sentences that are generic, over-explained, too promotional, rhythmically alien, or reliant on common AI connective tissue. Rewrite only where needed. Preserve the argument and provenance.
