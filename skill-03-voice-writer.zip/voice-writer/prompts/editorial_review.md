# Editorial review prompt

Audit the draft for:
- fidelity to the original idea;
- unsupported factual claims;
- accidental attribution of external material to the user;
- overstatement;
- clichés and filler;
- contradictions;
- weak or interchangeable structure.

Do not hide uncertainty. If a claim cannot be supported, remove or qualify it and record the issue in factual_risks.
