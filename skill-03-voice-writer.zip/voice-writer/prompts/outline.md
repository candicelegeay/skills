# Outline prompt

Build an argumentative outline for the selected angle.

Each point must have a job: establish the observation, advance the thesis, support it, test it against a counterargument, or derive an implication. Remove sections that exist only to create symmetrical structure.
