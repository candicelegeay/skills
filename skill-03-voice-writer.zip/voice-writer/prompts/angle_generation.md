# Angle generation prompt

Generate exactly three substantively different editorial angles from the supplied IdeaBrief.

For each angle return:

- angle
- central_claim
- why_interesting
- relationship_to_original_idea
- risk

Constraints:

- The IdeaBrief is the source of authority for what the user thinks.
- TrendReport and ResearchArtifacts may create context or tension, but must not replace the user’s thesis.
- Do not create three title variants of the same argument.
- Any extension beyond the IdeaBrief must be identifiable as an AI inference.
