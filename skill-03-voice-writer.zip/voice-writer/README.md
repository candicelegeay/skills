# Skill 03 — voice-writer

Package portable du troisième skill de la suite de rédaction.

## Contenu

- `SKILL.md` : spécification opérationnelle du skill.
- `manifest.yaml` : métadonnées et entrypoints.
- `tools.yaml` : contrat des capacités/outils.
- `schemas/` : schémas d’entrée et de sortie.
- `examples/` : cas complet + cas arrêté au checkpoint de sélection d’angle.
- `prompts/` : prompts spécialisés par étape.
- `references/` : modèle de voix, provenance et quality gates.
- `tools/` : helpers locaux déterministes et mock.
- `tests/` : validation des schémas et helpers.

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make validate-schemas
make test
```

## Intégration

Le dossier est provider-agnostic. Le runtime hôte peut mapper les capacités `llm_generation` / `llm_review` de `tools.yaml` vers le modèle de son choix. Les helpers Python ne nécessitent aucun accès réseau.

Pour intégrer le skill dans un dépôt contenant déjà `skills/`, placer ce dossier sous `skills/voice-writer/`.

## Point important

Le workflow conserve un checkpoint humain après les trois angles. Si `selected_angle` n’est pas fourni, le skill doit renvoyer `workflow.status: awaiting_angle_selection` au lieu d’écrire silencieusement un article complet.
