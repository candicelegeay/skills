---
name: voice-writer
description: Générer un contenu dans la voix de l’utilisateur à partir d’un IdeaBrief, avec sélection d’angle, contrôle humain, traçabilité des sources et revue explicite de fidélité à la voix.
version: 1.0.0
skill_number: 3
entrypoint: SKILL.md
input_schema: schemas/input.yaml
output_schema: schemas/output.yaml
tools_manifest: tools.yaml
---

# Voice Writer

## Objectif

`voice-writer` transforme un `IdeaBrief` déjà clarifié en contenu publiable qui conserve l’idée, le raisonnement et la voix de l’utilisateur. Il peut utiliser un `TrendReport`, des `ResearchArtifacts`, des exemples de voix et des préférences éditoriales, mais il ne doit jamais confondre ces sources avec la pensée originale de l’utilisateur.

Ce skill n’est ni un correcteur générique ni un simple reformulateur. Il doit reproduire une manière d’écrire et de raisonner, sans fabriquer d’opinions, d’expériences ou de faits attribués à l’utilisateur.

## Contrat d’entrée

Valider l’entrée contre `schemas/input.yaml` avant toute génération.

Entrées principales :

- `IdeaBrief` : requis. Source d’autorité pour l’idée, la thèse, les exemples personnels et les formulations de l’utilisateur.
- `TrendReport` : optionnel. Contexte externe récent. Ne jamais le transformer en opinion de l’utilisateur.
- `ResearchArtifacts` : optionnel. Sources factuelles déjà collectées ou validées.
- `VoiceExamples` : optionnel. Textes précédents servant de few-shot.
- `StylePreferences` : optionnel. Préférences explicites et règles rédactionnelles.
- `target_format`, `target_language` : requis.
- `audience`, `length`, `selected_angle` : optionnels.

## Hiérarchie de contexte

Traiter séparément quatre couches :

1. **Voix personnelle** : vocabulaire, cadence, longueur de phrase, ponctuation, formatage, humour.
2. **Démarche de raisonnement** : progression logique, degré de nuance, usage des contre-arguments, manière de relier stratégie et exemples.
3. **Préférences éditoriales** : hooks, introductions, transitions, niveau de densité, formulations ou tics à éviter.
4. **Connaissances de domaine** : faits, concepts et références présents dans les sources ou travaux antérieurs.

Ne jamais convertir une connaissance de domaine en préférence stylistique, ni une tendance externe en conviction personnelle.

## Règles absolues

- Ne pas inventer une opinion, une expérience, un chiffre, une citation ou une source.
- Ne pas modifier le `core_claim` pour le rendre plus « intéressant » sans signaler la modification comme `AI_INFERENCE` et demander validation si elle devient structurante.
- Conserver les formulations exactes issues de `quotable_user_language` lorsqu’elles sont utilisées comme citations.
- Marquer toute assertion externe avec une provenance `EXTERNAL_SOURCE` ou `SOCIAL_TREND`.
- Si une assertion factuelle n’a pas de source disponible, soit la supprimer, soit l’indiquer explicitement dans `review.factual_risks`.
- Si la cible est dans une autre langue que l’idée d’origine, réécrire naturellement. Ne pas traduire mot à mot.
- Ne pas copier le texte d’un `VoiceExample`. Imiter des caractéristiques de style, pas des passages.
- Les exemples de voix sont des signaux stylistiques, pas des sources factuelles.

## Workflow

### 1. Sélection des exemples de voix

Si plus de 5 `VoiceExamples` sont disponibles, sélectionner 3 à 5 exemples maximum en donnant priorité à :

1. même format que `target_format` ;
2. proximité de sujet et de type d’argument ;
3. qualité/canonicité explicite de l’exemple.

Utiliser `select_voice_examples` si le runtime expose cet outil. Conserver les IDs retenus dans `voice_context.examples_used`.

### 2. Génération des angles

Produire **exactement 3 angles réellement distincts**. Chaque angle doit contenir :

```yaml
angle: string
central_claim: string
why_interesting: string
relationship_to_original_idea: string
risk: string
```

Rejeter les faux choix qui ne diffèrent que par le titre, le hook ou le vocabulaire.

### 3. Human checkpoint

Si `selected_angle` n’est pas fourni, retourner les 3 angles dans `workflow.angle_candidates`, mettre `workflow.status: awaiting_angle_selection` et **ne pas rédiger l’article complet**.

Si `selected_angle` est fourni, vérifier qu’il reste compatible avec l’idée originale. Une reformulation légère est acceptable ; un changement de thèse doit être signalé.

### 4. Outline

Construire un plan argumenté. Chaque section doit avoir une fonction claire : avancer la thèse, apporter une preuve, traiter une objection, ou tirer une implication. Éviter les plans génériques en trois parties qui pourraient s’appliquer à n’importe quel sujet.

### 5. Draft

Rédiger le texte complet en tenant compte de :

- l’`IdeaBrief` ;
- l’angle sélectionné ;
- les sources externes disponibles ;
- 3 à 5 exemples de voix maximum ;
- les préférences éditoriales explicites ;
- le format, la langue, l’audience et la longueur cible.

La voix doit être obtenue par similarité de comportement rédactionnel, pas par ajout artificiel de tics stylistiques.

### 6. Voice review

Relire le texte pour détecter :

- phrases génériques ou interchangeables ;
- transitions typiques de texte IA ;
- vocabulaire absent des exemples de voix ;
- sur-explication ;
- perte du degré de nuance de l’utilisateur ;
- rythme ou structure incompatibles avec les exemples.

Corriger lorsque possible et documenter le résultat dans `review.voice_fidelity` et `review.genericness_risks`.

### 7. Editorial / factual review

Vérifier :

- fidélité à l’idée ;
- distinction entre assertions utilisateur et faits externes ;
- présence de sources pour les claims factuels ;
- contradictions internes ;
- clichés, tiédeur ou remplissage ;
- risque de sur-affirmation.

Documenter le résultat dans `review.idea_fidelity` et `review.factual_risks`.

### 8. Sortie

Valider la sortie contre `schemas/output.yaml`.

Le résultat doit contenir :

- `artifact` : format, langue, angle, outline, draft ;
- `provenance` : claims utilisateur, claims externes, inférences IA ;
- `voice_context` : exemples et préférences réellement utilisés ;
- `review` : fidélité à l’idée, fidélité à la voix, risques de généricité et risques factuels ;
- `workflow` : angles, état du checkpoint humain et étapes exécutées.

## Politique de provenance

Utiliser les labels décrits dans `provenance.yaml` :

- `USER_IDEA`
- `USER_WORDS`
- `USER_INFERENCE`
- `EXTERNAL_SOURCE`
- `SOCIAL_TREND`
- `AI_INFERENCE`
- `AI_GENERATION`
- `HUMAN_EDIT`

Un même passage peut avoir plusieurs sources de provenance, mais il ne faut jamais faire remonter `AI_INFERENCE` ou `EXTERNAL_SOURCE` vers `USER_IDEA` sans validation humaine explicite.

## Failure behavior

- Entrée invalide : ne pas générer ; retourner les erreurs de validation.
- Aucun exemple de voix : rédiger fidèlement à l’idée mais signaler `voice_fidelity: "unassessed_no_examples"`.
- Sources insuffisantes pour un claim : retirer ou qualifier le claim ; renseigner `factual_risks`.
- Angle non sélectionné : arrêter après la proposition des trois angles.
- Conflit entre préférence et exemple : la préférence explicite la plus récente prévaut ; consigner le conflit dans `review.voice_fidelity`.

## Fichiers associés

- `tools.yaml` : contrat des outils utilisables par le skill.
- `schemas/input.yaml` : schéma d’entrée canonique.
- `schemas/output.yaml` : schéma de sortie canonique.
- `prompts/` : sous-prompts spécialisés par étape.
- `references/` : règles de voix, provenance et quality gates.
- `tools/` : implémentations locales déterministes / mock.
- `examples/` : exemples valides d’entrée et de sortie.
