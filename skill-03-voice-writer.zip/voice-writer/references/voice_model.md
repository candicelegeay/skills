# Voice model

Model the user’s voice as a set of observable behaviors rather than adjectives.

## 1. Lexical layer

Track recurring vocabulary, technical density, preferred verbs, use of jargon, contractions, punctuation and taboo phrases.

## 2. Rhythm layer

Track sentence-length distribution, paragraph length, use of fragments, cadence, transitions and whether emphasis comes from compression or elaboration.

## 3. Reasoning layer

Track how the writer moves from observation to claim, how they use examples, how strongly they state uncertainty, where they place counterarguments, and how they bridge strategy and implementation.

## 4. Editorial layer

Track preferred openings, endings, hook types, formatting, amount of context, use of rhetorical questions, anecdotes and explicit signposting.

## Few-shot policy

Select 3–5 examples at most. Prefer the same format first, then similar subject/reasoning, then canonical quality. Never copy a phrase merely because it sounds distinctive. Preserve actual user wording only when it comes from `USER_WORDS` / `quotable_user_language`.
