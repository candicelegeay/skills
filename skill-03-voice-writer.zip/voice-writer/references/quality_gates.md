# Quality gates

A draft is not `draft_ready` unless all gates below are addressed.

## Idea fidelity

- Core claim remains materially unchanged unless the user explicitly selected a modified angle.
- Personal experience is not invented.
- Counterarguments are represented without turning them into the user’s position.

## Voice fidelity

- 3–5 relevant examples maximum when a corpus is available.
- No obvious boilerplate AI transitions.
- No forced imitation of surface quirks.
- Language sounds native in the target language rather than translated.

## Factual integrity

- External factual claims are sourced or qualified.
- Unsupported numbers, quotes and named attributions are removed.
- Trend popularity is not presented as factual importance.

## Editorial quality

- Each section advances the argument.
- Angle is materially different from the two rejected options.
- Opening earns attention without fabricated drama.
- Ending adds implication or synthesis rather than merely repeating the introduction.
