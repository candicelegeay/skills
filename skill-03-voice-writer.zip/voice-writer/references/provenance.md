# Provenance rules

The writing pipeline has three semantic origins that must remain distinguishable:

1. **User origin**: idea, words, personal experience, user-made inference.
2. **External origin**: research artifacts and trend evidence.
3. **Model origin**: angle suggestions, transitions, structure, synthesis and model-made inference.

The final prose may blend these origins stylistically, but the output metadata must not collapse them semantically.

## Hard rules

- A source can support an external claim, not prove that the user believes it.
- A trend can motivate an editorial angle, not rewrite the user’s thesis.
- A model inference remains an inference until the user confirms it.
- A voice example is evidence of style, not evidence of fact.
- A human edit can supersede model wording while preserving the prior provenance trail.
