from pathlib import Path
import yaml
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def load(rel):
    return yaml.safe_load((ROOT / rel).read_text(encoding="utf-8"))


def assert_valid(instance, schema):
    errors = list(Draft202012Validator(schema).iter_errors(instance))
    assert not errors, "\n".join(e.message for e in errors)


def test_input_example():
    assert_valid(load("examples/input.example.yaml"), load("schemas/input.yaml"))


def test_output_example():
    assert_valid(load("examples/output.example.yaml"), load("schemas/output.yaml"))


def test_waiting_example():
    assert_valid(load("examples/awaiting-angle.example.yaml"), load("schemas/output.yaml"))
