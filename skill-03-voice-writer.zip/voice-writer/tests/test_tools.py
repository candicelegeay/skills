import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.select_voice_examples import select_voice_examples
from tools.provenance import claim


def test_selector_prioritizes_format_and_caps_at_five():
    examples = [
        {"id": "a", "format": "post", "content": "agents governance"},
        {"id": "b", "format": "article", "content": "agents control governance", "canonical": True},
    ] + [
        {"id": f"x{i}", "format": "article", "content": "unrelated text"} for i in range(10)
    ]
    out = select_voice_examples({"core_claim": "agents control governance"}, "article", examples, 5)
    assert len(out) == 5
    assert out[0]["id"] == "b"


def test_provenance_rejects_unknown_label():
    try:
        claim("x", ["NOPE"])
    except ValueError:
        pass
    else:
        raise AssertionError("unknown label should fail")
