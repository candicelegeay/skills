# Change log

## 1.0.0 — 2026-10-21
- Reconstructed portable voice-writer skill based on available original skill specification and four author-provided samples.
- Separates analytical voice, modern idiomatic English, venue-specific register, and evidence provenance.
- Adds anti-AI prose safeguards and an explicit policy against treating co-written AI drafts as authentic author samples.
- Initial profile **prepared for user review**; has not been installed into a pre-existing private skill.
