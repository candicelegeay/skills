# Evidence from real author-written texts

This file contains **short quotations from authentic writing** with a description of what they demonstrate. Samples are not generic text to reuse or copy. The two English documents are older student essays; their mistakes are not style targets.

## E1 | English historical essay: Norman Conquest
Source: `Essay.doc`, user-authored, original English.

> "1066 is perceived as the turning point of English history. The consequences of this conquest still being strongly noticeable in Britain's society, it might be legitimate to assume that this is true. However, a closer look at today's Britain has us wonder whether a sole event is powerful enough to beget such a complex society or if it is rather a gathering of events."

Signal: accepts intuitive claim as plausible, then immediately explores whether a single cause can explain a complex system. **Preserve the dialectical logic, not the literal idiom or syntax.**

## E2 | English social analysis: British class identity
Source: `Essay n°2 LA14.pdf`, user-authored, original English.

> "Nonetheless, the class system has evolved. Indeed, it seemed irrelevant to keep using income tied to occupation as criteria in a society where handy jobs ... could now earn more than a medium manager. Thus, using new criteria entails a deeper stratification of classes."

Signal: attention to categories that change over time, to the limits of existing metrics, and to social mechanisms. **Preserve the conceptual shift; correct grammatical and idiomatic issues.**

## F1 | French analytical paper: La Poste, resilience
Source: `Note personnelle - EI04 - .pdf`, user-authored, French.

> "Le terme est parfois galvaudé, pouvant à la fois faire référence à la capacité d’une entité à résister à des évènements et à la capacité d’une entité à se réinventer. Si les deux notions sont liées, les manières d’approcher et d’agir sont différentes."

Signal: examines a concept that seems obvious, distinguishes neighboring meanings, then explains why the difference matters operationally.

## F2 | French reflective analysis: value-engineering method
Source: `Analyse réflexive TD analyse de la valeur.docx`, user-authored, French.

> "Cela étant dit, étant une méthode assez longue, si elle peut se dérouler sur deux jours, il faut prendre la précaution d’arrêter la méthode à un endroit judicieux [...]"

Signal: concrete, conditional evaluation. A tool can have strengths but require safeguards or adaptation in real practice. The author connects benefits and implementation costs.

## Explicit contemporary editorial preferences (not raw writing samples)
- Thought leadership about AI should remain prospective, nuanced and technically informed; distinguish observed facts, thought experiments and normative proposals.
- Medium drafts are targeted around 1,200–1,300 words unless otherwise specified.
- The user repeatedly asked for fewer AI-like paragraph breaks, less repetition and more natural argumentative prose.
- LinkedIn announcements should balance seriousness with light energy; user rejected both overly jokey and overly formal versions.
- Avoid recasting a complex discussion as a 'hot take' and avoid expanding scope when the user's request is editorial condensation.

## Caution
The prior Second Brain series was co-written with an AI assistant. It can provide user-validated **topic framing and editorial feedback**, but should not be treated as unambiguous, independently user-authored evidence of voice.
