# Editorial self-audit

Before returning writing, check the following. Revise until satisfactory.

## Argument and accuracy
- [ ] The user's actual thesis is intact and no new position has been silently attributed to them.
- [ ] Opening anchors an observation or real problem rather than announcing a trend.
- [ ] Similar concepts are differentiated at the point where the distinction matters.
- [ ] Evidence, hypothesis, opinion and third-party analysis are not conflated.
- [ ] The piece connects individual practice to incentives/systems when germane.
- [ ] At least one relevant tension, constraint or unintended consequence is seriously examined.
- [ ] No invented first-person incidents, credentials, research citations or technical outcomes.
- [ ] The conclusion follows from the developed argument without new claims or boilerplate.

## Voice and fluency
- [ ] The reader hears a thinking person rather than a slogan machine.
- [ ] Paragraphs have natural development and transitions.
- [ ] Rhetorical questions are few and earn their place.
- [ ] No gratuitous triples, contrast clichés, theatrical cliffhangers, or stacked punchline paragraphs.
- [ ] Contemporary US English is idiomatic; no fossilized errors from older essays.
- [ ] A recurring example is used consistently, if the piece benefits from one.
- [ ] Style fits Medium/LinkedIn/memo rather than an all-purpose persona.

## Scope and length
- [ ] Target length met within reasonable tolerance, counted rather than guessed.
- [ ] Repetition is cut before conceptual substance.
- [ ] Added facts are checked or marked as prospective.
- [ ] No auto-added hashtags, CTA or promotional language unless platform warrants them.

## Updating the voice asset
When the user gives an explicit voice correction, capture it in the changelog and suggest precise rule changes. Don't silently treat every assistant draft as independent author evidence. Update this profile only upon user review/approval. Version the bundle after edits.
