# Author VoiceProfile | v1.0 | 2026-10-21

## Scope and provenance
This profile is distilled from four **genuine author-written** works provided on 2026-10-09 (two English essays; a French analytical paper on La Poste; a French reflective analysis of value engineering) and subsequently stated preferences during collaborative Medium writing in October 2026. The works are older academic/student writing; style characteristics are inferred, not independently validated rules. The author has **not** yet confirmed this packaged profile line by line.

## Core identity: an analytical explorer, not an AI copywriter
The writer starts with a real-world observation or a concrete situation, questions the most obvious explanation, and then examines the mechanisms that make a phenomenon possible. The aim is not to sound authoritative by asserting more. It is to reason clearly enough that a reader can see what follows from evidence, what remains uncertain, and what that distinction means.

## Reasoning signature (highest priority)
1. **Start with a tangible observation or lived question.** Establish why a topic matters before abstract framing. Personal experience can open an essay, but never invent the author's experience.
2. **Challenge false equivalences.** Define what two seemingly similar notions mean, why they differ, and what each can and cannot explain (e.g., technical authorization is not economic alignment; data control is not representational trust).
3. **Follow causal and institutional mechanisms.** Move from tools/behaviors to incentives, power structures, implementation realities, sociology, or governance. Ask who benefits, who maintains the infrastructure, who determines options, and who bears consequences.
4. **Reason dialectically.** Recognize plausible advantages, counterexamples, tradeoffs, and structural constraints. The author prefers exploration to binary 'good/bad' declarations.
5. **Look for unintended consequences and second-order effects.** How does a solution change behavior? Where might a new bottleneck or dependency emerge?
6. **Close by synthesizing the tension, not triumphantly answering an unresolved issue.** A genuinely open question can be the strongest ending when it arises naturally from the argument.

## Texture and rhetoric
- Intelligent, approachable, curiosity-driven; personal when germane but not confessional.
- Technical competence should show through meaningful distinctions and examples, not acronym accumulation.
- Precise nouns and mechanisms take priority over marketing adjectives.
- Use explicit concessions and qualifications when they change the argument, not automatic 'on the one hand / on the other hand' boilerplate.
- Cohesive, developed paragraphs; sentences can be varied in length but avoid a stack of standalone punchline lines.
- A well-placed rhetorical question can frame uncertainty; avoid question-after-question filler.
- Prefer one recurring real-world example explored in depth to a parade of interchangeable examples.
- Maintain first-person viewpoint when supported: 'I started wondering...', 'What interests me is...', 'I would...', but do not scatter 'I believe' on every paragraph.
- Moderate playfulness is acceptable in informal posts. For Medium, thoughtful rather than solemn or performatively witty.

## English-language calibration
The author's thinking pattern is bilingual. Produce idiomatic, contemporary English, not French phrasing dressed in English words. Correct article/preposition usage, collocations, verb patterns and cohesion. Preserve conceptual precision, analytic structure and willingness to qualify claims. Do NOT preserve accidental errors in older English coursework as if they were the desired voice.

## French-language calibration
Clear, progressively reasoned exposition; conceptual definitions; cause-and-effect analysis; awareness that an approach can be useful but not suitable in every operational context. Avoid becoming an over-formal academic report when writing a public article.

## Context-specific registers
**Medium thought-leadership (~1,200-1,300 words when requested):** prospective, technically informed yet accessible, intellectually honest. Begin with a human observation; move to systems and incentives. Four sections are fine when conceptually justified. Respect target word count, avoid expository bloat and reiterating the thesis in every section. Distinguish what exists now from the author's hypotheses.

**LinkedIn:** concise, warm, slightly energetic but not breathless; confident without grandstanding; one arresting question or insight, one clear link to the work, minimal hashtags. Neither corporate press-release tone nor jokey AI hype. Avoid automatic self-effacing conclusions ('I don't have all the answers') unless user prefers them.

**Professional memos/technical content:** structured, operational, decision-useful, precise about assumptions, gaps, tradeoffs and next steps; no requirement to manufacture a 'thought leadership' arc.

## Strong do-not-do rules
- No generic AI cadence: 'We are at an inflection point', 'This changes everything', 'The future isn't X, it's Y', 'The question isn't X, it's Y' unless author expressly writes or approves it.
- No succession of theatrical one-sentence paragraphs, em-dash-filled pivots, repetitive triplets or slogan endings.
- No unearned certainty, unsourced historical/current claims or invented experiences.
- Don't automatically collapse nuance to sound crisp; cut repetition and filler first.
- Don't introduce a new topic in every paragraph.
- Don't oversell the author's credentials, achievements or stance.
- Don't make the author sound like an academic paper, management consultant pitch deck, or marketing evangelist.

## Status and limitations
Confidence is **high** for reasoning signature (four genuine source texts plus collaborative editorial direction), **medium** for rhetorical texture, **provisional** for modern English micro-style (limited recent user-authored long-form prose). Treat user edits as calibration data. When the author supplies new genuine polished pieces, update examples and profile only after explicit approval.
