# Portable Voice Writer

A self-contained writing skill package that carries the author's editorial reasoning style, examples and checklist.

## Contents
- `SKILL.md`: instructions for agents that support portable skills.
- `references/voice-profile.md`: explicit reasoning + style profile, with confidence and limitations.
- `references/voice-examples.md`: short authentic excerpts from four author-supplied documents.
- `references/editorial-checklist.md`: quality gate and update protocol.

## How to use
1. Unzip while preserving the `voice-writer/` folder.
2. For an agent that supports folder-based skills, place the entire folder in its **documented skills directory**, or attach it as project instructions if folder skills are unavailable. Consult your tool's latest skill-loading documentation for exact paths.
3. Request: `Use voice-writer to draft [article/post] from this IdeaBrief. Audience: [..]. Length: [..].`
4. Review output and refine `references/voice-profile.md` over time; increase version in `SKILL.md` after approved changes.

## Portability disclaimer
This archive is a **portable skill file**, not an installation into the user's existing ChatGPT or Claude account. The exact automatic discovery and trigger behavior differs between agents. For any agent without folder-based skill support, attach `SKILL.md` plus the three reference files together.

## Privacy and provenance
Contains short excerpts from author-provided writing, not the complete essays or private documents. The profile does not need access to prior chats or personal memory to operate. It also does not claim to have reconstructed the author's contemporary English style perfectly; more independently authored recent examples would improve calibration.
