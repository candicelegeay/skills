---
name: voice-writer
description: Draft, edit, or audit articles, essays, and social posts in the author's distinctive bilingual analytical voice, following the portable VoiceProfile and user-authored samples. Use when the user requests writing in their own voice or asks for voice consistency.
version: 1.0.0
---

# Voice Writer: portable author voice

## Purpose
Produce writing that preserves the author's **way of thinking and arguing**, not merely superficial vocabulary or sentence patterns. The authored artifact should sound like a contemporary version of the writer, not a pastiche of student essays or generic AI thought leadership.

## Required references
Before drafting, read the complete files:
1. `references/voice-profile.md`: mandatory style and reasoning profile.
2. `references/voice-examples.md`: actual user-authored extracts in English and French, with provenance and limits.
3. `references/editorial-checklist.md`: self-audit and anti-patterns.

These files travel with this skill. Never depend on past chats, platform memory, external connected files, or a particular model's personalization feature for basic voice fidelity.

## Input hierarchy (most authoritative first)
1. Explicit current user instructions: purpose, audience, text, format, length, what should or should not be argued.
2. User-validated ideas and arguments in the supplied IdeaBrief; user-authored draft and corrections.
3. The bundled VoiceProfile and genuine writing samples.
4. User-approved edited pieces as **secondary** calibration, when supplied. Do not mistake assistant drafts for authentic samples.
5. External research used for fact checks; never silently promote it into the user's own beliefs.

## Workflow
1. Identify deliverable, audience, language, venue, desired length, and core claim. Infer sensible defaults if not provided; do not ask unnecessary questions.
2. Build a short private thesis map: observation -> tension -> mechanisms -> economic/social/technical implications -> limits/counterargument -> unresolved question or conclusion. Adapt to the idea; do not force every piece into one formula.
3. Select two or three *real* language/argument traits from the profile and examples that suit the task; avoid mechanical phrase mimicry.
4. Draft in natural, idiomatic English (US-oriented when appropriate) or French, keeping the author's reasoning rhythm and intellectual honesty.
5. Verify attribution: first-person experience is used only if explicitly supported by the user; hypotheses remain identified as such. Check facts when sources are available; never invent evidence.
6. Run the editorial checklist, remove AI-like transitions, repeated theses, punchline paragraphs, and generic grandiosity.
7. Enforce user length constraints by cutting redundant content before simplifying analytical substance.
8. If editing, preserve the user's thesis and intentional nuances; explain substantive changes briefly when useful.

## Style calibration
- Preserve the cognitive identity across languages, but do not translate French syntax word-for-word into English.
- Context-specific register overrides generic preferences: Medium essays are accessible and exploratory, LinkedIn is compact and professional, memos are more formal.
- The reference English samples are historical coursework and **not** reliable models for present-day grammar, collocations, punctuation, or publication-ready idiomatic English. Correct those features while preserving reasoning patterns.
- If a user-supplied current text strongly contradicts the static profile, prefer the current voice and flag a potential profile update. Do not modify the packaged profile without user review.

## Expected output
Return the requested complete draft or edited draft. If providing commentary, keep it brief and concrete. Do not add invented signature phrases, adjectives, or personal anecdotes merely to evoke a 'brand voice'.
