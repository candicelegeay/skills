# A2FCP12 brochure final draft to use.pdf

## Contents
- PDF page 1: 1 / A2FCP12 – Cultures et pratiques de l'écrit dans le monde anglophone
- PDF page 2: 2 / Table of Contents:
- PDF page 3: 3 / Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS
- PDF page 4: 4
- PDF page 5: 5
- PDF page 6: 6
- PDF page 7: 7
- PDF page 8: 8
- PDF page 9: 9 / UNIT I:
- PDF page 10: 10 / A. Ten Rhetorical Modes for Essay-Writing
- PDF page 11: 11 / 1. narration & anecdote
- PDF page 12: 12
- PDF page 13: 13
- PDF page 14: 14
- PDF page 15: 15
- PDF page 16: 16
- PDF page 17: 17 / 2. description:
- PDF page 18: 18 / boxes of materials scattered about and a small forklift pushed in a corner. Maud doesn’t touch any of
- PDF page 19: 19 / sanctions for asserting their right to live and run—shit—to exist in the world. Ask why? Ask why?
- PDF page 20: 20 / Maud, fleeing now for no less than six minutes, runs toward a red-faced Travis McMichael who stands
- PDF page 21: 21 / what he couldn’t have known was an unarmed white man behind him. Glynn County police officers
- PDF page 22: 22 / On February 23, 2020, a young man out for a run was lynched in Glynn County, Georgia. […]
- PDF page 23: 23 / 3. division or analysis (breaking something down into parts)
- PDF page 24: 24 / sexually faithful to me so that I do not have to clutter up my intellectual life with jealousies. And I
- PDF page 25: 25 / 4. classification (sorting the subject into different groups or kinds)
- PDF page 26: 26 / The third way open to oppressed people in their quest for freedom is the way of nonviolent resistance.
- PDF page 27: 27 / 5. comparison & contrast
- PDF page 28: 28
- PDF page 29: 29
- PDF page 30: 30
- PDF page 31: 31
- PDF page 32: 32 / 6. providing examples
- PDF page 33: 33 / chests bandolier style, they forge ahead as though bracing themselves against being talked. I
- PDF page 34: 34 / in the evening. I give a wide berth to nervous people on subway platforms during the wee hours,
- PDF page 35: 35 / 7. process analysis (explaining ‘how to’ do something step by step)
- PDF page 36: 36 / no vitamin D. In Edmonton (52°N) this period extended from October to March. But further south
- PDF page 37: 37 / 8. definition (tracing a boundary and providing information)
- PDF page 38: 38 / Millions of Jews were systematically slaughtered, as were untold other “undesirables”, not for any
- PDF page 39: 39 / 9. cause and effect (showing a logical chain of events)
- PDF page 40: 40
- PDF page 41: 41
- PDF page 42: 42
- PDF page 43: 43
- PDF page 44: 44
- PDF page 45: 45
- PDF page 46: 46
- PDF page 47: 47
- PDF page 48: 48
- PDF page 49: 49
- PDF page 50: 50 / 10. argument (persuading the reader to side with your opinions)
- PDF page 51: 51 / We cannot be satisfied as long as the colored person’s basic mobility is from a smaller ghetto to a
- PDF page 52: 52 / This will be the day when all of God’s children will be able to sing with new meaning “My country
- PDF page 53: 53 / B. Fallacies of Reasoning – General list of Fallacies
- PDF page 54: 54 / -Gaslighting
- PDF page 55: 55 / 9. “I cannot imagine someone as important as the Vice-President being involved in something so
- PDF page 56: 56 / 12. “Listen, Mom, how can you say that it is un-American to accept government money and aid when
- PDF page 57: 57 / C. Tips on Writing College Papers
- PDF page 58: 58
- PDF page 59: 59
- PDF page 60: 60
- PDF page 61: 61
- PDF page 62: 62
- PDF page 63: 63 / UNIT II:
- PDF page 64: 64
- PDF page 65: 65
- PDF page 66: 66
- PDF page 67: 67
- PDF page 68: 68
- PDF page 69: 69
- PDF page 70: 70
- PDF page 71: 71
- PDF page 72: 72
- PDF page 73: 73
- PDF page 74: 74
- PDF page 75: 75
- PDF page 76: 76
- PDF page 77: 77
- PDF page 78: 78
- PDF page 79: 79
- PDF page 80: 80
- PDF page 81: 81
- PDF page 82: 82
- PDF page 83: 83
- PDF page 84: 84
- PDF page 85: 85
- PDF page 86: 86
- PDF page 87: 87
- PDF page 88: 88
- PDF page 89: 89
- PDF page 90: 90
- PDF page 91: 91 / B. Sample News Articles
- PDF page 92: 92 / men who did the same. What over the past decade has caused young women to lurch so dramatically
- PDF page 93: 93 / But whatever the reasons, the extent to which young women feel alienated from the rest of the country
- PDF page 94: 94 / MPs across UK Parties Criticise Ministers over Cautious Stance on Venezuela
- PDF page 95: 95 / The MPs’ frustrations were voiced after a tense day of international diplomacy in which Cooper spoke
- PDF page 96: 96 / Some Trumpists Object to MAGA’s White Power Element. Why Now?
- PDF page 97: 97 / And here’s the irony: The same conservative media figures now sounding the alarm helped build the
- PDF page 98: 98 / Fierce Backlash within GOP after Tucker Carlson Gives White Nationalist Nick
- PDF page 99: 99 / “I’m disgusted by this and don’t understand how this premeditated and orchestrated response could
- PDF page 100: 100 / Roberts apologizes to Heritage staff
- PDF page 101: 101 / Tucker Carlson’s Interview with Antisemite Nick Fuentes Exposes Rift among
- PDF page 102: 102 / But the controversy has revealed the ongoing challenge of balancing different factions within the
- PDF page 103: 103 / They Saw Their Neighbors Taken Away by ICE. Then They Made a Plan
- PDF page 104: 104 / Laborer Organizing Network. “All we have are our friends, our allies and ourselves.” One of his
- PDF page 105: 105 / spouses and children who’ve been here for decades, those who’ve followed all the rules in seeking
- PDF page 106: 106 / in masks, wearing civilian clothes, pulling guns against people who are exercising their rights while
- PDF page 107: 107 / ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor
- PDF page 108: 108 / The simple truth is that the low wage/high welfare economy dependent on illegal immigration isn’t
- PDF page 109: 109 / Protests against ICE Have Continued in LA into the Week. Here’s What to
- PDF page 110: 110 / “To the extent that protests or acts of violence directly inhibit the execution of the laws, they constitute
- PDF page 111: 111 / UNIT THREE
- PDF page 112: 112 / Civilization Studies:
- PDF page 113: 113 / The English Turned Barbados into a Slave Society. Now, after 396 Years, We’re
- PDF page 114: 114 / abundant fig trees, which have a beard-like appearance. Others surmised it was down to the presence
- PDF page 115: 115 / As part of the transition, there will be ceremonial activities in National Heroes Square in the capital
- PDF page 116: 116 / Boris Johnson’s Phoney Posturing at the French Won’t Resolve the Migrant
- PDF page 117: 117 / closed off and ways of establishing safer routes, such as allowing asylum applications at UK
- PDF page 118: 118 / is one of the least well-kept secrets in diplomacy that Anglo-French relations are dreadful. Brexit-
- PDF page 119: 119 / Labour Needs Its Own Answer to the Channel Crisis
- PDF page 120: 120 / succeed in getting a grip on the issue – which currently seems a less likely prospect, I’ll grant you –
- PDF page 121: 121 / The UK and France Must Mend Ties – Lives Depend on It
- PDF page 122: 122 / don’t work like that. New treaties can’t be conjured out of the air. They can only be built on trust that
- PDF page 123: 123 / This Is the Real Reason Priti Patel Has Been Barred from France
- PDF page 124: 124 / The migrant crisis is bigger than Britain and indeed bigger than Britain and France. It is precisely the
- PDF page 125: 125 / Boris’s Blundering Brilliance:
- PDF page 126: 126 / future for the U.K. but pioneering a path for other Western parties of the center right confronted by
- PDF page 127: 127 / Post-Brexit, We Need Real Capitalism – Not Stealth Foreign Nationalisation
- PDF page 128: 128 / Civilization Studies:
- PDF page 129: 129 / Remarks at the Democratic National Convention
- PDF page 130: 130 / and adults to get the education and training they need, to make our streets safer, to help Americans
- PDF page 131: 131 / In Defense of Monica
- PDF page 132: 132 / We are also familiar with the linking of sex, lies and tapes. We are a generation whose parents openly
- PDF page 133: 133 / Address on the U.S. Response to the Attacks on September 11
- PDF page 134: 134 / structure, to appropriate authorities. Give the United States full access to terrorist training camps, so
- PDF page 135: 135 / The Renaissance of Anti-Intellectualism
- PDF page 136: 136 / […] In the torrent of popular culture, there emerges more talk about public affairs than ever before--
- PDF page 137: 137 / Speech on Health Care Reform
- PDF page 138: 138 / Now, it is true that providing these tax credits to middle class families and small businesses, that’s
- PDF page 139: 139 / How the US Justifies Drone Strikes: Targeted Killing, Secrecy and the Law
- PDF page 140: 140 / policies relating to military detention and prosecution. It is doubtful that the courts or the public would
- PDF page 141: 141 / Speech Declaring a National Emergency
- PDF page 142: 142 / Donald Trump Is a Good President: One foreigner’s perspective
- PDF page 143: 143 / President Trump tears up treaties and trade agreements when he thinks it was wrong to sign them.
- PDF page 144: 144 / ‘Clueless’ and ‘Saved by the Bell’ Are How We Got Trump:
- PDF page 145: 145 / […] I did not go to the W.T.O. protest partly because my mom told me I couldn’t and partly because
- PDF page 146: 146 / LITERARY STUDIES
- PDF page 147: 147 / Wuthering Heights (1847), Emily BRONTË
- PDF page 148: 148 / Heart of Darkness (1902), Joseph CONRAD
- PDF page 149: 149 / Atonement (2001), by Ian McEwan
- PDF page 150: 150 / He was taking her question seriously. ‘No one’s really going to give me work as a landscape
- PDF page 151: 151 / The Scarlet Letter (1850), Nathaniel HAWTHORNE
- PDF page 152: 152 / birth, with stronger assimilations than the first, had converted the forest-land, still so uncongenial
- PDF page 153: 153 / The Human Stain (2000), Philip ROTH
- PDF page 154: 154 / known perhaps fifty years ago but had wholly forgotten that ‘spooks’ is an invidious term
- PDF page 155: 155 / No Country for Old Men (2005), by Cormac McCarthy
- PDF page 156: 156 / to one of them stunguns like they use at the slaughterhouse. Yessir. Well that’s what it looks
- PDF page 157: 157 / Bibliography:
- PDF page 158: 158 / Kotkin, Joel. “ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor.” Los

## PDF page 1

1 
 
A2FCP12 – Cultures et pratiques de l'écrit dans le monde anglophone 
UE Fondamentale 
Responsables :    Dennis Tredy (dennis.tredy@sorbonne-nouvelle.fr) 
 
Langue principale du cours : anglais   
               Class taught primarily in English 
  
 
 
 
 
 
 
 
Type : TD 
ECTS : 3 
                        Nombre d’heures hebdomadaires : 2 heures (TD) 
 
Course description:  
This course covers the fundamental aspects of academic work in the humanities and social 
sciences and focuses on improving students’ written work in English. In addition to the 
mechanics and proper structure of English expression, students will also learn to develop 
critical thinking skills when studying various types of written documents (historical, literary, 
journalistic writings), in order to construct well-written essays and convincing, well-reasoned 
arguments in English.  
 
Descriptif :   
Cet enseignement porte sur les aspects fondamentaux du travail universitaire dans le domaine 
des humanités et des sciences sociales : apprendre à développer une réflexion critique sur des 
documents de natures différentes (en particulier des sources écrites historiques, littéraires ou 
tirées de la presse anglophone contemporaine), et à maîtriser les mécanismes et la structure 
de l'anglais, pour construire des devoirs structurés et cohérents et pouvoir argumenter 
rigoureusement aussi bien à l'écrit qu'à l'oral. 
 
Œuvres au programme / Set Reading   
Une brochure de textes sera fournie aux étudiants au début du premier cours, contenant un 
recueil d’extraits de texte en anglais de types variés (essai, document historique, discours, 
extrait de presse, etc.). 
NB : Votre enseignant pourra vous donner une bibliographie plus détaillée en cours ou sur 
iCampus. 
 
Type d’évaluation :  
Les note des étudiants sera basée sur le travail produit par l’étudiant pendant le semestre, 
sur un partiel de mi-semestre et par un examen final. 
 
Objectifs / Compétences : 
• 
Faire une rédaction en anglais en appliquant les règles spécifiques au monde anglophone 
en termes de mise en page, ponctuation, construction des paragraphes, représentation 
des dialogues ou des citations, et emploi d'une problématique bien définie, de transitions 
et d'une construction logique de son argumentation. 
• 
Eviter le plagiat et maitriser les bases de la citation des sources et de la notion de propriété 
intellectuelle. 
• 
Lire des articles et des essais d'opinion afin d'analyser leur construction et leur 
argumentation, et pouvoir répondre par une argumentation cohérente. 
• 
Construire une argumentation convaincante en évitant les sophismes, ainsi que les 
erreurs les plus souvent commises par les non-anglophones. 
• 
Explorer des formats d'écriture qui se pratiquent hors du cadre universitaire.  


## PDF page 2

2 
 
Table of Contents: 
An Introduction on Writing: A Writer’s Questions……………………………………………………… 4 
Unit I: The Mechanics of Good Esay-Writing  
A. The Ten Rhetorical Modes & Sample Essays………………………………………………………… 10 
1. narration & anecdote: “Graduation” by Maya Angelou (1969)………………………………………. 11 
2. description: “Twelve Minutes and a Life…” by Mitchell S. Jackson (2020)………………………… 17 
3. division or analysis: “Why I Want a Wife” by Judy Brady-Syfers (1971)……………………………. 23  
4. classification: “Three Types of Resistance to Oppression” by Martin Luther King, Jr. (1958)………. 25 
5. comparison & contrast: “Racism and Recapitulation” by Stephen Jay Gould (1977)………………... 27 
6. providing examples: “Just Walk on By: Black People and Public Space” by Brent Staples (1986)….. 32  
7. process analysis: “How Our Skins Get Their Color” by Marvin Harris (1988)………….…………… 35 
8; definition: “The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979)……………. 37 
9. cause and effect: “Groping toward That Invisible Light” by Richard Wright (1930)………………… 39 
10. argument: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)……………………….. 50 
B. Fallacies of Reasoning – General list of Fallacies……………………………………………………. 53 
     Practice Exercises on Fallacies of Reasoning………………………………………………………… 54 
C. Tips on Writing College Papers………………………………………………………………………. 57 
 
Unit II: Journalistic Writing 
A. The American Journalism Handbook – Concepts, Issues, and Skills, 1st Ed. (Zamith)……………… 64 
B. Sample News Articles 
1. “Young Women are Radicalizing…” by Scarlett Maguire……………………………………………. 91 
2. “MPs across UK Parties Criticise Ministers over Cautious Stance on Venezuela Attack…” by  
Kiran Stacey and Sammy Gecsoyler…………………………………………………………………….. 94 
3. “Some Trumpists Object to MAGA’s White Power Element. Why Now?” by Matt K. Lewis………. 96 
4. “Fierce Backlash within GOP after Tucker Carlson Gives White Nationalist Nick Fuentes a  
Platform” by Andrew Kaczynski and Steve Contorno………………………………………………….. 98 
5. “Tucker Carlson’s Interview with Antisemite Nick Fuentes Exposes Rift among Republicans”,  
PBS News Hour…………………………………………………………………………………………. 101 
6. “They Saw Their Neighbors Taken Away by ICE…” by Michelle Goldberg………………………… 103 
7. “ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor” by Joel Kotkin……… 107 
8. “Protests against ICE Have Continued in LA into the Week...” by Ayana Archie……………………. 109  
 
 
 


## PDF page 3

3 
 
Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS 
A. Civilization Studies: The United Kingdom 
“The English Turned Barbados into a Slave Society…” by Suleiman Bulbulia,  
The Guardian (2021)……………………………………………………………………………………. 113  
“Boris Johnson’s Phoney Posturing at the French Won’t Resolve the Migrant Crisis…” by  
Andrew Rawnsley, The Guardian (2021)……………………………………………………………….. 116 
“Labour Needs Its Own Answer to the Channel Crisis” by Patrick O'Flynn, The Spectator (2021)…… 119 
“The UK and France Must Mend Ties – Lives Depend on It…” by Peter Ricketts, The New  
Statesman (2021)………………………………………………………………………………………… 121 
“This Is the Real Reason Priti Patel Has Been Barred from France” by Sean O’Grady, The  
Independent (2021)………………………………………………………………………………………. 123 
“Boris’s Blundering Brilliance…” by Andrew Sullivan, New York Magazine (2019)…………………... 125  
“Post-Brexit, We Need Real Capitalism – Not Stealth Foreign Nationalisation” by Allister Heath,  
The Telegraph (2019)……………………………………………………………………………………. 127 
B. Civilization Studies: The United States 
“Remarks at the Democratic National Convention” by Bill Clinton, Aug. 29, 1996……………………. 129 
“In Defense of Monica” by Amelia Richards and Jennifer Baumgardner, The Nation (1998)………….. 131  
“Address on the U.S. Response to the Attacks on September 11” by George W. Bush, Sept. 22, 2001… 133 
“The Renaissance of Anti-Intellectualism” by Tod Gitlin, Chronicle of Higher Education (2000)…….. 135 
“Speech on Health Care Reform” by Barack Obama, March 15, 2010…………………………………. 137 
“How the US Justifies Drone Strikes…” by Jameel Jaffer, The Guardian (2016)……………………… 139 
“Speech Declaring a National Emergency” by Donald Trump, Feb. 15, 2019………………………….. 141 
“Donald Trump Is a Good President: One Foreigner’s Perspective” by Michel Houellebecq,  
John Cullen (Translator), Harper’s Magazine (2019)…………………………………………………… 142 
“‘Clueless’ and ‘Saved by the Bell’ Are How We Got Trump…” by Lindy West, The New York  
Times (2019)…………………………………………………………………………………………….. 144 
C. Literary Studies (excerpts) 
Wuthering Heights (1847), by Emily Brontë……………………………………………………………. 147 
Heart of Darkness (1902), by Joseph Conrad…………………………………………………………… 148 
Atonement (2001), by Ian McEwan……………………………………………………………………… 149 
The Scarlet Letter (1850), by Nathaniel Hawthorne…………………………………………………….. 151 
The Human Stain (2000), by Philip Roth……………………………………………………………….. 153 
No Country for Old Men (2005), by Cormac McCarthy………………………………………………… 155 
 
Bibliography…………………………………………………………………………………………….. 157 
 


## PDF page 4

4 
 
 
 


## PDF page 5

5 
 
 
 
 
 
 
 


## PDF page 6

6 
 
 
 
 
 
 
 


## PDF page 7

7 
 
 
 
 
 
 
 
 
 


## PDF page 8

8 
 
 
 
 
 
 
 
 
 


## PDF page 9

9 
 
 
 
 
 
 
UNIT I: 
THE MECHANICS OF  
GOOD ESSAY-WRITING 
 
 
 


## PDF page 10

10 
 
A. Ten Rhetorical Modes for Essay-Writing 
 
The ten following essays each correspond to one of the ten main ‘rhetorical modes’ for composition 
writing: 
 
1. narration & anecdote 
sample essay: 
“Graduation” by Maya Angelou (Chapter 23 of I Know Why the Caged Bird Sings, 1969) 
 
2. description 
sample essay: 
“Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was gunned down in the street. 
How running fails Black America” by Mitchell S. Jackson (2020) 
 
3. division or analysis (breaking something down into parts) 
sample essay: 
“Why I Want a Wife” by Judy Brady-Syfers (1971) 
 
4. classification (sorting the subject into different groups or kinds) 
sample essay: 
“Three Types of Resistance to Oppression” by Martin Luther King, Jr. (1958) 
 
5. comparison & contrast 
sample essay: 
“Racism and Recapitulation” by Stephen Jay Gould (1977) 
 
6. providing examples 
sample essay: 
“Just Walk on By: Black People and Public Space” by Brent Staples (1986)  
 
7. process analysis (explaining ‘how to’ do something step by step) 
sample essay: 
“How Our Skins Get Their Color” by Marvin Harris (1988) 
 
8. definition (tracing a boundary and providing information) 
sample essay: 
“The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979) 
 
9. cause and effect (showing a logical chain of events) 
sample essay: 
“Groping toward That Invisible Light” by Richard Wright (1930) 
 
10. argument (persuading the reader to side with your opinions) 
sample essay: 
“I Have a Dream” by Martin Luther King, Jr. (August 28, 1963) 
 
 


## PDF page 11

11 
 
1. narration & anecdote 
 
“Graduation” by Maya Angelou (Chapter 23 of I Know Why the Caged Bird Sings, 1969) 
 
 


## PDF page 12

12 
 
 
 
 


## PDF page 13

13 
 
 
 


## PDF page 14

14 
 
 
 


## PDF page 15

15 
 
 
 
 


## PDF page 16

16 
 
 
 
 
 
 


## PDF page 17

17 
 
2. description:  
 
Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was gunned 
down in the street. How running fails Black America  
By Mitchell S. Jackson, Jun 18, 2020  
Imagine young Ahmaud “Maud” Arbery, a junior varsity scatback turned undersized varsity 
linebacker on a practice field of the Brunswick High Pirates. The head coach has divided the squad 
into offense and defense and has his offense running the plays of their next opponent. The coach, as 
is his habit, has been taunting his defense. “Y’all ain’t ready,” he says. “You can’t stop us,” he says. 
“What y’all gone do?” The next play, Maud, all 5 feet 10 inches and 165 pounds of him, bursts 
between blockers and— BOOM!—lays a hit that makes the sound of cars crashing, that echoes across 
the field and into the stands, that just might reach the locker room. It’s a feat that teenage Maud also 
intends as a message to his coaches, his teammates, and all else that ain’t hitherto hipped: Don’t test 
my heart. […]  
That Friday, in Glynn County Stadium (one of the largest high school stadiums in all of gridiron-
loving Georgia) the Pirates, clad in their home white jerseys with blue and gold trim, huddle in the 
locker room. Maud, who wears high shoulder pads, a 2x4 face mask, and number 21 in honor of his 
brother, Buck, and his idol, famed NFL safety Sean Taylor, swaggers into the center of his teammates 
and begins the chant he’s christened into a pre-game ritual.  
“Y’all ready!” he shouts.  
“Hell yeah!” they shout.  
“Y’all ready!” he shouts.  
“Hell yeah!” they shout.  
“Y’all ain’t ready?!” he shouts.  
“Sheeeeeit!” they shout.  
To applause that could be thunder, the team stampedes out of the fog-filled mouth of a blow-up tunnel 
onto the field. The school band plays the fight song and cheerleaders shake pom-poms from a row in 
front of the band. There’s a raucous sea of blue and gold in the stands, including plenty of Maud’s 
people. Game time, the opposing team calls the play that Maud put the fierce kaput on in practice, 
and beneath a metal-halide glare that’s also a gauntlet, Maud barrels towards the running back and—
BOOM!—lays a hit that sounds like trucks colliding. It’s a noise that resounds across the field and 
into the stands, that just might ring all over Brunswick. The fans send up a roar but Maud trots to the 
sidelines almost insouciant. Jason Vaughn, an assistant coach who also coached Maud on JV, grabs 
him by his face mask. “Now that’s how you hit,” he says, tamping astonishment that a boy his size 
could hit that hard.  
But that’s young Maud, undersized in the physical sense, super-sized in heart.  
Sunday, February 23, 2020 | 1:04pm Time-stamped security footage from an adjacent home shows 
Maud, who’s out for a run in Brunswick’s Satilla Shores subdivision, wandering up a sunny patch of 
narrow road and stopping on the spotty lawn of a sand-colored under-construction bungalow 
addressed 220 Satilla Drive. There’s a red portable toilet in the front yard. The garage is wide open.  
Ahmaud, dressed in light-colored low-top Nikes, a white t-shirt, and khaki cargo shorts, loafs on the 
lawn for a moment before drifting into the building. The security camera records him inside the home, 
a brightened skeleton of beams and plywood and stacks of sheetrock and piping and wire. There are 


## PDF page 18

18 
 
boxes of materials scattered about and a small forklift pushed in a corner. Maud doesn’t touch any of 
those things. He looks around, gazes beyond the frame of the camera toward the river behind the 
house.  
Maybe he wonders what the home will look like when it’s finished. Maybe he conjures an image of 
a family who could afford to live in a place so close to water.  
Maud ain’t the first person to wander onto the site. Its security cameras have recorded others including 
a white couple one evening and a pair of white boys one day. On four occasions, it also recorded what 
appears to be the same person: a slim young Black man with wild natural hair and tattoos on his 
shoulders and arms, a dude, that by my eye, don’t resemble Maud. Let me add that the homeowner 
will confirm that nothing was stolen or damaged during any of the visits.  
Meanwhile, a coveralled neighbor spies Maud roaming the site and calls 9-1-1. “There’s a guy in the 
house right now,” he reports. “It’s a house under construction. 219 or 220 Satilla Drive.” The man 
waits near the corner of Jones Road and Satilla Drive. “I just need to know what he’s doing wrong,” 
says the dispatcher. “He’s been caught on the camera a bunch before. It’s kind of an ongoing thing 
out here,” says the caller. It’s a statement of which he can’t be sure, though he does get right Maud’s 
physical description: “Black guy, white t-shirt.”  
To fathom what it meant for Maud to be out for a run in Glynn County, you need to know a thing or 
two about the pastime of recreational running. Before the 1960s, the idea of jogging for almost 
everybody save serious athletes was this: Now why would I do that? But in 1962, legendary track 
coach and Nike co-founder Bill Bowerman visited New Zealand and met with fellow coach Arthur 
Lydiard who’d developed a cross-country training program. Bowerman returned to the States excited 
by what he’d seen. He launched a similar program in Eugene (home of his alma mater and employer, 
the University of Oregon), wrote a pamphlet on the subject in 1966, and the next year, published a 
co-written book titled Jogging: A Medically-Approved Physical Fitness Program for all Ages 
Prepared by a Heart Specialist and a Famous Track Coach. That book became a bestseller and 
kickstarted jogging as an American pastime.  
Let me acknowledge that I am one of the rarest of Americans, one otherwise known as a Black 
Oregonian. As such, I feel compelled to share a truth about my home state: It’s white. I’m talking 
banned-Blacks-in-its-state-constitution white. At the time that Bowerman was inspiring Eugene 
residents to trot miles around their neighborhoods in sweatpants and running shoes, Eugene was a 
stark 97 percent white. One could argue that the overwhelming whiteness of jogging today may be, 
in part, a product of Eugene’s demographics. But if we’re keeping it 100, the monolithic character of 
running can be credited to the ways in which it’s been marketed and to the systemic forces that have 
placed it somewhere on a continuum between impractical extravagance and unaffordable hazard for 
scores of people who ain’t white.  
Matter of truth, around the time Bowerman visited New Zealand and published a bestselling book, 
millions of Blacks were living in the Jim Crow South; by 1968, Blacks diaspora-wide had mourned 
the assassinations of Medgar Evers, Malcolm X, and Martin Luther King Jr. And by the late ’60s and 
beyond, the Blacks of the Great Migration were redlined into ever more depressed sections of northern 
and western cities, areas where the streets were less and less safe to walk, much less run. Forces 
aplenty discouraged Blacks from reaping the manifold benefits of jogging. And though the 
demographics of runners have become more diverse over the last 50 years, jogging, by and large, 
remains a sport and pastime pitched to privileged whites.  
Peoples, I invite you to ask yourself, just what is a runner’s world? Ask yourself who deserves to run? 
Who has the right? Ask who’s a runner? What’s their so-called race? Their gender? Their class? Ask 
yourself where do they live, where do they run? Where can’t they live and run? Ask what are the 


## PDF page 19

19 
 
sanctions for asserting their right to live and run—shit—to exist in the world. Ask why? Ask why? 
Ask why?  
Ahmaud Arbery, by all accounts, loved to run but didn’t call himself a runner. That is a shortcoming 
of the culture of running. That Maud’s jogging made him the target of hegemonic white forces is a 
certain failure of America. Check the books—slave passes, vagrancy laws, Harvard’s Skip Gates 
arrested outside his own crib—Blacks ain’t never owned the same freedom of movement as whites.  
Sunday, February 23, 2020 | 1:08pm Maud strolls out the house and in just a few steps, begins to 
jog. He’s unaware of the witness who called 9-1-1, a man still surveilling him. “He’s running right 
now. There he goes right now,” says the witness to dispatch. “Okay, what is he doing?” says the 
dispatcher. “He’s running down the street,” says the man. The footage shows Maud jogging past the 
Satilla Drive home of Gregory and Travis McMichael—a father and son. Gregory McMichael, an ex-
cop stripped of his power to arrest for failure to attend use-of-force training, notices Maud passing 
his house and deems him suspicious. “Travis, the guy is running down the street,” he hollers. “Let’s 
go.” For reasons the McMichaels must now account for in court (both have been indicted on nine 
counts, including felony murder and aggravated assault), they arm themselves—the son with a 
Remington 870 shotgun and the father with a .357 Magnum—and hop in a white Ford pickup truck.  
The Golden Isles lie along Georgia’s Atlantic coast between Savannah and Jacksonville, Florida. The 
region encompasses the barrier islands of St. Simons, Sea Island, Little St. Simons, and Jekyll, as 
well as the mainland cities of Darien and Brunswick. Satilla Shores, part of the Golden Isles, is an 
unincorporated neighborhood of upper- and middle-class families; of blue- and white-collar retirees; 
of seasonal vacation-home owners and lifelong denizens; of fresh transplants. The small 
neighborhood features narrow roads canopied by moss-draped live oaks, tall Southern Pines, and 
crepe *myrtle; and one- and two-story homes with landscaped lawns and driveways parked with late-
model vehicles and boats. Homes on one side of Satilla Drive—the neighborhood’s main street—
boast as a backyard amenity, the sediment-colored Little Satilla River, replete with its miles-wide 
spartina salt marshes.  
Maud’s family home in Brunswick, the one where he lived at the time he was murdered, is a mere 
two miles from Satilla Shores, but in meaningful ways, it’s almost another country. The median 
household income for all of Glynn County is $51,000; in Brunswick that figure is $26,000. The 
poverty rate of what young Black residents call “The Wick” is a staggering 38 percent. […]  
Sunday, February 23, 2020 | 1:10pm The McMichaels, both strapped, tear off after Maud in their 
pickup, stalk him down Burford Road, another narrow street shaded by lush oaks, pines, and 
magnolias. From his front yard, William “Roddie” Bryan, sees his neighbors hounding Maud, and for 
reasons he’ll have to answer for in court (he’s been indicted on nine counts, including felony murder 
and criminal attempt to commit false imprisonment), jumps in his pickup and joins them. The 
McMichaels race ahead of Maud and try to cut him off, but Maud doubles back—maybe recalling all 
the times he’s eluded a would-be tackler—only to find himself facing down Bryan’s pickup. Bryan 
tries to block Maud, but he skirts the truck, and huffs around a bend onto Holmes Road. The elder 
McMichael, Gregory, climbs from the cab to the bed of his son’s truck, the one with a Confederate 
flag on its toolbox, armed with his .357. They track Maud as he sprints down Holmes Road. […]  
Sunday, February 23, 2020 | 1:14pm Cell phone footage captures Maud on Holmes Road, bolting 
away from Bryan’s pickup but toward the McMichael’s white pickup. Bryan, about this time, pulls 
out his cell phone and starts to film. Meanwhile, Gregory McMichael calls 9-1-1. “Uh, I’m out here 
at Satilla Shores,” he tells dispatch. “There’s a Black male running down the street.” The dispatcher 
asks where. “I don’t know what street we’re on,” he says. “Stop right there. Dammit. Stop!” the tape 
records him yelling at Maud.  


## PDF page 20

20 
 
Maud, fleeing now for no less than six minutes, runs toward a red-faced Travis McMichael who stands 
inside the door of his truck with his shotgun aimed, toward Gregory McMichael perched in the truck 
bed with his gun in hand, runs into what must feel like a trap, but perhaps feels like another time his 
courage has been tested. Maud zags one way and the other. He darts around the right side of the truck 
and crosses in front of the hood. Travis McMichael heads him off at the nose of the truck and shoots  
Maud in no more than a heartbeat. The blast cracks over Bryan’s cell footage. “Travis!” screams 
Gregory McMichael and he drops his phone in the truck bed.  
The buckshot blast hits Maud in the chest, puncturing his right lung, ribs, and sternum. And yet 
somehow, he wrestles with Travis McMichael for the shotgun, and yet somehow, he manages to punch 
at him. Gregory watches for a moment from his roost. Meanwhile, Bryan continues to film. Travis 
fires his shotgun again, a blast that occurs outside the view of Bryan’s phone, but sends a spray of 
dust billowing into the frame. Maud, an island of blood now staining his white t-shirt, continues to 
tussle with Travis McMichael, fighting now for what he must know is his life. In the midst of the 
scuffle, Travis McMichael blasts Maud again point blank, piercing him in his upper chest. Maud 
whiffs a weak swing, staggers a couple of steps, and falls face down near the traffic stripes. Travis, 
shotgun in hand, backs away, watches Maud collapse, and makes not the slightest effort to tend him. 
His father, still clutching his revolver, runs to where Maud lies facedown, blood leaking out of his 
wounds.  
Maud jogged alone on the day he was killed. No one can know for sure the route he took before 
reaching Satilla Shores, but he’d set off from his home, which means there’s a strong chance that on 
his run he encountered homes flying a Confederate flag or a Gadsden flag (“Don’t Tread on Me”), 
homes tacked with No Trespassing signs. To reach Satilla Shores from Boykin Ridge, he would’ve 
also had to cross US Route 17, a highway that for years served as a de facto county border between 
the area’s Blacks and whites.  
Maud had been running for years, but the origin of his practice lacks consensus. According to his 
sister, Jasmine, who was once an avid runner, sometime in 2017 Maud asked her how many miles a 
day she ran and soon after, began doing it himself. She says it was natural for her brother since he 
loved the outdoors and “wanted a release.” Akeem agrees that Maud used running as a kind of therapy, 
but thinks his main motivation was staying fit after football. This theory would locate the timing of 
when he began running to a few years before 2017.  
Maud would run in a white t-shirt and khaki shorts. He’d run shirtless in basketball shorts. He’d run 
in a tank top and basketball shoes. Or as Keem sums it, “He could run in anything.” Sometimes Maud 
would persuade his boy J.T. who “doesn’t like running all like that,” and a couple of other homeboys 
to ride out to the North Glynn Country Recreational Complex and run miles around the park’s 
freshwater lake. Other times, when Keem was home from college, he and Maud would cruise to one 
end of the Sidney Lanier Bridge—the longest spanning bridge in all of Georgia—do some warm-up 
stretching and run back and forth across it, a distance of just under three miles. The pair would keep 
a steady pace. “But sometimes he’d push me,” Akeem says.  
There’s no evidence of Maud training for 10Ks or full or half marathons or obsessing over his miles 
or PR times. And yet it’s obvious that he was a young man who loved to run and who by all accounts 
was a gifted runner. It’s also clear to me that the same forces that transformed running from a fledgling 
pastime in my white-ass home state into a billion-dollar global industry also circumscribed a culture 
that was at best, unwelcoming, and at worse, restrictive to him.  
Sunday, February 23, 2020 | 1:15pm Per the police report, Gregory McMichael rolls Maud from 
prostrate to his back to check for a weapon. He checks despite the fact that Maud hasn’t brandished 
or fired a gun during any part of his flight, not even when caught between two armed white men and 


## PDF page 21

21 
 
what he couldn’t have known was an unarmed white man behind him. Glynn County police officers 
will arrive within seconds of the shooting, their sirens screaming along Satilla Drive. But before those 
squad cars reach the scene, Travis McMichael—per Bryan’s statement to investigators in May—will 
call Maud a “f*cking [n-word].”  
The bridge that Maud and Keem used to jog is named for 19th century poet and Confederate Sidney 
Lanier. It’s hard to imagine a Georgian with honorifics on par with Lanier. Not only is he the namesake 
of that bridge, there’s also the eponymous Lanier County in southern Georgia, and Lake Lanier, a  
reservoir in northern Georgia. Keem seems surprised when I mention Lanier’s Confederate ties, 
which makes me wonder how much Maud knew about the history of his home. Whether the young 
men were aware of Lanier’s hagiography or not (who stops to read the plaque on a bridge?) every 
single jog across that bridge was insult, an insidious means of humiliating them and their/our people. 
Yeah, the tiki-torch toting bald-face racists menace a spectacle. But what about the legions of bigoted 
invisible men and their myriad symbols?  
Lanier died in 1881, which is to say near the end of Reconstruction and the outset of Jim Crow. In 
1964, a few months after the Civil Rights Act ushered the de jure end to Jim Crow, a documentary 
film crew from National Educational Television (the precursor to PBS) profiled Brunswick because 
it was managing to integrate without the bloodshed that was occurring almost everywhere else in the 
South. “The Quiet Conflict” won numerous awards and was a key reason for Brunswick’s reputation 
as a “model southern city.”  
On February 23, 2020, a young man out for a run was lynched in Glynn County, Georgia.  
While Brunswick might not have equaled the bloodletting of its southern counterparts, its 
segregationists still put up stern resistance. In one example, the KKK was called in to threaten Blacks 
attempting to integrate a local bowling alley. In another, whites filled a public pool with dirt rather 
than let Black kids swim in it. Several residents have gone on record to proclaim their surprise at 
Maud’s slaying and to downplay the significance of race. […]  
The NAACP once defined lynching as a death in which 1) There was evidence that a person was 
killed 2) The death was illegal 3) A group of at least three actors participated in the killing. According 
to “Lynching in America,” a report by the Equal Justice Initiative, there were 4,084 southern-state 
lynchings between 1877 and 1950. Of the 594 reported in Georgia during that period—one of only 
four states yet to pass a law on hate crimes—three occurred in Glynn County. […]  
A boy was lynched today: for walking hooded down a street and refusing the command of an 
overzealous neighborhood watchman. A man was lynched today: for selling loosies outside a bodega. 
A teen was lynched today: for a disputed exchange of cigarillos. A child was lynched today: for 
holding a toy outside a rec center. A man was lynched today: for fleeing a traffic stop unarmed. For 
hawking CDs outside a convenience store. For announcing a legal gun and reaching for his license. 
A woman was lynched today: for sleeping. And yet another man was lynched today: for suspicion of 
passing a fake twenty. D-e-a-t-h! In Florida, New York, Missouri, Ohio, South Carolina, Louisiana, 
Minnesota, Kentucky, and again in Minnesota.  
Sunday, February 23, 2020 | 1:16pm “Two subjects on Holmes Road. Shots fired. Male on ground, 
bleeding out,” radios an officer. Maud musters his last breath near the intersection of Holmes Road 
and Satilla Drive, a mere 300 yards from where, not 10 minutes prior, he wandered inside a 
construction site. The officers will cordon the scene and investigate. They will question the 
McMichaels—Gregory’s hands bloody from rolling Maud onto his back—and William Bryan. And 
in an act that is itself another violence, they will let all three go about their merry way as free men—
for almost three months.  


## PDF page 22

22 
 
On February 23, 2020, a young man out for a run was lynched in Glynn County, Georgia. […]  
Ahmaud Marquez Arbery was more than a viral video. He was more than a hashtag or a name on a 
list of tragic victims. He was more than an article or an essay or posthumous profile. He was more 
than a headline or an op-ed or a news package or the news cycle. He was more than a retweet or 
shared post. He, doubtless, was more than our likes or emoji tears or hearts or praying hands. He 
was more than an R.I.P. t-shirt or placard. He was more than an autopsy or a transcript or a police 
report or a live-streamed hearing. He, for damn sure, was more than the latest reason for your liberal 
white friend’s ephemeral outrage. He was more than a rally or a march. He was more than a symbol, 
more than a movement, more than a cause. He. Was. Loved. […] 
 
 


## PDF page 23

23 
 
3. division or analysis (breaking something down into parts) 
“Why I Want a Wife” by Judy Brady-Syfers.  
I belong to that classification of people known as wives. I am A Wife.  
And, not altogether incidentally, I am a mother. Not too long ago a male friend of mine appeared on 
the scene fresh from a recent divorce. He had one child, who is, of course, with his ex-wife. He is 
looking for another wife. As I thought about him while I was ironing one evening, it suddenly 
occurred to me that I too, would like to have a wife. Why do I want a wife?  
I would like to go back to school so that I can become economically independent, support myself, 
and if need be, support those dependent upon me. I want a wife who will work and send me to school. 
And while I am going to school I want a wife to take care of my children. I want a wife a wife to keep 
track of the children's doctor and dentist appointments. And to keep track of mine, too. I want a wife 
to make sure my children eat properly and are kept clean. I want a wife who will wash the children's 
clothes and keep them mended. I want a wife who is a good nurturing attendant to my children, who 
arranges for their schooling, makes sure that they have an adequate social life with their peers, takes 
them to the park, the zoo, etc. I want a wife who takes care of the children when they are sick, a wife 
who arranges to be around when the children need special care, because, of course, I cannot miss 
classes at school. My wife must arrange to lose time at work and not lose the job. It may mean a small 
cut in my wife's income from time to time, but I guess I can tolerate that. Needless to say, my wife 
will arrange and pay for the care of the children while my wife is working.  
I want a wife who will take care of my physical needs. I want a wife who will keep my house clean. 
A wife who will pick up after my children, a wife who will pick up after me. I want a wife who will 
keep my clothes clean, ironed, mended, replaced when need be, and who will see to it that my personal 
things are kept in their proper place so that I can find what I need the minute I need it. I want a wife 
who cooks the meals, a wife who is a good cook. I want a wife who will plan the menus, do the 
necessary grocery shopping, prepare the meals, serve them pleasantly, and then do the cleaning up 
while I do my studying. I want a wife who will care for me when I am sick and sympathize with my 
pain and loss of time from school. I want a wife to go along when our family takes a vacation so that 
someone can continue care for me and my when I need a rest and change of scene. I want a wife who 
will not bother me with rambling complaints about a wife's duties. But I want a wife who will listen 
to me when I feel the need to explain a rather difficult point I have come across in my course of 
studies. And I want a wife who will type my papers for me when I have written them.  
I want a wife who will take care of the details of my social life. When my wife and I are invited out 
by my friends, I want a wife who take care of the baby-sitting arrangements. When I meet people at 
school that I like and want to entertain, I want a wife who will have the house clean, will prepare a 
special meal, serve it to me and my friends, and not interrupt when I talk about things that interest me 
and my friends. I want a wife who will have arranged that the children are fed and ready for bed 
before my guests arrive so that the children do not bother us. I want a wife who takes care of the 
needs of my quests so that they feel comfortable, who makes sure that they have an ashtray, that they 
are passed the hors d'oeuvres, that they are offered a second helping of the food, that their wine glasses 
are replenished when necessary, that their coffee is  
served to them as they like it. And I want a wife who knows that sometimes I need a night out by 
myself.  
I want a wife who is sensitive to my sexual needs, a wife who makes love passionately and eagerly 
when I feel like it, a wife who makes sure that I am satisfied. And, of course, I want a wife who will 
not demand sexual attention when I am not in the mood for it. I want a wife who assumes the complete 
responsibility for birth control, because I do not want more children. I want a wife who will remain 


## PDF page 24

24 
 
sexually faithful to me so that I do not have to clutter up my intellectual life with jealousies. And I 
want a wife who understands that my sexual needs may entail more than strict adherence to 
monogamy. I must, after all, be able to relate to people as fully as possible.  
If, by chance, I find another person more suitable as a wife than the wife I already have, I want the 
liberty to replace my present wife with another one. Naturally, I will expect a fresh, new life; my wife 
will take the children and be solely responsible for them so that I am left free.  
When I am through with school and have a job, I want my wife to quit working and remain at home 
so that my wife can more fully and completely take care of a wife's duties.  
My God, who wouldn't want a wife? 
 
 


## PDF page 25

25 
 
4. classification (sorting the subject into different groups or kinds) 
 
“Three Types of Resistance to Oppression” by Martin Luther King, Jr. (1958) 
 
Oppressed people deal with their oppression in three characteristic ways. One way is acquiescence: 
the oppressed resign themselves to their doom. They tacitly adjust themselves to oppression, and 
thereby become conditioned to it. In every movement toward freedom some of the oppressed prefer 
to remain oppressed. Almost 2800 years ago Moses set out to lead the children of Israel from the 
slavery of Egypt to the freedom of the Promised Land. He soon discovered that slaves do not always 
welcome their deliverers. They become accustomed to being slaves. They would rather bear those ills 
they have, as Shakespeare pointed out, than flee to others that they know not of. They prefer the 
“fleshpots of Egypt” to the ordeals of emancipation.  
There is such a thing as the freedom of exhaustion. Some people are so worn down by the yoke of 
oppression that they give up. A few years ago in the slum areas of Atlanta, a Negro guitarist used to 
sing almost daily: “Ben down so long that down don’t bother me.” This is the type of negative freedom 
and resignation that often engulfs the life of the oppressed.  
But this is not the way out. To accept passively an unjust system is to cooperate with that system; 
thereby the oppressed become as evil as the oppressor. Noncooperation with evil is as much a moral 
obligation as is cooperation with good. The oppressed must never allow the conscience of the 
oppressor to slumber. Religion reminds every man that he is his brother’s keeper. To accept injustice 
or segregation passively is to say to the oppressor that his actions are morally right. It is a way of 
allowing his conscience to fall asleep. At this moment the oppressed fails to be his brother’s keeper. 
So acquiescence—while often the easier way—is not the moral way. It is the way of the coward. The 
Negro cannot win the respect of his oppressor by acquiescing; he merely increases the oppressor’s 
arrogance and contempt. Acquiescence is interpreted as proof of the Negro’s inferiority.  
The Negro cannot win respect of the white people of the South or the peoples of the world if he is  
willing to sell the future of his children for his personal and immediate comfort and safety. A second 
way that oppressed people sometimes deal with oppression is to resort to physical violence and 
corroding hatred. Violence often brings about momentary results. Nations have frequently won their 
independence in battle. But in spite of temporary victories, violence never brings permanent peace. It 
solves no social problem; it merely creates new and more complicated ones.  
Violence as a way of achieving racial justice is both impractical and immoral. It is impractical because 
it is a descending spiral ending in destruction for all. The old law of an eye for an eye leaves everybody 
blind. It is immoral because it seeks to humiliate the opponent rather than win his understanding; it 
seeks to annihilate rather than to convert. Violence is immoral because it thrives on hatred rather than 
love. It destroys community and makes brotherhood impossible. It leaves society in monologue rather 
than dialogue. Violence ends by defeating itself. It creates bitterness in the survivors and brutality in 
the destroyers.  
A voice echoes through time saying to every potential Peter, “Put up your sword.” History is cluttered 
with the wreckage of nations that failed to follow this command.  
If the American Negro and other victims of oppression succumb to the temptation of using violence 
in the struggle for freedom, future generations will be the recipients of a desolate night of bitterness, 
and our chief legacy to them will be an endless reign of meaningless chaos. Violence is not the way.  


## PDF page 26

26 
 
The third way open to oppressed people in their quest for freedom is the way of nonviolent resistance. 
Like the synthesis in Hegelian philosophy, the principle of nonviolent resistance seeks to reconcile 
the truths of two opposites—acquiescence and violence—while avoiding the extremes and 
immoralities of both. The nonviolent resister agrees with the person who acquiesces that one should 
not be physically aggressive toward his opponent, but he balances the equation by agreeing with the 
person of violence that evil must be resisted. He avoids the nonresistance of the former and the  
violent resistance of the latter. With nonviolent resistance, no individual or group need submit to any 
wrong, nor need anyone resort to violence in order to right a wrong.  
It seems to me that this is the method that must guide the actions of the Negro in the present crisis in 
race relations. Through nonviolent resistance the Negro will be able to rise to the noble height of 
opposing the unjust system while loving the perpetrators of the system. The Negro must work 
passionately and unrelentingly for full stature as a citizen, but he must not use inferior methods to 
gain it. He must never come to terms with falsehood, malice, hate or destruction.  
Nonviolent resistance makes it possible for the Negro to remain in the South and struggle for his 
rights. The Negro’s problem will not be solved by running away. He cannot listen to the glib 
suggestion of those who would urge him to migrate en masse to other sections of the country. By 
grasping his great opportunity in the South, he can make a lasting contribution to the moral strength 
of the nation and set a sublime example of courage for generations yet unborn.  
By nonviolent resistance, the Negro can also enlist all men of good will in his struggle for equality. 
The problem is not a purely racial one, with Negroes set against whites. In the end, it is not a struggle 
between people at all, but a tension between justice and injustice. Nonviolent resistance is not aimed 
against oppressors but against oppression. Under its banner consciences, not racial groups, are 
enlisted.  
If the Negro is to achieve the goal of integration, he must organize himself into a militant and 
nonviolent mass movement. All three elements are indispensable. The movement for equality and 
justice can only be a success if it has both a mass and militant character; the barriers to be overcome 
require both. Nonviolence is an imperative in order to bring about ultimate community.  
A mass movement of a militant quality that is not at the same time committed to nonviolence tends 
to generate conflict, which in turn breeds anarchy. The support of the participants and the sympathy 
of the uncommitted are both inhibited by the threat that bloodshed will engulf the community. This 
reaction in turn encourages the opposition to threaten and resort to force. When,  
however, the mass movement repudiates violence while moving resolutely toward its goal, its 
opponents are revealed as the instigators and practitioners of violence if it occurs. Then public support 
is magnetically attracted to the advocates of nonviolence, while those who employ violence are 
literally disarmed by overwhelming sentiment against their stand. 
 
 
 
 


## PDF page 27

27 
 
5. comparison & contrast 
 
“Racism and Recapitulation” by Stephen Jay Gould (1977) 
 
 
 


## PDF page 28

28 
 
 
 
 


## PDF page 29

29 
 
 
 
 


## PDF page 30

30 
 
 
 
 


## PDF page 31

31 
 
 
 
 


## PDF page 32

32 
 
6. providing examples 
 
“Just Walk on By: Black People and Public Space” by Brent Staples (1986)  
My first victim was a woman—white, well dressed, probably in her early twenties. I came upon her 
late one evening on a deserted street in Hyde Park, a relatively affluent neighborhood in an otherwise 
mean, impoverished section of Chicago. As I swung onto the avenue behind her, there seemed to be 
a discreet, uninflammatory distance between us. Not so. She cast back a worried glance. To her, the 
youngish black man—a broad six feet two inches with a beard and billowing hair, both hands shoved 
into the pockets of a bulky military jacket—seemed menacingly close. After a few more quick 
glimpses, she picked up her pace and was soon running in earnest. Within seconds she disappeared 
into a cross street.  
That was more than a decade ago. I was 23 years old, a graduate student newly arrived at the 
University of Chicago. It was in the echo of that terrified woman’s footfalls that I first began to know 
the unwieldy inheritance I’d come into—the ability to alter public space in ugly ways. It was clear 
that she thought herself the quarry of a mugger, a rapist, or worse. Suffering a bout of insomnia, 
however, I was stalking sleep, not defenseless wayfarers. As a softy who is scarcely able to take a 
knife to raw chicken—let alone hold it to a person’s throat—I was surprised, embarrassed, and 
dismayed all at once. Her flight made me feel like an accomplice in tyranny. It also made it clear that 
I was indistinguishable from the muggers who occasionally seeped into the area from the surrounding 
ghetto. That first encounter, and those that followed signified that a vast unnerving gulf lay between 
nighttime pedestrians—particularly women— and me. And I soon gathered that being perceived as 
dangerous is a hazard in itself. I only needed to turn a corner into a dicey situation, or crowd some 
frightened, armed person in a foyer somewhere, or make an errant move after being pulled over by a 
policeman. Where fear and weapons meet—and they often do in urban America—there is always the 
possibility of death.  
In that first year, my first away from my hometown, I was to become thoroughly familiar with the 
language of fear. At dark, shadowy intersections in Chicago, I could cross in front of a car stopped at 
a traffic light and elicit the thunk, thunk, thunk, thunk of the driver—black, white, male, or female—
hammering down the door locks. On less traveled streets after dark, I grew accustomed to but never 
comfortable with people who crossed to the other side of the street rather than pass me. Then there 
were the standard unpleasantries with police, doormen, bouncers, cab drivers, and others whose 
business it is to screen out troublesome individuals before there is any nastiness.  
I moved to New York nearly two years ago and I have remained an avid night walker. In central 
Manhattan, the near-constant crowd cover minimizes tense one-on-one street encounters. 
Elsewhere—visiting friends in SoHo, where sidewalks are narrow and tightly spaced buildings shut 
out the sky—things can get very taut indeed.  
Black men have a firm place in New York mugging literature. Norman Podhoretz in his famed (or 
infamous) 1963 essay, “My Negro Problem—and Ours,” recalls growing up in terror of black males; 
they were “tougher than we were, more ruthless,” he writes—and as an adult on the Upper West Side 
of Manhattan, he continues, he cannot constrain his nervousness when he meets black men on certain 
streets. Similarly, a decade later, the essayist and novelist Edward Hoagland extols a New York where 
once “Negro bitterness bore down mainly on other Negroes.” Where some see mere panhandlers, 
Hoagland sees “a mugger who is clearly  
screwing up his nerve to do more than just ask for money.” But Hoagland has “the New Yorker’s 
quickhunch posture for broken-field maneuvering,” and the bad guy swerves away.  
I often witness that “hunch posture,” from women after dark on the warrenlike streets of Brooklyn 
where I live. They seem to set their faces on neutral and, with their purse straps strung across their 


## PDF page 33

33 
 
chests bandolier style, they forge ahead as though bracing themselves against being talked. I 
understand, of course, that the danger they perceive is not a hallucination. Women are particularly 
vulnerable to street violence, and young black males are drastically overrepresented among the 
perpetrators of that violence. Yet these truths are no solace against the kind of alienation that comes 
of being ever the suspect, against being set apart, a fearsome entity with whom pedestrians avoid 
making eye contact.  
It is not altogether clear to me how I reached the ripe old age of 22 without being conscious of the 
lethality nighttime pedestrians attributed to me. Perhaps it was because in Chester, Pennsylvania, the 
small, angry industrial town where I came of age in the 1960s, I was scarcely noticeable against a 
backdrop of gang warfare, street knifings, and murders. I grew up one of the good boys, had perhaps 
a half-dozen first fights. In retrospect, my shyness of combat has clear sources.  
Many things go into the making of a young thug. One of those things is the consummation of the 
male romance with the power to intimidate. An infant discovers that random flailings send the baby 
bottle flying out of the crib and crashing to the floor. Delighted, the joyful babe repeats those motions 
again and again, seeking to duplicate the feat. Just so, I recall the points at which some of my boyhood 
friends were finally seduced by the perception of themselves as tough guys. When a mark cowered 
and surrendered his money without resistance, myth and reality merged—and paid off. It is, after all, 
only manly to embrace the power to frighten and intimidate. We, as men, are not supposed to give an 
inch of our lane on the highway; we are to seize the fighter’s edge in work and in play and even in 
love; we are to be valiant in the face of hostile forces.  
Unfortunately, poor and powerless young men seem to take all this nonsense literally. As a boy, I saw 
countless tough guys locked away; I have since buried several, too. They were babies, really—a 
teenage cousin, a brother of 22, a childhood friend in his mid-twenties—all gone down in episodes 
of bravado played out in the streets. I came to doubt the virtues of intimidation early on. I chose, 
perhaps even unconsciously, to remain a shadow—timid, but a survivor.  
The fearsomeness mistakenly attributed to me in public places often has a perilous flavor. The most 
frightening of these confusions occurred in the late 1970s and early 1980s when I worked as a 
journalist in Chicago. One day, rushing into the office of a magazine I was writing for with a deadline 
story in hand, I was mistaken for a burglar. The office manager called security and, with an ad hoc 
posse pursued me through the labyrinthine halls, nearly to my editor’s door. I had no way of proving 
who I was. I could only move briskly toward the company of someone who knew me.  
Another time I was on assignment for a local paper and killing time before an interview. I entered a 
jewelry store on the city’s affluent Near North Side. The proprietor excused herself and returned with 
an enormous red Doberman pinscher straining at the end of a leash. She stood, the dog extended 
toward me, silent to my questions, her eyes bulging nearly out of her head. I took a cursory look 
around, nodded, and bade her good night. Relatively speaking,  
however, I never fared as badly as another black male journalist. He went to nearby Waukegan, 
Illinois, a couple of summers ago to work on a story about a murderer who was born there. Mistaking 
the reporter for the killer, police hauled him from his car at gunpoint and but for his press credentials 
would probably have tried to book him. Such episodes are not uncommon. Black men trade talks like 
this all the time.  
In “My Negro Problem—And Ours,” Podhoretz writes that the hatred he feels for blacks makes itself 
known to him through a variety of avenues—one being taken for a criminal. Not to do so would surely 
have led to madness—via that special “paranoid touchiness” that so annoyed Podhoretz at the time 
he wrote the essay.  
I began to take precautions to make myself less threatening. I move about with care, particularly late 


## PDF page 34

34 
 
in the evening. I give a wide berth to nervous people on subway platforms during the wee hours, 
particularly when I have exchanged business clothes for jeans. If I happened to be entering a building 
behind some people who appear skittish, I may walk by, letting them clear the lobby before I return, 
so as not to seem to be following them. I have been calm and extremely congenial on those rare 
occasions when I’ve been pulled over by the police.  
And on late-evening constitutionals along streets less traveled by, I employ what has proved to be an 
excellent tension-reducing measure: I whistle melodies from Beethoven and Vivaldi and the more 
popular classical composers. Even steely New Yorkers hunching toward nighttime destinations seem 
to relax and occasionally they even join in the tune. Virtually everybody seems to sense that a mugger 
wouldn’t be warbling bright, sunny selections from Vivaldi’s Four Seasons. It is my equivalent to the 
cowbell that hikers wear when they know they are in bear country. 
 
 


## PDF page 35

35 
 
7. process analysis (explaining ‘how to’ do something step by step) 
 
“How Our Skins Get Their Color” by Marvin Harris (1988) 
Most human beings are neither very fair nor very dark, but brown. The extremely fair skin of northern 
Europeans and their descendants, and the very black skins of central Africans and their descendants, 
are probably special adaptations. Brown-skinned ancestors may have been shared by modern-day 
blacks and whites as recently as 10,000 years ago.  
Human skin owes its color to the presence of particles known as melanin. The primary function of 
melanin is to protect the upper levels of the skin from being damaged by the sun’s ultraviolet rays. 
This radiation poses a critical problem for our kind because we lack the dense coat of hair that acts 
as a sunscreen for most mammals […]. Hairlessness exposes us to two kinds of radiation hazards: 
ordinary sunburn, with its blisters, rashes, and risk of infection; and skin cancers, including malignant 
melanoma, one of the deadliest diseases known. Melanin is the body's first line of defense against 
these afflictions. The more melanin particles, the darker the skin, and the lower the risk of sunburn 
and all forms of skin cancer. This explains why the highest rates for skin cancer are found in sun-
drenched lands such as Australia, where light skinned people of European descent spend a good part 
of their lives outdoors wearing scanty attire. Very dark-skinned people such as heavily pigmented 
Africans of Zaire seldom get skin cancer, but when they do, they get it on depigmented parts of their 
bodies: palms and lips.  
If exposure to solar radiation had nothing but harmful effects, natural selection would have favored 
inky black as the color for all human populations. But the sun’s rays do not present an unmitigated 
threat. As it falls on the skin, sunshine converts a fatty substance in the epidermis into vitamin D. The 
blood carries vitamin D from the skin to the intestines (technically making it a hormone rather than a 
vitamin), where it plays a vital role in the absorption of calcium. In turn, calcium is vital for strong 
bones. Without it, people fall victim to the crippling diseases rickets and osteomalacia. In women, 
calcium deficiencies can result in a deformed birth canal, which makes childbirth lethal for both 
mother and fetus.  
Vitamin D can be obtained from a few foods, primarily the oils and livers of marine fish. But inland 
populations must rely on the suns rays and their own skins for the supply of this crucial substance. 
The particular color of a human population’s skin, therefore, represents in large degree a trade-off 
between the hazards of too much versus too little solar radiation: acute sunburn and skin cancer on 
the one hand, and rickets and osteomalacia on the other. It is this trade-off that largely accounts for 
the preponderance of brown people in the world and for the general tendency for skin color to be 
darkest among equatorial populations and lightest among populations dwelling at higher latitudes.  
At middle latitudes, the skin follows a strategy of changing colors with the seasons. Around the 
Mediterranean basin, for example, exposure to the summer sun brings high risk of cancer but low risk 
for rickets; the body produces more melanin and people grow darker (i.e., they get suntans). Winter 
reduces the risk of sunburn and cancer; the body produces less melanin, and the tan wears off.  
The correlation between skin color and latitude is not perfect because other factors such as the 
availability of foods containing vitamin D and calcium, regional cloud cover during the winter, 
amount of clothing worn, and cultural preferences-may work for or against the predicted relationship. 
Arctic-dwelling Eskimo, for example, are not as light-skinned as expected, but their habitat and 
economy afford them a diet that is exceptionally rich in both vitamin D and calcium.  
Northern Europeans, obliged to wear heavy garments for protection against the long, cold, cloudy 
winters, were always at risk for rickets and osteomalacia from too little vitamin D and calcium. This 
risk increased sometime after 6000 B.C., when pioneer cattle herders who did not exploit marine 
resources began to appear in northern Europe. The risk would have been especially great for the 
brown-skinned Mediterranean peoples who migrated northward along with the crops and farm 
animals. Samples of Caucasian skin (infant penile foreskin obtained at the time of circumcision) 
exposed to sunlight on cloudless days in Boston (42°N) from November through February produced 


## PDF page 36

36 
 
no vitamin D. In Edmonton (52°N) this period extended from October to March. But further south 
(34°N) sunlight was effective in producing vitamin D in the middle of the winter. Almost all of Europe 
lies north of 42°N. Fair-skinned, nontanning individuals who could utilize the weakest and briefest 
doses of sunlight to synthesize vitamin D were strongly favored by natural selection. During the frigid 
winters, only a small circle of a child's face could be left to peek out at the sun through the heavy 
clothing, thereby favoring the survival of individuals with translucent patches of pink on their cheeks 
characteristic of many northern Europeans. (People who could get calcium by drinking cow's milk 
would also be favored by natural selection.)  
If light-skinned individuals on the average had only 2 percent more children survive per generation, 
the changeover in their skin color could have begun 5,000 years ago and reached present levels well 
before the beginning of the Christian era. But natural selection need not have acted alone. Cultural 
selection may also have played a role. It seems likely that whenever  
people consciously or unconsciously had to decide which infants to nourish and which to neglect, the 
advantage would go to those with lighter skin, experience having shown that such individuals tended 
to grow up to be taller, stronger, and healthier than their darker siblings. White was beautiful because 
white was healthy.  
To account for the evolution of black skin in equatorial latitudes, one has merely to reverse the 
combined effects of natural and cultural selection. With the sun directly overhead most of the year, 
and clothing a hindrance to work and survival, vitamin D was never in short supply (and calcium was 
easily obtained from vegetables). Rickets and osteomalacia were rare. Skin cancer was the main 
problem, and what nature started, culture amplified. Darker infants were favored by parents because 
experience showed that they grew up to be freer of disfiguring and lethal malignancies. Black was 
beautiful because black was healthy. 
 
 


## PDF page 37

37 
 
8. definition (tracing a boundary and providing information) 
 
“The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979) 
 
To begin with, it was not the hapless victims of the Nazis who named their incomprehensible and 
totally unmasterable fate the “holocaust.” It was the Americans who applied this artificial and highly 
technical term to the Nazi extermination of the European Jews. But while the event as mass murder 
most foul evokes the most immediate, most powerful revulsion, when it is designated by a rare 
technical term, we must first in our minds it back into emotionally meaningful language. Using 
technical or specially created terms instead of words from our common vocabulary is one of the best-
known and most widely used distancing devices, separating the intellectual from the emotional 
experience. Talking about “the holocaust” permits us to manage it intellectually where the raw facts, 
when given their ordinary names, would overwhelm us emotionally—because it was catastrophe 
beyond comprehension, beyond the limits of our imagination, unless we force ourselves against our 
desire to extend it to encompass these terrible events.  
This linguistic circumlocution began while it was only in the planning stage. Even the Nazis – usually 
given to grossness in language and action—shied away from facing openly what they were up to and 
called this vile mass murder “the final solution of the Jewish problem.” After all, solving a problem 
can be made to appear like an honorable enterprise, as long as we are not forced to recognize that the 
solution we are about to embark on consists of the completely unprovoked, vicious murder of millions 
of helpless men, women and children. The Nuremberg judges of these Nazi criminals followed their 
example of circumlocution by coining a neologism out of one Greek and one Latin root: genocide. 
These artificially created technical terms fail to connect with our strongest feelings. The horror of 
murder is part of our most common human heritage. From earliest infancy on, it arouses violent 
abhorrence in us. Therefore in whatever form it appears we should give such an act its true designation 
and not hide it behind polite, erudite terms created out of classical words.  
To call this vile mass murder “the holocaust” is not to give it a special name emphasizing its 
uniqueness which would permit, over time, the word becoming invested with feelings germane to the 
even it refers to. The correct definition of "holocaust" is "burnt offering". As such, it is part of the 
language of the psalmist, a meaningful word to all who have some acquaintance with the Bible, full 
of the richest connotations. By using the term Holocaust, entirely false associations are established 
through conscious and unconscious connotations between the most vicious of mass murders and 
ancient rituals of a deeply religious nature.  
Using a word with such strong unconscious religious connotations when speaking of the murder of 
millions of Jews robs the victims of this abominable mass murder of the only thing left to them: their 
uniqueness. Calling the most callous, most brutal, most horrid, most heinous mass murder a burnt 
offering is a sacrilege, a profanation of God and man.  
Martyrdom is part of our religious heritage. A martyr, burned at the stake, is a burnt offering to his 
God. And it is true that after the Jews were asphyxiated, the victim's corpses were burned. But I 
believe we fool ourselves if we think we are honoring the victims of systematic murder by using this 
term, which has the highest moral connotations. By doing so, we connect for our own psychological 
reasons what happened in the extermination camps with historical events we deeply regret, but also 
greatly admire. We do so because this makes it easier for to cope; only in doing so we cope with our 
distorted image of what happened, not with the events the way they did happen.  
By calling the victims of the Nazis "martyrs", we falsify their fate. The true meaning of the word 
martyr is "one who voluntarily undergoes the penalty of death for refusing to renounce their faith" 
(OED). The Nazis made sure that nobody could mistakenly think that their victims were murdered 
for their religious beliefs. Renouncing their faith would not have saved none of them. Those who had 
converted to Christianity were gassed, as those who were atheists, and those who were deeply 
religious Jews. They did not die for any conviction, and certainly not out of choice.  


## PDF page 38

38 
 
Millions of Jews were systematically slaughtered, as were untold other “undesirables”, not for any 
convictions of theirs, but only because they stood in the way of the realization of an illusion. They 
neither died for their convictions, nor were they slaughtered because of their convictions, but only in 
consequence of the Nazis’ delusional belief about what was required to protect the purity of their 
assumed superior racial endowment, and what they thought necessary to guarantee them the living 
space they believed they needed and were entitled to.  
Thus while these millions were slaughtered for an idea, they did not die for one.  
Millions—men, women, and children—were processed after they had been utterly brutalized, their 
humanity destroyed, their clothes torn from their bodies. Naked, they were sorted into those who were 
destined to be murdered immediately, and those others who had a short-term usefulness as slave labor. 
But after a brief interval they, too, were to be herded into the same gas chambers into which the others 
were immediately piled, there to be asphyxiated so that, in their last moments, they could not prevent 
themselves from fighting each other in vain for a last breath of air.  
To call these most wretched victims of a murderous delusion, of destructive drives run rampant, 
martyrs or a burnt offering is a distortion invented for our comfort, small as it may be. It pretends that 
this most vicious of mass murders had some deeper meaning; that in some fashion the victims either 
offered themselves or at least became sacrifices to a higher cause. It robs them of the last recognition 
which could be theirs, denies them the last dignity we could accord them: to face and accept what 
their death was all about, not embellishing it for the small psychological relief this may give us.  
We could feel so much better if the victims had acted out of choice. For our emotional relief, therefore, 
we dwell on the tiny minority who did exercise some choice: the resistance fighters of the Warsaw 
Ghetto, for example, and others like them. We are ready to overlook the fact that these people fought 
back only at a time when everything was lost, when the overwhelming majority of those who had 
been forced into the ghettos had already been exterminated without resisting. Certainly those few who 
finally fought for their survival and their convictions, risking and losing their lives in doing so, 
deserve our admiration; their deeds give us a moral lift. But the more we dwell on these few, the more 
unfair are we to the memory of the millions who were slaughtered – who gave in, did not fight back—
because we deny them the only thing which up to the very end remained uniquely their own: their 
fate. 
 
 


## PDF page 39

39 
 
9. cause and effect (showing a logical chain of events) 
 
“Groping toward That Invisible Light” by Richard Wright (1930) 
 
 
 
 


## PDF page 40

40 
 
 
 
 


## PDF page 41

41 
 
 
 
 


## PDF page 42

42 
 
 
 
 


## PDF page 43

43 
 
 
 
 


## PDF page 44

44 
 
 
 
 


## PDF page 45

45 
 
 
 
 


## PDF page 46

46 
 
 
 
 


## PDF page 47

47 
 
 
 
 


## PDF page 48

48 
 
 
 
 


## PDF page 49

49 
 
 
 
 


## PDF page 50

50 
 
10. argument (persuading the reader to side with your opinions) 
 
“I Have a Dream” by Martin Luther King, Jr. (August 28, 1963) 
 
I am happy to join with you today in what will go down in history as the greatest demonstration for 
freedom in the history of our nation.  
Five score years ago, a great American, in whose symbolic shadow we stand today, signed the 
Emancipation Proclamation. This momentous decree came as a great beacon of hope to millions of 
slaves, who had been seared in the flames of withering injustice. It came as a joyous daybreak to end 
the long night of their captivity. But one hundred years later, the colored America is still not free. One 
hundred years later, the life of the colored American is still sadly crippled by the manacle of 
segregation and the chains of discrimination.  
One hundred years later, the colored American lives on a lonely island of poverty in the midst of a 
vast ocean of material prosperity. One hundred years later, the colored American is still languishing 
in the corners of American society and finds himself an exile in his own land So we have come here 
today to dramatize a shameful condition.  
In a sense we have come to our Nation’s Capital to cash a check. When the architects of our great 
republic wrote the magnificent words of the Constitution and the Declaration of Independence, they 
were signing a promissory note to which every American was to fall heir.  
This note was a promise that all men, yes, black men as well as white men, would be guaranteed the 
inalienable rights of life liberty and the pursuit of happiness.  
It is obvious today that America has defaulted on this promissory note insofar as her citizens of color 
are concerned. Instead of honoring this sacred obligation, America has given its colored people a bad 
check, a check that has come back marked “insufficient funds.”  
But we refuse to believe that the bank of justice is bankrupt. We refuse to believe that there are 
insufficient funds in the great vaults of opportunity of this nation. So we have come to cash this check, 
a check that will give us upon demand the riches of freedom and security of justice.  
We have also come to his hallowed spot to remind America of the fierce urgency of Now. This is not 
time to engage in the luxury of cooling off or to take the tranquilizing drug of gradualism.  
Now is the time to make real the promise of democracy.  
Now it the time to rise from the dark and desolate valley of segregation to the sunlit path of racial 
justice.  
Now it the time to lift our nation from the quicksand of racial injustice to the solid rock of 
brotherhood.  
Now is the time to make justice a reality to all of God’s children.  
I would be fatal for the nation to overlook the urgency of the moment and to underestimate the 
determination of it’s colored citizens. This sweltering summer of the colored people’s legitimate 
discontent will not pass until there is an invigorating autumn of freedom and equality. Nineteen sixty-
three is not an end but a beginning. Those who hope that the colored Americans needed to blow off 
steam and will now be content will have a rude awakening if the nation returns to business as usual.  
There will be neither rest nor tranquility in America until the colored citizen is granted his citizenship 
rights. The whirlwinds of revolt will continue to shake the foundations of our nation until the bright 
day of justice emerges. 
We can never be satisfied as long as our bodies, heavy with the fatigue of travel, cannot gain lodging 
in the motels of the highways and the hotels of the cities.  


## PDF page 51

51 
 
We cannot be satisfied as long as the colored person’s basic mobility is from a smaller ghetto to a 
larger one.  
We can never be satisfied as long as our children are stripped of their selfhood and robbed of their 
dignity by signs stating “for white only.”  
We cannot be satisfied as long as a colored person in Mississippi cannot vote and a colored person in 
New York believes he has nothing for which to vote.  
No, no we are not satisfied and we will not be satisfied until justice rolls down like waters and 
righteousness like a mighty stream.  
I am not unmindful that some of you have come here out of your trials and tribulations. Some of you 
have come from areas where your quest for freedom left you battered by storms of persecutions and 
staggered by the winds of police brutality.  
You have been the veterans of creative suffering. Continue to work with the faith that unearned 
suffering is redemptive.  
Go back to Mississippi, go back to Alabama, go back to South Carolina go back to Georgia, go back 
to Louisiana, go back to the slums and ghettos of our modern cities, knowing that somehow this 
situation can and will be changed.  
Let us not wallow in the valley of despair. I say to you, my friends, we have the difficulties of today 
and tomorrow.  
I still have a dream. It is a dream deeply rooted in the American dream.  
I have a dream that one day this nation will rise up and live out the true meaning of its creed. We hold 
these truths to be self-evident that all men are created equal.  
I have a dream that one day out in the red hills of Georgia the sons of former slaves and the sons of 
former slaveowners will be able to sit down together at the table of brotherhood.  
I have a dream that one day even the state of Mississippi, a state sweltering with the heat of 
oppression, will be transformed into an oasis of freedom and justice.  
I have a dream that my four little children will one day live in a nation where they will not be judged 
by the color of their skin but by their character.  
I have a dream today.  
I have a dream that one day down in Alabama, with its vicious racists, with its governor having his 
lips dripping with the words of interposition and nullification; that one day right down in Alabama 
little black boys and black girls will be able to join hands with little white boys and white girls as 
sisters and brothers.  
I have a dream today.  
I have a dream that one day every valley shall be engulfed, every hill shall be exalted and every 
mountain shall be made low, the rough places will be made plains and the crooked places will be 
made straight and the glory of the Lord shall be revealed and all flesh shall see it together.  
This is our hope. This is the faith that I will go back to the South with. With this faith we will be able 
to hew out of the mountain of despair a stone of hope.  
With this faith we will be able to transform the jangling discords of our nation into a beautiful 
symphony of brotherhood. 
With this faith we will be able to work together, to pray together, to struggle together, to go to jail 
together, to climb up for freedom together, knowing that we will be free one day.  


## PDF page 52

52 
 
This will be the day when all of God’s children will be able to sing with new meaning “My country 
’tis of thee, sweet land of liberty, of thee I sing. Land where my father’s died, land of the Pilgrim’s 
pride, from every mountainside, let freedom ring!”  
And if America is to be a great nation, this must become true. So let freedom ring from the hilltops 
of New Hampshire. Let freedom ring from the mighty mountains of New York.  
Let freedom ring from the heightening Alleghenies of Pennsylvania.  
Let freedom ring from the snow-capped Rockies of Colorado.  
Let freedom ring from the curvaceous slopes of California.  
But not only that, let freedom, ring from Stone Mountain of Georgia.  
Let freedom ring from every hill and molehill of Mississippi and every mountainside.  
When we let freedom ring, when we let it ring from every tenement and every hamlet, from every 
state and every city, we will be able to speed up that day when all of God’s children, black men and 
white men, Jews and Gentiles, Protestants and Catholics, will be able to join hands and sing in the 
words of the old spiritual, “Free at last, free at last. Thank God Almighty, we are free at last.” 
 
 


## PDF page 53

53 
 
B. Fallacies of Reasoning – General list of Fallacies 
 
 
 
A2FCP11 
1. Ad hominem  
2. Ad ignorantiam  
3. Argument from Authority  
4. False Authority   
5. Argument from Final Consequences (Teleological arguments)  
6. Post Hoc / False Cause   
7. Argument from Personal Incredulity  
8. False Dilemma or Either-Or Fallacy  
9. Inconsistency  
10. Non-Sequitur  
11. Reductio ad absurdum  
12. Slippery Slope  
13. Straw Man  
14. Red Herring  
15. Oversimplification  
16. Begging the Question / Circular Reasoning  
17. Moving the Goalpost  
18. Tu quoque  
19. Hasty Generalization  
20. False Analogy  
21. Guilt by Association  
22. Amphiboly/ Double Talk  
23. Equivocation  
24. Bandwagon  
25. Special Pleading, or Ad-hoc Reasoning  
26. The Loaded Question   
 
-------------------------Fallacies related to lesson on Trump & Fallacies-----------------  
Others seen in the introduction:  
-Enthymeme  
-Wordplay  
Additions in the era of Trumpism:  
-Poisoning the Well (within Ad hominem)  
-Appeal to Common Sense (within Bandwagon)  
-Ad terrorem (with False Dilemma or Slippery Slope)  
-Whataboutism (with Red Herring)  
Extended forms of Speculation:  
-Historian’s Fallacy  
-Appeal to Probability  
-Contrafactual Evidence   
-Argumentum ex silentio  
Going to Extremes:  
-Subverted Support   
-Proof by Assertion  


## PDF page 54

54 
 
-Gaslighting 
Practice Samples I: Which fallacy is being committed here?  
(Use the general list of 26 fallacies)  
1. “The bailout Obama signed on for has led to the worst housing market crisis in decades.”  
2. “The President spoke about the reports he received angry letters, which were filled with errors and 
inconsistencies.”  
3. “All the French are Socialists anyway. It’s not surprising that they like our new ‘President’.” 4. 
“Since Obama came into office, unemployment is up 20% - those millions of men and women who 
lost their jobs know who to thank for that!”  
5. “Bob is a Republican, and Bob is quite racist. That’s why I say that Republicans are racist.”  
6. June 2004:   
Alan: “You should get behind your President. Protesting the decisions of our Commander-in-Chief is 
un-American!”  
June 2009:  
Alan: “Impeach the President! He’s a Socialist! He’s a terrorist!”  
Bill: “But last time you told me that it was un-American to protest our President. You said we have 
to ‘get behind our President’ – remember?”   
Alan: “Yes, but that applies when the country is at war. We had just started the war in Iraq.”  
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”  
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”  
7. “Sarah Palin is a real, down-to-earth American like you and me. She’ll be the best vice-president 
we’ve ever had.”  
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”  
Bob: “No, he was born in Hawaii. He’s registered as being born on August 4th, 1961, in Kapi’olani 
Hospital in Honolulu.”   
Arvin: “I’m not buying it. I need hard evidence.”  
Bob: “Well, here’s a photocopy of the hospital register – you see, born at 8:45 pm, 7 lbs. 4 oz.”  
Arvin:” That could have been scribbled in by anyone. I need proof that he was there.”  
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward 
when he was just a few hours old. Notice the name of the hospital on that sign on the wall…”  
Arvin: “How do I know that’s him? That could be a doll they’re holding, for all I know! I need to see 
a birth certificate. Why won’t he produce a birth certificate? What’s he trying to hide?”  
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate. You see it’s 
there, as I told you, in black and white.”  
Arvin: “A copy?! I’d need to see the real thing!”  


## PDF page 55

55 
 
9. “I cannot imagine someone as important as the Vice-President being involved in something so 
underhanded and illegal. No way!”  
10. “Give me a straight answer on this. Did you decide to betray the American people who voted for 
you by accepting ‘gifts’ from lobbyists before or after taking those bribes?”   
11. “The constitution says that when the country is “at war”, individual liberties may have to be 
infringed. Well, if that’s the only way to win the War on Terror, then so be it!”  
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our government at the highest level – 
that’s just what I think, and no one has shown me proof that he isn’t.”   
13. “Geithner was a cabinet member under Bush and Cheney. They all went to Yale or Harvard. He 
was probably all on board for the Iraq War. There’s no way he should be part of the new 
administration. Would you make Bush or Cheney Secretary of the Treasury?!” 
Samples concerning the Health Care Debate under President Obama:  
(Use the general list of 26 fallacies)  
1. “So basically the opposition’s argument is that it is more important to help those who have no 
health care than to care at all about the 85% of hard-working Americans who already have coverage.  
How on earth can anyone agree to that?”  
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published in the New 
England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says this healthcare bill 
will increase the deficit and raise health care costs, I believe him!”  
3. “Listen, 85% of the citizens of our state think changing health care is a bad idea. Isn’t it obvious 
that this is wrong-headed?”  
4. “The choice is yours, America – accept this health care reform or stick with the status quo and its 
ever-rising premiums and outrageous medical bills.”  
5. “Both the House and the Senate health care proposals were written by a Democratic majority, aim 
at providing health care to those who have no coverage and were developed in committees at the 
request of the same liberal President. One is just as bad as the other and they should both be rejected.”  
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not 
improve health care.”  
7. “Representatives who voted against the new health care bill were just voting along party lines”  
8. “If you allow the government to get involved in our health care, in no time we’ll have government 
controlled ‘death panels’, we’ll be waiting on bread lines, and we’ll be living in a Communist state!”  
9. “Why are we talking so much about health care when the real problem in this country is 
unemployment?”  
10. “I’m not going to accept a health care proposal from a man who is not even a real American. He’s 
a terrorist, I’m telling you. Go home, Hussein!”  
11. “I can tell you why this health care proposal isn’t good enough. It’s because there are many 
provisions that could be improved and too many policies regarding hard-working Americans that just 
don’t cut the mustard. It’s clear that it needs to be revamped, isn’t it?”  


## PDF page 56

56 
 
12. “Listen, Mom, how can you say that it is un-American to accept government money and aid when 
you’re young and healthy enough to work. You were on Welfare for years before you got remarried.”  
13. (The same news presenter from a cable news channel)  
November 2008: “We have the worst health care system in the world, ladies and gentlemen. I know 
– I’ve just been through it myself for a botched operation. They only care about money, not your well-
being.”  
November 2009: “Ladies and gentlemen, this president is trying to tamper with the best healthcare 
system in the world – bar none! He’s trying to bring down America!” 
 
 


## PDF page 57

57 
 
C. Tips on Writing College Papers 
 
 
 
 


## PDF page 58

58 
 
 
 
 
 


## PDF page 59

59 
 
 
 
 
 


## PDF page 60

60 
 
 
 
 
 
 


## PDF page 61

61 
 
 
 
 
 
 


## PDF page 62

62 
 
 
 
 
 


## PDF page 63

63 
 
 
 
 
 
 
 
UNIT II: 
JOURNALISTIC WRITING 
 
 
 


## PDF page 64

64 
 
 
 
 


## PDF page 65

65 
 
 
 
 


## PDF page 66

66 
 
 
 
 


## PDF page 67

67 
 
 
 
 


## PDF page 68

68 
 
 
 
 


## PDF page 69

69 
 
 
 
 


## PDF page 70

70 
 
 
 
 


## PDF page 71

71 
 
 
 
 


## PDF page 72

72 
 
 
 
 


## PDF page 73

73 
 
 
 
 


## PDF page 74

74 
 
 
 
 


## PDF page 75

75 
 
 
 
 


## PDF page 76

76 
 
 
 
 


## PDF page 77

77 
 
 
 
 


## PDF page 78

78 
 
 
 
 


## PDF page 79

79 
 
 
 
 


## PDF page 80

80 
 
 
 
 


## PDF page 81

81 
 
 
 
 


## PDF page 82

82 
 
 
 
 


## PDF page 83

83 
 
 
 
 


## PDF page 84

84 
 
 
 
 


## PDF page 85

85 
 
 
 
 


## PDF page 86

86 
 
 
 
 


## PDF page 87

87 
 
 
 
 


## PDF page 88

88 
 
 
 
 


## PDF page 89

89 
 
 


## PDF page 90

90 
 
 
 
 


## PDF page 91

91 
 
B. Sample News Articles 
Young Women Are Radicalizing: 
Britain’s Young Women Are Sad, Alienated and Increasingly Left-wing 
By Scarlett Maguire 
5 January, 2026 | The New Statesman 
 
  
Over the past decade we have had countless opinion pieces, documentaries and dramas about 
dangerously disenfranchised young men, with much discussion about why they’re moving to the 
populist right. Frustrated and overly online young men are widely seen to be the drivers of a quiet 
revolution that has been taking place in youth politics: the widening gender gap. Yet not enough 
thought has been given to young women’s much greater movement in the opposite direction. It might 
not be too surprising that women’s political preferences get less attention than men’s, but that does 
not mean they are any less significant. 
Many have noted that at the last general election young (18- to 24-year-old) men were twice as likely 
as young women to vote Reform, while young women were twice as likely to vote Green as young 
men. There was also extensive coverage given to the signs of Gen Z men backing Nigel Farage. What 
these observations fail to take into account is that, in fact, a smaller percentage of young men voted 
for Reform (12 per cent) than the general population (14.3 per cent). Actually, 18- to 24-year-old men 
were far less likely to have voted for Farage than every other age cohort of men, and young men were 
still overwhelmingly more likely to vote for left-wing or liberal parties (68 per cent voted Labour, 
Lib Dem or Green) than they were for a right-wing party (22 per cent voted Conservative or Reform). 
If voting for a populist right party is indicative of a more radical mindset, then by this metric young 
men were some of the least radical demographic groups of the whole country.  
The 2024 voting patterns of young women tell a very different story. Nearly one in four (23 per cent) 
of 18- to 24-year-old women voted for the Green Party at the last general election, compared to just 
6.7 per cent of the general population (12 per cent of young men voted for the Greens). Greens 
performed far better with young women than with any other key demographic (just 10 per cent of 25- 
to 49-year-old women voted Green, and only 4 per cent of 50- to 64-year-olds). In last year’s general 
election, young women moved to the populist left considerably more than young men moved to the 
populist right.  
Current voting intention polls show these trends not only persisting but becoming more pronounced. 
Recent data from More In Common shows that one in three (33 per cent) of young women now say 
they will vote for the Green Party. Meanwhile, young men, far from being more right wing than the 
population as a whole, are as likely to vote Green as they are Reform (20 per cent) with Reform still 
significantly underperforming with under 25 males relative to other age groups.  
In fact, the UK is not alone in seeing young women move increasingly to the left. Recent elections in 
the US, Germany and Portugal all show similar movements between the sexes.  
In previous decades young women were actually more likely to vote Conservative than men. 
However, this trend started reversing in 2015, primarily driven by the younger end of the electorate. 
In 2019, 18- to 25-year-old women voted for Jeremy Corbyn at more than double the rate of the 
general population (65 per cent to 32.1 per cent), dwarfing the still considerable 46 per cent of young 


## PDF page 92

92 
 
men who did the same. What over the past decade has caused young women to lurch so dramatically 
to the left?  
I recently recorded a documentary for Radio 4 with Gaby Hinsliffe exploring some potential 
explanations as to why women are moving dramatically to the left. We discussed the idea that there 
might be more to the change than conventional party politics. Strikingly, the majority of young people 
do not identify as either right- or left-wing. Instead, young women see their politics as flowing from 
their deeply held progressive personal values, which they increasingly think are at odds with the 
country they see around them.  
Britain’s young women seem to feel more alienated from their country than their male peers, and are 
more likely to think that the country is treating them unfairly compared to older generations (men 
marginally disagree with the statement, women agree 55 per cent to 37 per cent).  Young women feel 
less connected to their country than young men and are 21 points more likely to think that the country 
is racist than young men (58 per cent to 37 per cent). Only a minority (31 per cent) say they take pride 
in being British (compared to 51 per cent of men the same age) and only 38 per cent believe Britain 
is a tolerant nation (56 per cent of young men think the same).  
In fact, young women are not just pessimistic about the country’s culture, but the country’s economy 
too. It makes sense, with sky-high rental prices, a hardening graduates job market, and years of 
stagnated living standards, that Gen Z would feel worse about the economy than average. What is 
less clear is why young women are the most pessimistic group when it comes to the UK economy, 
with an astonishingly low net economic optimism score of -57 (18 points worse than men of that age 
group). Perhaps this is why younger women are much more likely to place prices for food and energy 
bills and housing affordability in their top issues than young men, although it does not fully explain 
their political priorities. One in three (31 cent) of 16- to 25-year-old women say the conflict in Gaza is 
in their top three issues, placing it above things like taxes and immigration (just 22 per cent of young 
men say the same). 
Again, it is not immediately obvious why young women would report feeling more isolated than their 
male peers, but there does seem to be a loneliness epidemic among young women. A majority (53 per 
cent) saying they feel lonely, substantially more than the proportion of young men saying the same.    
The amount of time spent online is also surprisingly skewed across the gender divide. It is well known 
that the “Covid generation” were kept off school and forced to live out their social lives on the 
internet, and that algorithms mean young men and women live increasingly parallel lives online. What 
is less well known is that Covid generation women self-report as being more online, or at least more 
worried about it, than their male peers. Eighty-four per cent of women this age say they use TikTok 
regularly compared to 67 per cent men. Young men are more likely than women to use X, but in much 
smaller numbers than women use TikTok (46 per cent to 26 per cent). Online media consumption 
seems to be worrying young women more than men, with far more likely to say they spend “far too 
much time on social media” (49 per cent of 18- to 24-year-old women compared to 36 per cent of 
men the same age).  
Behavioural differences, as well as personal values, could be significantly shaping the gender divide. 
Online media consumption, higher education (the gender divide is starkest between women with 
university degrees and men without them, with 56 per cent of university students now women) and 
even relationship status all seem to drive the increasingly different political outlooks from young men 
and young women. The political gap between those that are single is even more pronounced than 
between those who are married. 


## PDF page 93

93 
 
But whatever the reasons, the extent to which young women feel alienated from the rest of the country 
matters. There is still a prevailing sense that whatever young women are thinking or feeling, it doesn’t 
matter very much. Political trends among this cohort are generally seen more like a questionable 
fashion choice that they’ll probably soon grow out of, rather than anything meaningful or significant. 
But the extent to which young women are moving to the populist left is dramatic and doesn’t show 
signs of changing anytime soon. This crucial gender divide will not only continue to shape our politics 
but could also alter our social fabric as women increasingly feel they have less in common with older 
generations and men their own age. The consequences of an increasingly radical generation of young 
women could be dramatic and long-lasting.  
 
 


## PDF page 94

94 
 
MPs across UK Parties Criticise Ministers over Cautious Stance on Venezuela 
Attack:  
Keir Starmer and Yvette Cooper challenged for refusing to criticise Trump’s 
raid despite widespread doubts about legality 
By Kiran Stacey and Sammy Gecsoyler 
Monday, 5 Jan 2026 | The Guardian 
 
MPs have attacked UK ministers over their refusal to criticise Donald Trump’s attack on Venezuela, 
as Keir Starmer attempts to walk a fine line between defending international law and keeping the US 
president on side. 
Labour, Conservative and Liberal Democrat MPs rounded on the foreign secretary, Yvette Cooper, on 
Monday night as frustration grew over the government’s cautious response to the US capture of the 
Venezuelan president, Nicolás Maduro. 
Both Cooper and the prime minister have been reluctant to criticise Trump’s actions or to give an 
opinion on their legality, prompting concern among critics that the UK’s response will embolden 
China and Russia. 
Speaking in the Commons on Monday evening, Emily Thornberry, the Labour chair of the foreign 
affairs select committee, said: “If a large and powerful country abducts the leader of another, however 
abhorrent that leader is, and then tries to intimidate the smaller country – in order it says itself to gain 
access to its resources – doesn’t the foreign secretary agree that this should be called out, not just by 
Britain, but by our western allies?”  
She added: “We should be calling it out for what it is: a breach of international law.” 
Those sentiments were echoed by colleagues from the left of the Labour party, but also from many 
on the Liberal Democrat and even the Conservative benches. 
Richard Burgon, a Labour MP, said: “It was the prime minister that decided to disregard the United 
Nations charter when it came to Trump’s bombing, killing, and [the] kidnapping of a head of state. I 
think it speaks volumes that the prime minister has chosen not to come to this house to explain his 
decision.” 
Ed Davey, the Liberal Democrat leader, said: “Maduro is a brutal, illegitimate dictator, but that does 
not give President Trump a free pass for illegal action.” 
The former Conservative foreign secretary, Jeremy Hunt, warned that the entire future of Nato could 
be at risk if western allies did not face down American threats to launch an attack on Greenland next. 
“If the new US approach extends to the annexation of Greenland – the sovereign territory of a Nato 
member – it could mean the end of the alliance with disastrous consequences. 
“So how much planning is going on at the Foreign Office to actually make sure such a disaster doesn’t 
happen? We understand the discussions between allies have to be in private, but what it looks like 
from the outside is that Europe is weak and divided.” 


## PDF page 95

95 
 
The MPs’ frustrations were voiced after a tense day of international diplomacy in which Cooper spoke 
to both her US counterpart, Marco Rubio, and María Machado, the prominent Venezuelan opposition 
politician. 
Cooper told the Commons she had stressed the importance of international law in her conversation 
with Rubio, but would not say whether she saw the US action as illegal, saying it was for Washington 
to set out its justification. 
Starmer spent much of the day preparing for a meeting of the “coalition of the willing” – the group 
of countries that are prepared to contribute to the long-term security of Ukraine. That group has been 
keen to keep Washington on side as it prepares for the possibility of a peace deal between Moscow 
and Kyiv. The prime minister said on Monday he wanted to “establish the facts” before passing 
judgment on whether Trump broke international law with the attack on Caracas. 
He did however mount a robust defence of Denmark after Trump reiterated suggestions the US could 
annex Greenland. 
“Denmark is a close ally in Europe, it is a Nato ally,” he said. “It’s very important the future of 
Greenland is for the kingdom of Denmark and for Greenland, and only for Greenland and the kingdom 
of Denmark.” 
Those comments came hours after the Home Office minister, Mike Tapp, attracted criticism for 
refusing to say that the UK would defend Denmark over the future of Greenland. 
In broadcast interviews earlier on Monday, Tapp refused to directly criticise the idea of a US takeover 
of Greenland, telling Sky News: “Diplomacy is delicate, which means we’re not here to give a running 
commentary in the news.” 
 
 


## PDF page 96

96 
 
Some Trumpists Object to MAGA’s White Power Element. Why Now? 
By Matt K. Lewis 
7 November 2025 | LA Times 
 
The uproar over Tucker Carlson’s interview with white nationalist and Holocaust denier Nick Fuentes 
has sparked yet another round of MAGA civil war talk. 
Full disclosure: I previously worked for Carlson at the Daily Caller, so I’ve had a front-row seat for 
this ongoing battle for a long time now. 
In case you missed the latest: Carlson invited Fuentes onto his podcast. What followed wasn’t an 
interview so much as a warm bubble bath of mutual validation — the kind of “conversation” that 
helps launder extremist ideas. 
Enter Kevin Roberts, president of the Heritage Foundation — once the intellectual vanguard of 
conservatism, now something closer to an emotional support group for people who think President 
Reagan was too soft. Responding to whispers that Heritage might distance itself from Carlson, 
Roberts rushed out a video to reassure the faithful: Heritage will have no enemies to its right. 
Roberts disagreed with Fuentes (good for him) but insisted Heritage didn’t become the top 
conservative think tank by “canceling our own people or policing the consciences of Christians.” He 
also called Carlson’s critics a “venomous coalition” who “serve someone else’s agenda” — which 
echoes one of the oldest antisemitic tropes in the book. 
And then something surprising happened: People inside Heritage actually pushed back (a brave move, 
given Heritage’s Orwellian “one voice” policy). Some even resigned. 
The broader right-wing commentariat weighed in, too. Ben Shapiro called Carlson an “intellectual 
coward.” Ted Cruz made some noise. The Wall Street Journal editorial board huffed. And talk radio 
host Mark Levin criticized Fuentes and Carlson during a speech to the Republican Jewish Coalition. 
For a brief moment, it looked like accountability was actually trending. 
But … why this moment? Why now? 
Keep in mind: Then-former President Trump dined with Fuentes in 2022 and wrongly claimed 
immigrants were eating pets in 2024. As president, he told the Proud Boys to “stand back and stand 
by” in 2020. And of course he launched his political career by questioning President Obama’s birth 
certificate. I could go on. 
Despite all of this, Trump’s grip on the conservative movement only grew firmer. 
Meanwhile, right-wing antisemitism has metastasized on Trump’s watch — despite his support for 
Israel. 
Charlottesville, anyone? 
The “alt-right” has shed its “alt.” They’re just “right” now. 
This is especially observable when it comes to young conservatives who came of age during the 
Trump era. Indeed, one Heritage staffer told the New York Post that “a growing number” of Heritage 
interns “actually agree” with Fuentes. 


## PDF page 97

97 
 
And here’s the irony: The same conservative media figures now sounding the alarm helped build the 
machine. 
Take Levin. Fuentes recently admitted that it was Levin’s radio show that first radicalized him. “He 
planted the seed, at least,” Fuentes told Carlson. 
Likewise, aside from endorsing Trump in 2024, Shapiro made conspiracy theorist Candace Owens 
famous when his Daily Wire hired her to host a podcast on its platform after she became buddies with 
Kanye West and after she suggested the only problem with Adolf Hitler was that “he had dreams 
outside of Germany.” 
So if these more mainstream Trumpers are horrified now, it’s probably because they helped create 
monsters — and those monsters are now coming to devour their creators, as monsters always do. 
Rest assured, though, this rot is not limited solely to antisemitism. In recent months, MAGA figures 
such as Vivek Ramaswamy, FBI Director Kash Patel and even Vice President JD Vance (who is 
married to an Indian American woman) have all been targets of racist abuse online. 
It’s important to note that none of these folks are considered “Never Trump” or Reagan conservatives. 
They are Trump allies. The revolution devours itself. (First they came for the Never Trumpers.…) 
Again, this is far from the first skirmish in the MAGA civil war. But all of these internecine fights 
obscure the root cause of the problem: Trump. And yet, the orange emperor himself? Off-limits. 
The fever won’t break while Trump’s still around, serving as a magnet for the worst people and 
cultivating the toxic ecosystem that made all of this right-wing racism possible, if not inevitable. 
So by all means, conservatives: Condemn Carlson, denounce Fuentes and scold Heritage for failing 
to police the right and only punching left. 
But as long as you avert your eyes from Trumpism, your righteous outrage is just theater — the 
political equivalent of aggressively mopping the floor while the pipes keep bursting. 
 
Excerpted from: https://www.latimes.com/opinion/story/2025-11-07/tucker-carlson-nick-fuentes-
no-enemies-to-the-right 
 
 


## PDF page 98

98 
 
Fierce Backlash within GOP after Tucker Carlson Gives White Nationalist Nick 
Fuentes a Platform 
By Andrew Kaczynski and Steve Contorno 
6 November 2025 | CNN 
 
 
Nick Fuentes, the well-known White nationalist and Holocaust denier, has ignited a civil war within 
the Republican Party — and inside one of Washington’s most prominent conservative think tanks.  
A bitter split has erupted on the political right after former Fox News host Tucker Carlson hosted 
Fuentes on his podcast for an overwhelmingly friendly conversation. Some conservatives, including 
Dinesh D’Souza and Ben Shapiro, have condemned Carlson for elevating a fringe figure who has 
expressed an affinity for Adolf Hitler and regularly traffics in racist, sexist and antisemitic tropes.  
Much of the pushback has focused on their sharp criticism of Israel during the show and their mockery 
of Christians who have made support for the Jewish state a top priority.  
But Heritage Foundation President Kevin Roberts defended Carlson, a close ally who addressed the 
organization’s annual gathering in April. Roberts argued that criticizing Carlson and shunning Fuentes 
undermines the crusade against censorship and so-called cancel culture.  
“Christians can critique the state of Israel without being antisemitic,” Roberts said in a lengthy direct-
to-camera statement that has since garnered more than 24 million views on social media.  
The backlash has been swift against Roberts, triggering a wave of unrest within Heritage and raising 
questions about the future of an institution that has for decades been a pillar of the conservative 
movement.  
[…] 
Attempts by CNN to reach Fuentes and Carlson for comment were not successful. But on his podcast, 
Fuentes has said disorder is central to his plan for pulling the GOP toward his worldview.  
“We want disruption, we want chaos, we want infighting,” he said in September.  
Heritage takes a far-right turn  
Founded in 1973, Heritage has long been a driving force aiding Republican policymaking — from 
past Republican administrations’ conservative tax agendas to President Donald Trump’s judicial 
appointments.  
Under Roberts, it has pushed a harder-line message, positioning the organization at the center of 
Project 2025 — a sweeping policy blueprint for a potential Republican administration that included 
calls for restructuring the federal government and curtailing federal workforce protections. The plan 
proved controversial enough that even Trump publicly distanced himself from some of its proposals.  
The Fuentes controversy has only deepened internal divisions over that direction.  
“Many staff are outraged,” a former top staffer who worked under Roberts also told CNN. “I’ve 
spoken with numerous (staff).”  


## PDF page 99

99 
 
“I’m disgusted by this and don’t understand how this premeditated and orchestrated response could 
come out of one of the biggest think tanks in the world,” another wrote in the text exchange.  
[…] 
One major donor, whose organization contributes more than half a million dollars annually to the 
Heritage Foundation, told CNN they have lost faith in Roberts’ leadership. “I’m waiting to see how 
things play out, but if Kevin remains as president we will not be giving to Heritage,” said the donor, 
who asked their name not be used due to privacy concerns.  
The episode also comes just weeks after similar divisions emerged on the right over a trove of text 
messages from young Republican operatives published by Politico, which included someone saying 
“I love Hitler,” with others contributing Holocaust jokes and racial slurs.  
“If you sit there with someone who says Adolf Hitler was very, very cool and their mission is to 
combat and defeat ‘global Jewry’, and you say nothing, then you are a coward, and you are complicit 
in that evil,” Texas Sen. Ted Cruz — who has sparred with Carlson before — said last weekend during 
remarks at the Republican Jewish Coalition’s annual gathering.  
‘Tucker Carlson is a poison pill’  
The growing influence of Fuentes, especially following the death of conservative activist Charlie 
Kirk, exposes a broader rift inside the Republican Party over whether to distance the GOP from the 
kind of rhetoric he represents.  
In addition to Cruz, Kentucky Sen. Mitch McConnell has also come out against Carlson’s approach 
to Fuentes in recent days. So has Laura Loomer, the far-right provocateur close to Trump, who warned 
that the GOP was “imploding” over Fuentes and engaged in a “power struggle” to “try to hijack and 
redefine what MAGA is and should be post-Trump.”  
While Loomer and Fuentes have publicly feuded in recent days over who had more sway with the 
president and his followers, she was unsparing in whom she blamed for the past week.  
“Tucker Carlson is a poison pill to the GOP,” she told CNN in a text message. “And he will cost the 
GOP elections in 2026 and 2028.”  
Fuentes has suggested the past week has signaled his growing influence in today’s Republican Party 
— especially with young men, a key force in Trump’s electoral coalition last fall.  
After being cast to the edges of the conservative movement and getting banned from social media 
over offensive statements, Fuentes and his devoted listeners — whom he calls “groypers” — are 
making their presence felt, he said. Fuentes’ X account, reinstated by Elon Musk, now has 1 million 
followers.  
“We are thoroughly in the groyper war,” Fuentes said on his web show last week as the fight unfolded. 
“The civil war for the GOP.”  
Last fall, Fuentes said he did not vote for Trump because the Republican nominee did not go far 
enough to push an America First agenda that’s more in-line with his White nationalist views. Fuentes 
has said he wants to go back to the Middle Ages and a time when women couldn’t vote and 
contraceptives and fornication were banned. He celebrated Afghanistan falling under control of the 
Taliban because they would “ban abortion, vaccines and gay marriage.” In his interview with Carlson, 
Fuentes expressed admiration for former Soviet leader Joseph Stalin, a brutal dictator whose 
tyrannical reign resulted in millions of deaths from starvation and imprisonment in labor camps.  


## PDF page 100

100 
 
Roberts apologizes to Heritage staff  
At Heritage, the fallout continues. On Monday, Heritage Chief of Staff Ryan Neuhaus resigned, days 
after he reposted a comment on X urging internal critics of Heritage’s defense of Carlson to leave the 
organization.  
On Tuesday, the Zionist Organization of America (ZOA), the country’s oldest pro-Israel advocacy 
group, announced it was withdrawing from the Heritage Foundation’s Project Esther on Antisemitism, 
an initiative launched in 2024 to combat antisemitism. In a statement provided to CNN, ZOA said it 
would end its participation unless Roberts publicly apologizes, retracts his praise for Carlson, and 
“condemns and permanently ends his affiliation with Carlson.”  
On Wednesday, at an all-staff meeting, Roberts acknowledged mishandling the controversy. 
According to an audio recording obtained by CNN, Roberts told Heritage employees, “I made a 
mistake, and I let you down, and I let down this institution, and I’m sorry, period, full stop.”  
Roberts also said during the meeting that he had no intention of resigning.  
Current and former staffers are also accusing Roberts of political opportunism, pointing to past 
statements they said contradict his current alignment with figures like Carlson.  
In tweets posted after the January 6, 2021, attack on the US Capitol and later deleted, Roberts 
appeared to take aim at Trump and praised then-Vice President Mike Pence and Texas Rep. Chip Roy 
for their criticism of the president’s effort to overturn the 2020 election.  
“Storming the Capitol will do more to quash the need for real election reform than anything the Left 
has done and will do to prevent it. This is stupid, and real leaders would condemn immediately,” 
Roberts wrote in a since-deleted post.  
In another tweet, he praised Roy, a Texas Republican who condemned Trump’s false claims of 
election fraud on the House floor saying, “the president should never have spun up certain Americans 
to believe something that simply cannot be.”  
 
Excerpted from: https://edition.cnn.com/2025/11/06/politics/nick-fuentes-tucker-carlson-heritage-
foundation-kevin-roberts 
 
 


## PDF page 101

101 
 
Tucker Carlson’s Interview with Antisemite Nick Fuentes Exposes Rift among 
Republicans 
PBS News Hour 
7 November 2025 | PBS 
 
This week, a task force dedicated to fighting antisemitism reportedly decided to cut ties with the 
conservative Heritage Foundation. It comes after the think tank’s president, Kevin Roberts, defended 
Tucker Carlson’s interview with a far-right, antisemitic activist. The infighting has laid bare a growing 
schism within conservative circles over how to address antisemitism. William Brangham reports. […] 
The interview, which lasted over two hours, was posted late last month and has been seen over 20 
million times, the conservative commentator Tucker Carlson interviewing Nick Fuentes, the 27-year-
old hard-right influencer with millions of followers known as Groypers. 
Fuentes is known for his open racism. 
Nick Fuentes: 
White people have a special heritage here as Americans. 
William Brangham: 
His misogyny, like when he wrote, “Your body, my choice,” after the 2024 election. 
Nick Fuentes: 
The whole political system is just based around women never being accountable for any of their 
choices. 
William Brangham: 
And his overt antisemitism, ranging from Holocaust denial to his belief in a global Jewish conspiracy. 
Nick Fuentes: 
The big challenge to that is organized Jewry in America. 
The interview with Carlson drew quick, sharp condemnation from many in the conservative 
movement. […] 
But Kevin Roberts, head of The Heritage Foundation, defended Carlson. Heritage is the influential 
conservative think tank behind Project 2025 and which has long supported Israel and America’s 
support for it. Roberts argued attacking Carlson was a distraction. 
Kevin Roberts: 
The venomous coalition attacking him are sowing division. Their attempt to cancel him will fail. Most 
importantly, the American people expect us to be focusing on our political adversaries on the left, not 
attacking our friends on the right. 
Roberts faced a strong backlash, including from staffers within Heritage, and calls for his resignation. 
He later apologized and denounced Nick Fuentes specifically. 


## PDF page 102

102 
 
But the controversy has revealed the ongoing challenge of balancing different factions within the 
MAGA base. 
For the “PBS News Hour,” I'm William Brangham. 
[…] 
Excerpted from: https://www.pbs.org/newshour/show/tucker-carlsons-interview-with-antisemite-
nick-fuentes-exposes-rift-among-republicans 
 
 


## PDF page 103

103 
 
They Saw Their Neighbors Taken Away by ICE. Then They Made a Plan 
By Michelle Goldberg 
30 July 2025 | The New York Times 
 
Elizabeth Castillo wasn’t an activist until Immigration and Customs Enforcement started taking away 
her neighbors. 
It all began in June, after Donald Trump directed Immigration and Customs Enforcement agents to 
sweep Los Angeles, then used scattered violence at protests of ICE’s tactics as a pretext to send in the 
military. Castillo felt her working-class neighborhood in Pasadena, just outside Los Angeles, was 
under siege. Six people, she said, were seized at a Winchell’s doughnut shop. Two people were taken 
when ICE raided her apartment complex. 
[…] she’s someone who knows firsthand what deportation can do to families. In 2012, she said, when 
her kids were all under 10, her husband, who was born in Mexico but grew up in the United States, 
was thrown out of the country. She had been a full-time student; he was the family’s sole provider. 
Castillo had to drop out of college and explain to her children why their father could no longer live 
with them. “I can relate to what it does to a family,” she said. So this summer, when ICE started 
grabbing people from her community off the streets, she felt she had to act. 
At first, Castillo was on her own with a megaphone. When she saw ICE vehicles in the streets she 
followed them in her car, honking and shouting to warn people that they were coming. She started 
getting up before dawn to patrol her apartment complex. Then she contacted the National Day Laborer 
Organizing Network, which runs a nearby job center. Through it, she was plugged into a citywide 
network of people who are constantly tracking ICE’s activities. 
Among those doing amateur anti-ICE reconnaissance in Los Angeles are people from established 
nonprofits that work closely with the mayor’s office. Then there are more militant groups that, beyond 
simply documenting ICE’s operations, try to actively disrupt them. 
[…] 
The widespread raids that have upended life in Los Angeles may soon spread to other cities, especially 
now that Republicans in Congress have increased ICE’s budget to $27.7 billion, up from about $8 
billion. (That’s more than that of most militaries.) “We are a petri dish,” Mayor Karen Bass of Los 
Angeles told me. “They’re experimenting with us. If they come and make this stand in Los Angeles, 
then they can scare all the other cities, just like the universities have been scared, just like the legal 
firms have been scared.” 
Yet if Los Angeles is a testing ground for mass deportation, it’s also a place to see how the resistance 
is evolving. Though there have been some big anti-Trump marches this year, many of the people most 
horrified by this administration are looking for more immediate, tangible ways to thwart it. The 
movement against ICE in Los Angeles — one that is starting to take root, in different forms, in cities 
like New York — is part of a growing shift from symbolic protest to direct action. 
[…] 
“We have been abandoned by the courts, by the business community,” and, with few exceptions, “by 
the political class in Washington, D.C.,” said Pablo Alvarado, a co-founder of the National Day 


## PDF page 104

104 
 
Laborer Organizing Network. “All we have are our friends, our allies and ourselves.” One of his 
group’s slogans is, “Solo el pueblo salva al pueblo.” It means, “Only the people can save the people.” 
[…] 
In the first Trump presidency, the resistance announced itself with the Women’s March, a gargantuan 
display of feminist fury at Trump’s improbable victory. No similar spectacle greeted his return. For 
those who abhor him, Trump’s re-election was devastating, but it wasn’t shocking. He’d won the 
popular vote, giving him a democratic legitimacy he didn’t have the first time around. The dominant 
mood in many blue precincts was despair rather than outrage. Organized opposition to Trump seemed, 
at least to some observers, to be dormant. […] 
While the exhaustion was real, it wasn’t the whole story. […] 
Resistance in the second Trump term, however, looks a bit different than it did in the first. There’s 
less focus on big marches and rallies, and more on trying to make a concrete difference, often close 
to home. Think of the doctors sending abortion medication into states with prohibitions, or the protests 
in front of Tesla dealerships that helped push down the company’s stock price. “Resistance 2.0 is 
much more locally grounded and community-embedded,” said Dana Fisher, an American University 
sociologist who studies protest movements. 
The shift in tactics derives in part from a changing understanding of the crisis we face. During 
Trump’s first term, the resistance often put its trust in existing institutions. Indivisible, founded by 
two former Hill staffers, organized people by congressional district and taught them how to lobby 
their representatives. Some liberals made heroes of establishment figures like Robert Mueller, the 
special counsel who led the investigation into Russian interference in the 2016 election, and Dr. 
Anthony Fauci, director of the National Institute of Allergy and Infectious Diseases. Newly awakened 
citizens showered the Democratic Party and big nonprofits like the A.C.L.U. and Planned Parenthood 
with donations. 
The assumption underlying the resistance then, said Fisher, was “that Trump was a blip,” elected by 
a freakish confluence of unlucky circumstances. His victory was seen as a mistake that future 
elections could fix. The resistance, she said, “was all about getting us to 2018, and all about trying to 
create the capacity to push back using the political system.” 
This is, of course, a generalization; there was plenty of civil disobedience and left-wing radicalism 
during Trump’s first term, especially in the febrile summer of 2020. But looking back from the bleak 
vantage of 2025, it’s striking how optimistic many people were that some established power in 
American life — be it Congress, law enforcement, government bureaucrats or the media — could 
stop Trump from doing his worst. 
As such faith has withered, the character of the resistance has changed. “We recognize that in a period 
of authoritarian breakthrough where there is a very rapid sprint to consolidate power, you cannot 
focus purely on the formal political avenues of representation,” said Leah Greenberg, one of 
Indivisible’s founders. “Getting out of this is going to require a symphony of defiance.” 
Indivisible is running a campaign called “One Million Rising” aimed at training a million people in 
strategies of protest, noncooperation and civil disobedience, especially around mass deportation. The 
emphasis on ICE is in part simply a response to the sheer cruelty of Trump’s immigration regime. Far 
from prioritizing criminals, ICE, under pressure from Trump’s fanatical deputy chief of staff Stephen 
Miller, seems desperate to round up as many people as possible. That includes people with American 


## PDF page 105

105 
 
spouses and children who’ve been here for decades, those who’ve followed all the rules in seeking 
asylum, and even those with green cards. 
In recent months viral videos have shown ICE agents breaking car windows, throwing people to the 
ground and ripping parents away from their kids. Human Rights Watch has reported on the degrading 
treatment of immigrants in federal detention; at one Florida facility, men described being forced to 
eat “like dogs” with their hands shackled behind their backs. Venezuelan migrants sent by the United 
States to a megaprison in El Salvador have reportedly faced even worse conditions; Andry Hernández 
Romero, a gay makeup artist later freed as part of a prisoner exchange, described being tortured and 
sexually assaulted by guards. 
Yet the campaign against ICE isn’t only about immigrants, because to many on the left, the agency is 
understood as the tip of the authoritarian spear. Trump and those close to him, after all, are openly 
fantasizing about stripping Americans of citizenship or sending them to the same El Salvador gulag 
that held Hernández Romero. Americans are being forced to acclimate to the once-unthinkable sight 
of masked men, wearing civilian clothes and refusing to show identification, grabbing people off the 
streets and throwing them in the back of vehicles. There have been reports of ICE agents assaulting 
and detaining U.S. citizens. […] 
“They have made a calculation that they can get away with a bunch of things as long as it’s framed 
as immigration enforcement,” said Greenberg. “That will then allow them to ratchet up authoritarian 
conditions for the rest of us.” 
[…] 
This month, armed ICE agents backed by National Guard troops, some on horseback or in armored 
vehicles, stormed into the city’s MacArthur Park, forcing kids at a nearby summer camp to shelter 
inside. Bass was livid, but the administration made clear that she had little authority. “I don’t work 
for Karen Bass,” the Border Patrol chief, Gregory Bovino, told Fox News. “Better get used to us now, 
because this is going to be normal very soon. We will go anywhere, anytime we want in Los Angeles.” 
[…] 
One thing Los Angeles has going for it, however, is a deep, established immigrant rights ecosystem. 
These groups, said Bass, “have prepared for this type of stuff in the past, though not as massive, not 
as egregious as this.” Indeed, she told me her office relies on activist networks to keep abreast of ICE 
activity in the city. “That’s how I learn about where raids are happening,” she said. “It’s not like we’re 
notified of anything.” 
It’s a jarring statement about the relative impotence of city government, but also a testament to what 
an important role the activists are playing. 
[…] 
There is, of course, only so much such resistance can accomplish in the face of a heavily armed, 
spectacularly well-funded and politically powerful deportation machine.  
[…] 
Clearly, however, it matters that people are watching what ICE is doing. As Alvarado points out, a 
major reason public opinion is turning against Trump’s mass deportation campaign is the viral videos 
showing what it looks like in practice. Activist groups train people to record ICE activities wherever 
they see them, helping to capture both arrests and agents’ aggression toward civilian observers. “Men 


## PDF page 106

106 
 
in masks, wearing civilian clothes, pulling guns against people who are exercising their rights while 
filming, that’s exactly what Americans don’t like to see,” he said. 
Alvarado is a citizen now, but he grew up in El Salvador, fleeing the civil war with his brother when 
he was 22. The sight of masked men taking people away to sites unknown feels familiar to him. “This 
is a word I don’t take lightly, but people talk about disappearances,” he said of the situation in Los 
Angeles. “For now, it’s a stretch, I will say, but that’s how it starts. No right to due process. People 
just snatch you and put you in the vans. It’s something I’ve seen, and I know where that leads.” 
To fight what’s coming, he believes, people will have to depend on one another. “Not by being violent 
and responding with more violence, but by building community and understanding,” he said. 
If nothing else, neighbors banding together to weather an emergency is an antidote to helplessness 
and isolation. The three people volunteering at Orange Grove and Garfield when I was there — 
Castillo, Simental and Karen Skelly, who works as a personal and administrative assistant — hadn’t 
known one another before June. Now, said Simental, they’re intertwined like shoelaces: “We just all 
tied up together.” As we spoke, people kept walking up to take signs, fliers or bracelets, or just to say 
thank you. Passing drivers honked in appreciation. Simental told me about a local man who checks 
with him to make sure the coast is clear before he goes to the laundromat or the market. 
“Everyone is protecting each other right now, and we can see it, we can feel it,” said Castillo. “I don’t 
know — we feel like the sheriffs in town.” 
 
Excerpted from: https://www.nytimes.com/2025/07/30/opinion/ice-immigration-protest-
resistance.html 
 
 


## PDF page 107

107 
 
ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor 
By Joel Kotkin 
14 July 2025 | LA Times 
 
Even as Californians protest the crude and often brutal deportation tactics employed by President 
Trump’s ICE and Homeland Security agents, we’re giving too little thought to how our state, and the 
nation, is failing the very immigrant community we want to protect. 
In the past, particularly in the last century, when the U.S. economy, and California’s, was growing at 
a fast rate, loosely controlled immigration filled critical needs and, over time, moved many 
immigrants into an increasingly diverse middle class. But now newcomers are getting stuck. 
According to new findings from USC and University of California researchers, immigrants account 
for nearly a quarter of the U.S. population living in poverty, up from 14% three decades ago. 
The immigrant poverty rate fluctuates, but it has been rising in recent years, especially since the 
pandemic. In 2024, 22.4% of all immigrants and 28.4% of non-citizen immigrants, including the 
undocumented, were poor, the highest rates since 2008. 
As well, welfare dependency is more pronounced among immigrants than the native born. A 2023 
analysis of census data showed that 54% of households headed by naturalized citizens, legal residents 
and the undocumented use one or more welfare programs versus 39% of U.S.-born households. 
In California, the overall situation is only slightly better. A 2023 report from the Public Policy Institute 
of California put the poverty rate for all foreign-born residents at 17.6%, compared to 11.5% for those 
born here. For unauthorized immigrants, however, the rate was even higher than the national figure: 
29.6%. Undocumented households, notes a separate USC study, have consistently had the lowest 
median household income in L.A. — $46,500, compared to $75,000 among all Angelenos in 2024. 
The grim statistics reflect a decline starting in the 1980s in blue-collar industries in California, which 
traditionally offered upward mobility to immigrants. Unionization in the immigrant-heavy hospitality 
industry has helped lift some families, but those gains may lead to fewer jobs as employers look to 
rein in costs, potentially by automating some services. And immigration itself, especially mass 
immigration, puts downward pressure on many of the jobs newcomers fill — in agriculture, for 
example, or construction. 
The dearth of jobs that support families has pushed California toward a model that Michael Lind, a 
Texas-based historian and author, describes as the “low wage/high welfare model.” 
The fiscal implications are severe. The president has signed executive orders denying federal funds 
to sanctuary cities, funds that would shore up city and state budgets for policing, education and many 
other services affected by immigration. Those orders have been stymied in the courts, although Trump 
is sure to try again. At the same time, the budget the president signed into law on July 4 boosts funds 
for border enforcement but cuts back such things as medical services for non-citizens, even for those 
who are here legally. 
This will cause particular distress in deep blue states. California’s current budget shortfall has forced 
Trump “resistance” leader Gov. Gavin Newsom to scale back healthcare for the undocumented, which 
is also occurring in other progressive hotbeds such as Washington state, Illinois and Minnesota. 


## PDF page 108

108 
 
The simple truth is that the low wage/high welfare economy dependent on illegal immigration isn’t 
sustainable. Economic reality suggests we need a commonsense policy to restrict new migration and 
to focus on policies that can allow current immigrants — especially those deeply embedded in our 
communities and those with useful skills — to enjoy the success of previous generations. 
What would a commonsense policy look like? It would secure the border, which the Trump 
administration is already doing, and shift immigration priorities away from family reunion and more 
toward attracting those who can contribute to an increasingly complex economy. Deportations should 
prioritize convicted criminals and members of criminal gangs, whose presence is hardly welcomed 
by most immigrants. 
Law-abiding immigrants who are here without authorization should be offered a ticket home or a 
chance to register for legal status based on a clean record, paying taxes and steady employment. In 
addition we need to consider a new Bracero Program, which allowed guest workers to come to the 
U.S. legally without their families in the mid-20th century. Even President Trump has been forced to 
acknowledge that low-wage immigrant labor is difficult to replace in some sectors.  
This kind of immigration reform has eluded Congress for decades, but a clear-eyed assessment shows 
that merely welcoming newcomers willy-nilly won’t pay off for most migrants or for California. A 
large pool of undocumented labor is the exact opposite of what is needed to nurture a strong and 
sustainable economy. If you are protesting against ICE raids and immigrant bashing, you should also 
be protesting for remaking U.S. immigration according to economic fundamentals. The prospect of a 
better life should be available to us all. 
 
Excerpted from: https://www.latimes.com/opinion/story/2025-07-14/california-immigration-
poverty-welfare-deportation-wages 
 
 


## PDF page 109

109 
 
Protests against ICE Have Continued in LA into the Week. Here’s What to 
Know 
By Ayana Archie  
10 June 2025 | NPR 
 
As a weekend of protests against immigration raids in California have continued into this week, the 
Trump administration has responded by deploying more Marines and National Guard troops to Los 
Angeles, sparking heated exchanges with politicians in the state. 
Los Angeles police said that while the protests have mostly been peaceful, some violence has 
occurred. Though, several officials have rebuffed the president's intervention, saying they have it 
handled.  
Los Angeles Mayor Karen Bass said she feels the city is being used as a “test case for what happens 
when the federal government moves in and takes the authority away from the state, or away from 
local government.” 
Dozens of people have been arrested in LA 
In Los Angeles, 50 people were arrested between Saturday and Monday morning, the LAPD said. 
Los Angeles Police Chief Jim McDonnell has said the department supports the First Amendment right 
to assemble. 
“Those who choose to incite violence, engage in vandalism or graffiti, and/or attack officers will be 
arrested,” he said Monday. “There’s no tolerance for criminal activity under the guise of protest.” 
The department said some people were building barricades and throwing objects at officers. Police 
used tear gas canisters and more than 600 rounds of “less lethal munitions” to disperse the crowds. 
Five officers had minor injuries. The LAPD Professional Standards Bureau is investigating if the 
department used excessive force. 
Some of the charges those arrested are facing include attempted murder with a Molotov cocktail, 
assault on a police officer, looting and failure to disperse, LAPD said. One of those arrested was 
David Huerta, the president of the Service Employees International Union California, who was 
released Monday afternoon. 
Trump has deployed Marines to California 
Two government officials told NPR Monday that 700 Marines have been deployed to the state. Police 
Chief McDonnell said Monday he had not been briefed about the Marines showing up.  
“The Los Angeles Police Department, alongside our mutual aid partners, have decades of experience 
managing large-scale public demonstrations, and we remain confident in our ability to do so 
professionally and effectively,” he said. 
On Saturday, President Trump federalized 2,000 National Guard troops for 60 days or whatever 
duration Defense Secretary Pete Hegseth finds appropriate. Trump additionally said other branches 
of the armed forces may be dispatched to support. He put in an order for another 2,000 troops Monday. 


## PDF page 110

110 
 
“To the extent that protests or acts of violence directly inhibit the execution of the laws, they constitute 
a form of rebellion against the authority of the Government of the United States,” Trump said in the 
order. 
McDonnell refuted claims that it took LAPD more than two hours to respond to a federal request for 
assistance. He said the LAPD did not know federal forces were coming and thus took longer to 
respond to calls about the protest due to traffic conditions and hazardous conditions caused by tear 
gas used by federal troops. The department was on the scene in 38 minutes, McDonnell said. 
He reiterated that LAPD does not partner with ICE to enforce immigration policies. 
California Gov. Gavin Newsom is suing the Trump administration 
On Monday, California Gov. Gavin Newsom said his state is suing the Trump administration for 
sending National Guard troops into California. Newsom says the Trump administration’s actions 
violate the California Constitution, which gives the governor control over the state’s National Guard. 
The White House said in a statement, “Democrats like Gavin Newsom and [Los Angeles Mayor] 
Karen Bass should be thanking President Trump for stepping up and leading where they refused — 
and for ridding their streets of criminal illegal immigrant killers, rapists, and gangbangers.” 
Newsom claims the troops Trump sent out are going without food and water, and that most of them 
were waiting in federal buildings for orders. 
“This isn't about public safety,” he said. “It's about stroking a dangerous President’s ego. This is 
Reckless. Pointless. And Disrespectful to our troops. 
In response to Vice President Vance telling Newsom “do your job,” the governor said Monday, “Do 
YOUR job. We didn't have a problem until Trump got involved. Rescind the order. Return control to 
California.” 
 
Excerpted from: https://www.npr.org/2025/06/10/nx-s1-5428579/protests-against-ice-have-
continued-in-la-into-the-week-heres-what-to-know 
 
 


## PDF page 111

111 
 
 
 
 
 
UNIT THREE 
ACADEMIC WRITING: 
COMMENTARIES, THE BASICS 
 
 


## PDF page 112

112 
 
 
 
 
 
 
 
 
 
Civilization Studies:  
The United Kingdom 
 
 


## PDF page 113

113 
 
The English Turned Barbados into a Slave Society. Now, after 396 Years, We’re 
Free 
By Suleiman Bulbulia, The Guardian, Monday 29 Nov 2021  
(Suleiman Bulbulia was a member of the republican status transition advisory committee in 
Barbados and is a columnist for Barbados Today) 
The former British colony is about to become a republic, and we Barbadians can cast off our label 
of Little England 
 
The official opening of the Golden Square Freedom Park in Bridgetown, Barbados, to celebrate the country 
becoming a republic, 27 November 2021. Photograph: Randy Brooks/AFP/Getty Images 
Mon 29 Nov 2021  
 
On 20 October, in a joint sitting of parliament, Mia Mottley, the prime minister of Barbados, described 
the removal of Queen Elizabeth as the head of state and the decision to become a republic as a 
“seminal moment” in our country’s history. We have reached the day that this becomes a reality, as 
Barbados embarks on its new path, cutting the umbilical cord that bound it to its former colonial 
master, the United Kingdom. 
It begins on Monday evening, when Dame Sandra Mason will be installed as the first president of 
Barbados. That event, at which public participation will be extremely limited due to Covid protocols, 
but which will be beamed across the internet, will have the Prince of Wales in attendance as 
representative of the Queen. 
That decision has itself stirred emotions. Some Barbadians will protest at his presence. Others suggest 
that now may be a good time to raise the issue of reparations with Charles. 
In any case, this day has been a long time coming. It was on 14 May 1625 that the first English ship 
reached the island under the command of Captain John Powell, who claimed it on behalf of James I. 
It was from that time, 396 years ago, that “Los Barbados” (the bearded ones) became an English 
colony. It acquired its name from the Portuguese, earlier visitors who some claim were struck by the 


## PDF page 114

114 
 
abundant fig trees, which have a beard-like appearance. Others surmised it was down to the presence 
of bearded people. 
From 1627, the English settled on the island, wiping away any traces of the original inhabitants, the 
Arawaks, who had lived here for centuries. People with good financial backgrounds and social 
connections with England were allocated land in this new colony; Barbados’s strong connection and 
staunchly British attitude earned it the title of Little England. The English turned Barbados into a 
slave society, a slave economy, which would be replicated in several parts of the “new world”. It was 
known as the “jewel in the crown” of the Caribbean. It is a history that we can never be proud of, but 
one that we must understand. 
Prof Hilary Beckles, a Barbadian historian, the current vice-chancellor of the University of the West 
Indies and a leading figure in the push by Caribbean islands to secure reparations, sums it up best. 
“Barbados was the birthplace of British slave society and the most ruthlessly colonised by Britain’s 
ruling elites,” he writes. “They made their fortunes from sugar produced by an enslaved, ‘disposable’ 
workforce, and this great wealth secured Britain’s place as an imperial superpower and caused untold 
suffering.” 
Barbados, this beautiful island known today for its social amiability and political civility, has truly 
had a tumultuous history and a painful legacy, which still haunts us. But this has not prevented the 
nation, as Kofi Annan, the former UN secretary general, once said, from “punching above its weight”. 
We see it as a journey: 30 November – when we become a republic – is another stop on our journey. 
It’s a date with resonance, as 30 November 1966 was independence day. It is a sign of this journey 
continuing that at 55 we are confident to say to the UK and the world that, despite our size and our 
limited resources, we can be our own shepherds, our own stewards. 
 
Of course, our transition may not find favour among those whose view remains that the “sun will 
never set on the British empire” and that Barbados should always remain Little England. Older 
folks here remember the days when British royalty would visit. They would stand in the sun waving 
the union flag, hoping to catch a glimpse of the Queen or her representatives. But Little England has 
grown up, it has matured, it should no longer be loitering in its “master’s castle”.  
 


## PDF page 115

115 
 
As part of the transition, there will be ceremonial activities in National Heroes Square in the capital 
city, Bridgetown, but one notable absence will be Lord Nelson. For 208 years his statue stood in 
that square but in 2020 it was ceremoniously removed – a result of the Black Lives Matter 
movement here and the reawakening of our consciousness. 
There are no plans to change our national symbols: the flag, the coat of arms, the national pledge, 
the national anthem. But the terms “royal” and “crown” will be removed from official terminology. 
The Royal Barbados Police Force will be the Barbados Police Service; “crown lands” will become 
“state lands”. 
Independence day will still be on 30 November, but the focus will not be this event. The day will 
belong, as it always has, to our national hero, our first prime minister, the father of independence, 
the Right Excellent Errol Walton Barrow. 
Of course, Barbados will maintain a strong relationship with the UK. Our main source for tourists is 
from there; Brits love Barbados. But this is a new era, in which all Barbadians must take pride and 
take ownership. As for Little England, these times may call for a new term of endearment. 
 
 


## PDF page 116

116 
 
Boris Johnson’s Phoney Posturing at the French Won’t Resolve the Migrant 
Crisis 
Brexit sold with a slogan ‘take back control’ has left the UK with a border that is now harder 
to control 
By Andrew Rawnsley, The Guardian, 28 Nov 2021 
 
When Priti Patel appeared before the Commons, the fiercest contributions 
were from former members of her fan club. Photograph: Jessica Taylor/UK 
Parliament/AFP/Getty 
At the Spectator magazine’s parliamentarian of the year awards, the swankiest shindig in the political 
calendar, one of the gongs went to Nadhim Zahawi. He received a big cheer from an audience heavily 
populated with Tory MPs and ministers when he used his acceptance speech to remark: “How did a 
boy from Iraq end up on these shores without a word of English at the age of 11 and become the 
secretary of state for education? This is the greatest country of the world, my friends.” 
On the same day, just a few hours earlier, at least 27 souls, among them a pregnant woman and several 
children, had also tried to make it to these shores only to die in the attempt. Less fortunate than Mr 
Zahawi, they and their dreams of making a better life in “the greatest country of the world” were 
drowned as they risked the treacherous crossing from the coast of northern France to that of southern 
England. We will never know if a future cabinet minister might have been among them. 
Even after that tragedy, more people subsequently crammed into fragile craft to attempt the perilous 
passage. No one would try navigating the Dover Straits, the world’s busiest shipping lane, in a small 
boat and in winter, if they thought they had any better options. 
Viewed from Greece or Italy, which have seen greater flows of migration, what Britain calls a ‘crisis’ 
is a modest challenge 
There is a cognitive dissonance in the government’s thinking about refugees. An eagerness to 
celebrate immigrant success stories, like that of Mr Zahawi, is accompanied by a system of managing 
asylum seekers designed to place huge and often treacherous obstacles in the path of anyone hoping 
to replicate his story. The result is a regime that neither displays compassion towards those seeking 
refuge nor gives voters confidence that the government has migration under control. 
There are millions of displaced people on the borders of Europe. They are fleeing conflict, poverty 
and/or persecution, as the education secretary’s Kurdish parents did during the early years of Saddam 
Hussein’s tyrannical reign in Iraq. Viewed from Greece or Italy, which have seen much greater flows 
of migration, what Britain calls a “crisis” is a relatively modest challenge. The numbers making the 
risky passage across the Channel have dramatically increased, more than 1,000 coming ashore on one 
day earlier in November, but it is important to be clear why. Legal pathways into the UK have been 


## PDF page 117

117 
 
closed off and ways of establishing safer routes, such as allowing asylum applications at UK 
embassies, are anathema to the government. Even where supposedly binding commitments to 
refugees have been made, these are being dishonoured. A resettlement scheme for Afghans fleeing 
the murderous Taliban was announced at the time of the retreat from Kabul. This was held out by the 
prime minister as a noble example of the UK standing by those Afghans to whom we had moral 
obligations. He told an emergency session of the Commons in August: “We will support those people 
in coming to this country… with a new and bespoke settlement scheme focusing on the most 
vulnerable.” Disgracefully, that scheme is still not operational more than three months after its 
creation was first trumpeted by Mr Johnson, forcing more desperate people to take life-threatening 
gambles. 
It is not so much the numbers of those trying to cross the Channel as the visibility of them that has 
turned this into a political crisis. People risking all to get to the UK, and being daily featured doing 
so on news bulletins, has made the issue highly salient. Even before the tragedy in the Channel and 
the rancorously recriminatory exchanges between London and Paris that have followed, Tory MPs 
were becoming alarmed by the volume of email and post they were receiving. For liberal 
humanitarian voters, the deaths in the Channel reinforce a conviction that the UK’s posture towards 
refugees is callous. For the voter who is mainly concerned that the government knows what it is 
doing, it is yet another reason to question the basic competence of this one. For those who see 
seaborne refugees as intruders to be repelled, a constituency at the heart of the Brexit vote that put 
Mr Johnson where he is today, this exposes the government to the charge that it is failing to “take 
back control” of the country’s borders. 
It is this latter group that most unnerves Number 10. Nigel Farage, who can never see an issue without 
wanting to make it more toxic, is threatening another comeback. Just because he’s already had more 
of them than Frank Sinatra doesn’t mean he won’t do it again. Tory strategists are shivered by the 
spectre of beer breath founding a new vehicle for his ego and carving away a chunk of the rightwing 
vote. The prime minister is, and has been for months, angrily exasperated by what he sees as Priti 
Patel’s failure to “grip” the issue. The home secretary, in turn, has spent her time blaming the French. 
They shouldn’t take it personally, because she also blames her own officials and legal advisers. Her 
efforts to shift culpability elsewhere are no longer working with her party. When the home secretary 
appeared before the Commons, the fiercest contributions by Conservative MPs were from some who 
were previously members of her fan club. 
One senior Tory remarks: “The trouble is all the political pressure on Boris is coming from hopelessly 
unrealistic headbangers on the right of my party saying, ‘Just send them back’. This is leading Boris 
and Priti in exactly the wrong direction because it will only increase French intransigence and make 
it even more difficult to solve.” 
If there were an easy remedy, it would have been adopted a long time ago, but it is the impulse of 
rightwing populists to claim that complex issues have simple solutions. Ms Patel has promoted the 
notion of adopting a “push-back” policy by ordering the coastguard and the navy to force boats back 
to the French side of the Channel. This is an instruction no captain is ever likely to obey and even 
less so now, for fear of breaking maritime laws and capsizing boats. As a rule, sailors don’t like 
drowning people. There have also been repeated suggestions that the processing of asylum seekers 
could be subcontracted to other countries far away. When it was recently spun that the government 
was in talks with Albania, that country’s foreign minister dismissed the claim as “totally fake”.  
France is the country Britain most needs to be talking to. Neither the plight of the refugees nor public 
confidence in the management of migration will be improved without cooperation. Unfortunately, it 


## PDF page 118

118 
 
is one of the least well-kept secrets in diplomacy that Anglo-French relations are dreadful. Brexit-
related disputes about fisheries and trade rules have been compounded by the UK’s crowing 
involvement in the American submarine deal with the Australians that left the French feeling shafted 
and humiliated. British ministers accuse Emmanuel Macron of ramping up nationalist rhetoric to 
please his domestic audience ahead of next year’s presidential election. 
Our country is even more dependent on collaboration with European neighbours who have much less 
incentive to be cooperative 
There’s truth in that, but what were those same British ministers doing in the run-up to our last 
election? They are still at it now in an effort, as crude as it is counterproductive, to swerve their own 
responsibilities by bashing the French. The waters had barely closed over the dead souls in the 
Channel before Mr Johnson dispatched a three-page letter to Mr Macron that included a series of 
consciously provocative assertions and demands he knows the French will not accept. The publication 
of the letter on Twitter, before the French president had even seen it, confirmed that this was not a 
sincere attempt to find common ground with Paris, but frantic posturing to try to please the rightwing 
media and appease Tory backbenchers. “Things are often difficult with the French at the best of 
times,” observes one former Conservative cabinet minister. “Baiting the French when we need their 
help is just stupid.” Mr Macron retorted that serious leaders don’t communicate with each other about 
grave issues “by tweets and letters that we make public”. The French interior minister, Gérald 
Darmanin, disinvited Ms Patel from a meeting due to be held today involving him and counterparts 
from Germany, the Netherlands and Belgium, all countries essential to any effort to achieve better 
management of this crisis. 
Which points to a glaring and tragic irony. A Brexit sold with the slogan “take back control” has left 
the UK with a border that is now harder to control. Our country is even more dependent on 
collaboration with European neighbours who have much less incentive to be cooperative. There will 
be an empty chair where Britain should be sitting. Puerile point-scoring and phoney posturing have 
to stop before more people perish in the icy waters of the Channel.  
Andrew Rawnsley is Chief Political Commentator of the Observer 
 
 
 


## PDF page 119

119 
 
Labour Needs Its Own Answer to the Channel Crisis 
By Patrick O'Flynn, The Spectactor, 28 November 2021 
 
Given the complexities of modern government, with all its pitfalls and unforeseeable reverses, 
pointing out when ministers have made a mess of things is certainly an important part of the repertoire 
of opposition – the equivalent of a boxer’s jab in our pugilistic political system. But the ‘it’s a 
shambles’ method of politics can only take an opposition party or its leader so far. 
On the rare occasions that Labour has talked about illegal migration across the English Channel since 
Boris Johnson became PM and Priti Patel was appointed Home Secretary, this has been its favoured 
line of attack. 
Earlier in the month Keir Starmer told BBC Radio 4: ‘The Home Secretary repeatedly says in strong 
language what she is going to do about the immediate problem and delivers absolutely nothing.’ 
A week or so ago shadow home secretary Nick Thomas-Symonds declared: ‘The Home Secretary’s 
incompetence on this matter is dangerous.’ Given the tragic drownings in the Channel that followed 
a few days later he may feel entitled to congratulate himself on his prescience. 
But there comes a point, often when an issue has risen up the list of voter concerns, when an 
opposition must add depth to its message. If it wants to deliver a knock-out blow it certainly has to 
find a strong and electorally appealing answer to the question: well, what would you do then? 
For all the failings of Johnson and Patel in their struggle to stem the flow of migrant boats, this is 
where Starmer’s Labour appears doomed to failure. Its answers involve a rehash of its failed Brexit 
positioning, via the claim that being gentler with France will somehow lead to a better outcome, and 
via its own commitment to provide ‘safe routes’ so that those presently entering the UK illegally and 
perilously can in future do so legally and safely. 
On Friday this even led Labour to take the side of petulant President Macron in his ‘lettergate’ row 
with Britain. Boris Johnson’s public letter to Macron, in which he had proposed possible solutions, 
was a ‘grave error of judgment’, claimed Mr Thomas-Symonds. ‘This is a humiliation for a prime 
minister and a home secretary who have completely lost control of the situation… it’s ended up within 
a matter of hours with the government being excluded from these vital talks,’ he added. This ‘Britain 
bad, abroad good’ mindset has damaged Labour before with key groups of voters as it fails a basic 
test of patriotism. 
Meanwhile the idea that providing new ‘safe routes’ for those gathering on the French coast can solve 
the crisis barely stands a moment’s scrutiny unless one envisages such routes being made available 
to unlimited numbers of people in poor countries who would like to live in our rich one. 
As Peter Lilley noted in a House of Lords debate on Thursday: ‘This simply would not work. Anyone 
who was refused… would still have exactly the same incentive as now to enter the UK illegally by 
boat… Many more people will apply for asylum if such a simple route is established.’ 
So talk of safe routes, which goes down very well with Labour’s activist base, is simply code for 
giving up on the battle to stop the asylum regime being abused – and a way of facilitating higher 
volumes of immigration. 
These Labour positions aren’t a haymaker but rather the party leading with its chin. Should the Red 
Wall voters that Labour lost and needs to win back start noticing them, or should the Tories actually 


## PDF page 120

120 
 
succeed in getting a grip on the issue – which currently seems a less likely prospect, I’ll grant you – 
then Labour will be the party in the most trouble by far. 
The recent opinion poll pattern of Tory ratings sinking without Labour ones surging ahead is already 
pointing to the fact that the Conservatives are losing the support of voters who wish to see a much 
tougher approach taken on migration matters, not an even weaker one.  
I knocked on enough doors in by-elections in Red Wall seats when Nigel Farage’s Ukip was in its 
heyday to know that it is working class ‘old Labour’ voters who feel strongest on this issue. It is their 
neighbourhoods which have lost social cohesion and their working lives that have been most 
disrupted by the knock-on effects of uncontrolled immigration. 
While the Tories won many of these voters over in 2019, there are plenty more who stuck with Labour 
but could be persuaded to switch should the government find a way to deliver on this issue while the 
opposition is seen to push for a still more open-door approach. 
So we have a paradox where the issue that is causing most mid-term damage to the Conservatives is 
likely to do most long-term further electoral harm to Labour. Complacent Keir is there for the taking 
so long as the Tories actually do something decisive to bolster the borders. 
 
 
 


## PDF page 121

121 
 
The UK and France Must Mend Ties – Lives Depend on It 
The French have lost all confidence in Boris Johnson – but the migrant crisis demands the 
relationship is rebuilt. 
By Peter Ricketts, The New Statesman, 26 November 2021 
Four centuries ago, the poet Philip Sidney put his finger on the constant ambivalence in the UK-
French relationship when he referred to “that sweet enemy, France”. There is not much 
sweetness right now. In fact, relations are the worst I have known them in my 40 years as a diplomat. 
How have things got so bad? The way Brexit was handled has played a large part in unsettling what 
had been a close partnership. In particular, Boris Johnson’s handling of the Northern Ireland protocol 
left the impression in Paris that the Prime Minister had either not understood its terms or never 
intended to implement them. Since then, the aftershocks of Brexit have continued to get in the way 
of efforts to promote “Global Britain”. Most of them have involved London and Paris, whether it was 
the Johnson/Macron spat at the Cornwall G7 summit over sausages for Northern Ireland, or the war 
of words over fishing licences that was the backdrop to the Cop26 climate summit. 
The Aukus defence deal announced in September left the French feeling humiliated because London 
and Washington, DC, two of their closest allies, had been negotiating behind their backs for six 
months with Australia to wrest a submarine deal from them, scuppering a Paris-Canberra alliance. 
What happened next was revealing. Joe Biden understood the problem, rang the French president 
Emmanuel Macron to apologise for the handling, and sent his top advisers hot-foot to Paris to mend 
fences. From Boris Johnson, all the French got was mockery (“donnez-moi un break”). 
The result of all this is the total collapse of trust on the part of France in Johnson and his government. 
That is very evident in the handling of the crisis over small boat crossings of the English Channel. 
For months, Home Secretary Priti Patel and her French counterpart Gérald Darmanin have been 
sniping at each other in public. The awful loss of 27 lives when a boat capsized on 24 November 
should have been a moment for leaders in London and Paris to put aside the politics and concentrate 
on stepping up their cooperation to prevent further tragedies. But Johnson’s open letter to Macron on 
25 November has made matters worse. 
The French were never going to accept a blanket commitment to take back so-called “illegal 
migrants”. Some of the ideas raised in the letter could have been a basis for discussion, particularly 
joint patrols on French beaches. But it should also have included proposals for the UK to share the 
burden, for example by setting up a processing centre in France, allowing those with a well-founded 
asylum claim to come to the UK in safety. 
The British proposals should have been discussed quietly with France and then taken by Patel to the 
meeting of European ministers in Paris on 28 November before being made public. Instead, Macron 
saw Johnson’s letter for the first time on Twitter. Hence his withering public commentabout the need 
to be serious. For all that, it was an error by Paris to disinvite Patel from the multilateral meeting, 
which will as a result be less useful in coming up with practical solutions to stop the murderous traffic 
in human lives 
It is heartbreaking to see how far relations between London and Paris have deteriorated. Europe’s two 
global powers, with all the interests and experience we share, must do better than this. Where do we 
begin? The British media was briefed recently that London is preparing an ambitious new defence 
treaty with France, going well beyond the 2010 Lancaster House treaties. But international relations 


## PDF page 122

122 
 
don’t work like that. New treaties can’t be conjured out of the air. They can only be built on trust that 
each side will work together in good faith and respect its commitments. 
The migrant crisis is now central to rebuilding the relationship. There are no easy answers. But the 
lives of many vulnerable people depend on getting this right. So both sides need to dial down the 
rhetoric, stop the blame game and be willing to look at any proposal, even if politically difficult, 
which will reduce the appalling toll of deaths in the Channel. Working together to tackle this crisis 
will create the positive dynamic we so urgently need. 
 
 
 


## PDF page 123

123 
 
This Is the Real Reason Priti Patel Has Been Barred from France 
It goes to show how dreadful Anglo-French relations have become – and how weak the UK is 
By Sean O’Grady, The Independent, 26 November, 2021 
There is some irony in the fact that about the only person the French are not allowing into their country 
right now is Priti Patel. In an unusually blunt diplomatic snub, her day trip to Calais on Sunday has 
been cancelled – and so have the scheduled face-to-face talks with the French authorities about the 
loss of life in the English Channel.  
One hopes they’ll still pick up the phone for her but you never know. Given the enormity of what has 
happened, it seems a bit impetuous – childish, even – banning Patel from her own meeting but it does 
go to show how dreadful Anglo-French relations have become and how weak the UK is.  
Apparently the French didn’t like the tone of Boris Johnson’s letter to the president of the republic, 
nor that he shoved it out on Twitter. That is not how such things should be done Monsieur Johnson, 
they were telling him, and they have a point.  
It’s maybe not the first time Johnson’s had a bit of trouble with a French letter but the tone was all 
wrong. Johnson – of all people – was offering his sage advice on how they should be running their 
backward little country.  
They don’t really need that and they don’t really want to enact his helpful suggestion that they let  
After all, the job of any country’s border force is to stop people getting in, not so much to prevent 
them from lawfully leaving. As Macron says, these people do not wish to live in France and he cannot 
make them.  
Rather tellingly, the French explained that the British ideas are unacceptable because they violated 
the “sovereignty” of France. Whoever is at fault in this, it seems plain that nothing will be done as a 
result of the tragedy this week and the people who will suffer from this spat are the refugees still 
attempting a Channel crossing in flimsy boats and worsening weather; more will die. 
You have to admit that Brexit has not helped. Like so many divorces where the participants believe 
that it’s all going to be quite amicable, leaving the EU was always going to be acrimonious – and so 
it has proved.  
Within the EU’s structures, the British and the French had to talk to one another and the other EU 
partners involved in the migrant crisis – such as Italy, Malta and Greece and now Poland and 
Lithuania.  
We did have the Dublin Regulation system for pan-EU migrant returns, which may not have been 
perfect but was at least some sort of agreement. Now, there is none.  
Where once Britain could exert influence and some power over EU migration policy and what was 
happening “upstream” in the Mediterranean and policy towards Turkey, the British now have next to 
no say.  
The old concept of shared sovereignty meant that the British would no longer have complete control 
over their own borders but in return would have a say on the border regime across the whole continent, 
which was of some use. At the moment, the British have no say over anyone else’s border policies 
and little practical control of their own.  


## PDF page 124

124 
 
The migrant crisis is bigger than Britain and indeed bigger than Britain and France. It is precisely the 
kind of thing that demands action at a supranational scale. This was what was going to be happening 
over the weekend, when Patel was going to swap ideas and contacts with counterparts from a half 
dozen other European countries – just like the old days in an EU Council of Ministers meeting.  
Sovereignty was to be pooled. If the UK was still an EU member state, the French would not have 
been able to “disinvite” the British home secretary – she’d have freedom of movement for a start.  
Johnson’s pompous attempt at a billet-doux to President Macron was the immediate cause of French 
irritation but it is Brexit that has clearly poisoned relations.  
 
 
 


## PDF page 125

125 
 
Boris’s Blundering Brilliance: 
Brexit has given the U.K’s self-seeking Prime Minister the opportunity to show he actually 
knows what he’s doing 
By Andrew Sullivan Dec. 6, 2019, New York Magazine 
 
It’s hard to take the British prime minister, Boris Johnson, completely seriously. […] 
[…] This comic figure has somehow managed to find himself at the center of the populist storms 
sweeping Britain and the West — first by becoming the most senior politician in Britain to back Brexit 
in 2016, and now by plotting a course that might actually bring the United Kingdom out of the epic, 
years-long, once-impossible-looking mess he helped make. Just over four months into office as PM, 
he appears poised to win an election he called and, if the polls are anywhere near correct, score a clear 
victory and take Britain out of the E.U. by the end of January. 
Not so long ago, this Brexit scenario seemed inconceivable: What the E.U. demanded and the British 
Parliament could support seemed irreconcilable, and no single resolution to the Brexit referendum 
had enough support to budge the country’s politics out of a maddening stall. But here we are, with 
Boris having budged it. 
In the politics of this, he has been helped by the British winner-takes-all electoral system; by a very 
unpopular Labour leader, Jeremy Corbyn; and by an opposition split down the middle on Brexit. But 
he deserves credit for getting the E.U. to change (if somewhat marginally) a final deal it long said 
was absolutely nonnegotiable and for seeing an opportunity that others didn’t — in the U.K., across 
Europe, and in the U.S. — to become not more ideological in a tumultuous era of uncorked populism 
but less so. […] 
How has he pulled all this off? His critics argue that he has cynically become the British Trump, 
whipping up xenophobia and ugly racism, lying with abandon, and reinventing the British Tory party 
as a hard-right populist engine for the worst instincts of the deplorable masses. He is now attacked as 
a racist and reckless Little Englander, gleefully wrecking the British economy, polarizing the country, 
and threatening to break up the U.K. solely to advance his own narcissistic ambitions. Shallow, lazy, 
incompetent, and bigoted, this clown has somehow leveraged the fears of the many to advance the 
only thing he has ever genuinely believed in: his own destiny. 
But there is another story to be told about him: that he has been serious all along, using his humor 
and ridiculousness to camouflage political instincts that have, in fact, been sharper than his peers’. 
He sensed the shifting populist tides of the 2010s before most other leading politicians did and 
grasped the Brexit issue as a path to power. But he also understood how important it was not to be 
fully captured by that raw xenophobic energy. He saw Brexit discontent as something the political 
Establishment needed to engage and co-opt rather than dismiss and demonize, and he approached the 
opportunity in a very different way from his sometime ally Nigel Farage, whose provincial extremism 
veered into outright racism and whose political career Johnson has now all but ended. 
As a longtime liberal Tory, Boris, as he’s invariably called in the press and by the public, saw the deep 
unpopularity of his party’s legacy of fiscal austerity and the need to shift left in economic and social 
policy. So he is quietly forging a new conservatism — appealing to the working poor and aspiring 
middle classes, tough on immigration and crime, but much more generous in spending on hospitals 
and schools and science. Or so he says for now. And if he succeeds — by no means a sure thing, 
though at this point it almost seems foolish to bet against him — he won’t just be charting a new 


## PDF page 126

126 
 
future for the U.K. but pioneering a path for other Western parties of the center right confronted by 
the rise of populist extremism. 
Excerpted from: https://nymag.com/intelligencer/2019/12/boris-johnson-brexit.html  
 
 


## PDF page 127

127 
 
Post-Brexit, We Need Real Capitalism – Not Stealth Foreign Nationalisation 
By Allister Heath, The Telegraph, 12 September 2019 
 
It was Voltaire, as so often, who got it right. In his Letters on the English, the French philosopher and 
original Anglophile understood what made this country special far better than most domestic 
observers of the time (or, arguably, since). Writing in 1733, he marvelled at Britain’s religious 
tolerance, its freedoms and its increasingly commercial society, sentiments which led to his book 
being burnt in France. 
“Go into the London Stock Exchange – a more respectable place than many a court”, Voltaire 
explained, “and you will see representatives from all nations gathered together for the utility of men. 
Here Jew, Mohammedan and Christian deal with each other as though they were all of the same faith, 
and only apply the word infidel to people who go bankrupt.” The free market, Voltaire realised, brings 
people with different values and backgrounds together. 
His observations have long been influential among one category of Eurosceptic: those who consider 
Britain’s traditions to be far more classically liberal, far more respectful of personal and economic 
freedom than those of most of the continent. 
If we do somehow end up leaving the EU, we will need to decide what kind of capitalism and 
globalisation we wish to nail our colours to. It would be apposite, therefore, were the Hong Kong 
Stock Exchange’s stunning £32 billion hostile takeover bid for the London Stock Exchange to turn 
out to be an early test of Britain’s post-Brexit economic policy. 
As it happens, I doubt it will ever come to that: the bid is likely to collapse of its own accord. Not 
only does it undervalue the LSE but two-thirds of the payment would come from printing more Hong 
Kong Stock Exchange shares. This would tie LSE shareholders into a financial centre in probable 
terminal decline, thanks to China’s repression and the prospect of never ending turmoil. Its 
shareholders, if they have any sense, will send the Hong Kongers packing. 
Yet thirty years after the fall of the Berlin Wall it is time to acknowledge that there are now two kinds 
of “capitalism”: the libertarian, spontaneous, bottom-up variety described by Voltaire and promoted 
by the modern free market movement from F.A. Hayek to Milton Friedman, and the statist, 
imperialistic variety that dominates Russia and China. Post-Brexit Britain should embrace the first 
and aim to contain the latter. 
Libertarian, competitive capitalism is the greatest system ever devised to create wealth and allow 
people to pursue their dreams. By seeking to maximise profits, companies serve their customers in 
the most efficient way. Growth is maximised. Individual rights are sacrosanct: property cannot be 
confiscated, lying and committing fraud is not permissible and a well-enforced rule of law is essential. 
There are no bailouts and no subsidies. Externalities, such as pollution, can be internalised with the 
right policies 
State capitalism is different. Its agents don’t focus on maximising profits: instead, they serve their 
political masters and help them conduct their domestic and foreign policy. Nominally private firms 
that control key infrastructure are ideal vehicles to facilitate espionage, or to exert leverage on rival 
nations. Factories are built in favoured locations, not where it makes the most commercial sense. 
Resources are allocated inefficiently, and growth isn’t maximised. Rights are violated: the Chinese 
tech industry is based on a gross disregard for privacy. (…). 
 


## PDF page 128

128 
 
 
 
 
 
 
 
 
 
Civilization Studies: 
The United States 
 
 
 


## PDF page 129

129 
 
Remarks at the Democratic National Convention 
By Bill Clinton, Aug. 29, 1996 
[…] Four years ago, you and I set forth on a journey to bring our vision to our country, to keep the 
American dream alive for all who were willing to work for it, to make our American community 
stronger, to keep America the world's strongest force for peace and freedom and prosperity. 
Four years ago, with high unemployment, stagnant wages, crime, welfare, and the deficit on the rise, 
with a host of unmet challenges and a rising tide of cynicism, I told you about a place I was born, and 
I told you that I still believed in a place called Hope. 
Well, for four years now, to realize our vision we have pursued a simple but profound strategy: 
opportunity for all, responsibility from all, a strong united American community. […] 
Look at what's happened. We have the lowest combined rates of unemployment, inflation, and home 
mortgages in 28 years. Look at what happened: 10 million new jobs, over half of them high-wage 
jobs; 10 million workers getting the raise they deserve with the minimum wage law; 25 million people 
now having protection in their health insurance  […]; 40 million Americans with more pension 
security; a tax cut for 15 million of our hardest working, hardest pressed Americans, and all small 
businesses; 12 million Americans  […] taking advantage of the family and medical leave law so they 
can be good parents and good workers. Ten million students have saved money on their college loans. 
We are making our democracy work. […] 
We have increased our investments in research and technology. We have increased investments in 
breast cancer research dramatically. We are developing a supercomputer – a supercomputer that will 
do more calculating in a second than a person with a hand-held calculator can do in 30,000 years. 
[…] 
Our country is still the strongest force for peace and freedom on Earth. On issues that once before 
tore us apart, we have changed the old politics of Washington. For too long, leaders in Washington 
asked, who's to blame? But we asked, what are we going to do? 
On crime, we're putting 100,000 police on the streets. We made "three strikes and you're out" the law 
of the land. We stopped 60,000 felons, fugitives, and stalkers from getting handguns under the Brady 
bill. We banned assault rifles. […] Four years now – for four years now – the crime rate in America 
has gone down. 
On welfare, we worked with States to launch a quiet revolution. Today there are 1.8 million fewer 
people on welfare than there were the day I took the oath of office. We are moving people from 
welfare to work. 
[…] The federal work force is the smallest it has been since John Kennedy. And the deficit has come 
down for four years in a row […]. 
We are on the right track to the 21st century. We are on the right track. But our work is not finished. 
What should we do? First, let us consider how to proceed. […] 
I love and revere the rich and proud history of America. And I am determined to take our best 
traditions into the future. But with all respect, we do not need to build a bridge to the past. We need 
to build a bridge to the future. And that is what I commit to you to do. 
So tonight, tonight let us resolve to build that bridge to the 21st century, to meet our challenges and 
protect our values. Let us build a bridge to help our parents raise their children, to help young people 


## PDF page 130

130 
 
and adults to get the education and training they need, to make our streets safer, to help Americans 
succeed at home and at work, to break the cycle of poverty and dependence, to protect our 
environment for generations to come, and to maintain our world leadership for peace and freedom. 
Let us resolve to build that bridge. 
Excerpted from: https://millercenter.org/the-presidency/presidential-speeches/august-29-1996-
remarks-democratic-national-convention  
 
 


## PDF page 131

131 
 
In Defense of Monica  
By Amelia Richards and Jennifer Baumgardner, The Nation, Dec. 21, 1998  
 
Pundits across the political spectrum have assumed that there are two ways for feminist-minded 
people to view Monica Lewinsky: As a careerist Delilah (who exposed the President to humiliation) 
or as a victim (to whom the President exposed himself). As feminists and activists committed to 
fighting for the rights of young women, we want to raise our voices not to decry or condescend to her 
but to support her in the name of feminism.  
When the Lewinsky story broke eleven months ago, we did not know the former White House intern 
and initially learned only scant details of her alleged tryst with President Clinton. Now, she could be 
our best girlfriend. We know her wardrobe down to her undies, her vacillating aspirations and the 
intimate details of her sex life. We also know more than enough explicit play-by-play (more than any 
best girlfriend would reveal) about her relationship with the President. But then none of our best 
girlfriends have been threatened with imprisonment or had her mother subpoenaed and threatened 
with the slammer if such details were not laid out before the world. With so much information, we 
feel comfortable coming out in support of Lewinsky despite never having met her.  
As far as classic feminist concerns go, Lewinsky has been exploited - but not in the way some of her 
detractors suggest. Linda Tripp violated her privacy and trust, and she has been ridiculed by the media 
and by the American people. The independent counsel and FBI agents ambushed her for an eleven-
hour intimidation ritual, with nary a pause when she said she wanted to call her lawyer (as if 
constitutional rights don’t extend to people who don’t know precisely what their rights are). Then she 
was served up most salaciously by Kenneth Starr in his report - now for sale in book form. Although 
she will soon have her own book in the stores, one can’t argue that her literary relationship with Starr 
is consensual. The Barbara Walters interview, scheduled for broadcast early next year, will mark the 
first time Monica speaks for herself, at least without the threat of jailtime hanging over her head. 
Many people don’t agree with the choice Lewinsky made to have an affair with the President of the 
United States, a decision that left her subject to public humiliation. Yet the point is not that we think 
her choice was stupid or her motives delusional but that the relationship was consensual. At the root 
of feminism is the right to make our own choices, provided our actions don’t limit or infringe upon 
the options of other people. Take abortion: While we would not coerce any woman into having one, 
we also wouldn’t deny that alternative to someone else. And with freedom comes the possibility that 
we will make bad choices.  
If Monica Lewinsky were in fact a best girlfriend, it would be our responsibility as friends to offer an 
opinion. Maybe you shouldn’t be having an affair with a married man; maybe, given his age and job 
as leader of the most powerful nation on earth, he isn’t going to be available as often as you need him 
to be; maybe you shouldn’t be threatening him if he doesn’t aid in your future career; and maybe you 
should have had that dress dry-cleaned. However, we don’t need to defend Lewinsky’s decisions or 
justify her love to support her rights in the name of the rights of all young women. We want the right 
to be sexually active without the presumption that we were used or duped. We want the right to 
determine our own choices based on our own morality.  
Young people should be particularly empathetic with Lewinsky. We know what it’s like not to be 
listened to and to have our ideas dismissed. As a constituency, we fight to be heard by our parents, 
our teachers and our politicians. In our careers we struggle to do more than operate the photocopier, 
and in our personal lives we strive to live according to our own moral voice and not that of others. 


## PDF page 132

132 
 
We are also familiar with the linking of sex, lies and tapes. We are a generation whose parents openly 
had affairs, who have been lied to by Reagan and Bush, and for whom a media-delivered barrage of 
sex and scandal has been a constant.  
Tossed into this national peepshow, the figure of Monica Lewinsky has taken on the singularity of the 
very famous. But in some respects her experience as a young woman was not that weird. Who hasn't 
dated someone less than in love with you, or what the experts call "emotionally unavailable"? We 
feminists should take care not to put words in Lewinsky’s mouth: She has not said that Clinton 
"victimized" her nor that it was a power difference that forced her to express her crush and flash her 
thong. She has said that she had an affair with the President, and that she initiated and did her best to 
prolong this affair. The effect of his presidential authority was not coercive but seductive - the 
aphrodisiac of power. Whatever we think of this, if feminists hold Lewinsky up as a violated naif, 
then we don't believe that an adult woman can take responsibility for her own desires and actions. In 
other words, we will have gone a long way back, baby. Feminists should support Monica Lewinsky 
not as a victim of a rapacious man but as a young woman with a libido of her own.  
Source: https://www.feminist.com/resources/artspeech/poli/monica.htm  
  
 
 


## PDF page 133

133 
 
Address on the U.S. Response to the Attacks on September 11 
George W. Bush, Sept. 22, 2001 
 
[…] Tonight we are a country awakened to danger and called to defend freedom.  Our grief has turned 
to anger, and anger to resolution.  Whether we bring our enemies to justice, or bring justice to our 
enemies, justice will be done. […] 
On September the 11th, enemies of freedom committed an act of war against our country.  Americans 
have known wars -- but for the past 136 years, they have been wars on foreign soil, except for one 
Sunday in 1941.  Americans have known the casualties of war -- but not at the center of a great city 
on a peaceful morning.  Americans have known surprise attacks -- but never before on thousands of 
civilians.  All of this was brought upon us in a single day -- and night fell on a different world, a world 
where freedom itself is under attack. 
Americans have many questions tonight.  Americans are asking:  Who attacked our country?  The 
evidence we have gathered all points to a collection of loosely affiliated terrorist organizations known 
as al Qaeda. They are the same murderers indicted for bombing American embassies in Tanzania and 
Kenya, and responsible for bombing the USS Cole. 
Al Qaeda is to terror what the mafia is to crime.  But its goal is not making money; its goal is remaking 
the world -- and imposing its radical beliefs on people everywhere. 
The terrorists practice a fringe form of Islamic extremism that has been rejected by Muslim scholars 
and the vast majority of Muslim clerics -- a fringe movement that perverts the peaceful teachings of 
Islam.  The terrorists’ directive commands them to kill Christians and Jews, to kill all Americans, and 
make no distinction among military and civilians, including women and children. 
This group and its leader -- a person named Osama bin Laden -- are linked to many other organizations 
in different countries […].  There are thousands of these terrorists in more than 60 countries.  They 
are recruited from their own nations and neighborhoods and brought to camps in places like 
Afghanistan, where they are trained in the tactics of terror.  They are sent back to their homes or sent 
to hide in countries around the world to plot evil and destruction. 
The leadership of al Qaeda has great influence in Afghanistan and supports the Taliban regime in 
controlling most of that country.  In Afghanistan, we see al Qaeda's vision for the world. 
Afghanistan's people have been brutalized -- many are starving and many have fled.  Women are not 
allowed to attend school.  You can be jailed for owning a television.  Religion can be practiced only 
as their leaders dictate.  A man can be jailed in Afghanistan if his beard is not long enough.   
The United States respects the people of Afghanistan -- after all, we are currently its largest source of 
humanitarian aid -- but we condemn the Taliban regime. It is not only repressing its own people, it is 
threatening people everywhere by sponsoring and sheltering and supplying terrorists.  By aiding and 
abetting murder, the Taliban regime is committing murder.   
And tonight, the United States of America makes the following demands on the Taliban:  Deliver to 
United States authorities all the leaders of al Qaeda who hide in your land. Release all foreign 
nationals, including American citizens, you have unjustly imprisoned.  Protect foreign journalists, 
diplomats and aid workers in your country. Close immediately and permanently every terrorist 
training camp in Afghanistan, and hand over every terrorist, and every person in their support 


## PDF page 134

134 
 
structure, to appropriate authorities. Give the United States full access to terrorist training camps, so 
we can make sure they are no longer operating.   
These demands are not open to negotiation or discussion. The Taliban must act, and act 
immediately.  They will hand over the terrorists, or they will share in their fate.   
I also want to speak tonight directly to Muslims throughout the world.  We respect your faith.  It's 
practiced freely by many millions of Americans, and by millions more in countries that America 
counts as friends.  Its teachings are good and peaceful, and those who commit evil in the name of 
Allah blaspheme the name of Allah. The terrorists are traitors to their own faith, trying, in effect, to 
hijack Islam itself.  The enemy of America is not our many Muslim friends; it is not our many Arab 
friends.  Our enemy is a radical network of terrorists, and every government that supports them.   
Our war on terror begins with al Qaeda, but it does not end there.  It will not end until every terrorist 
group of global reach has been found, stopped and defeated. […] 
Excerpted from: https://millercenter.org/the-presidency/presidential-speeches/september-22-2001-
address-us-response-attacks-september-11  
 
 
  
 
 
 


## PDF page 135

135 
 
The Renaissance of Anti-Intellectualism 
By Tod Gitlin 
Chronicle of Higher Education, December 8, 2000, Vol. 47, Edition 15 
 
THE PRESIDENTIAL CAMPAIGN ENDED, effectively, in a tie, but it did speak clearly about the 
value accorded intellectuals and intellectuality in American culture. What it declared is, to say the 
least, inauspicious.  
However the next four years play out in the White House, George W. Bush deserves a certain credit 
for resurrecting--though probably not intentionally--the subject of anti-intellectualism. […] 
Early in the campaign, Bush had famously dubbed the inhabitants of Greece "Grecians" and flubbed 
a talk-show host's quiz about names of foreign leaders. There was so much ignorance on display as 
to raise the suspicion, on one hand, that Bush was dyslexic or, on the other, that this lazy-minded 
graduate of Andover, Yale, and Harvard Business School was a chip off his father's pork rinds, 
appealing self-consciously to his audience's resentment of brains. Thanks to videotape and a media 
maw hungry for simple charges and sound bites, Duh-bya seemed to have stridden right out of central 
casting, a veritable personification of the politician as clown.  
Yet none of the easy charges against Bush touched upon his more substantial incapacities: his lack of 
curiosity about the world (he has scarcely traveled outside the United States and Mexico City) and 
the ample evidence that he does not reason. During the debates, he was unresponsive to questions the 
answers to which he had not memorized. In public appearances, he spoke in sloganistic lists, not arcs. 
It would seem that, precisely because his thinking was disordered, the governor lost track of his 
points, so that items came out nonsensical […].  
There has been much talk since the election to the effect that "two nations" were evenly matched in 
the contest: roughly speaking, the rural, inland, heavily male, and white Bushland versus the urban, 
coastal, heavily female, black, and immigrant Goreland. To be sure, suspicion of intellectuals and 
intellectuality was visible in both camps, but most plainly so in Bush's. So it came to pass that half of 
the voting population was appalled that the other half judged this man of little discernible 
achievement, little knowledge of the world or curiosity about it, to be an acceptable president of the 
United States. His defenders were in the position of claiming that it didn't matter whether the governor 
was smart or not, he could hire a smart staff, thereby certifying that intelligence was something for 
underlings.  
In the minds of many of Bush's supporters, the absence of thoughtfulness, the narrowness of scope, 
the presence of diminished capacity were all reduced to a question of "management style." Gore, 
meanwhile, suffered bad reviews for his dismissive and overbearing style of intellectual combat. In 
the eyes of half the population, the vice president fell prey to a suspicion that he was not only preachy 
but also a sharpie. In the media's campaign story line, the standard charge against Gore, shared by the 
Bush campaign and the comedians, was that, like the traditional confidence man, Gore--too smart for 
his own good--lied, while Bush was the amiable common man. […] 
A central force boosting anti-intellectualism […] has been the bulking up of popular culture and, in 
particular, the rise of a new form of faux cerebration: punditry. Everyday life, supersaturated with 
images and jingles, makes intellectual life look hopelessly sluggish, burdensome, difficult. In a video-
game world, the play of intellect--the search for validity, the willingness to entertain many 
hypotheses, the respect for difficulty, the resistance to hasty conclusions--has the look of retardation.  


## PDF page 136

136 
 
[…] In the torrent of popular culture, there emerges more talk about public affairs than ever before--
virtually nonstop talk about political concerns, debate on burning questions available at all hours of 
the day and night. But the talk that fills the channels amounts mainly to signals, gestures, and stances-
-not reasoning.  
[…] The punditocracy, as Eric Alterman calls it, does not assess either reason or reasons. Its job is 
simply to declare which issues are discussable, which positions presentable. It makes up for its 
intellectual deficits by supplying precooked opinion. The point is not to clarify: It is never to be at a 
loss for words. […] 
But the crucial public development […] is the rise of the pseudo-intellectual, thanks to the premium 
on smirking and glibness, which, in much of the popular mind, passes for intellect. The pundit is a 
smart person in both senses--intelligent and a smarty-pants--and his knowingness about how the game 
is played is a substitute for knowledge about what would improve society. Punditry is to intellectual 
life as fast food is to fine cuisine.  
After Gore, selt-cast as wonk-expert and therefore prey to […] anti-intellectualism […] challenged 
Bush to state his position on the Dingell-Norwood patients-rights' bill during the third debate, and 
Bush avoided the question, the pseudo-brains of ABC'S This Week, Cokie Roberts and Sam 
Donaldson, made much mirth by mocking the names. They did not think it their obligation to clarify 
what Gore was talking about. Deadly, that would have been. Chock full of attitude, deploying the 
cheap gags and knowingness that mark them as qualified for their jobs, those maestros of the Beltway 
paraded their superiority to knowledge while (as Michael Kinsley pointed out) refraining from 
showing that they knew more than the public. […] 
 
 


## PDF page 137

137 
 
Speech on Health Care Reform 
Barack Obama, March 15, 2010 
 
[…] I don’t believe we should give the government or insurance companies more control over health 
care in America.  I believe it’s time to give you, the American people, more control over your own 
health insurance.   
And that’s what our proposal does.  Our proposal builds on the current system where most Americans 
get their health insurance from their employer.  So if you like your plan, you can keep your plan.  If 
you like your doctor, you can keep your doctor.  I don't want to interfere with people’s relationships 
between them and their doctors. 
Essentially, here’s what my proposal would change:  three things about the current health care system, 
but three important things. 
Number one, it would end the worst practices of the insurance companies.  […] This is like a patient’s 
bill of rights on steroids.  Within the first year of signing health care reform, thousands of uninsured 
Americans with preexisting conditions will be able to purchase health insurance for the first time in 
their lives or the first time since they got sick.  This year, insurance companies will be banned forever 
from denying coverage to children with preexisting conditions.  So parents can have a little bit of 
security.  This year, under this legislation, insurance companies will be banned from dropping your 
coverage when you get sick.  Those practices would end.   
With this reform package, all new insurance plans would be required to offer free preventive care to 
their customers starting this year -- so free check-ups to catch preventable diseases on the front 
end.  That’s a smart thing to do.  Starting this year, if you buy a new plan, there won’t be lifetime or 
restrictive annual limits on the amount of care you receive from your insurance companies, so you 
won’t be surprised by the fine print that says suddenly they’ve stopped paying and you now suddenly 
are $50,000 or $100,000 or $200,000 out of pocket.  That won’t -- that will not happen if this becomes 
law this year.   
[…] The second thing that this plan would change about the current system is this:  For the first time, 
uninsured individuals, small businesses, they’d have the same kind of choice of private health 
insurance that members of Congress get for themselves.  […] So basically what would happen is, 
we’d set up a pool of people; millions of people across the country would all buy into these pools that 
give them more negotiating power.  If you work for a big company, you’ve got a better insurance deal 
because you’ve got more bargaining power as a whole.  We want you to have all the bargaining power 
that the federal employees have, that big companies have, so you’ll be able to buy in or a small 
business will be able to buy into this pool.  And that will lower rates, it’s estimated, by up to 14 to 20 
percent over what you’re currently getting.  That’s money out of pocket. 
And what my proposal says is if you still can’t afford the insurance in this new marketplace, then 
we’re going to offer you tax credits to do so.  And that will add up to the largest middle-class tax cut 
for health care in history.  That’s what we’re going to do.   
[…] Look, I want everybody to understand -- the wealthiest among us can already buy the best 
insurance there is.  The least well among us, the poorest among us, they get their health care through 
Medicaid.  So it’s the middle class, it’s working people that are getting squeezed, and that’s who we 
have to help, and we can afford to do it.   


## PDF page 138

138 
 
Now, it is true that providing these tax credits to middle class families and small businesses, that’s 
going to cost some money.  It’s going to cost about $100 billion per year.  But most of this comes 
from the nearly $2.5 trillion a year that Americans already spend on health care.  It’s just right now, 
a lot of that money is being spent badly. 
So with this plan, we’re going to make sure the dollars we make -- the dollars that we spend on health 
care are going to make insurance more affordable and more secure.  And we’re going to eliminate 
wasteful taxpayer subsidies that currently go to insurance company.  Insurance companies are making 
billions of dollars on subsidies from you, the taxpayer.  […] 
And, yes, we will set a new fee on insurance companies because they stand to gain millions more 
customers who are buying insurance.  There’s nothing wrong with them giving something back.  But 
here’s the bottom line:  Our proposal is paid for. […] This plan doesn’t expand the deficit. […] 
Now, so let me talk about the third thing, which is my proposal would bring down the cost of health 
care 
for 
families, 
for 
businesses, 
and 
for 
the 
federal 
government. […] 
We have incorporated most of the serious ideas from across the political spectrum about how to 
contain the rising costs of health care.  We go after waste and abuse in the system, especially in 
Medicare.  Our cost-cutting measures would reduce most people’s premiums and bring down our 
deficit by up to a trillion dollars over the next two decades.  […] 
We need courage.  You know, in the end, this debate is about far more than politics.  It comes down 
to what kind of country do we want to be.  It’s about the millions of lives that would be touched and, 
in some cases, saved, by making health insurance more secure and more affordable.  […] And the 
truth is, what’s at stake in this debate, it’s not just our ability to solve this problem; it’s about our 
ability to solve any problem. 
Excerpted from: https://millercenter.org/the-presidency/presidential-speeches/march-15-2010-
speech-health-care-reform  
 
 


## PDF page 139

139 
 
How the US Justifies Drone Strikes: Targeted Killing, Secrecy and the Law  
By Jameel Jaffer The Guardian, 15 Nov 2016 
 
For decades the US condemned targeted killings, characterizing them as assassinations – but it was 
unclear what distinguished America’s drone campaign from the killings it historically rejected as 
unlawful 
[…] Over just a short period in early 2016 […], the United States deployed remotely piloted aircraft 
to carry out deadly attacks in six countries across central and south Asia, north Africa, and the Middle 
East, and it announced that it had expanded its capacity to carry out attacks in a seventh. And yet […], 
the drone attacks did not seem to spark controversy or reflection. As the 2016 presidential primaries 
were getting under way, sporadic and sketchy reports of strikes in remote regions of the world 
provided a kind of background noise – a drone in a different sense of the word – to which Americans 
had become inured. 
Senior officials in the administration of President Barack Obama variously described drone strikes as 
“precise,” “closely supervised,” “effective,” “indispensable,” and even the “only game in town” – but 
what they emphasized most of all is that the drone strikes they authorized were lawful. 
In this context, though, “lawful” had a specialized meaning. Except at the highest level of abstraction, 
the law of the drone campaign had not been enacted by Congress or published in the US Code. No 
federal agency had issued regulations relating to drone strikes, and no federal court had adjudicated 
their legality. Obama administration officials insisted that drone strikes were lawful, but the “law” 
they invoked was their own. It was written by executive branch lawyers behind closed doors, withheld 
from the public and even from Congress, and shielded from judicial review. […] 
Secret law is unsettling in any context, but it was especially so in this one. For decades the US 
government had condemned targeted killings, characterizing them as assassinations or extrajudicial 
executions. On its face, the drone campaign signified a dramatic departure from that position – a 
departure that demanded explanation, at the very least. It was far from obvious what distinguished 
American drone strikes from the targeted killings the United States had historically rejected as 
unlawful. Nor was it clear how these targeted killings could be reconciled with international human 
rights law, with a decades-old executive order that bans assassinations, with the constitutional 
guarantee of due process, or, for that matter, with domestic laws that criminalize murder. 
The scale of the drone campaign, and the human cost of it, made government secrecy even more 
disquieting. […] By the end of President Obama’s first term, American strikes had killed several 
thousand people in Pakistan, Yemen, and Somalia, including many hundreds of civilian bystanders. 
The deaths of innocents raised sharp moral questions, and the moral questions gave urgency to the 
legal ones. […] 
There is something ironic, and even sad, in the fact that the expansion and normalization of the drone 
campaign was overseen by President Obama, a onetime professor of constitutional law who was 
elected after promising to end the lawless national security policies of the administration that 
preceded his. Perhaps it is also true, though, that only President Obama could have overseen it. When 
President George W Bush left office, he was unpopular and distrusted. The evidence he had cited to 
justify the invasion of Iraq had been exposed as a fiction. His administration’s torture policies were 
widely viewed as an embarrassment and an outrage. The supreme court had repeatedly rejected his 


## PDF page 140

140 
 
policies relating to military detention and prosecution. It is doubtful that the courts or the public would 
have allowed him to expand the drone campaign. 
But many Americans who were appalled when Bush ordered extrajudicial detention were untroubled 
when Obama ordered extrajudicial killing. If they appreciated the breadth of the power Obama had 
claimed, they assumed he would use the power wisely. Equally significant, some of the scholars and 
human rights lawyers who might otherwise have been expected to harshly criticize Obama’s targeted-
killing policies were part of Obama’s administration and deeply involved in developing the policies. 
Several months before the 2012 presidential election, when it appeared that Americans might not give 
President Obama a second term, administration officials began to worry privately that the powers 
they had claimed for themselves might soon be in the hands of another president. They began to 
consider ways of narrowing the powers they had asserted. By this point, though, the administration 
had already persuaded a federal judge that the courts had no role to play in determining whether (or 
when) an American citizen could be targeted by his own government. The administration was already 
on its way toward persuading another judge that the government should not have to present evidence 
even after a targeted killing had been carried out. The powers claimed by the Obama administration 
had become entrenched – so entrenched that they could not readily be surrendered. This was even 
more true in early 2016, when Obama administration officials turned once again to the question of 
what legacy they would leave to their successors. 
Now the lethal bureaucracy whose growth Obama personally oversaw will be turned over to a new 
administration. The powers Obama claimed will be wielded by another president. Perhaps as 
significant is the jarring fact that the practice of targeted killing – assassination, as it would once have 
been called, without a second thought – no longer seems remarkable, and the fact that the United 
States now boasts a legal and bureaucratic infrastructure to sustain this practice. Eight years ago the 
targeted-killing campaign required a legal and bureaucratic infrastructure, but now that infrastructure 
will demand a targeted-killing campaign. The question the next president will ask is not whether the 
powers Obama claimed should be exploited, but where, and against whom. 
Source: https://www.theguardian.com/us-news/2016/nov/15/targeted-killing-secrecy-drone-memos-
excerpt, originally appeared The Drone Memos: Targeted Killing, Secrecy, and the Law (2016) 
 
 


## PDF page 141

141 
 
Speech Declaring a National Emergency 
Donald Trump, Feb. 15, 2019 
Today, I’m announcing several critical actions that my administration has taken to confront a problem 
that we have right here at home.  We fight wars that are 6,000 miles away; wars that we should have 
never been in, in many cases.  But we don’t control our own border. 
So we’re going to confront the national security crisis on our southern border.  And we’re going to do 
it one way or the other — we have to do it — not because it was a campaign promise, which it is.  It 
was one of many, by the way; not my only one.  […] 
So our country is doing very well, economically.  And we’ve done a lot.  But one of the things I said 
I have to do and I want to do is border security, because we have tremendous amounts of drugs flowing 
into our country, much of it coming from the southern border.  […] They say walls don’t work.  Walls 
work 100 percent. […] 
he only weakness is they go to a wall and then they go around the wall.  They go around the wall and 
in.  Okay?  That’s what it is.  It’s very simple.  And a big majority of the big drugs — the big drug 
loads — don’t go through ports of entry.  They can’t go through ports of entry.  You can’t take big 
loads because you have people — we have some very capable people; the Border Patrol, law 
enforcement — looking. 
You can’t take human traffic — women and girls — you can’t take them through ports of entry.  You 
can’t have them tied up in the backseat of a car or a truck or a van.  They open the door.  They 
look.  They can’t see three women with tape on their mouth or three women whose hands are tied. 
They go through areas where you have no wall.  Everybody knows that.  […] 
You don’t have to be very smart to know: You put up a barrier, the people come in, and that’s it.  They 
can’t do anything unless they walk left or right, and they find an area where there’s no barrier, and 
they come into the United States.  Welcome. 
We’ve detained more people.  Our border agents are doing such incredible work.  Our military has 
been incredible.  We put up barbed wire on top of certain old walls that were there.  We fixed the wall 
and we loaded it up with barbed wire.  It’s very successful. […] 
We’ve been actually working with Mexico much better than ever before.  I want to thank the 
President.  I want to thank Mexico.  […] But I just want to thank the President, because he’s been 
helping us with these monstrous caravans that have been coming up.  We had one that it was up to 
over 15,000 people.  It’s largely broken up.  Others have gotten through.  And, in Tijuana, you have 
a lot of people staying there.  If we didn’t have the wall up, and if we didn’t have the wall secured 
and strengthened, they would have walked right through; they’d be welcomed to the United States. 
[…] 
So I’m going to be signing a national emergency. […] And it’s a great thing to do because we have 
an invasion of drugs, invasion of gangs, invasion of people, and it’s unacceptable. […] 
Excerpted from: https://millercenter.org/the-presidency/presidential-speeches/february-15-2019-
speech-declaring-national-emergency  
 
 


## PDF page 142

142 
 
Donald Trump Is a Good President: One foreigner’s perspective 
Michel Houellebecq, John Cullen (Translator), Harper’s Magazine, January 2019 
 
In all sincerity, I like Americans a lot; I’ve met many lovely people in the United States, and I 
empathize with the shame many Americans (and not only “New York intellectuals”) feel at having 
such an appalling clown for a leader. 
However, I have to ask—and I know what I’m requesting isn’t easy for you—that you consider things 
for a moment from a non-American point of view. I don’t mean “from a French point of view,” which 
would be asking too much; let’s say, “from the point of view of the rest of the world.” 
On the numerous occasions when I’ve been questioned about Donald Trump’s election, I’ve replied 
that I don’t give a shit. France isn’t Wyoming or Arkansas. France is an independent country, more or 
less, and will become totally independent once again when the European Union is dissolved (the 
sooner, the better). 
The United States of America is no longer the world’s leading power. It was for a long time, for almost 
the entire course of the twentieth century. It isn’t anymore. 
It remains a major power, one among several. This isn’t necessarily bad news for Americans. It’s very 
good news for the rest of the world. 
My response is a bit of an exaggeration. One has an ongoing obligation to take at least a modicum of 
interest in American political life. The United States is still the world’s leading military power and 
unfortunately has yet to break its habit of mounting interventions beyond its borders. I’m not a 
historian, and I don’t know much about ancient history […] but I have the impression that it’s been a 
good long time since the United States last won a war, and that for at least fifty years its foreign 
military interventions, whether acknowledged or clandestine, have been nothing but a succession of 
disgraces culminating in failures. 
[…] Enormous progress was made under Obama. Maybe he was awarded the Nobel Peace Prize a 
little too soon; but as far as I’m concerned, he truly earned it later, on the day when he refused to back 
Francois Hollande’s proposed attack on Syria. Obama’s attempts at racial reconciliation were less 
successful, and I don’t know your country well enough to understand exactly why; all I can do is 
regret the fact. But at the very least, Obama can be congratulated for not adding Syria to the long list 
(Afghanistan, Iraq, Libya, and others I’m no doubt forgetting) of Muslim lands where the West has 
committed atrocities. 
Trump is pursuing and amplifying the policy of disengagement initiated by Obama; this is very good 
news for the rest of the world. The Americans are getting off our backs. The Americans are letting us 
exist. 
The Americans have stopped trying to spread democracy to the four corners of the globe. Besides, 
what democracy? Voting every four years to elect a head of state—is that democracy? In my view, 
there’s one country in the world (one country, not two) that enjoys partially democratic institutions, 
and that country isn’t the United States of America; it’s Switzerland. A country otherwise notable for 
its laudable policy of neutrality. […] 
But what’s most remarkable about the new American policies is certainly the country’s position on 
trade, and there Trump has been like a healthy breath of fresh air; you’ve really done well to elect a 
president with origins in what is called “civil society.” 


## PDF page 143

143 
 
President Trump tears up treaties and trade agreements when he thinks it was wrong to sign them. 
He’s right about that; leaders must know how to use the cooling-off period and withdraw from bad 
deals. 
Unlike free-market liberals (who are, in their way, as fanatical as communists), President Trump 
doesn’t consider global free trade the be-all and end-all of human progress. When free trade favors 
American interests, President Trump is in favor of free trade; in the contrary case, he finds old-
fashioned protectionist measures entirely appropriate. 
President Trump was elected to safeguard the interests of American workers; he’s safeguarding the 
interests of American workers. During the past fifty years in France, one would have wished to come 
upon this sort of attitude more often. 
[…] In summary, President Trump seems to me to be one of the best American presidents I’ve ever 
seen. 
On the personal level, he is, of course, pretty repulsive. […]  
Source: https://harpers.org/archive/2019/01/donald-trump-is-a-good-president/  
 
 
 


## PDF page 144

144 
 
‘Clueless’ and ‘Saved by the Bell’ Are How We Got Trump: 
How ’90s pop culture convinced a generation of would-be earnest activists that caring was 
uncool. 
By Lindy West, The New York Times, Oct. 26, 2019 
 
I remember sitting in physics class on the first day of the World Trade Organization protests in Seattle 
in 1999. I was a senior, still 17, and we’d been hearing for weeks that a huge and bad anarchist riot 
was coming to destroy our town, with tanks and bricks and garbage fires and naked bicyclists and 
people dressed as turtles. Turtles! The Gap was on high alert! 
My understanding, at the time, was that activist types were mad about globalization, which, as I 
understood it, was something to do with money, which I assumed was morally neutral (incorrect), 
sweatshop labor, which I recognized as bad, and the killing of sea turtles, very bad. Inasmuch as I 
could formulate an opinion on something that I did not understand, I was on the side of the hippies, 
even the Gap smashers probably. I was certainly not on the side of the cops. At least I knew that much. 
But I remember, on that day, a procession of protesters barreling down the hall outside my physics 
class, yelling and waving signs, trying to entice other kids to march downtown and join the throng. 
My classmates and I looked at one another, yearning to be one of those kids who isn’t scared of 
sincerity, of action, of authority. To be the kind of smart, engaged young person who actually 
understood things about the globe. 
Only one kid in the class grabbed his bag and walked out. I remember feeling, with innate certainty, 
that he was a different kind of person from me. 
In the 1990s, activism — particularly student activism — was stigmatized as tedious, silly, self-
important and, most damningly, ineffectual. Student activism was Paul Rudd smirking behind 
designer sunglasses in the 1995 movie “Clueless”: “I’m going to a Tree People meeting. We might 
get Marky Mark to plant a celebrity tree.” […] 
If you were very, very cool in the early to mid-’90s, you could pull off a Beastie Boys “Free Tibet” 
bumper sticker or quote Rage Against the Machine in your social studies paper, but for your middle-
of-the-road fat white dorks? The safest path was to say all the right things about freedom and equality 
while rolling your eyes at the try-hards. 
I want to be very clear that I’m not talking about kids of marginalized identities or communities who 
have never for one second had the luxury to choose whether to fight or not. I’m talking about the 
mediocre white kids, the comfortable kids, the suburban kids. 
If you were a privileged white kid in the ’90s who could feel a moral pull to fight for something but 
didn’t know where to start, looking to the media for inspiration was a dry, dry well. We had the joyless 
ecofeminists Lisa Simpson and Darlene from “Roseanne.” We had Wendy Testaburger, who spent a 
significant bulk of her screen time on “South Park” being vomited on by Stan.  
Kat from “10 Things I Hate About You” is a rabid feminist until she’s cured by getting a boyfriend. 
Topanga’s feminism on “Boy Meets World” was often a punch line. On “Saved by the Bell,” Jessie 
Spano was relentlessly mocked for calling out Slater’s chauvinism. It was a running gag for the entire 
series. 


## PDF page 145

145 
 
[…] I did not go to the W.T.O. protest partly because my mom told me I couldn’t and partly because 
I didn’t understand it, but primarily because I’d been taught that when ordinary people, especially 
young people, try to do activism, they look stupid. 
But things are different now. 
One recent afternoon, my stepdaughter, who is neither mediocre nor white, paused while passing 
through the living room and asked, “Are you guys busy tomorrow night?” 
“Probably,” my husband said. “Why?” 
“Oh, you know how I’m in the Art of Resistance and Resilience Club? We’re finally unveiling our 
Black Panthers mural. Bobby Seale is going to be there, and I’m giving a speech. Well, actually, it’s 
more of a poem. You guys can come if you want to.” Shrug, bye. 
We canceled our plans. 
The mural is spectacular, at the intersection of the two major roads that carry drivers from fully 
gentrified central Seattle to quickly gentrifying south Seattle. Images of Black Panthers distributing 
food and registering black voters stretch 40 feet along the sidewalk outside the high school, which is 
93 percent kids of color. 
Activism comes so naturally to my girls. They are native to it. They are not afraid of sincerity. They’re 
at every protest, ones I haven’t even heard about. 
Sure, there’s a concomitant swell among young people on the right, of conservative kids encouraged 
by Trumpism to memeify cruelty, roast Priuses, and trigger the libs with their MAGA hats. But this 
generation wasn’t fed activism as a punch line the way I was, and as Donald Trump emboldens 
conservative teenagers, my daughters and their friends aren’t cowed — they’re galvanized. 
Think of 16-year-old Greta Thunberg, whose stone-faced protest outside the Swedish Parliament in 
2018 inspired student strikes in more than a dozen countries and made her a global voice on climate 
change. 
Think of the Parkland school shooting survivors, who, in the thick of unimaginable trauma, rejected 
the typical thoughts, prayers and shrugs from their government and helped pass 67 new gun laws in 
2018. 
Those kids were born after Sept. 11 into a fractured place. They didn’t get any quiet years, I guess, 
when, in many communities (not all, of course) the end of the world felt abstract and far away. Young 
people are here and strong and smart and fierce, and they do not intend to die. As Ms. Thunberg noted 
in her blistering address to the United Nations last month, it is not their job to save us — we are the 
parents — but may they inspire us to help them save themselves. I feel afraid in this moment, but I 
do not feel hopeless. 
In the auditorium, my stepdaughter took the mic. “We are tired of the fact that we still have to fight,” 
she chanted, “for what the white man gets to call his inalienable rights. And it’s not how we fight, it’s 
that we dare to.” She took a deep breath. “So we, as a people, will keep fighting, whether it’s peaceful 
or scary, until we reach justice by whatever means necessary.” 
Excerpted from: https://www.nytimes.com/2019/10/26/opinion/sunday/90s-movies-tv-
activism.html  
 


## PDF page 146

146 
 
 
 
 
 
 
 
LITERARY STUDIES 
 
 


## PDF page 147

147 
 
Wuthering Heights (1847), Emily BRONTË 
Charlotte (1816-55), Emily (1818-48) and Anne (1820-49) Brontë grew up in 
Yorkshire. Their mother died when they were still young, and they and their brother 
were left with their father, an Anglican clergyman, and an aunt. They were educated 
mostly at home where they had plenty of time to read, write, and walk on the moors. 
They would make up games and stories in which they invented imaginary worlds, and 
all three wrote. Wuthering Heights, Emily’s influential work, is a novel of romantic 
passion and imagination. It relates the impassioned love of Catherine Earnshaw and 
Heathcliff, an orphan who was adopted by Catherine’s father. But after the latter’s 
death, Heathcliff was ill-treated by Catherine’s brother, and disappeared. Catherine 
then married Edgar Linton. When Heathcliff comes back years later to see her, their mutual love is as strong 
as ever, and Catherine is torn between her husband and Heathcliff. In the following excerpt, Nelly Dean, the 
housekeeper, is the narrator. 
‘Oh, you see, Nelly! He would not relent a moment to keep me out of the grave! That is how I’m 
loved! Well, never mind! That is not my Heathcliff. I shall love mine yet; and take him with me 
- he’s in my soul. And,’ added she, musingly, ‘the thing that irks me most is this shattered 
 prison, after all. I’m tired, tired of being enclosed here. I’m wearying to escape into that 
glorious world, and to be always there; not seeing it dimly through tears, and yearning for it 
5 
through the walls of an aching heart; but really with it, and in it. Nelly, you think you are better 
and more fortunate than I; in full health and strength - you are sorry for me - very soon that will 
be altered.  
I shall be sorry for you. I shall be incomparably beyond and above you all. I wonder he won’t 
be near me!’ She went on to herself. ‘I thought he wished it. Heathcliff, dear! you should not 
10 
be sullen now. Do come to me, Heathcliff.’ 
In her eagerness she rose, and supported herself on the arm of the chair. At that earnest 
appeal, he turned to her, looking absolutely desperate. His eyes wide, and wet, at last, flashed 
fiercely on her; his breast heaved convulsively. An instant they held asunder; and then how they 
met I hardly saw, but Catherine made a spring, and he caught her, and they were locked in an 
15 
embrace from which I thought my mistress would never be released alive. In fact, to my eyes, 
she seemed directly insensible. He flung himself into the nearest seat, and on my approaching 
hurriedly to ascertain if she had fainted, he gnashed at me, and foamed like a mad dog, and 
gathered her to him with greedy jealousy. I did not feel as if I were in the company of a creature 
of my own species; it appeared that he would not understand, though I spoke to him; so, I stood 
20 
off, and held my tongue, in great perplexity. 
A movement of Catherine’s relieved me a little presently: she put up her hand to clasp his neck, 
and bring her cheek to his, as he held her: while he, in return, covering her with frantic caresses, 
said wildly -‘You teach me now how cruel you’ve been - cruel and false. Why did you despise 
me? Why did you betray your own heart, Cathy? I have not one word of comfort - you deserve 
25 
this. You have killed yourself. Yes, you may kiss me, and cry; and wring out my kisses and 
tears. They’ll blight you - they’ll damn you. You loved me - then what right had you to leave 
me? What right – answer me - for the poor fancy you felt for Linton? Because misery, and 
degradation, and death, and nothing that God or satan could inflict would have parted us, you, 
of your own will, did it. I have not broken your heart - you have broken it - and in breaking it, 
30 
you have broken mine. So much the worse for me, that I am strong. Do I want to live? What 
kind of living will it be when you - oh, God! would you like to live with your soul in the grave?’


## PDF page 148

148 
 
Heart of Darkness (1902), Joseph CONRAD 
Is Marlowe a racist; was Conrad a racist? 
Does the ‘heart of darkness’ equate Africa with moral decadence present in   
every man, or is it a critique of imperialism? 
What is the underlying relation that draws Marlowe to Kurtz; 
what is the real nature of both these men’s quest? 
Is Kurtz overcome by guilt or does he represent the dangers of ‘savagery’ and  
of a man ‘gone native’? 
What is the “horror” Kurtz speaks of? 
Joseph Conrad, 1857-1924 
 
“His was an impenetrable darkness. I looked at him as you peer down at a man who is lying at 
the bottom of a precipice where the sun never shines. But I had not much time to give him, 
because I was helping the engine-driver to take to pieces the leaky cylinders, to straighten a 
bent connecting-rod, and in other such matters. I lived in an infernal mess of rust, filings, nuts, 
bolts, spanners, hammers, ratchet-drills—things I abominate, because I don’t get on with them. 
5 
I tended the little forge we fortunately had aboard; I toiled wearily in a wretched scrap-heap—
unless I had the shakes too bad to stand. 
“One evening coming in with a candle I was startled to hear him say a little tremulously, ‘I am 
lying here in the dark waiting for death.’ The light was within a foot of his eyes. I forced myself 
to murmur, ‘Oh, nonsense!’ and stood over him as if transfixed. 
10 
“Anything approaching the change that came over his features I have never seen before, and 
hope never to see again. Oh, I wasn’t touched. I was fascinated. It was as though a veil had been 
rent. I saw on that ivory face the expression of somber pride, of ruthless power, of craven 
terror—of an intense and hopeless despair. Did he live his life again in every detail of desire, 
temptation, and surrender during that supreme moment of complete knowledge? He cried in a 
15 
whisper at some image, at some vision,—he cried out twice, a cry that was no more than a 
breath: 
“The horror! The horror!” 
“I blew the candle out and left the cabin. The pilgrims were dining in the mess-room, and I took 
my place opposite the manager, who lifted his eyes to give me a questioning glance, which I 
20 
successfully ignored. He leaned back, serene, with that peculiar smile of his sealing the 
unexpressed depths of his meanness. A continuous shower of small flies streamed upon the 
lamp, upon the cloth, upon our hands and faces. Suddenly the manager’s boy put his insolent 
black head in the doorway, and said in a tone of scathing contempt: 
“‘Mistah Kurtz—he dead.’
25 
 
 
 


## PDF page 149

149 
 
Atonement (2001), by Ian McEwan 
Ian McEwan, born in 1948 in Hampshire, England, is a renowned novelist and 
screenwriter. In 2001, he published his most successful and critically acclaimed work, 
Atonement (2001), a metafictional novel covering three time periods (1935 England, 
Second World War England and France, and present-day England) in the lives of upper-
class sisters Briony and Cecilia Tallis and Robbie Turner, their housekeeper’s son and 
Cecilia’s love interest. This exchange between Cecilia and Robbie occurs during that 
fateful summer of 1935, before Briony forever ruins their lives. 
She felt she had said something stupid. Robbie was looking away across the park and the cows 
towards the oak wood that lined the river valley, the wood she had run through that morning. He 
might be thinking she was talking to him in code, suggestively conveying her taste for the full-
blooded and sensual. That was a mistake, of course, and she was discomfited and had no idea 
how to put him right. She liked his eyes, she thought, the unblended mix of orange and green, 
5 
made even more granular in sunlight. And she liked the fact that he was so tall. It was an 
interesting combination in a man, intelligence and sheer bulk. Cecilia had taken the cigarette and 
he was lighting it for her.  
‘I know what you mean,’ he said as they walked the remaining few yards to the fountain. ‘There’s 
more life in Fielding, but he can be psychologically crude compared to Richardson.’  
10 
She set down the vase by the uneven steps that rose to the fountain’s stone basin. The last thing 
she wanted was an undergraduate debate on eighteenth century literature. She didn’t think 
Fielding was crude at all, or that Richardson was a fine psychologist, but she wasn’t going to be 
drawn in, defending, defining, attacking. She was tired of that, and Robbie was tenacious in 
argument.   
15 
Instead she said, ‘Leon’s coming today, did you know?’ 
 ‘I heard a rumour. That’s marvellous.’  
‘He’s bringing a friend, this man Paul Marshall.’ 
 ‘The chocolate millionaire. Oh no! And you’re giving him flowers!’  
She smiled. Was he pretending to be jealous to conceal the fact that he was? She no longer 
20 
understood him. They had fallen out of touch at Cambridge. It had been too difficult to do 
anything else. She changed the subject.  
‘The Old Man says you’re going to be a doctor.’  
‘I’m thinking about it.’ 
 ‘You must love the student life.’  
25 
He looked away again, but this time for only a second or less, and when he turned to her she 
thought she saw a touch of irritation. Had she sounded condescending? She saw his eyes again, 
green and orange flecks, like a boy’s marble. When he spoke he was perfectly pleasant.  
‘I know you never liked that sort of thing, Cee. But how else do you become a doctor?’  
‘That’s my point. Another six years. Why do it?’  
30 
He wasn’t offended. She was the one who was over-interpreting, and jittery in his presence, and 
she was annoyed with herself.  


## PDF page 150

150 
 
He was taking her question seriously. ‘No one’s really going to give me work as a landscape 
gardener. I don’t want to teach, or go in for the civil service. And medicine interests me…’ He 
broke off as a thought occurred to him. ‘Look, I’ve agreed to pay your father back. That’s the 
35 
arrangement.’  
‘That’s not what I meant at all.’ She was surprised that he should think she was raising the 
question of money. That was ungenerous of him. Her father had subsidised Robbie’s education 
all his life. Had anyone ever objected? She had thought she was imagining it, but in fact she was 
right – there was something trying in Robbie’s manner lately. He had a way of wrong-footing her 
40 
whenever he could. Two days before he had rung the front doorbell – in itself odd, for he had 
always had the freedom of the house. When she was called down, he was standing outside asking 
in a loud, impersonal voice if he could borrow a book. As it happened, Polly was on all fours, 
washing the tiles in the entrance hall. Robbie made a great show of removing his boots which 
weren’t dirty at all, and then, as an afterthought, took his socks off as well, and tiptoed with comic 
45 
exaggeration across the wet floor.   
Everything he did was designed to distance her. He was play-acting the cleaning lady’s son come 
to the big house on an errand. They went into the library together, and when he found his book, 
she asked him to stay for a coffee. It was a pretence, his dithering refusal – he was one of the 
most confident people she had ever met. She was being mocked, she knew. Rebuffed, she left the 
50 
room and went upstairs and lay on the bed with Clarissa, and read without taking in a word, 
feeling her irritation and confusion grow. She was being mocked, or she was being punished – 
she did not know which was worse. Punished for being in a different circle at Cambridge, for not 
having a charlady for a mother; mocked for her poor degree – not that they actually awarded 
degrees to women anyway. 
55 
Awkwardly, for she still had her cigarette, she picked up the vase and balanced it on the rim of 
the basin. It would have made better sense to take the flowers out first, but she was too irritable. 
Her hands were hot and dry and she had to grip the porcelain all the tighter.  
Robbie was silent, but she could tell from his expression – a forced, stretched smile that did not 
part his lips – that he regretted what he had said. That was no comfort either. This was what 
60 
happened when they talked these days; one or the other was always in the wrong, trying to call 
back the last remark. There was no ease, no stability in the course of their conversations, no 
chance to relax. Instead, it was spikes, traps, and awkward turns that caused her to dislike herself 
almost as much as she disliked him, though she did not doubt that he was mostly to blame. She 
hadn’t changed, but there was no question that he had. He was putting distance between himself 
65 
and the family that had been completely open to him and given him everything. For this reason 
alone – expectation of his refusal, and her own displeasure in advance – she had not invited him 
to dinner that night. If he wanted distance, then let him have it.
 
 
 
 
 
 


## PDF page 151

151 
 
The Scarlet Letter (1850), Nathaniel HAWTHORNE 
 
The title of Hawthorne’s most famous novel refers to the red letter that Hester Prynne has to 
wear as a punishment for having committed adultery in the Puritan society of colonial 
America. In the following passage, as Hester comes out of prison, her feelings of guilt and 
sin and her moral conflicts are exposed. 
Nathaniel Hawthorne (1804-1864) 
 
Hester Prynne’s term of confinement was now at an end. Her prison-door was thrown open, and 
she came forth into the sunshine, which, falling on all alike, seemed, to her sick and morbid heart, 
as if meant for no other purpose than to reveal the scarlet letter on her breast. Perhaps there was 
a more real torture in her first unattended footsteps from the threshold of the prison, than even in 
the procession and spectacle that have been described, where she was made the common infamy, 
5 
at which all mankind was summoned to point its finger. Then, she was supported by an unnatural 
tension of the nerves, and by all the combative energy of her character, which enabled her to 
convert the scene into a kind of lurid triumph. It was, moreover, a separate and insulated event, 
to occur but once in her lifetime, and to meet which, therefore, reckless of economy, she might 
call up the vital strength that would have sufficed for many quiet years. The very law that 
10 
condemned her—a giant of stern features, but with vigor to support, as well as to annihilate, in 
his iron arm—had held her up, through the terrible ordeal of her ignominy. But now, with this 
unattended walk from her prison-door, began the daily custom, and she must either sustain and 
carry it forward by the ordinary resources of her nature, or sink beneath it. She could no longer 
borrow from the future, to help her through the present grief. To-morrow would bring its own 
15 
trial with it; so would the next day, and so would the next; each its own trial, and yet the very 
same that was now so unutterably grievous to be borne. The days of the far-off future would toil 
onward, still with the same burden for her to take up, and bear along with her, but never to fling 
down; for the accumulating days, and added years, would pile up their misery upon the heap of 
shame. Throughout them all, giving up her individuality, she would become the general symbol 
20 
at which the preacher and moralist might point, and in which they might vivify and embody their 
images of woman’s frailty and sinful passion. Thus the young and pure would be taught to look 
at her, with the scarlet letter flaming on her breast,—at her, the child of honorable parents,—at 
her, the mother of a babe, that would hereafter be a woman,—at her, who had once been 
innocent,—as the figure, the body, the reality of sin. And over her grave, the infamy that she must 
25 
carry thither would be her only monument. 
It may seem marvellous, that, with the world before her,—kept by no restrictive clause of her 
condemnation within the limits of the Puritan settlement, so remote and so obscure,—free to 
return to her birthplace, or to any other European land, and there hide her character and identity 
under a new exterior, as completely as if emerging into another state of being, and having also 
30 
the passes of the dark, inscrutable forest open to her, where the wildness of her nature might 
assimilate itself with a people whose customs and life were alien from the law that had 
condemned her, it may seem marvellous, that this woman should still call that place her home, 
where, and where only, she must needs be the type of shame. But there is a fatality, a feeling so 
irresistible and inevitable that it has the force of doom, which almost invariably compels human 
35 
beings to linger around and haunt, ghost-like, the spot where some great and marked event has 
given the color to their lifetime; and still the more irresistibly, the darker the tinge that saddens 
it. Her sin, her ignominy, were the roots which she had struck into the soil. It was as if a new 


## PDF page 152

152 
 
birth, with stronger assimilations than the first, had converted the forest-land, still so uncongenial 
to every other pilgrim and wanderer, into Hester Prynne’s wild and dreary, but life-long home. 
40 
All other scenes of earth—even that village of rural England, where happy infancy and stainless 
maidenhood seemed yet to be in her mother’s keeping, like garments put off long ago—were 
foreign to her, in comparison. The chain that bound her here was of iron links, and galling to her 
inmost soul, but never could be broken. 
It might be, too,—doubtless it was so, although she hid the secret from herself, and grew pale 
45 
whenever it struggled out of her heart, like a serpent from its hole,—it might be that another 
feeling kept her within the scene and pathway that had been so fatal. There dwelt, there trode the 
feet of one with whom she deemed herself connected in a union, that, unrecognized on earth, 
would bring them together before the bar of final judgment, and make that their marriage-altar, 
for a joint futurity of endless retribution. Over and over again, the tempter of souls had thrust this 
50 
idea upon Hester’s contemplation, and laughed at the passionate and desperate joy with which 
she seized, and then strove to cast it from her. She barely looked the idea in the face, and hastened 
to bar it in its dungeon. What she compelled herself to believe,—what, finally, she reasoned upon, 
as her motive for continuing a resident of New England,—was half a truth, and half a self-
delusion. Here, she said to herself, had been the scene of her guilt, and here should be the scene 
55 
of her earthly punishment; and so, perchance, the torture of her daily shame would at length purge 
her soul, and work out another purity than that which she had lost; more saint-like, because the 
result of martyrdom.
 
 
 
 
 
 
 
 
 
 


## PDF page 153

153 
 
The Human Stain (2000), Philip ROTH 
 
Philip Roth is an American of second-generation Jewish parentage whose depiction of 
contemporary Jewish life has caused much controversy. The Human Stain concludes his 
trilogy on post-war America, following American Pastoral (1997) and I Married a 
Communist (1998). It is set in the 1990s, when race, class and gender moralities and 
ideologies are in conflict. The plot revolves around Coleman Silk’s secret: no one knows 
that the Jewish Athena College professor is a black man who passes as white. 
Philip Roth (1933-2018) 
Coleman was one of a handful of Jews on the Athena faculty when he was hired and perhaps 
among the first of the Jews permitted to teach in a classics department anywhere in America; a 
few years earlier, Athena’s solitary Jew had been E. I. Lonoff, the all-but-forgotten short story 
writer whom, back when I was myself a newly published apprentice in trouble and eagerly 
seeking the validation of a master, I had once paid a memorable visit to here. Through the 
5 
eighties and into the nineties, Coleman was also the first and only Jew ever to serve at Athena 
as dean of faculty; then, in 1995 after retiring as dean in order to round out his career back in 
the classroom, he resumed teaching two of his courses under the aegis of the combined 
languages and literature program that had absorbed the Classics Department and that was run 
by Professor Delphine Roux. As dean, and with the full support of an ambitious new president, 
10 
Coleman had taken an antiquated, backwater, Sleepy Hollowish college and, not without 
steamrolling, put an end to the place as a gentlemen’s farm by aggressively encouraging the 
deadwood among the faculty’s old guard to seek early retirement, recruiting ambitious young 
assistant professors, and revolutionizing the curriculum. It’s almost a certainty that had he 
retired, without incident, in his own good time, there would have been the festschrift, there 
15 
would have been the institution of the Coleman Silk Lecture Series, there would have been a 
classical studies chair established in his name, and perhaps—given his importance to the 
twentieth-century revitalization of the place—the humanities building or even North Hall, the 
college’s landmark, would have been renamed in his honor after his death. In the small 
academic world where he had lived the bulk of his life, he would have long ceased to be resented 
20 
or controversial or even feared, and, instead, officially glorified forever. 
It was about midway into his second semester back as a full-time professor that Coleman spoke 
the self-incriminating word that would cause him voluntarily to sever all ties to the college—
the single self-incriminating word of the many millions spoken aloud in his years of teaching 
and administering at Athena, and the word that, as Coleman understood things, directly led to 
25 
his wife’s death. 
The class consisted of fourteen students. Coleman had taken attendance at the beginning of the 
first several lectures so as to learn their names. As there were still two names that failed to elicit 
a response by the fifth week into the semester, Coleman, in the sixth week, opened the session 
by asking, “Does anyone know these people? Do they exist or are they spooks?” 
30 
Later that day he was astonished to be called in by his successor, the new dean of faculty, to 
address the charge of racism brought against him by the two missing students, who turned out 
to be black, and who, though absent, had quickly learned of the locution in which he’d publicly 
raised the question of their absence. Coleman told the dean, “I was referring to their possibly 
ectoplasmic character. Isn’t that obvious? These two students had not attended a single class. 
35 
That’s all I knew about them. I was using the word in its customary and primary meaning: 
‘spook’ as a specter or a ghost. I had no idea what color these two students might be. I had 


## PDF page 154

154 
 
known perhaps fifty years ago but had wholly forgotten that ‘spooks’ is an invidious term 
sometimes applied to blacks. Otherwise, since I am totally meticulous regarding student 
sensibilities, I would never have used that word. Consider the context: Do they exist or are they 
40 
spooks? The charge of racism is spurious. It is preposterous. My colleagues know it is 
preposterous and my students know it is preposterous. The issue, the only issue, is the 
nonattendance of these two students and their flagrant and inexcusable neglect of work. What’s 
galling is that the charge is not just false it is spectacularly false.” Having said altogether enough 
in his defense, considering the matter closed, he left for home.
45 
 
 
 
 
 


## PDF page 155

155 
 
No Country for Old Men (2005), by Cormac McCarthy 
Cormac McCarthy (1933-2023) was an American author who wrote twelve novels, two 
plays, five screenplays, and three short stories and is considered one of the greatest 
American novelists of the past fifty years. Among his main features are his contemporary 
Southern Gothic style, along with his unusually stark writing style, which often strips the 
text of punctuation and attribution. In this opening passage from his 2005 novel No 
5 
Country for Old Men, we’re introduced to two of the three main characters: the son-to-be-
retired Sheriff Bell and the unstoppable killer Anton Chigurh. 
 
 
10 
I sent one boy to the gaschamber at Huntsville. One and only one. My arrest and my testimony. 
I went up there and visited with him two or three times. Three times. The last time was the day 
of his execution. I didnt have to go but I did. I sure didnt want to. He’d killed a fourteen year 
old girl and I can tell you right now I never did have no great desire to visit with him let alone 
go to his execution but I done it. The papers said it was a crime of passion and he told me there 
5 
wasnt no passion to it. He’d been datin this girl, young as she was. He was nineteen. And he 
told me that he had been plannin to kill somebody for about as long as he could remember. Said 
that if they turned him out he’d do it again. Said he knew he was goin to hell. Told it to me out 
of his own mouth. I dont know what to make of that. I surely dont. I thought I’d never seen a 
person like that and it got me to wonderin if maybe he was some new kind. I watched them 
10 
strap him into the seat and shut the door. He might of looked a bit nervous about it but that was 
about all. I really believe that he knew he was goin to be in hell in fifteen minutes. I believe 
that. And I’ve thought about that a lot. He was not hard to talk to. Called me Sheriff. But I didnt 
know what to say to him. What do you say to a man that by his own admission has no soul? 
Why would you say anything? I’ve thought about it a good deal. But he wasnt nothin compared 
15 
to what was comin down the pike. 
They say the eyes are the windows to the soul. I dont know what them eyes was the windows 
to and I guess I’d as soon not know. But there is another view of the world out there and other 
eyes to see it and that’s where this is goin. It has done brought me to a place in my life I would 
not of thought I’d of come to. Somewhere out there is a true and living prophet of destruction 
20 
and I dont want to confront him. I know he’s real. I have seen his work. I walked in front of 
those eyes once. I wont do it again. I wont push my chips forward and stand up and go out to 
meet him. It aint just bein older. I wish that it was. I cant say that it’s even what you are willin 
to do. Because I always knew that you had to be willin to die to even do this job. That was 
always true. Not to sound glorious about it or nothin but you do. If you aint they’ll know it. 
25 
They’ll see it in a heartbeat. I think it is more like what you are willin to become. And I think a 
man would have to put his soul at hazard. And I wont do that. I think now that maybe I never 
would. 
The deputy left Chigurh standing in the corner of the office with his hands cuffed behind him 
while he sat in the swivelchair and took off his hat and put his feet up and called Lamar on the 
30 
mobile. 
Just walked in the door. Sheriff he had some sort of thing on him like one of them oxygen tanks 
for emphysema or whatever. Then he had a hose that run down the inside of his sleeve and went 


## PDF page 156

156 
 
to one of them stunguns like they use at the slaughterhouse. Yessir. Well that’s what it looks 
like. You can see it when you get in. Yessir. I got it covered. Yessir. 
35 
When he stood up out of the chair he swung the keys off his belt and opened the locked desk 
drawer to get the keys to the jail. He was slightly bent over when Chigurh squatted and scooted 
his manacled hands beneath him to the back of his knees. In the same motion he sat and rocked 
backward and passed the chain under his feet and then stood instantly and effortlessly. If it 
looked like a thing he’d practiced many times it was. He dropped his cuffed hands over the 
40 
deputy’s head and leaped into the air and slammed both knees against the back of the deputy’s 
neck and hauled back on the chain. 
They went to the floor. The deputy was trying to get his hands inside the chain but he could not. 
Chigurh lay there pulling back on the bracelets with his knees between his arms and his face 
averted. The deputy was flailing wildly and he’d begun to walk sideways over the floor in a 
45 
circle, kicking over the wastebasket, kicking the chair across the room. He kicked shut the door 
and he wrapped the throwrug in a wad about them. He was gurgling and bleeding from the 
mouth. He was strangling on his own blood. Chigurh only hauled the harder. The nickelplated 
cuffs bit to the bone. The deputy’s right carotid artery burst and a jet of blood shot across the 
room and hit the wall and ran down it. The deputy’s legs slowed and then stopped. He lay 
50 
jerking. Then he stopped moving altogether. Chigurh lay breathing quietly, holding him. When 
he got up he took the keys from the deputy’s belt and released himself and put the deputy’s 
revolver in the waistband of his trousers and went into the bathroom. 
He ran cold water over his wrists until they stopped bleeding and he tore strips from a handtowel 
with his teeth and wrapped his wrists and went back into the office. He sat on the desk and 
55 
fastened the toweling with tape from a dispenser, studying the dead man gaping up from the 
floor. When he was done he got the deputy’s wallet out of his pocket and took the money and 
put it in the pocket of his shirt and dropped the wallet to the floor. Then he picked up his airtank 
and the stungun and walked out the door and got into the deputy’s car and started the engine 
and backed around and pulled out and headed up the road. 
60 
On the interstate he picked out a late model Ford sedan with a single driver and turned on the 
lights and hit the siren briefly. The car pulled onto the shoulder. Chigurh pulled in behind him 
and shut off the engine and slung the tank across his shoulder and stepped out. The man was 
watching him in the rearview mirror as he walked up. 
What’s the problem, officer? he said. 
65 
Sir would you mind stepping out of the vehicle? 
The man opened the door and stepped out. What’s this about? he said. 
Would you step away from the vehicle please. 
The man stepped away from the vehicle. Chigurh could see the doubt come into his eyes at this 
bloodstained figure before him but it came too late. He placed his hand on the man’s head like 
70 
a faith healer. The pneumatic hiss and click of the plunger sounded like a door closing. The man 
slid soundlessly to the ground, a round hole in his forehead from which the blood bubbled and 
ran down into his eyes carrying with it his slowly uncoupling world visible to see. Chigurh 
wiped his hand with his handkerchief. I just didnt want you to get blood on the car, he said.
 


## PDF page 157

157 
 
Bibliography: 
 
Angelou, Maya. “Graduation.” I Know Why the Caged Bird Sings, 1969. Penguin Readers Edition, 
Pearson Education Limited, 2008, pp. 64–69. 
Archie, Ayana. “Protests against ICE Have Continued in LA into the Week. Here’s What to Know.” 
NPR, 10 June 2025. 
Bettelheim, Bruno. “The Holocaust—One Generation After.” Surviving, and Other Essays, Knopf, 
1979, pp. 91–95. 
Brady-Syfers, Judy (as Judy Syfers). “Why I Want a Wife.” The Ladder, vol. 9, June–July 1971, pp. 
15–16. 
Brontë, Emily. Wuthering Heights. 1847. Thomas Cautley Newby. 
Bulbulia, Suleiman. “The English Turned Barbados into a Slave Society. Now, after 396 Years, 
We’re Free.” The Guardian, 29 Nov. 2021. 
Bush, George W. “Address on the U.S. Response to the Attacks on September 11.” 22 Sept. 2001, 
speech. 
Clinton, Bill. “Remarks at the Democratic National Convention.” 29 Aug. 1996, speech. 
Conrad, Joseph. Heart of Darkness. Youth and Two Other Stories, Messrs. W. Blackwood & Sons, 
1902. 
Fulwiler, Toby and Hayakawa, Alan R. Pocket Reference for Writers, 1st Ed., Prentice Hall, 2001. 
Gitlin, Tod. “The Renaissance of Anti-Intellectualism.” Chronicle of Higher Education, vol. 47, no. 
15, 8 Dec. 2000. 
Goldberg, Michelle. “They Saw Their Neighbors Taken Away by ICE. Then They Made a Plan.” 
The New York Times, 30 July 2025. 
Gould, Stephen Jay. “Racism and Recapitulation.” 1977. In The Lexington Reader. Lynn Z. Bloom 
(ed). Lexington: Heath, 1987, pp. 776–780. 
Harris, Marvin. “How Our Skins Get Their Color.” Our Kind: Who We Are, Where We Came from, 
Where We Are Going, Harper & Row, 1989, pp. 112–14. 
Hawthorne, Nathaniel. The Scarlet Letter. 1850. James R. Osgood and Company, 1878. 
Heath, Allister. “We Need Real Capitalism—Not Stealth Foreign Nationalisation.” The Telegraph, 
12 Sept. 2019. 
Houellebecq, Michel. “Donald Trump Is a Good President: One Foreigner’s Perspective.” 
Translated by John Cullen, Harper’s Magazine, Jan. 2019. 
Jackson, Mitchell S. “Twelve Minutes and a Life: Ahmaud Arbery Went Out for a Jog and Was 
Gunned Down in the Street.” Runner’s World, 18 June 2020. 
Jaffer, Jameel. “How the US Justifies Drone Strikes: Targeted Killing, Secrecy and the Law.” The 
Guardian, 15 Nov. 2016. 
Kaczynski, Andrew, and Steve Contorno. “Fierce Backlash within GOP after Tucker Carlson Gives 
White Nationalist Nick Fuentes a Platform.” CNN, 6 Nov. 2025. 
King, Martin Luther, Jr. “I Have a Dream.” 28 Aug. 1963. The Resourceful Writer, Harcourt Brace 
Jovanovich, 1987, pp. 521–527. 
———. “Three Types of Resistance to Oppression.” Stride toward Freedom: The Montgomery 
Story, Harper & Bros., 1958. 


## PDF page 158

158 
 
Kotkin, Joel. “ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor.” Los 
Angeles Times, 14 July 2025. 
Lewis, Matt K. “Some Trumpists Object to MAGA’s White Power Element. Why Now?” Los 
Angeles Times, 7 Nov. 2025. 
McCarthy, Cormac. No Country for Old Men. Alfred A. Knopf, 2005. 
McEwan, Ian. Atonement. Jonathan Cape, 2001. 
Maguire, Scarlett. “Young Women Are Radicalising: Britain’s Young Women Are Sad, Alienated 
and Increasingly Left-wing.” The New Statesman, 5 Jan. 2026. 
O’Flynn, Patrick. “Labour Needs Its Own Answer to the Channel Crisis.” The Spectator, 28 Nov. 
2021. 
O’Grady, Sean. “This Is the Real Reason Priti Patel Has Been Barred from France.” The 
Independent, 26 Nov. 2021. 
Obama, Barack. “Speech on Health Care Reform.” 15 Mar. 2010, speech. 
PBS News. “Tucker Carlson’s Interview with Antisemite Nick Fuentes Exposes Rift among 
Republicans.” PBS NewsHour, 7 Nov. 2025. 
Rawnsley, Andrew. “Boris Johnson’s Phoney Posturing at the French Won’t Resolve the Migrant 
Crisis.” The Guardian, 28 Nov. 2021. 
Richards, Amelia, and Jennifer Baumgardner. “In Defense of Monica.” The Nation, 21 Dec. 1998. 
Ricketts, Peter. “The UK and France Must Mend Ties—Lives Depend on It.” The New Statesman, 
26 Nov. 2021. 
Roth, Philip. The Human Stain. Houghton Mifflin Harcourt, 2000. 
Stacey, Kiran, and Sammy Gecsoyler. “MPs across UK Parties Criticise Ministers over Cautious 
Stance on Venezuela Attack.” The Guardian, 5 Jan. 2026. 
Staples, Brent. “Just Walk on By: Black Men and Public Space.” Ms. Magazine, 1986. The Bedford 
Reader, St. Martin’s Press, 1989, pp. 159–62. 
Sullivan, Andrew. “Boris’s Blundering Brilliance.” New York Magazine, 6 Dec. 2019. 
Trump, Donald J. “Speech Declaring a National Emergency.” 15 Feb. 2019, speech. 
West, Lindy. “‘Clueless’ and ‘Saved by the Bell’ Are How We Got Trump.” The New York Times, 26 
Oct. 2019. 
Wright, Richard. “Groping toward That Invisible Light.” 1930. The Resourceful Writer, Harcourt 
Brace Jovanovich, 1987, pp. 225–35. 
Zamith, Rodrigo. The American Journalism Handbook – Concepts, Issues, and Skills, Libretexts 
Ed., University of Massachusetts Amherst, 2022. 


