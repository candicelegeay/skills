# A2FCP12 Week five video 1 PDF.pdf

## Contents
- PDF page 1: The Mechanics of Good Writing: / A2FCP12 – Week 5 (2 videos)
- PDF page 2: The Mechanics of Good Writing I: Paragraphs / The Special Case of Opening Paragraphs
- PDF page 3: The Mechanics of Good Writing I: Paragraphs / The Special Case of Opening Paragraphs
- PDF page 4: The Mechanics of Good Writing I: Paragraphs / Isaac (V.O.)
- PDF page 5: The Mechanics of Good Writing I: Paragraphs / ISAAC (V.O., Con’t)
- PDF page 6: The Mechanics of Good Writing I: Paragraphs / Closing Paragraphs
- PDF page 7: The Mechanics of Good Writing I: Paragraphs / Closing Paragraphs
- PDF page 8: The Mechanics of Good Writing I: Paragraphs / Closing Paragraphs
- PDF page 9: The Mechanics of Good Writing I: Paragraphs / Closing Paragraphs
- PDF page 10: The Mechanics of Good Writing II: Style Sheets & Citing Sources / A quick word on plagiarism…
- PDF page 11: The Mechanics of Good Writing II: Style Sheets & Citing Sources / Which ‘style sheet’?
- PDF page 12: The Mechanics of Good Writing II: Style Sheets & Citing Sources / The ‘Parenthetical Notation’ Option:
- PDF page 13: The Mechanics of Good Writing II: Style Sheets & Citing Sources / The ‘Parenthetical Notation’ Option:
- PDF page 14: The Mechanics of Good Writing II: Style Sheets & Citing Sources / The ‘Parenthetical Notation’ Option:
- PDF page 15: The Mechanics of Good Writing II: Style Sheets & Citing Sources / The ‘Parenthetical Notation’ Option:
- PDF page 16: The Mechanics of Good Writing II: Style Sheets & Citing Sources / The ‘Parenthetical Notation’ Option:
- PDF page 17: The Mechanics of Good Writing II: Style Sheets & Citing Sources / The ‘Parenthetical Notation’ Option:
- PDF page 18: The Mechanics of Good Writing II: Style Sheets & Citing Sources / Chicago / Turabian Notes Style (no in-text citations):
- PDF page 19: The Mechanics of Good Writing II: Style Sheets & Citing Sources / APA In-Text Citations:                               (Note the different u

## PDF page 1

The Mechanics of Good Writing:
A2FCP12 – Week 5 (2 videos)
1. Finish Discussion of ‘Paragraphs’ (Opening and Closing Paragraphs)
2. Style Sheets & Citing Sources
3. Style, Syntax and Sentence Structure
4. Common Mistakes among Non-Native Writers


## PDF page 2

The Mechanics of Good Writing I: Paragraphs
The Special Case of Opening Paragraphs
-Most writers write (or go back and rewrite) their opening paragraph last
-In journalism, which relies on the ‘inverted pyramid’ format, you can find the ‘5 W’s & the H’ in the opening 
paragraph
-Regardless of the type of writing, the opening paragraph should include some type of hook, a thesis 
statement and an indication of how you will prove that thesis statement.
-Try to avoid the French method of systematically giving an ‘open question’ for your thesis statement.
-Remember that the opening paragraph not only sets up your introduction (if it is not your entire introduction), 
but it sets the tone for the whole essay and lets your reader know what to expect.
Example of a hook:                    (cf. Michael Dorries, “Father’s Day”)
My father, a career army officer, was twenty-seven when he was killed and as a result, I can’t help but take war personally. 
Over the years his image has coalesced for me as an amalgam of familiar anecdotes: a dashing mixed-blood man from the 
Northwest who, improbably, could do the rhumba. A soldier who regularly had his quirkier qualities, indistinct, better 
remembered for his death – my grandmother still wears a gold star on her coat – than for his brief life. […]  
Possible thesis statement: Though British youth today may not seem to hold those who have 
devoted their life to the military and national defence in as high an esteem, there is evidence 
that they have developed other ways to honour those who have served the nation—both in 
traditional shows of support and in unexpected ways, including the use of social media. 


## PDF page 3

The Mechanics of Good Writing I: Paragraphs
The Special Case of Opening Paragraphs
-Remember to adapt your opening paragraph (form, tone, vocabulary) to your expected audience.
An (fun?) example from cinema: The Opening to Woody Allen’s Manhattan (1979)
Think of the opening to Woody Allen’s film Manhattan, in which a writer, in voice-over, repeatedly abandons 
and rewrites the opening line of his first paragraph on the borough of Manhattan:
EXT. / VARIOUS MANHATTAN SCENES — VARIOUS TIMES 
The words "United Artists, a Transamerica Company," appear in white over a silent 
black screen, cutting almost immediately and suddenly to a series of shots of the 
New York City skyline. As "RHAPSODY IN BLUE" IS HEARD over the scenery, the images 
flash on and off: the skyline at dawn, the sun silhouetting the Empire State 
Building, jutting skyscrapers, parking lots, crowded streets, 
the Brooklyn Bridge, neon lights advertising Broadway, Coca-Cola, 
various hotels, the snow-covered and lamp-lit streets of Park 
Avenue and Central Park, the garment district, an excited 
demonstration downtown, etc.
As the MUSIC SWELLS over the Manhattan scenery, the voice of 
author Isaac Davis is heard, as if reading aloud from his writings.


## PDF page 4

The Mechanics of Good Writing I: Paragraphs
Isaac (V.O.)
"Chapter One. He adored New York City. He 
idolized it all out of proportion." 
Uh, no, make that: "He—he . . . romanticized 
it all out of proportion. Now ... to him ... 
no matter what the season was, this was still 
a town that existed in black and white and 
pulsated to the great tunes of George Gershwin." 
Ahhh, now let me start this over. "Chapter One. 
He was too romantic about Manhattan as he was 
about everything else. He thrived on the hustle
and bustle of the crowds and the traffic." 
(Montage continues: sophisticated Manhattanites, piles of garbage, children in a 
private school, joggers in the park, etc. , as the "RHAPSODY IN BLUE” SCORE 
CONTINUES very softly in the background.
Isaac (V.O., Con’t)
"To him, New York meant beautiful women and 
street-smart guys who seemed to know all the 
angles." Nah, no. Corny, too corny for my taste 
(Clearing his throat)


## PDF page 5

The Mechanics of Good Writing I: Paragraphs
ISAAC (V.O., Con’t)
I mean, let me try and make it more profound. 
"Chapter One. He adored New York City. To him, 
it was a metaphor for the decay of contemporary 
culture. The same lack of individual integrity 
to cause so many people to take the easy way out
was rapidly turning the town of his dreams into—" 
No, it's gonna be too preachy. I mean, you know, 
let's face it, I want to sell some books here.
 
 
"Chapter One. He adored New York City, although 
to him, it was a metaphor for the decay of 
contemporary culture. How hard it was to exist in 
a society desensitized by drugs, loud music, 
television, crime, garbage." Too angry. I don't want 
to be angry. "Chapter One. He was as ... tough and 
romantic as the city he loved. Behind his black-rimmed 
glasses was the coiled sexual power of a jungle cat." 
I love this. "New York was his town. And it always 
would be.“
“RHAPSODY IN BLUE” RISES IN CRESCENDO to fireworks over the 
Manhattan skyline. 


## PDF page 6

The Mechanics of Good Writing I: Paragraphs
Closing Paragraphs
-Concluding is just as difficult and just as important as your opening
-Just as your opening had a ‘hook’, your closing usually includes a clever ‘kicker’ or ‘curtain line’
-More importantly, you need to tie all of your main points together, reminding the reader of what you have 
proved or argued, while giving the impression of closure. (Avoid starting new analysis you cannot finish).
-Many arguments also reserve or include their recommendation in the final paragraph.
Most common ways of organizing your final paragraph(s):
-summarizing your main points
Example: David Brooks’s final paragraph in “Bobos in Paradise”
Marx told us that classes inevitably conflict, but sometimes they just blur. The values of the bourgeois 
mainstream culture and the values of the 1960s counterculture have merged. That culture war has ended at least 
within the educated class. In its place that class has created a third culture which is reconciliation between the 
previous two. The educated elites didn’t set out to create this reconciliation. It is 
the product of millions of individual efforts to have it both ways. But it is now the 
dominant tone of our age. In the resolution between the culture and the counterculture, 
it is impossible to tell who has co–opted whom because in reality the bohemians and 
the bourgeois co–opted each other. They emerge from this process as bourgeois 
bohemians or Bobos.


## PDF page 7

The Mechanics of Good Writing I: Paragraphs
Closing Paragraphs
-provide a recommendation:
Example: Cathy Young in “Keeping Women Weak”
We need a Third Wave feminism that rejects the excesses of the gender fanatics and 
sentimental traditionalism of the Phyllis Schlaflys, one that does not seek special 
protection for women and does not view us as too socially disadvantaged to take care of 
ourselves. Because in the path that feminism has taken in the last few years, we are 
allowing ourselves to be treated as frail, helpless little things by our would–be 
liberators. 


## PDF page 8

The Mechanics of Good Writing I: Paragraphs
Closing Paragraphs
-tying the last paragraph to the first paragraph
Example: Barbara Kingsolver’s “How Mr. Dewey Decimal Saved My Life”
The following is the Opening Paragraph :
A librarian named Miss Truman Richey snatched me from the jaws of ruin and it’s too 
late now to thank her. I’m not the first person to notice that we rarely get around to 
thanking those who’ve helped us most. Salvation is such a heady thing the temptation is 
to dance gasping on the shore, shouting that we’re still alive till our forgotten savior has 
long since gone under. Or else sit quietly, sideswiped and embarrassed, mumbling that 
we really did know pretty much how to swim. But now that I see the wreck that could 
have been, without Miss Richey, I ‘m of a fearsome mind to throw my arms around 
every living librarian who crosses my path, on behalf of the souls they never knew they 
saved.
The last paragraph, after summarizing the main points, ended in this line:
My thanks to Doris Lessing and William Saroyan and Miss Truman 
Richey. And every other wise teacher who may ever save a surly 
soul likes mine.


## PDF page 9

The Mechanics of Good Writing I: Paragraphs
Closing Paragraphs
-tying the last paragraph to the first paragraph
We also saw this in Judith Brady-Syfer’s “Why I Want a Wife” too:
Opening line:
I belong to that classification of people known as wives. I am A Wife. And, not altogether incidentally, I am a 
mother. Not too long ago a male friend of mine appeared on the scene fresh from a recent divorce. He had one 
child, who is, of course, with his ex-wife. He is looking for another wife. As I thought about him while I was 
ironing one evening, it suddenly occurred to me that I too, would like to have a wife. Why do I want a wife?
Then after main paragraphs on a Wife’s duties regarding child/husband-care, housework and physical duties, 
social duties and sexual duties, the essay ends on two ‘disclaimers’ and a reference back to the opening:
Closing lines:
If, by chance, I find another person more suitable as a wife than the wife I already have, I want the liberty to 
replace my present wife with another one. Naturally, I will expect a fresh, new life; my 
wife will take the children and be solely responsible for them so that I am left free. 
When I am through with school and have a job, I want my wife to quit working and 
remain at home so that my wife can more fully and completely take care of a wife’s 
duties. My God, who wouldn't want a wife?


## PDF page 10

The Mechanics of Good Writing II: Style Sheets & Citing Sources
A quick word on plagiarism…
-intellectual property (copyright, trademark, patent, etc.) has broader notion in academia
-no need to cite sources of established facts (e.g., Katherine Mansfield was born in New Zealand in 1888 and died 
in France in 1923. / Midnight Cowboy won the Oscar for Best Picture in 1970, even though it was X-rated.)
-there is of course tolerance for quoting one’s own work (This happens a lot in PhD work, from which many 
articles may have been derived).
-you do need to cite sources when you borrow anyone else’s ideas, even if you change the wording.
-penalties and consequences in undergraduate studies, even worse in graduate studies
-Rule of thumb: When in doubt, cite the source.
Related: Public Domain sources
-copyright protection usually expires 75 years after the death of the author, but you 
still need to cite the source in academic writing. 
-use of photos and illustrations have very specific rules to follow as well 
(e.g., a film poster before 1964 is in the free domain, a limited number 
screen captures from a film/TV show are usually permitted, written 
permission is required for many paintings and portraits held in galleries, etc.)


## PDF page 11

The Mechanics of Good Writing II: Style Sheets & Citing Sources
Which ‘style sheet’?
When writing, one of the first questions asked of one’s editor is usually which style sheet should be used (or if the 
publication has its own style sheet). This concerns many general aspects of writing (margins, font style and size, 
punctuation, etc.), but it also concerns how you cite sources.
‘Style Sheets’ regarding citing sources
•
APA (American Psychological Association) is used in Psychology and Sciences
•
MLA (Modern Language Association) style is used by the Humanities
•
Chicago/Turabian style is generally used by Business, History, and the Fine Arts
Other variations, all using a list of ‘References’ at the end
IEEE Style (The Institute for Electrical and Electronic Engineers)
-uses numbers in brackets [1] within the text [2]…
and then a numbers list of ‘References’ at the end’ (e.g., Wikipedia uses this!)
Harvard System (a variation of the MLA & Chicago system)
e.g., (Jones 1982) & a ‘Reference’ list at the end in alphabetical order by author’s name.
AMA Style (The American Medical Association)
-uses a raised number for each reference and then a numbered list of ‘References’ at the end
MHRA System (Medicine and Health Care Products Regulatory Agency)
-footnotes possible but mainly endnotes as full ‘References’ at the end


## PDF page 12

The Mechanics of Good Writing II: Style Sheets & Citing Sources
The ‘Parenthetical Notation’ Option:
The main style sheets (MLA, Chicago & APA) all offer the possibility of parenthetical notation within the body 
of the text, reserving footnotes for non-bibliographical information, development of ideas, translations, 
discussions, proposed related works, etc.
Quick samples:
MLA :
Within the text:
(Frank 834), or simply (34) if the author’s name is clearly mentioned.
In a Works Cited list at the end:
Frank, H. "Wolves, Dogs, Rearing and Reinforcement: Complex Interactions Underlying Species Differences in 
Training and Problem-Solving Performance." Behavior Genetics 41.6 (2011): 830-39. Print.
Chicago / Turabian:
Within the text:
(Frank, 2011; 831-32)
In a Bibliography at the end:
Frank, H. 2011. "Wolves, Dogs, Rearing and Reinforcement: Complex Interactions 
Underlying Species Differences in Training and Problem-Solving Performance."
Behavior Genetics 41 (6): 830-839.


## PDF page 13

The Mechanics of Good Writing II: Style Sheets & Citing Sources
The ‘Parenthetical Notation’ Option:
The main style sheets (MLA, Chicago & APA) all offer the possibility of parenthetical notation within the body 
of the text, reserving footnotes for non-bibliographical information, development of ideas, translations, 
discussions, proposed related works, etc.
Quick samples:
APA :
Within the text:
(Frank, 2011, p.834)
In a Bibliography at the end:
Frank, H. (2011). Wolves, Dogs, Rearing and Reinforcement: Complex Interactions Underlying Species 
Differences in Training and Problem-Solving Performance. Behavior Genetics, 41(6), 830-839.


## PDF page 14

The Mechanics of Good Writing II: Style Sheets & Citing Sources
The ‘Parenthetical Notation’ Option:
MLA In-Text Notation Samples
Material Type
In-text Citation
Author's name in text
Magny develops this argument (67-69).
Author's name in reference
This argument has been developed elsewhere (Magny 67-69).
Two authors' names in 
reference
The most notorious foreign lobby in Washington is the "Sugar 
Mafia" (Howe and Trott 134).
Quotation found in indirect or 
"secondhand" source
The philosopher Alain states that "admiration is not pleasure but a 
kind of attention. . ." (qtd. in Magny 66).


## PDF page 15

The Mechanics of Good Writing II: Style Sheets & Citing Sources
The ‘Parenthetical Notation’ Option:
MLA Works Cited Entries: With MLA style, you must include a Works Cited page at the end of your paper. A Works Cited 
page is an alphabetical listing of the resources cited in your paper. Below are some examples of MLA style 
citations. Note: Some instructors may require access dates for websites or other pieces of information.
Material Type
Works Cited
Book in print
Card, Claudia. The Atrocity Paradigm: A Theory of Evil. Oxford UP, 2005.
eBook
Gaither, Milton. Homeschool: An American History. Palgrave Macmillan, 
2017. SpringerLink, doi-org.pitt.idm.oclc.org/10.1057/978-1-349-95056-0.
An article in a print journal
Doggart, Julia. "Minding the Gap: Realizing Our Ideal Community Writing 
Assistance Program." The Community Literacy Journal, vol. 2, no. 1, 2007, 
pp. 71-80.
An article in an electronic journal Sherrard-Johnson, Cherene. "'A Plea for Color': Nella Larsen's Iconography 
of the Mulatta." American Literature, vol. 76, no. 4, 2004, pp. 833-869, doi: 
10.1215/00029831-76-4-833.
A encyclopedia entry
“Patanjali.” Benét’s Reader’s Encyclopedia, edited by Bruce Murphy, 4th 
ed., HarperCollins Publishers, 1996, p. 782.
NB: For digitial 
publications, putting the 
DOI (Digital Object 
Identification) number is 
recommended.


## PDF page 16

The Mechanics of Good Writing II: Style Sheets & Citing Sources
The ‘Parenthetical Notation’ Option:
MLA Works Cited Entries:
A government publication
United States, Federal Maritime Commission. Hawaiian Trade Study: An 
Economic Analysis. Government Printing Office, 1978.
An interview you conducted
Brandt, Deborah. Personal interview. 28 May 2008.
(Note: List the interview under the name of the interviewee)
A film/DVD
It’s a Wonderful Life. Dir. Frank Capra. Perf. James Stewart, Donna Reed, 
Lionel Barrymore, and Thomas Mitchell. RKO, 1946.
Note: Depending on the focus of your work, you may start with the 
director’s name, or the screenwriter, or the producer, etc.
A Page on a Website with no 
author
"Stunning Lakeside View on Lake Erie." VisitPA, Commonwealth of 
Pennsylvania, 7 June 2018, www.visitpa.com/article/stunning-lakeside-
views-lake-erie.
A Page on a Website with an 
author
Del Castillo, Inigo. "How Not to Kill Your Houseplants, According to 
Botanists." Apartment Therapy, 29 Jan. 2020, 
www.apartmenttherapy.com/houseplant-tips-botanists-36710191.
Artwork - from website
Sherald, Amy. Former First Lady, Michelle Obama. 2018. National Portrait 
Gallery, npg.si.edu/object/npg_NPG.2018.15.


## PDF page 17

The Mechanics of Good Writing II: Style Sheets & Citing Sources
The ‘Parenthetical Notation’ Option:
Chicago / Turabian In-Text Citations: The Author-Date Style
The author-date style has long been used by those in the physical, natural, and social sciences. In this system, sources are 
briefly cited in the text, usually in parentheses, by author’s last name and date of publication. The short citations are 
amplified in a bibliography, where full bibliographic information is provided.
Author/Date Style
In-text Citation
Bibliography
A book
(Pollan 2006, 99–100)
Pollan, Michael. 2006. The Omnivore’s Dilemma: 
A Natural History of Four Meals. New York: Penguin.
An article in a print 
journal
(Weinstein 2009, 440)
Weinstein, Joshua I. 2009. “The Market in Plato’s
Republic.” Classical Philology 104:439–58.
An article in an 
electronic journal
(Kossinets and Watts 2009, 411)
Kossinets, Gueorgi, and Duncan J. Watts. 2009. “Origins 
of Homophily in an Evolving Social Network.” American 
Journal of Sociology 115:405–50. Accessed February 28, 
2010. doi:10.1086/599247.
A website
(Google 2009)
Google. 2009. “Google Privacy Policy.” Last modified 
March 11. http://www.google.com/intl/en/
privacypolicy.html.


## PDF page 18

The Mechanics of Good Writing II: Style Sheets & Citing Sources
Chicago / Turabian Notes Style (no in-text citations):
Material Type
Notes/Bibliography Style
A book in print
Note Style: 1. Michael Pollan, The Omnivore's Dilemma: A Natural History of Four Meals (New York: Penguin, 
2006), 99–100.
Duplicate Note: 2. Pollan, Omnivore's Dilemma, 3.
Bibliography: Pollan, Michael. The Omnivore's Dilemma: A Natural History of Four Meals. New York: Penguin, 
2006.
An article in a print journal Note Style: 1. Joshua I. Weinstein, "The Market in Plato’s Republic," Classical Philology 104 (2009): 440.
Duplicate Note: 2. Weinstein, "Plato’s Republic," 452–53.
Bibliography: Weinstein, Joshua I. "The Market in Plato’s Republic." Classical Philology 104 (2009): 439–58.
An article in an electronic 
journal
Note Style: 1. Gueorgi Kossinets and Duncan J. Watts, “Origins of Homophily in an Evolving Social 
Network,” American Journal of Sociology 115 (2009): 411, accessed February 28, 2010, doi:10.1086/599247.
Duplicate Note: Kossinets and Watts, “Origins of Homophily,” 439.
Bibliography: Kossinets, Gueorgi, and Duncan J. Watts. “Origins of Homophily in an Evolving Social 
Network.” American Journal of Sociology 115 (2009): 405–50. Accessed February 28, 2010. 
doi:10.1086/599247.
A website
Note Style: 1.“Google Privacy Policy,” last modified March 11, 2009, 
http://www.google.com/intl/en/privacypolicy.html.
Duplicate Note: “Google Privacy Policy.”
Bibliography: Google. “Google Privacy Policy.” Last modified March 11, 2009. 
http://www.google.com/intl/en/privacypolicy.html.


## PDF page 19

The Mechanics of Good Writing II: Style Sheets & Citing Sources
APA In-Text Citations:                               (Note the different use of punctuation/capitalization for titles)
Material Type
In-text Citation
Bibliography
A book
(Sapolsky, 2017)
Sapolsky, R. M. (2017). Behave: The biology of humans at our best and worst. Penguin 
Books.
Chapter in 
an edited book
(Dillard, 2020)
Dillard, J. P. (2020). Currents in the study of persuasion. In M. B. Oliver, A. A. Raney, & J. 
Bryant (Eds.), Media effects: Advances in theory and research (4th ed., pp. 115–129). 
Routledge.
An article in a print 
journal
(Weinstein, 2009)
Weinstein, J. (2009). “The market in Plato’s Republic.” Classical Philology, 104(4), 439-
458.
An article in an 
electronic journal
(Grady et al., 2019)
Grady, J. S., Her, M., Moreno, G., Perez, C., & Yelinek, J. (2019). Emotions in storybooks: A 
comparison of storybooks that represent ethnic and racial groups in the United 
States. Psychology of Popular Media Culture, 8(3), 207–
217. https://doi.org/10.1037/ppm0000185
A website
(Bologna, 2019)
Bologna, C. (2019, October 31). Why some people with anxiety love watching horror 
movies. HuffPost. https://www.huffpost.com/entry/anxiety-love-watching-horror-
movies_l_5d277587e4b02a5a5d57b59e


