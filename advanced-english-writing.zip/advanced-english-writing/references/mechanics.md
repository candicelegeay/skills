# A2FCP12 Lesson five video 2 common mistakes PDF.pdf

## Contents
- PDF page 1: The Mechanics of Good Writing:                     Lesson 5, Part 2 / 1. Finish Discussion of ‘Paragraphs’ (Opening and Closing Paragraphs)
- PDF page 2: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / A. Capitalization and Punctuation of Titles (yours, titles referre
- PDF page 3: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / B. Set Your Word Processor to English
- PDF page 4: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / B. Set Your Word Processor to English
- PDF page 5: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / D. Present Dialogue and Quotations Correctly
- PDF page 6: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / D. Present Dialogue and Quotations Correctly
- PDF page 7: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / D. Present Dialogue and Quotations Correctly
- PDF page 8: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / D. Present Dialogue and Quotations Correctly
- PDF page 9: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 10: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 11: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 12: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 13: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 14: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 15: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 16: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 17: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 18: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 19: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 20: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 21: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 22: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 23: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 24: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 25: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 26: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 27: The Mechanics of Good Writing III: Style, Syntax and Sentence Structure / E. Syntax and Sentence Structure
- PDF page 28: The Mechanics of Good Writing IV: Common Mistakes among Non-Native Writers / 30 Most Common Mistakes
- PDF page 29: The Mechanics of Good Writing IV: Common Mistakes among Non-Native Writers / 30 Most Common Mistakes
- PDF page 30: The Mechanics of Good Writing IV: Common Mistakes among Non-Native Writers / 30 Most Common Mistakes
- PDF page 31: That finishes Unit I! / Next Week: Online Midterm on all of Unit I

## PDF page 1

The Mechanics of Good Writing:                     Lesson 5, Part 2
1. Finish Discussion of ‘Paragraphs’ (Opening and Closing Paragraphs)
2. Style Sheets & Citing Sources
3. Style, Syntax and Sentence Structure
4. Common Mistakes among Non-Native Writers


## PDF page 2

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
A. Capitalization and Punctuation of Titles (yours, titles referred to anywhere in your text, etc.)
1. Underlining/Italicizing or Quotating Titles: 
Italicize (or underline) titles of larger, inclusive works, such as novels, books, collections, newspapers, magazines, 
films, albums, etc. 
Put titles of smaller works in quotes, such as short stories, poems, articles, songs, etc.
2. Capitalizing words of a title: 
Capitalize the first and last word and all other words except for articles, conjunctions and prepositions. 
(Capitalize subtitles in the same way)
“Just Walk on By: Black Men and Public Space” in Ms. Magazine
“Games at Twilight” by Anita Desai, in her collection Games at Twilight
“My Favorite Things” (from The Sound of Music) was sampled in “7 Rings” (from Thank You, Next)
Everything You Ever Wanted to Know about Sex but Were Afraid to Ask
“Tug of War: The Battle between The New York Times and The Washington Post to 
Publish the ‘Pentagon Papers’”
“’Misplaced Middles’ and ‘Displaced Pivots’: Structural Matters in Henry James’s 
The Wings of the Dove”


## PDF page 3

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
B. Set Your Word Processor to English
Nothing is more frustrating than an English text obviously written with a Word Processor set to another language, 
like French. 
-Setting it to English will make sure you use quotation marks (“ ”) and not French chevrons (« »). It will also 
make sure there are no superfluous spaces before colons (:), semi-colons (;) question marks (?) or exclamation 
points (!).
-Use your spell-check software, with the right language setting, before turning in your work.
-Make sure the type of English used is consistent (UK, US, etc.)
C. Only Divide Words at the End of the Line When Absolutely Necessary
-It is hard to know where to divide a word at the end of the line. You can check where English words can be cut by 
using an English dictionary (in which words are listed with a dot between paragraphs)
-Avoid leaving a single syllable of the divided word dangling at the end or the beginning of a line:
… which is why her decision was absolute-
ly not what I expected. 
-In most cases, this can be avoided by using the ‘dual flush’ function for margins.  
Check with your style sheet to see if flush or irregular right margins 
are preferred.


## PDF page 4

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
B. Set Your Word Processor to English
Nothing is more frustrating than an English text obviously written with a Word Processor set to another language, 
like French. 
-Setting it to English will make sure you use quotation marks (“ ”) and not French chevrons (« »). It will also 
make sure there are no superfluous spaces before colons (:), semi-colons (;) question marks (?) or exclamation 
points (!).
-Use your spell-check software, with the right language setting, before turning in your work.
-Make sure the type of English used is consistent (UK, US, etc.)
C. Only Divide Words at the End of the Line When Absolutely Necessary
-It is hard to know where to divide a word at the end of the line. You can check where English words can be cut by 
using an English dictionary (in which words are listed with a dot between paragraphs)
-Avoid leaving a single syllable of the divided word dangling at the end or the beginning of a line:
… which is why her decision was absolute-
ly not what I expected. 
-In most cases, this can be avoided by using the ‘dual flush’ function for margins.  
Check with your style sheet to see if flush or irregular right margins 
are preferred.


## PDF page 5

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
D. Present Dialogue and Quotations Correctly
In both narrative and essay format, use a comma to open or close a quotation.
Carol whispered into the phone, “I think there’s someone in the house.”
“Of all the gin-joints in all the towns in all the world, she walks into mine,” muttered Rick.
As William Congreve famously said, “Music hath charms that calms the savage breast.”
“If I had known how harsh the censorship was going to be, I probably would not have made the film,” Kubrick 
lamented in a 1973 interview.
Rarely, a colon can be used if set up correctly:
No one expected him to respond the way he did: “I’m not sorry, and I did it on purpose.”
Note: 
In essay/research format, you can have multiuple quotations from different people in the same 
paragraph, as the paragraph is centered on a main point/idea.
In narrative format, you change paragraphs each time a different character speaks, but you 
still use markers and commas when attributing that dialogue.


## PDF page 6

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
D. Present Dialogue and Quotations Correctly
In both narrative and essay format, use a comma to open or close a quotation.
Carol whispered into the phone, “I think there’s someone in the house.”
“Of all the gin-joints in all the towns in all the world, she walks into mine,” muttered Rick.
As William Congreve famously said, “Music hath charms that calms the savage breast.”
“If I had known how harsh the censorship was going to be, I probably would not have made the film,” Kubrick 
lamented in a 1973 interview.
Rarely, a colon can be used if set up correctly:
No one expected him to respond the way he did: “I’m not sorry, and I did it on purpose.”
Note: 
In essay/research format, you can have multiple quotations from different people in the same 
paragraph, as the paragraph is centered on a main point/idea.
In narrative format, you change paragraphs each time a different character speaks, but you 
still use markers and commas when attributing that dialogue.


## PDF page 7

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
D. Present Dialogue and Quotations Correctly
Correct (narrative format):
“George, what’s the matter? You look like you’ve seen a ghost,” Miriam wondered out loud.
George hesitated and then muttered, “I think I have seen a ghost. Didn’t you feel a sudden draft and see the lights 
flicker? It gave me the chills.”
“You two really need to loosen up,” Susan chimed in. “I opened the window ten minutes ago, and Miriam just 
leaned back against the light switch!” 
Incorrect:
Miriam: “George, what’s the matter? You look like you’ve seen a ghost.”
George: “I think I have seen a ghost. Didn’t you feel a sudden draft and see the lights flicker? It gave me the  
chills.”
Susan: “You two really need to loosen up. I opened the window ten minutes ago, and Miriam just leaned back 
against the light switch!”
Incorrect:
—“George, what’s the matter? You look like you’ve seen a ghost.”
—“I think I have seen a ghost. Didn’t you feel a sudden draft?”


## PDF page 8

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
D. Present Dialogue and Quotations Correctly
Correct (narrative format):
“George, what’s the matter? You look like you’ve seen a ghost,” Miriam wondered out loud.
George hesitated and then muttered, “I think I have seen a ghost. Didn’t you feel a sudden draft and see the lights 
flicker? It gave me the chills.”
“You two really need to loosen up,” Susan chimed in. “I opened the window ten minutes ago, and Miriam just 
leaned back against the light switch!” 
Incorrect:
Miriam: “George, what’s the matter? You look like you’ve seen a ghost.”
George: “I think I have seen a ghost. Didn’t you feel a sudden draft and see the lights flicker? It gave me the  
chills.”
Susan: “You two really need to loosen up. I opened the window ten minutes ago, and Miriam just leaned back 
against the light switch!”
Incorrect:
—“George, what’s the matter? You look like you’ve seen a ghost.”
—“I think I have seen a ghost. Didn’t you feel a sudden draft?”


## PDF page 9

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
1. Run-On Sentences: Learn to connect independent phrases correctly, not just with a comma.
In English, divide independent clauses properly with…
a semi-colon (;) 
The term was not coined by Henry James; it was his brother William who first used the expression.
with a comma & a conjunction (,and / ,but / ,or)
Griswold was made executor of Poe’s literary heritage, but the two writers had been bitter rivals for years.
with a relative phrase (,which was… / ,who had…)
In 1813 she wrote Pride and Prejudice, which was published anonymously. 
with a dash (—), often for an aside or change of tone
The new student sat next to the class bully—(which was) not a good idea!
with a period, starting a new sentence.
The math teacher had one favorite target. It was me.
We saw our new English teacher, he was old and looked really boring, in the end he 
was a crazy clown, maybe even my favorite teacher.
Defoe was known for his satire, this had landed him on the pillory more than once,
the people threw flowers and recited him rather than hurl insults or rotten vegetables, it 
only infuriated the authorities even more. 


## PDF page 10

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
1. Run-On Sentences: Learn to connect independent phrases correctly, not just with a comma.
In English, divide independent clauses properly with…
a semi-colon (;) 
The term was not coined by Henry James; it was his brother William who first used the expression.
with a comma & a conjunction (,and / ,but / ,or)
Griswold was made executor of Poe’s literary heritage, but the two writers had been bitter rivals for years.
with a relative phrase (,which was… / ,who had…)
In 1813 she wrote Pride and Prejudice, which was published anonymously. 
with a dash (—), often for an aside or change of tone
The new student sat next to the class bully—(which was) not a good idea!
with a period, starting a new sentence.
The math teacher had one favorite target. It was me.
We saw our new English teacher, he was old and looked really boring, in the end he 
was a crazy clown, maybe even my favorite teacher.
Defoe was known for his satire, this had landed him on the pillory more than once,
the people threw flowers and recited him rather than hurl insults or rotten vegetables, it 
only infuriated the authorities even more. 


## PDF page 11

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
1. Run-On Sentences: Learn to connect independent phrases correctly, not just with a comma.
In English, divide independent clauses properly with…
a semi-colon (;) 
The term was not coined by Henry James; it was his brother William who first used the expression.
with a comma & a conjunction (,and / ,but / ,or)
Griswold was made executor of Poe’s literary heritage, but the two writers had been bitter rivals for years.
with a relative phrase (,which was… / ,who had…)
In 1813 she wrote Pride and Prejudice, which was published anonymously. 
with a dash (—), often for an aside or change of tone
The new student sat next to the class bully—(which was) not a good idea!
with a period, starting a new sentence.
The math teacher had one favorite target. It was me.
We saw our new English teacher, he was old and looked really boring, in the end he 
was a crazy clown, maybe even my favorite teacher.
Defoe was known for his satire, this had landed him on the pillory more than once,
the people threw flowers and recited him rather than hurl insults or rotten vegetables, it 
only infuriated the authorities even more. 


## PDF page 12

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
1. Run-On Sentences: Learn to connect independent phrases correctly, not just with a comma.
In English, divide independent clauses properly with…
a semi-colon (;) 
The term was not coined by Henry James; it was his brother William who first used the expression.
with a comma & a conjunction (,and / ,but / ,or)
Griswold was made executor of Poe’s literary heritage, but the two writers had been bitter rivals for years.
with a relative phrase (,which was… / ,who had…)
In 1813 she wrote Pride and Prejudice, which was published anonymously. 
with a dash (—), often for an aside or change of tone
The new student sat next to the class bully—(which was) not a good idea!
with a period, starting a new sentence.
The math teacher had one favorite target. It was me.
We saw our new English teacher, who was old and looked really boring, but in the end he 
was a crazy clown—maybe even my favorite teacher.
Defoe was known for his satire, this had landed him on the pillory more than once,
the people threw flowers and recited him rather than hurl insults or rotten vegetables, it 
only infuriated the authorities even more. 


## PDF page 13

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
1. Run-On Sentences: Learn to connect independent phrases correctly, not just with a comma.
In English, divide independent clauses properly with…
a semi-colon (;) 
The term was not coined by Henry James; it was his brother William who first used the expression.
with a comma & a conjunction (,and / ,but / ,or)
Griswold was made executor of Poe’s literary heritage, but the two writers had been bitter rivals for years.
with a relative phrase (,which was… / ,who had…)
In 1813 she wrote Pride and Prejudice, which was published anonymously. 
with a dash (—), often for an aside or change of tone
The new student sat next to the class bully—(which was) not a good idea!
with a period, starting a new sentence.
The math teacher had one favorite target. It was me.
We saw our new English teacher, who was old and looked really boring, but in the end he 
was a crazy clown—maybe even my favorite teacher.
Defoe was known for his satire, which had landed him on the pillory more than once, though 
the people threw flowers and recited him rather than hurl insults or rotten vegetables—which
only infuriated the authorities even more. 


## PDF page 14

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
A completely unexpected turn of events.
Unbelievable. 
A best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put 
the modifiers afterwards, or put the modifiers before the noun.
It was popular with both critics and the public, rare these days.  
She was a young rebel, angry and bitter.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 15

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
Unbelievable. 
A best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, rare these days.  
She was a young rebel, angry and bitter.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 16

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
It was unbelievable to all those involved. 
A best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, rare these days.  
She was a young rebel, angry and bitter.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 17

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
It was unbelievable to all those involved. 
That first publication turned out to be a best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, rare these days.  
She was a young rebel, angry and bitter.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 18

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
It was unbelievable to all those involved. 
That first publication turned out to be a best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, rare these days.  
She was a young rebel, angry and bitter.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 19

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
It was unbelievable to all those involved. 
That first publication turned out to be a best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, which is rare these days.  
She was a young rebel, angry and bitter.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 20

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
It was unbelievable to all those involved. 
That first publication turned out to be a best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, which is rare these days.  
She was an angry and bitter young rebel.
Vonnegut was a prolific writer, both controversial and highly praised.


## PDF page 21

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
2. Fragments: Avoid using incomplete sentences in English, especially in academic writing.       
This was a completely unexpected turn of events.
It was unbelievable to all those involved. 
That first publication turned out to be a best-selling and award-winning novel.
Or you can tag it onto the previous sentence with a dash:
In 1958 he published his third work in English—his best-selling and award-winning novel Lolita. 
She told me to cheat on the test—a very unusual message for a teacher to give.
NB: You still need to vary the length of your sentences. Avoid coming off as too long-winded or too ‘choppy’ in 
your approach.
3. Beware of French syntax with modifiers. Either use a relative phrase if you put the modifiers afterwards, or
put the modifiers before the noun.
It was popular with both critics and the public, which is rare these days.  
She was an angry and bitter young rebel.
Vonnegut was a prolific writer who was both controversial and highly praised.


## PDF page 22

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
4. Superfluous Commas
-Do not needlessly separate a subject and its predicate with a comma.
Most older, married students, must hold a job in addition to going to school. 
-The Oxford comma (a serial comma after the penultimate item in the series) is not necessary:
Four countries participated in the summit: Spain, Great Britain, France, and Germany.
5. Using a Dash More Frequently
-used more frequently in English than in French
-can replace pairs of commas or parentheses
-common for a change in tone or extra information
-can better integrate sentence fragments
-should be used after an introductory series:
Black asphalt, white lines, green signs with white lettering, endless pine trees—there’s 
not much to see on this U.S. road trip.
“Raindrops on roses and whiskers on kittens, bright copper kettles and warm 
woolen mittens, brown paper packages tied up with strings—these are a few 
of my favorite things.”


## PDF page 23

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
4. Superfluous Commas
-Do not needlessly separate a subject and its predicate with a comma.
Most older, married students, must hold a job in addition to going to school. 
-The Oxford comma (a serial comma after the penultimate item in the series) is not necessary:
Four countries participated in the summit: Spain, Great Britain, France, and Germany.
5. Using a Dash More Frequently
-used more frequently in English than in French
-can replace pairs of commas or parentheses
-common for a change in tone or extra information
-can better integrate sentence fragments
-should be used after an introductory series:
Black asphalt, white lines, green signs with white lettering, endless pine trees—there’s 
not much to see on this U.S. road trip.
“Raindrops on roses and whiskers on kittens, bright copper kettles and warm 
woolen mittens, brown paper packages tied up with strings—these are a few 
of my favorite things.”


## PDF page 24

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
4. Superfluous Commas
-Do not needlessly separate a subject and its predicate with a comma.
Most older, married students, must hold a job in addition to going to school. 
-The Oxford comma (a serial comma after the penultimate item in the series) is not necessary:
Four countries participated in the summit: Spain, Great Britain, France, and Germany.
5. Using a Dash More Frequently
-used more frequently in English than in French
-can replace pairs of commas or parentheses
-common for a change in tone or extra information
-can better integrate sentence fragments
-should be used after an introductory series:
Black asphalt, white lines, green signs with white lettering, endless pine trees—there’s 
not much to see on this U.S. road trip.
“Raindrops on roses and whiskers on kittens, bright copper kettles and warm 
woolen mittens, brown paper packages tied up with strings—these are a few 
of my favorite things.”


## PDF page 25

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
6. Don’t confuse ellipsis points (…), a dash (—) and etc.
-At the end of a series, use ‘etc.’ and not ellipsis points.
She wrote novels, short stories, libretti, essays, etc.
-et al. can replace etc. in a list of proper names (especially in bibliographical entries)
The Lost Generation included Hemingway, Stein, Fitzgerald, et al.
7. When referring to a word as a word or using a foreign word, you can use italics (instead of quotation 
marks)
It comes from the Latin peplum, which means “they bear”.
That is why et al. replace etc. in a bibliography.
8. Dangling Participles
(incorrect) Winning numerous awards, including the Pulitzer, the public truly embraced 
Hemingway as the voice of a generation. →
Winning numerous awards, including the Pulitzer, Hemingway was elevated by the public 
to being considered the voice of a generation
(incorrect) Eating a banana and swinging from a tree, I saw a monkey at the zoo. →
I saw a monkey at the zoo that was eating a banana and swinging from a tree.


## PDF page 26

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
6. Don’t confuse ellipsis points (…), a dash (—) and etc.
-At the end of a series, use ‘etc.’ and not ellipsis points.
She wrote novels, short stories, libretti, essays, etc.
-et al. can replace etc. in a list of proper names (especially in bibliographical entries)
The Lost Generation included Hemingway, Stein, Fitzgerald, et al.
7. When referring to a word as a word or using a foreign word, you can use italics (instead of quotation 
marks)
It comes from the Latin peplum, which means “they bear”.
That is why et al. replace etc. in a bibliography.
8. Dangling Participles
(incorrect) Winning numerous awards, including the Pulitzer, the public truly embraced 
Hemingway as the voice of a generation. →
Winning numerous awards, including the Pulitzer, Hemingway was elevated by the public 
to being considered the voice of a generation
(incorrect) Eating a banana and swinging from a tree, I saw a monkey at the zoo. →
I saw a monkey at the zoo that was eating a banana and swinging from a tree.


## PDF page 27

The Mechanics of Good Writing III: Style, Syntax and Sentence Structure
E. Syntax and Sentence Structure
9. Register
Be sure to avoid using expressions that are too informal (“it is way better”, “she was like angry”, 
“it was a little bit controversial”) or slang (“epic fail”, “she ripped off Shakespeare”, “he decided to check it out”, 
“…and other stuff”).
Similarly, avoid using contractions (don’t, isn’t).
Needless to say, avoid profanity of any register.
10. Shifting Verb Tenses
One of the most common errors in your writing work. 
-Avoid writing narratives in the present tense
-Avoid shifting back and forth between present and past tenses.


## PDF page 28

The Mechanics of Good Writing IV: Common Mistakes among Non-Native Writers
30 Most Common Mistakes
I realized a new project for art class
She precised that…
She lived a terrible ordeal.
He crossed a stranger in the street.
He wanted to discuss (?)
She was considered as the best
He’s responsible of
We identify to the author
She succeeded to convince him.
on the photo, under the rain, 
She is one of the most famous author
All along the text, we find…
There were a lot of critics of…
Some informations, advices, news are…
We assisted to many crazy things.
We were five students in the class that day.
We were September 1st.


## PDF page 29

The Mechanics of Good Writing IV: Common Mistakes among Non-Native Writers
30 Most Common Mistakes
The most important/surprising/unexpected (?) was…
The story has been published in 1953
I’m agree with that.
experiment /experience
used to / to be used to +-ing
evolution / development
omnipresent / ubiquitous, pervasive
issues / problems
to remind someone of/ to remember something/someone, to remember to do something
particular / unusual / peculiar
relation / relationship / to visit relations or relatives
a small amount of / a small number of 
In addition, / Besides,
At last, / Lastly,


## PDF page 30

The Mechanics of Good Writing IV: Common Mistakes among Non-Native Writers
30 Most Common Mistakes
The most important/surprising/unexpected (?) was…
The story has been published in 1953
I’m agree with that.
experiment /experience
used to / to be used to +-ing
evolution / development
omnipresent / ubiquitous, pervasive
issues / problems
to remind someone of/ to remember something/someone, to remember to do something
particular / unusual / peculiar
relation / relationship / to visit relations or relatives
a small amount of / a small number of 
In addition, / Besides,
At last, / Lastly,


## PDF page 31

That finishes Unit I!
Next Week: Online Midterm on all of Unit I
-lots of fallacies, appeals, types of reasoning and rhetorical modes to identify
-questions on the readings
-questions on paragraph form and on style sheets
-questions on common errors in syntax, layout & grammar/vocabulary


