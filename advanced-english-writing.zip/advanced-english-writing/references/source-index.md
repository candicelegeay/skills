# Source index

Private user-provided university course corpus: A2FCP12, Cultures et pratiques de l’écrit dans le monde anglophone; course materials identify Dennis Tredy, Sorbonne Nouvelle. Treat these as writing instruction and historical examples, not current factual reporting. These references are page-labelled text extractions, not summaries. PDF page numbers are physical pages. Extraction can lose visual emphasis and reveal intermediate exercise answers.

## Files
- `week-1.md`: A2FCP12 Week 1 work no video.pdf; 24 pages.
- `week-2.md`: A2FCP12 Week 2 no video PDF.pdf; 30 pages.
- `week-3-modes.md`: A2FCP12 Week 3 part 1 modes PDF.pdf; 17 pages.
- `fallacies-1.md`: A2FCP12 fallacies part one only PDF.pdf; 55 pages.
- `fallacies-2.md`: A2FCP12 fallacies part two with Trump PDF.pdf; 76 pages.
- `paragraphs.md`: A2FCP12 Week 4 part 2 paragraphs 1 PDF.pdf; 43 pages.
- `openings-citations.md`: A2FCP12 Week five video 1 PDF.pdf; 19 pages.
- `mechanics.md`: A2FCP12 Lesson five video 2 common mistakes PDF.pdf; 31 pages.
- `brochure.md`: A2FCP12 brochure final draft to use.pdf; 158 pages.

## Reading routes
- Ten modes: week-1 pp. 13–23; week-2 pp. 12–22; week-3-modes pp. 2–16.
- Appeals and reasoning: week-2 pp. 1–11 and 24–29.
- Fallacies: fallacies-1 pp. 1–13 for the taxonomy, later pages for exercises; fallacies-2 for worked applications.
- Paragraph unity and progression: paragraphs pp. 3–16; later pages for mode-identification exercises.
- Openings/endings: openings-citations pp. 2–9; style sheets and attribution pp. 10–19.
- Punctuation, syntax, register and French interference: mechanics pp. 2–30.
- Sample essays, journalism and commentaries: brochure; consult its table of contents before choosing a section.

## Source limits and corrections
- The course repeatedly attributes the classical rhetoric discussion to Aristotle’s Poetics. Do not repeat this attribution as established; the relevant treatise is Rhetoric.
- Abduction is not simply intuition with little evidence: use inference to the best available explanation, compare alternatives, and mark uncertainty.
- Distinguish deductive validity (conclusion follows) from soundness (valid plus true premises). A false premise does not alone make an argument invalid.
- Ethos is credibility, not automatically an appeal-to-authority fallacy. Emotional appeals are not inherently fallacious. An enthymeme is not inherently deceptive.
- Paragraph sentence counts, avoiding all fragments, Oxford comma preferences, title case and dialogue presentation are contextual conventions, not universal grammatical laws.
- Some sample factual, political, biographical and linguistic claims may be inaccurate or dated. Do not reuse them as verified facts or infer motives from the examples.
- Distinguish the course’s instructional labels from independent additions and corrections. Do not claim all supplemental advice is stated in the course.