# A2FCP12 Week 4 part 2 paragraphs 1 PDF.pdf

## Contents
- PDF page 1: A2FCP12 – Week 4, Part One:      (previous video) / Fallacies II:
- PDF page 2: The Mechanics of Good Writing I: Paragraphs / -After covering the broader notions of rhetorical modes of organization for entire essays
- PDF page 3: The Mechanics of Good Writing I: Paragraphs / External View of Paragraphs:
- PDF page 4: The Mechanics of Good Writing I: Paragraphs / An exception to this rule of thumb: Representing Dialogue in English
- PDF page 5: The Mechanics of Good Writing I: Paragraphs / Too Long? Breaking down paragraphs
- PDF page 6: The Mechanics of Good Writing I: Paragraphs / For example, this paragraph, though not ‘too long’, could still be broken down:
- PDF page 7: The Mechanics of Good Writing I: Paragraphs / In the next example, we suggest that the author could have created new paragraphs at places wh
- PDF page 8: The Mechanics of Good Writing I: Paragraphs / Where would you break this one up?
- PDF page 9: The Mechanics of Good Writing I: Paragraphs / Where would you break this one up?
- PDF page 10: The Mechanics of Good Writing I: Paragraphs / An Internal View of a Good Paragraph
- PDF page 11: The Mechanics of Good Writing I: Paragraphs / Thus, there are three main parts to every paragraph:
- PDF page 12: The Mechanics of Good Writing I: Paragraphs / Sample paragraph 1:
- PDF page 13: The Mechanics of Good Writing I: Paragraphs / Felix Driver, “Henry Morton Stanley and His Critics”
- PDF page 14: The Mechanics of Good Writing I: Paragraphs / Language Note: Using clear transition words and markers (both within a paragraph or tying them
- PDF page 15: The Mechanics of Good Writing I: Paragraphs / Language Note: Using clear transition words and markers
- PDF page 16: The Mechanics of Good Writing I: Paragraphs / A Closer Look at the Topic Sentence:
- PDF page 17: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 18: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 19: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 20: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 21: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 22: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 23: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 24: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 25: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 26: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 27: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 28: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 29: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 30: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 31: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 32: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 33: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 34: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 35: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 36: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 37: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 38: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 39: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 40: The Mechanics of Good Writing I: Paragraphs / Which rhetorical mode of organization is announced in these topic sentences?
- PDF page 41: The Mechanics of Good Writing I: Paragraphs / We can also get an idea which of the three types of reasoning will be leaned on:
- PDF page 42: The Mechanics of Good Writing I: Paragraphs / Or even which appeal the author may rely on:
- PDF page 43: The Mechanics of Good Writing I: Paragraphs / Or even which appeal the author may rely on:

## PDF page 1

A2FCP12 – Week 4, Part One:      (previous video)
Fallacies II:
Correction of practice exercises from last week
Taking it to another level: Trump’s ‘tweets’ during his first term
A2FCP12 – Week 4, Part Two:
Paragraphs I – On writing coherent paragraphs


## PDF page 2

The Mechanics of Good Writing I: Paragraphs
-After covering the broader notions of rhetorical modes of organization for entire essays 
(with ten key samples), then narrowing our view to the rhetorical and logical elements that 
go into the construction of your argument (appeals, types of reasoning, fallacies), we will 
now narrow our view even more and focus on paragraphs this week (a sore point with 
many students), before we look even closer at style and syntax next week.
Main sources on paragraphs:
Maxine C. Hairston’s Successful Writing, 5th ed., New York: W.W.H. Norton & Co., 2003.
Variations provided by english-for-students.com
The Hodges Harbrace Handbook, 18th ed., Cheryl Glenn and Loretta Gray (eds.), New 
York: Wadsworth, 2013.


## PDF page 3

The Mechanics of Good Writing I: Paragraphs
External View of Paragraphs:
-Gives form on the page, creates its own body language
-Makes an impression on the reader (e.g., first impression of long, dense paragraphs)
-‘Standard Size’ of a short paragraph: 5 to 7 sentences (medium: 8 to 10; long: more than 
10)
-any paragraph longer than a page can surely be broken down
-knowing your audience will also help you decide how long they can be
Too short? Avoiding one-sentence paragraphs:
(Attention, French students!)
Though some of the short essays we’ve seen relied on a succession of very short 
paragraphs, this is not the norm, and French students especially have a habit of hitting the 
return carriage far too often (if not after each line…).
However, this doesn’t mean that an occasional short paragraph (or even a one-line 
paragraph) can’t be used sparingly, and at the right moment (for example, for an aside 
after a long, dense paragraph)


## PDF page 4

The Mechanics of Good Writing I: Paragraphs
An exception to this rule of thumb: Representing Dialogue in English
When writing dialogue, especially in narratives, try to go to the next line each time 
someone else speaks:
There was a heavy silence that came over the dining room as Davis, who was far better-dressed 
in his tailored tuxedo than any of the hundreds of white diners in the room, was prevented from 
entering and joining the rest of his jazz trio at their table.
“I’m sorry, Sir. I’m afraid we cannot allow you to dine here. I’m sure you understand…,” 
explained the maître d’, implying that it was just the way things were done in the South.
“I’m afraid I do not, “ he curtly replied. “Are you saying that I cannot eat in the same room as all 
of these diners, when they are all here to listen to me play?”
The maître d’ began to panic as every eye, it seemed, had turned toward him in the sustained hush 
in the dining hall. After clearing his throat, he suggested, “There is a honky-tonk just down the road 
that has kitchen service and would be more than happy to serve you.”
NB: We will return to matters of punctuation, but please note how dialogue is written and 
presented in English. Avoid the French techniques of slipping into play-like format for 
dialogue, and be sure to use a comma before the first quotation mark to open a quotation, 
or before the second quotation mark to close a quotation if there is not a question mark, 
exclamation point or dash at the end of the quoted line.


## PDF page 5

The Mechanics of Good Writing I: Paragraphs
Too Long? Breaking down paragraphs
There is logical criteria for where you can and should break up a long paragraph.
-As a paragraph is supposed to be a complete view of a single idea, you break to the next 
one when you shift to a new idea. 
(Though in practice, it rarely seems that straightforward, and some ideas are too complex 
to form a single paragraph).
Natural Division Points for Breaking Paragraphs :
A shift in time : Look for sentences beginning with words like first, next, formerly, at that 
time, etc.
A shift in place : Look for sentences beginning with words like elsewhere, in the 
meantime, etc.
A shift showing contrast : Look for sentences beginning with words like however, on the 
other hand, nevertheless, etc.
A shift in emphasis : Look for sentences beginning with terms like if that happens, in 
spite of another possibility, a case in point would be, not only, etc.
A shift signaling additional information : Look for sentences that begin with terms like 
moreover, in addition, besides, etc.


## PDF page 6

The Mechanics of Good Writing I: Paragraphs
For example, this paragraph, though not ‘too long’, could still be broken down:
There is a tendency to exaggerate the rate at which our lives will be changed by 
technology. We still have a whole year to go before 2001, but I doubt that Arthur C. 
Clarke’s vision of commercial flights to the moon is going to come true by then. Individual 
technologies reach plateaus beyond which further improvement is not worthwhile. // For 
instance, the experience of riding in commercial aircraft has not materially changed since 
the introduction of the Boeing 707 more than forty years ago. (The Concorde is an 
exception that proves the rule. It has never paid for the cost of its development.) Computer 
technology has not yet reached its plateau. But it will – probably when the miniaturization 
of the solid – state devise runs into the limits imposed by the state of the finite size of 
invaluable atoms. // Successful technologies also tend to be self – limiting once they 
become available to the general population. I doubt that it is possible to cross Manhattan 
from the east river to the Hudson River faster by automobile to day than it was by horse-
drawn streetcar a century ago. The Internet is already beginning to show the effects of 
overcrowding. I tremble at the thought of two billion air conditioners in a future China and 
India, each adding its exhaust heat to the earth’s atmosphere. (Steven Weinberg, “Five and 
a Half Utopias” 2000)


## PDF page 7

The Mechanics of Good Writing I: Paragraphs
In the next example, we suggest that the author could have created new paragraphs at places where she 
introduced new examples to illustrate her main idea.
Arranged marriage looks somewhat different from the point of view of the bride and her family. Arranged 
marriages continue to be preferred even among the more educated, Westernized sections of the Indian 
population. Many young women from these families still go along, more or less willingly, with the practice 
and also with the specific choices of their families. Young women do get excited about the prospects of their 
marriage, but there is an ambivalence and increasing uncertainty, as the bride contemplates leaving the 
comfort and familiarity of her own home whereas a temporary guest she has often been indulged to live 
among strangers. // Even in the best situation she now comes under the increased scrutiny of her husband’s 
family. How she dresses, how she behaves, how she gets along with other, where she goes, how she spends 
her time, her domestic abilities – all of this and much more – will be observed and commented on by a whole 
new set of relations. Her interaction with her family of birth will be monitored and curtailed 
considerably. // Not only will she leave their home, but with increasing geographic mobility, 
she may also live very far from them, perhaps even on another continent. Too 
much expression of her fondness for her family or her desire to visit them may 
be interpreted as an inability to adjust to her new family and may become a 
source of conflict. In an arranged marriage, the burden of adjustment is clearly 
heavier for a woman than for a man. And that is the best of circumstances. 
(Serna Nanda, “Arranging a Marriage In India”)


## PDF page 8

The Mechanics of Good Writing I: Paragraphs
Where would you break this one up?
In outline it was a good plan, but it quite failed to take into account the mentality of buzzards. As soon as they 
were wired to the tree, they all began to try and fly away. The wires prevented that, of course, but did not 
prevent them from falling off the limbs where they dangled upside down, wings flapping nether parts 
exposed. It is hard to imagine anything less likely to beguile a movie-going audience than a tree full of 
dangling buzzards. Everyone agreed it was unaesthetic. The buzzards were righted but they tried again and 
with each try their humiliation deepened. Finally, they abandoned their effort to fly away and resigned 
themselves to life on the tree. Their resignation was so complete that when the scene was readied and the time 
came for them to fly they refused. They had had enough of ignominy—better to wait on the limb indefinitely. 
Buzzards are not without patience. Profanity, firecrackers and even a shotgun full of rock salt failed to move 
them. I am told that in desperation a bird man was flown in from L.A. to teach the sulky bastards how to fly. 
The whole experience left everyone touchy. A day or so later, looking at the pictures again, I hated a further 
provocative detail. The dead heifer that figured so prominently in the scene was quite clearly a steer. When I 
pointed this out to the still photographers, they just shrugged. A steer was close 
enough, after all they were both essentially cows. “In essence, it’s a cow,’ one 
said moodily. No one wanted those buzzards back again.
Larry McMurtry, “Here’s HUD in Your Eye,” in In a Narrative Grave
(New York: Simon & Shuster, 1968), 10-11.


## PDF page 9

The Mechanics of Good Writing I: Paragraphs
Where would you break this one up?
In outline it was a good plan, but it quite failed to take into account the mentality of buzzards. As soon as they 
were wired to the tree, they all began to try and fly away. The wires prevented that, of course, but did not 
prevent them from falling off the limbs where they dangled upside down, wings flapping nether parts 
exposed. It is hard to imagine anything less likely to beguile a movie-going audience than a tree full of 
dangling buzzards. Everyone agreed it was unaesthetic. The buzzards were righted but they tried again and 
with each try their humiliation deepened. // Finally, they abandoned their effort to fly away and resigned 
themselves to life on the tree. Their resignation was so complete that when the scene was readied and the time 
came for them to fly they refused. They had had enough of ignominy—better to wait on the limb indefinitely. 
Buzzards are not without patience. // Profanity, firecrackers and even a shotgun full of rock salt failed to 
move them. I am told that in desperation a bird man was flown in from L.A. to teach the sulky bastards how 
to fly. The whole experience left everyone touchy. // A day or so later, looking at the pictures again, I hated a 
further provocative detail. The dead heifer that figured so prominently in the scene was quite clearly a steer. 
When I pointed this out to the still photographers, they just shrugged. A steer was close 
enough, after all they were both essentially cows. “In essence, it’s a cow,’ one 
said moodily. No one wanted those buzzards back again.
Larry McMurtry, “Here’s HUD in Your Eye,” in In a Narrative Grave
(New York: Simon & Shuster, 1968), 10-11.


## PDF page 10

The Mechanics of Good Writing I: Paragraphs
An Internal View of a Good Paragraph
Before looking at the breakdown of a paragraph, remember some key features that make a 
paragraph an autonomous whole:
1. Unity around a main idea (found in the Topic Sentence). 
2. Order: choosing the best order for your supporting claims (chronological, order of 
importance, most to least or least to most relevant, etc.
3. Coherence: sentences within a paragraph need to connect to each other and work 
together as a whole. One of the best ways to achieve coherency is to use the proper 
transition words within the paragraph. These often show order (first, second, third); spatial 
relationships (above, below) or logic (furthermore, in addition, in fact). Also, in writing a 
paragraph, using a consistent verb tense and point of view are important ingredients for 
coherency.
4. Completeness: if all sentences clearly and sufficiently support the main idea, then your 
paragraph is complete. Usually, at least three supporting sentences are provided between 
the topic sentence and the concluding sentence. The concluding sentence often 
summarizes your main idea by reinforcing your topic sentence, and it may also open the 
door to the next point.


## PDF page 11

The Mechanics of Good Writing I: Paragraphs
Thus, there are three main parts to every paragraph:
1. The Topic Sentence (usually the first sentence, unless there’s an opening hook or 
transition before it)
(Note that the transition can be a part of the Topic Sentence: e.g., Although most authors in 
humanities consistently use MLA style, there are several other choices depending on your 
field of study.)
2. The Middle ‘Supportive’ Sentences (clear development/justification/support of the 
Topic Sentence)
3. The Concluding Sentence (conclusion and/or transition): You need to tie up the current 
point before moving onto the next one. It is usually (but not always) the last sentence, it 
ties up the discussion of the paragraph and often reminds us of the point(s) made, and it 
can include or launch a transition, a recommendation or some type of closure.


## PDF page 12

The Mechanics of Good Writing I: Paragraphs
Sample paragraph 1:
The Internet has become really important for three main reasons. First, it enables people to 
access more information than ever before. That is, people can read books, newspapers, or 
magazines online and for free. Second, thanks to the Internet, people can communicate 
with others in every part of the world via social networking websites like Facebook, 
WhatsApp, WeChat, Twitter, Skype, Viber, Snapchat, LinkedIn, Reddit, etc. Third, the 
Internet is a perfect tool to study and get certificates from well-known top universities. In 
other words, now more than ever, anyone can do free online courses in a variety of 
subjects. In short, the Internet is, beyond doubt, an essential and valuable tool nowadays.
(from Englishidiom.net)


## PDF page 13

The Mechanics of Good Writing I: Paragraphs
Felix Driver, “Henry Morton Stanley and His Critics” 
The history of exploration has until recently been dominated by two sorts of historical writing: biographies, 
which of necessity focus on the life and personality of individual explorers, and somewhat Whiggish general 
histories, which have tended to celebrate the triumph of modern geographical science over the mysteries of 
the earth. However, neither of these approaches is particularly well equipped to meet the requirements of a 
more contextual perspective, concerned with the wider contemporary significance of the ideas and practices 
of exploration. In recent years, historians have paid much more attention to the institutional, intellectual, and 
social contexts in which projects of exploration were sustained, emphasizing in particular the relationship 
between exploration and empire. Whether explorers like Stanley are considered to be “progenitors” or 
merely “precursors’ of the new forms of imperialism developing during the late nineteenth century, their 
labors at the colonial frontier must be seen ii the wider context of changing relationships between Europe 
and the non‐European world. It has been suggested that the attitudes and assumptions of explorers constitute 
a kind of “unofficial symbolic imperialism,” helping to define the cultural terms on which unequal political 
relations between colonizer and colonized could subsequently be established. The fact that British explorers 
of Africa… received official sanction and support is, according to this view, but one aspect of their 
contribution to imperial history; another is their role in the popularization of myths and fantasies 
about the non‐European world. For geographical exploration did not merely overcome distance;
it helped created “imaginative geographies.” Joseph Conrad once described the most
famous African explorers as “conquerors of truth,” not because they exposed the inner
secrets of distant regions (as they often claimed), but rather because they established
particular ways of reading unknown landscapes.
More elaborate:
Topic sentence includes a one-sentence set-up, and the conclusion includes
an unexpected confirmation of the notion from the world of fiction.


## PDF page 14

The Mechanics of Good Writing I: Paragraphs
Language Note: Using clear transition words and markers (both within a paragraph or tying them together)
These are essential to maintaining a clear line of development throughout your essay.
Examples of Transition Words in English:
•
To introduce an additional idea: In addition, additionally, moreover, besides, furthermore, also, and, too, as 
well, not only …but also, an additional (+noun), another (+noun), etc.
•
To introduce an example: For example, for instance, an example of (+noun), like, such as (+noun), namely, to 
give an example, a great example is, a similar example is, an additional example is, another example is, a 
different example is, a better example is, a common example is, etc.
•
To express contrast or introduce an opposite idea: In contrast, on the other hand, however, yet, but, 
nevertheless, nonetheless, notwithstanding, although, though, even though, whereas, while, conversely, on the 
contrary, still, in spite of (+noun), despite (+noun), etc.
•
To list in order: First and foremost, First, second, third, next, last, finally, the first, the second, the third, the 
next, the final, first of all, etc.
•
To introduce a choice or alternative: or, otherwise, if, unless, etc.
•
To introduce a statement or explanation: In fact, as a matter of fact, indeed, that is, etc.
•
To summarize or introduce a conclusion: In brief, in short, clearly, in summary, 
in conclusion, in summary, to sum up, as a conclusion, indeed, all things considered, 
all in all, to conclude, in a nutshell, overall, at last, finally, last but not least, etc.


## PDF page 15

The Mechanics of Good Writing I: Paragraphs
Language Note: Using clear transition words and markers 
•
To express cause: For, because, since, as, because of, due to, owing to, thanks to, result from (verb), 
to be the result of, one effect of, one consequence of, as a result of, as a consequence of, etc.
•
To introduce a result: As a result, as a consequence, accordingly, consequently, therefore, thus,
hence, so, result in, cause, have an effect on, affect, thereby, etc. 
Similarly, be sure to use ‘development markers’ throughout your essay or thesis to make sure the reader sees 
how additional points feed into your thesis statement and so that they do not forget the overall point you are 
making.
e.g., 
Yet another way that social media has changed the landscape of advertising is the use of targeted ads depending 
on a user’s browsing history.
If such circumstantial evidence may not have seemed concrete enough to find O.J. 
Simpson guilty, the forensic evidence should have guaranteed a conviction. 
There are thus myriad reasons not to invest in Bitcoin or other cryptocurrencies, yet 
brokers continue to tout the benefits of such an investment and see it as relatively 
low-risk.


## PDF page 16

The Mechanics of Good Writing I: Paragraphs
A Closer Look at the Topic Sentence:
-The ‘thesis statement’ of the paragraph.
-It can include a transitional device from the previous topic
-It is usually an affirmation rather than a question, though the question-and-answer topic sentence can 
occasionally be used:
e.g., How can a writer achieve this unity? Most of us do it by employing some version of a common pattern.
or     What’s the difference between prison and college? They both prescribe your behavior for a given period of 
time.
-It usually sets up a movement from general information to specific supporting information, from assertion to 
explanation.
-The topic sentence usually announces the ‘rhetorical mode of organization’ of the 
coming paragraph.
All of the rhetorical modes for organizing an entire essay (seen in lessons 1 & 2) can 
be used to organize a paragraph (and modes can overlap here too).


## PDF page 17

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Inanimate objects are classified into three major categories—those that don't work, those that break down and 
those that get lost.” (Russell Banks)
“For some the benefits of living in the city will be enough of a lure, but for others those same features will be a 
turn-off.” (A.J. Smith)
“It is hard to see why anyone would think that religion is a cure for the world’s problems, given its history.” 
(Steven Weinberg)
“Families are many things—most of all they are the people for whom it matters if you have a cold, are feuding 
with your mate or training a new puppy.” (Mary Pipher)
“In twentieth–century America we place so much emphasis on romance that we barely 
notice the other multifaceted aspects of marriage that revolve around economics and 
child rearing.” (Anne Roiphe)


## PDF page 18

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Inanimate objects are classified into three major categories—those that don't work, those that break down and 
those that get lost.” (Russell Banks)
(classification)
“For some the benefits of living in the city will be enough of a lure, but for others those same features will be a 
turn-off.” (A.J. Smith)
“It is hard to see why anyone would think that religion is a cure for the world’s problems, given its history.” 
(Steven Weinberg)
“Families are many things—most of all they are the people for whom it matters if you have a cold, are feuding 
with your mate or training a new puppy.” (Mary Pipher)
“In twentieth–century America we place so much emphasis on romance that we barely 
notice the other multifaceted aspects of marriage that revolve around economics and 
child rearing.” (Anne Roiphe)


## PDF page 19

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Inanimate objects are classified into three major categories—those that don't work, those that break down and 
those that get lost.” (Russell Banks)
(classification)
“For some the benefits of living in the city will be enough of a lure, but for others those same features will be a 
turn-off.” (A.J. Smith)
(comparison & contrast)
“It is hard to see why anyone would think that religion is a cure for the world’s problems, given its history.” 
(Steven Weinberg)
“Families are many things—most of all they are the people for whom it matters if you have a cold, are feuding 
with your mate or training a new puppy.” (Mary Pipher)
“In twentieth–century America we place so much emphasis on romance that we barely 
notice the other multifaceted aspects of marriage that revolve around economics and 
child rearing.” (Anne Roiphe)


## PDF page 20

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Inanimate objects are classified into three major categories—those that don't work, those that break down and 
those that get lost.” (Russell Banks)
(classification)
“For some the benefits of living in the city will be enough of a lure, but for others those same features will be a 
turn-off.” (A.J. Smith)
(comparison & contrast)
“It is hard to see why anyone would think that religion is a cure for the world’s problems, given its history.” 
(Steven Weinberg)
(example / description & narrative)
“Families are many things—most of all they are the people for whom it matters if you have a cold, are feuding 
with your mate or training a new puppy.” (Mary Pipher)
“In twentieth–century America we place so much emphasis on romance that we barely 
notice the other multifaceted aspects of marriage that revolve around economics and 
child rearing.” (Anne Roiphe)


## PDF page 21

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Inanimate objects are classified into three major categories—those that don't work, those that break down and 
those that get lost.” (Russell Banks)
(classification)
“For some the benefits of living in the city will be enough of a lure, but for others those same features will be a 
turn-off.” (A.J. Smith)
(comparison & contrast)
“It is hard to see why anyone would think that religion is a cure for the world’s problems, given its history.” 
(Steven Weinberg)
(example / description & narrative)
“Families are many things—most of all they are the people for whom it matters if you have a cold, are feuding 
with your mate or training a new puppy.” (Mary Pipher)
(definition)
“In twentieth–century America we place so much emphasis on romance that we barely 
notice the other multifaceted aspects of marriage that revolve around economics and 
child rearing.” (Anne Roiphe)


## PDF page 22

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Inanimate objects are classified into three major categories—those that don't work, those that break down and 
those that get lost.” (Russell Banks)
(classification)
“For some the benefits of living in the city will be enough of a lure, but for others those same features will be a 
turn-off.” (A.J. Smith)
(comparison & contrast)
“It is hard to see why anyone would think that religion is a cure for the world’s problems, given its history.” 
(Steven Weinberg)
(example / description & narrative)
“Families are many things—most of all they are the people for whom it matters if you have a cold, are feuding 
with your mate or training a new puppy.” (Mary Pipher)
(definition)
“In twentieth–century America we place so much emphasis on romance that we barely 
notice the other multifaceted aspects of marriage that revolve around economics and 
child rearing.” (Anne Roiphe)
(division analysis)


## PDF page 23

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Planning an Indian wedding is no small feat; regardless of the size of the wedding party, there is a lot of time, 
effort, patience—as well as money—that will have to be invested.” (Arvind Jyot Sabhaney)
“The young woman who walked in and took her place at the front of the class the first day of the semester looked 
less like a professor than anyone might imagine.” (Maxine Hairston)
“Oppressed people deal with their oppression in three characteristic ways.” (Martin Luther King, Jr.)
“Though the impeachment trial is unlikely to find Trump guilty, there are two possible outcomes many seem to 
forget: a vote of censure and the invocation of the 14th Amendment” (Janet Hook)
“There is more than enough material out there to tell you why you should be investing 
in cryptocurrencies, the reasons why you should not do it are often overlooked.” 
(Anthony Xie)


## PDF page 24

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Planning an Indian wedding is no small feat; regardless of the size of the wedding party, there is a lot of time, 
effort, patience—as well as money—that will have to be invested.” (Arvind Jyot Sabhaney)
(process analysis)
“The young woman who walked in and took her place at the front of the class the first day of the semester looked 
less like a professor than anyone might imagine.” (Maxine Hairston)
“Oppressed people deal with their oppression in three characteristic ways.” (Martin Luther King, Jr.)
“Though the impeachment trial is unlikely to find Trump guilty, there are two possible outcomes many seem to 
forget: a vote of censure and the invocation of the 14th Amendment” (Janet Hook)
“There is more than enough material out there to tell you why you should be investing 
in cryptocurrencies, the reasons why you should not do it are often overlooked.” 
(Anthony Xie)


## PDF page 25

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Planning an Indian wedding is no small feat; regardless of the size of the wedding party, there is a lot of time, 
effort, patience—as well as money—that will have to be invested.” (Arvind Jyot Sabhaney)
(process analysis)
“The young woman who walked in and took her place at the front of the class the first day of the semester looked 
less like a professor than anyone might imagine.” (Maxine Hairston)
(narrative & description)
“Oppressed people deal with their oppression in three characteristic ways.” (Martin Luther King, Jr.)
“Though the impeachment trial is unlikely to find Trump guilty, there are two possible outcomes many seem to 
forget: a vote of censure and the invocation of the 14th Amendment” (Janet Hook)
“There is more than enough material out there to tell you why you should be investing 
in cryptocurrencies, the reasons why you should not do it are often overlooked.” 
(Anthony Xie)


## PDF page 26

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Planning an Indian wedding is no small feat; regardless of the size of the wedding party, there is a lot of time, 
effort, patience—as well as money—that will have to be invested.” (Arvind Jyot Sabhaney)
(process analysis)
“The young woman who walked in and took her place at the front of the class the first day of the semester looked 
less like a professor than anyone might imagine.” (Maxine Hairston)
(narrative & description)
“Oppressed people deal with their oppression in three characteristic ways.” (Martin Luther King, Jr.)
(classification)
“Though the impeachment trial is unlikely to find Trump guilty, there are two possible outcomes many seem to 
forget: a vote of censure and the invocation of the 14th Amendment” (Janet Hook)
“There is more than enough material out there to tell you why you should be investing 
in cryptocurrencies, the reasons why you should not do it are often overlooked.” 
(Anthony Xie)


## PDF page 27

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Planning an Indian wedding is no small feat; regardless of the size of the wedding party, there is a lot of time, 
effort, patience—as well as money—that will have to be invested.” (Arvind Jyot Sabhaney)
(process analysis)
“The young woman who walked in and took her place at the front of the class the first day of the semester looked 
less like a professor than anyone might imagine.” (Maxine Hairston)
(narrative & description)
“Oppressed people deal with their oppression in three characteristic ways.” (Martin Luther King, Jr.)
(classification)
“Though the impeachment trial is unlikely to find Trump guilty, there are two possible outcomes many seem to 
forget: a vote of censure and the invocation of the 14th Amendment” (Janet Hook)
(cause & effect / division analysis)
“There is more than enough material out there to tell you why you should be investing 
in cryptocurrencies, the reasons why you should not do it are often overlooked.” 
(Anthony Xie)


## PDF page 28

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“Planning an Indian wedding is no small feat; regardless of the size of the wedding party, there is a lot of time, 
effort, patience—as well as money—that will have to be invested.” (Arvind Jyot Sabhaney)
(process analysis)
“The young woman who walked in and took her place at the front of the class the first day of the semester looked 
less like a professor than anyone might imagine.” (Maxine Hairston)
(narrative & description)
“Oppressed people deal with their oppression in three characteristic ways.” (Martin Luther King, Jr.)
(classification)
“Though the impeachment trial is unlikely to find Trump guilty, there are two possible outcomes many seem to 
forget: a vote of censure and the invocation of the 14th Amendment” (Janet Hook)
(cause & effect / division analysis)
“There is more than enough material out there to tell you why you should be investing 
in cryptocurrencies, the reasons why you should not do it are often overlooked.” 
(Anthony Xie)
(for/against argument)


## PDF page 29

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“There are fair–weather friends and foul–weather friends and we need both kinds in our lives, especially so 
because each is likely to absent himself rather abruptly when the wind shifts.” (Edward Hoagland)
“Some of us who live in arid parts of the world think about water with a reverence those in western countries 
might find excessive” (Joan Didion)
“There are, it seems, three principal states of mind in human beings: waking, sleeping and dreaming.” 
(Carl Sagan)
“The general argument found many social uses in the South.” (Stephen Jay Gould)
“I want a wife who will take care of my physical needs.” (Judith Brady-Syfers)


## PDF page 30

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“There are fair–weather friends and foul–weather friends and we need both kinds in our lives, especially so 
because each is likely to absent himself rather abruptly when the wind shifts.” (Edward Hoagland)
(comparison and contrast)
“Some of us who live in arid parts of the world think about water with a reverence those in western countries 
might find excessive” (Joan Didion)
“There are, it seems, three principal states of mind in human beings: waking, sleeping and dreaming.” 
(Carl Sagan)
“The general argument found many social uses in the South.” (Stephen Jay Gould)
“I want a wife who will take care of my physical needs.” (Judith Brady-Syfers)


## PDF page 31

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“There are fair–weather friends and foul–weather friends and we need both kinds in our lives, especially so 
because each is likely to absent himself rather abruptly when the wind shifts.” (Edward Hoagland)
(comparison and contrast)
“Some of us who live in arid parts of the world think about water with a reverence those in western countries 
might find excessive” (Joan Didion)
(examples, narrative)
“There are, it seems, three principal states of mind in human beings: waking, sleeping and dreaming.” 
(Carl Sagan)
“The general argument found many social uses in the South.” (Stephen Jay Gould)
“I want a wife who will take care of my physical needs.” (Judith Brady-Syfers)


## PDF page 32

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“There are fair–weather friends and foul–weather friends and we need both kinds in our lives, especially so 
because each is likely to absent himself rather abruptly when the wind shifts.” (Edward Hoagland)
(comparison and contrast)
“Some of us who live in arid parts of the world think about water with a reverence those in western countries 
might find excessive” (Joan Didion)
(examples, narrative)
“There are, it seems, three principal states of mind in human beings: waking, sleeping and dreaming.” 
(Carl Sagan)
(classification)
“The general argument found many social uses in the South.” (Stephen Jay Gould)
“I want a wife who will take care of my physical needs.” (Judith Brady-Syfers)


## PDF page 33

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“There are fair–weather friends and foul–weather friends and we need both kinds in our lives, especially so 
because each is likely to absent himself rather abruptly when the wind shifts.” (Edward Hoagland)
(comparison and contrast)
“Some of us who live in arid parts of the world think about water with a reverence those in western countries 
might find excessive” (Joan Didion)
(examples, narrative)
“There are, it seems, three principal states of mind in human beings: waking, sleeping and dreaming.” 
(Carl Sagan)
(classification)
“The general argument found many social uses in the South.” (Stephen Jay Gould)
(examples / cause & effect)
“I want a wife who will take care of my physical needs.” (Judith Brady-Syfers)


## PDF page 34

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“There are fair–weather friends and foul–weather friends and we need both kinds in our lives, especially so 
because each is likely to absent himself rather abruptly when the wind shifts.” (Edward Hoagland)
(comparison and contrast)
“Some of us who live in arid parts of the world think about water with a reverence those in western countries 
might find excessive” (Joan Didion)
(examples, narrative)
“There are, it seems, three principal states of mind in human beings: waking, sleeping and dreaming.” 
(Carl Sagan)
(classification)
“The general argument found many social uses in the South.” (Stephen Jay Gould)
(examples / cause & effect)
“I want a wife who will take care of my physical needs.” (Judith Brady-Syfers)
(division analysis / examples)


## PDF page 35

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“It had been only through books—at best, no better than vicarious cultural transfusions—that I had managed to 
keep myself alive in a negatively vital way.” (Richard Wright)
“Human skin owes its color to the presence of particles known as melanin.” (Marvin Harris)
“By calling the victims of the Nazis "martyrs", we falsify their fate.” ‘Bruno Bettelheim)
“Though some may claim that the electoral college is an obsolete relic of the 18th century, the process still has its 
merits in today’s society.”  (Allen Guezlo)
“The reasons that Emmett Till was murdered were not new in 1955; in fact, they had 
long been part of the Southern Mind for generations.” (Jackson House)


## PDF page 36

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“It had been only through books—at best, no better than vicarious cultural transfusions—that I had managed to 
keep myself alive in a negatively vital way.” (Richard Wright)
(examples / narrative)
“Human skin owes its color to the presence of particles known as melanin.” (Marvin Harris)
“By calling the victims of the Nazis "martyrs", we falsify their fate.” ‘Bruno Bettelheim)
“Though some may claim that the electoral college is an obsolete relic of the 18th century, the process still has its 
merits in today’s society.”  (Allen Guezlo)
“The reasons that Emmett Till was murdered were not new in 1955; in fact, they had 
long been part of the Southern Mind for generations.” (Jackson House)


## PDF page 37

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“It had been only through books—at best, no better than vicarious cultural transfusions—that I had managed to 
keep myself alive in a negatively vital way.” (Richard Wright)
(examples / narrative)
“Human skin owes its color to the presence of particles known as melanin.” (Marvin Harris)
(definition/division analysis)
“By calling the victims of the Nazis "martyrs", we falsify their fate.” ‘Bruno Bettelheim)
“Though some may claim that the electoral college is an obsolete relic of the 18th century, the process still has its 
merits in today’s society.”  (Allen Guezlo)
“The reasons that Emmett Till was murdered were not new in 1955; in fact, they had 
long been part of the Southern Mind for generations.” (Jackson House)


## PDF page 38

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“It had been only through books—at best, no better than vicarious cultural transfusions—that I had managed to 
keep myself alive in a negatively vital way.” (Richard Wright)
(examples / narrative)
“Human skin owes its color to the presence of particles known as melanin.” (Marvin Harris)
(definition/division analysis)
“By calling the victims of the Nazis "martyrs", we falsify their fate.” ‘Bruno Bettelheim)
(definition / division analysis)
“Though some may claim that the electoral college is an obsolete relic of the 18th century, the process still has its 
merits in today’s society.”  (Allen Guezlo)
“The reasons that Emmett Till was murdered were not new in 1955; in fact, they had 
long been part of the Southern Mind for generations.” (Jackson House)


## PDF page 39

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“It had been only through books—at best, no better than vicarious cultural transfusions—that I had managed to 
keep myself alive in a negatively vital way.” (Richard Wright)
(examples / narrative)
“Human skin owes its color to the presence of particles known as melanin.” (Marvin Harris)
(definition/division analysis)
“By calling the victims of the Nazis "martyrs", we falsify their fate.” ‘Bruno Bettelheim)
(definition / division analysis)
“Though some may claim that the electoral college is an obsolete relic of the 18th century, the process still has its 
merits in today’s society.”  (Allen Guezlo)
(comparison & contrast / process / cause & effect)
“The reasons that Emmett Till was murdered were not new in 1955; in fact, they had 
long been part of the Southern Mind for generations.” (Jackson House)


## PDF page 40

The Mechanics of Good Writing I: Paragraphs
Which rhetorical mode of organization is announced in these topic sentences?
“It had been only through books—at best, no better than vicarious cultural transfusions—that I had managed to 
keep myself alive in a negatively vital way.” (Richard Wright)
(examples / narrative)
“Human skin owes its color to the presence of particles known as melanin.” (Marvin Harris)
(definition/division analysis)
“By calling the victims of the Nazis "martyrs", we falsify their fate.” ‘Bruno Bettelheim)
(definition / division analysis)
“Though some may claim that the electoral college is an obsolete relic of the 18th century, the process still has its 
merits in today’s society.”  (Allen Guezlo)
(comparison & contrast / process / cause & effect)
“The reasons that Emmett Till was murdered were not new in 1955; in fact, they had 
long been part of the Southern Mind for generations.” (Jackson House)
(examples/narrative/cause & effect)


## PDF page 41

The Mechanics of Good Writing I: Paragraphs
We can also get an idea which of the three types of reasoning will be leaned on:
‘There are numerous signs that apes and other primates are more similar to humans 
than we might imagine.’
‘In fact, government officials have been impeached after they left office in the past, so 
there is no reason why Trump’s trial in the Senate should not proceed.’
‘If you think you may be suffering from post-partum depression, you probably are, but 
there are some clinical tests that can confirm your self-diagnosis’


## PDF page 42

The Mechanics of Good Writing I: Paragraphs
Or even which appeal the author may rely on:
‘Unarmed black men being gunned down by white police officers is more than a 
question of ‘optics’, and it has triggered justifiable outrage in the streets of 
America’
‘Having tried censorship cases in front of the Supreme Court over a dozen 
times, Marjorie Heins’s insights on what is currently being called ‘cancel 
culture’ are quite eye-opening.’
‘If one removes his divisive rhetoric and questionable methods from a 
discussion of his term, President Trump can be seen as having made some sound 
economic decisions.’


## PDF page 43

The Mechanics of Good Writing I: Paragraphs
Or even which appeal the author may rely on:
‘Unarmed black men being gunned down by white police officers is more than a 
question of ‘optics’, and it has triggered justifiable outrage in the streets of 
America’
‘Having tried censorship cases in front of the Supreme Court over a dozen 
times, Marjorie Heins’s insights on what is currently being called ‘cancel 
culture’ are quite eye-opening.’
‘If one removes his divisive rhetoric and questionable methods from a 
discussion of his term, President Trump can be seen as having made some sound 
economic decisions.’


