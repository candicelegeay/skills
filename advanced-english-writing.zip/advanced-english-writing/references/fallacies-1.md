# A2FCP12 fallacies part one only PDF.pdf

## Contents
- PDF page 1: Fallacies of Reasoning / As we’ve already seen, following a logical structure does not necessarily make for a sound argument
- PDF page 2: A2FCP12 – Week 3, Part Two: Fallacies of Reasoning / Fallacies of Reasoning
- PDF page 3: Fallacies of Reasoning / So, when we talk of these tricks or errors in reasoning, we speak of fallacies (or fallacious
- PDF page 4: The 26 Most Common Fallacies of Reasoning / 1. Ad hominem
- PDF page 5: The 26 Most Common Fallacies of Reasoning / 4. False Authority
- PDF page 6: The 26 Most Common Fallacies of Reasoning / 7. Argument from Personal Incredulity
- PDF page 7: The 26 Most Common Fallacies of Reasoning / 10. Non-Sequitur
- PDF page 8: The 26 Most Common Fallacies of Reasoning / 12. Slippery Slope
- PDF page 9: The 26 Most Common Fallacies of Reasoning / 15. Oversimplification
- PDF page 10: The 26 Most Common Fallacies of Reasoning / 17. Moving the Goalpost
- PDF page 11: The 26 Most Common Fallacies of Reasoning / 19. Hasty Generalization
- PDF page 12: The 26 Most Common Fallacies of Reasoning / 23. Equivocation
- PDF page 13: The 26 Most Common Fallacies of Reasoning / 26. The Loaded Question
- PDF page 14: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 15: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 16: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 17: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 18: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 19: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 20: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 21: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 22: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 23: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 24: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 25: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 26: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 27: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 28: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 29: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 30: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 31: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 32: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 33: Practice with (rather obvious) samples: / Samples of fallacies:  What fallacy is being committed?
- PDF page 34: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 35: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 36: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 37: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 38: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 39: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 40: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 41: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 42: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 43: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 44: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 45: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 46: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 47: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 48: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 49: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 50: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 51: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 52: Practice with (rather obvious) samples: / This (ridiculous) argument is full of fallacies.  Can you spot all nine?
- PDF page 53: II. Two famous examples from The New York Times Op-Ed Page: / Here are the opening paragraphs to two landmark essays on legalizing marijuana
- PDF page 54: II. Two famous examples from The New York Times Op-Ed Page: / Opening to an opposing essay, “The Case for Slavery” by A. M. Rosenthal (1989)
- PDF page 55: So, can you see the Matrix?  Let’s find out… / Try the 26 exercises on the PDF handout on your own

## PDF page 1

Fallacies of Reasoning
As we’ve already seen, following a logical structure does not necessarily make for a sound argument 
or necessarily lead to a valid conclusion. 
Now, this can be done on purpose in order to manipulate your reader, or (more innocently) simply 
because of errors or fallacious reasoning. Traditionally, sophistry refers to subtly deceptive 
reasoning or argumentation, and a sophism a a deceptive argument itself, one that looks to follow 
valid reasoning but in fact does not. In English today, we prefer the term fallacy, as it does not 
necessarily imply malicious intent, but focuses on the error itself, whether intentional or not. 
Subtle example:
For example, one ‘trick’ used quite often is called an enthymeme, which involves drawing in the 
audience so that he or she feels directly involved in the matter. Imagine, for example, an employer 
speaking to his employees: "You can't create a successful program without a lot of money, and we 
certainly have a long way to go before we can call ourselves successful."  
Less subtle example:
Another technique involves wordplay in which the claim is technically true, but it is misleading as it 
implies something else. An example could be an aspirin manufacturer claims in an ad that “When it 
comes to pain relief, there's nothing better than our Reliefo."  The listener assumes this means that 
Reliefo is the best, but the truth could be that tests showed that all major aspirin products were the 
same (ie., none were better, but none were worse either). 
A2FCP12 – Week 3, Part Two: Fallacies of Reasoning


## PDF page 2

A2FCP12 – Week 3, Part Two: Fallacies of Reasoning
Fallacies of Reasoning
As we’ve already seen, following a logical structure does not necessarily make for a sound argument 
or necessarily lead to a valid conclusion. 
Now, this can be done on purpose in order to manipulate your reader, or (more innocently) simply 
because of errors or fallacious reasoning. Traditionally, sophistry refers to subtly deceptive 
reasoning or argumentation, and a sophism a a deceptive argument itself, one that looks to follow 
valid reasoning but in fact does not. In English today, we prefer the term fallacy, as it does not 
necessarily imply malicious intent, but focuses on the error itself, whether intentional or not. 
Subtle example:
For example, one ‘trick’ used quite often is called an enthymeme, which involves drawing in the 
audience so that he or she feels directly involved in the matter. Imagine, for example, an employer 
speaking to his employees: "You can't create a successful program without a lot of money, and we 
certainly have a long way to go before we can call ourselves successful."  
Less subtle example:
Another technique involves wordplay in which the claim is technically true, but it is misleading as it 
implies something else. An example could be an aspirin manufacturer claims in an ad that “When it 
comes to pain relief, there's nothing better than our Reliefo."  The listener assumes this means that 
Reliefo is the best, but the truth could be that tests showed that all major aspirin products were the 
same (ie., none were better, but none were worse either). 


## PDF page 3

Fallacies of Reasoning
So, when we talk of these tricks or errors in reasoning, we speak of fallacies (or fallacious 
reasoning).  It is very important for you to be able to recognize fallacies of reasoning when you see 
them, and this is for two main reasons:
1.  You need to be able to spot these fallacies in someone else’s arguments so that you can 
challenge them and point out their error or their attempt at manipulation.
2. You need to avoid using these fallacies in your own writing.  If you want your argument to be 
‘solid’ and ‘sound’, it cannot be corrupted by any of these fallacies.
Now let’s take a look at the 26 most common types of fallacies…
We will see around 40 in all in this lesson, and you will be expected to identify and 
name the fallacy when you see it being used…
A2FCP12 - Fallacies of Reasoning


## PDF page 4

The 26 Most Common Fallacies of Reasoning
1. Ad hominem
An ad hominem argument is any that attempts to counter another’s claims or conclusions by 
attacking the person, rather than addressing the argument itself.  
e.g., How can we trust a political agenda that comes from a man who cheated on his wife?
2. Ad ignorantiam
The argument from ignorance basically states that a specific belief is true because we don't know 
that it isn't true. 
e.g., How can you state beyond a shadow of a doubt that telekinesis is not possible, when there is 
so much about the human brain we do not know about?
3. Argument from Authority
Stating that a claim is true because a person or group of perceived authority says it is true. Often 
this argument is implied by emphasizing the many years of experience, or the formal degrees held 
by the individual making a specific claim. 
e.g., Trust me on this.  I’ve been studying legislative documents for thirty years and have a degree in 
Political Science.  This bill should not be made a law.
A2FCP12 - Fallacies of Reasoning


## PDF page 5

The 26 Most Common Fallacies of Reasoning
4. False Authority  
The assumption that an expert in one field can be a credible ‘expert’ in another field. (Similar to 
‘Argument from authority’, but even less logical!)
e.g., The country’s defense budget must be cut drastically, as the surgeon general has recently 
stated. (nb: The surgeon general is a medical doctor; what does he know about military spending?!)
5. Argument from Final Consequences  (Teleological arguments)
Such arguments are based on a reversal of cause and effect, because they argue that something is 
caused by the ultimate effect that it has, or purpose that is serves. 
e.g., I’m telling you, the bank bailout this president endorsed was the cause of the whole economic 
crisis. (nb:  The bank bailout was the response to the economic crisis, not the cause)
6. Post Hoc / False Cause 
(full name is ‘Post hoc, ergo propter hoc’: ‘After this, so because of this.’).  This is the assumption 
that because one event follows another, the first must be the cause of the second.   This is 
extremely common in politics.
e.g., The new mayor took office in January, and the crime rate has already increased 20%.
A2FCP12 - Fallacies of Reasoning


## PDF page 6

The 26 Most Common Fallacies of Reasoning
7. Argument from Personal Incredulity
I cannot explain or understand this, therefore it cannot be true. 
This is common on both sides of the argument for or against evolution, for example.  Some 
creationists argue that they cannot imagine the complexity of life resulting from blind evolution, but 
that does not mean life did not evolve.  Evolutionists often use the same approach to the idea of 
God creating man—that can’t believe it could happen that way, so it didn’t.
8. False Dilemma or Either-Or Fallacy
This is stating that only two alternatives exist when in fact there are more than two (also very 
common in politics)
e.g., We have only two choices: to build more nuclear power plants or to be completely dependent 
on foreign oil.
9. Inconsistency
Applying criteria or rules to one belief, claim, argument, or position but not to others, or blatantly 
changing one’s position . For example, some consumer advocates argue that we need stronger 
regulation of prescription drugs to ensure their safety and effectiveness, but at the same time argue 
that medicinal herbs should be sold with no regulation for either safety or effectiveness.  Why 
should it apply to one and not the other?
A2FCP12 - Fallacies of Reasoning


## PDF page 7

The 26 Most Common Fallacies of Reasoning
10. Non-Sequitur
In Latin this term translates to "doesn't follow". This refers to an argument in which the conclusion 
does not necessarily follow from the premises. In other words, a logical connection is implied where 
none exists.  
e.g., Billy is honest, therefore he will get a good job.  
(What does one have to do with the other, really?)
11. Reductio ad absurdum
This is basically the use of deductive reasoning or syllogisms to force a false conclusion.  The 
conclusion, in these cases, is often quite absurd!
e.g., 
Socrates was a man.
Socrates was a homosexual.
Therefore, all men are homosexuals.
or
UFO’s probably don’t exist because I’ve never seen one.
I’ve never seen the Great Wall of China.
Therefore, the Great Wall of China probably doesn’t exist.
A2FCP12 - Fallacies of Reasoning


## PDF page 8

The 26 Most Common Fallacies of Reasoning
12. Slippery Slope
This is the assumption that if one thing is allowed it will only be the first step in a downward spiral.  
It assumes that taking a moderate position will automatically lead to an extreme or radical position.
e.g., Handgun control will lead to a police state in which we will have no personal freedoms.
13. Straw Man
When you ‘set up a straw man’, you present your opponent’s argument in way that is easy to attack 
or argue against.  The speaker basically creates an opponent that is easy to defeat.
e.g., So what my worthy opponent is suggesting is that we create ‘death panels’ so that the 
government can decide whether or not your grandmother should live or die.
14. Red Herring
This is dodging or side-stepping the real issue by drawing attention to an irrelevant issue.  It is 
simple changing the subject.
e.g., Why are we worrying about acid rain when drunk driving is the biggest killer in our country?
(nb: This is often used by politicians to avoid troublesome topics)
A2FCP12 - Fallacies of Reasoning


## PDF page 9

The 26 Most Common Fallacies of Reasoning
15. Oversimplification
This is leaving out a relevant consideration about an issue or other, more relevant premises.
e.g., People who pass tests are lucky.  (nb: Many people pass tests because they study for them!) 
or ‘Internet policing was much better twenty years ago; online fraud has increased over 500% since 
then.’  (nb: Left out is the fact that very few people even had Internet twenty years ago!) 
16. Begging the Question / Circular Reasoning (petitio principii)
This is an assertion that simply restates the point just made.  It is circular reasoning in that it draws 
as a conclusion a point stated in the premise or creates a faulty logic.
e.g., Do you want to know why unemployment is on the rise in this country?  It is because more and 
more citizens are having a hard time finding a job.    (nb: This teaches us nothing: It just defines 
unemployment)
e.g.,  Ann: "To approve your application, we need a reference." 
Sam: "Why not talk to my friend Bill?" 
Ann: "OK, but how do I know that Bill is trustworthy?" 
Sam: "I'd be happy to vouch for him."
(nb: we’re going around in circles!)
A2FCP12 - Fallacies of Reasoning


## PDF page 10

The 26 Most Common Fallacies of Reasoning
17. Moving the Goalpost
This occurs when a person moving the criteria for ‘proof’ out of range each time some type of evidence is given.  
Basically, it is a way to keep an inductive argument ‘unresolved’” indefinitely, as one is never satisfied with the 
accumulated evidence.
e.g.,
Alan: “I don’t care if his fingerprints are on the gun.  I don’t believe he killed his wife. No one saw him do it.”
Bill:  “Actually, there are three witnesses who saw him shoot his wife.”
Alan. “OK, but witnesses can lie.  I need hard evidence.”
Bill: “Well, one of the witnesses filmed the entire scene with his cell phone.  Here is the film…”
Alan. “Well, I’ve seen enough Hollywood movies to know it is easy to use special effects that look real.  I’d have to 
see it myself to believe it…”
(This can go on forever, of course!)
18. Tu quoque
Literally, this translates as ‘you too’. This is an attempt to justify wrong action because someone 
else also does it.  It is most common when the behavior of the person making the argument is 
seen as invalidating his or her argument. (It’s the old do-as-I-say-not-as-I-do routine…)
e.g., John has advised me against investing in real estate, but that is how he made his fortune!
e.g., Mom told me to stay away from alcohol, but she has two martinis every night after dinner.
A2FCP12 - Fallacies of Reasoning


## PDF page 11

The 26 Most Common Fallacies of Reasoning
19. Hasty Generalization
This is making your inductive leap far too soon, when there is not enough evidence.  It can be based on too little 
evidence or on exceptional or biased evidence.
e.g. Teenagers are reckless drivers. (or)  All Americans are rich, overweight TV-addicts.
20. False Analogy
This is the assumption that because two things are alike in some ways, they must be alike in other ways.
e.g., Since the books are about the same length and are on the same topic, one must be just as good as the other.
21. Guilt by Association
This is an unfair attempt to make someone responsible for the beliefs or actions of someone close to them.
e.g., Billy hangs out with that drug-taking hoodlum, Carl, after school.  Billy must take drugs, too.
22. Amphiboly/ Double Talk
This occurs when ambiguous sentence structure or grammar leads to two or more possible 
interpretations.It often comes from poor syntax.
e.g., The professor handed back the summaries of the term papers, which were very poorly written. 
(The summaries or the term papers?)
A2FCP12 - Fallacies of Reasoning


## PDF page 12

The 26 Most Common Fallacies of Reasoning
23. Equivocation
This is an assertion that falsely relies on the use of a term in two different senses.  This is a form of wordplay.
e.g., This is a democratic country, isn’t it? Doesn’t it make sense, then, to vote for the Democratic Party?
24. Bandwagon
This is an argument that basically says that if everyone is saying or doing something, then it must be right.
e.g., ‘Everyone is cheating on their history tests, so why shouldn’t I?’  or 
‘It’s common knowledge that homeopathic treatments don’t work as well as prescription medication.’
25. Special Pleading, or Ad-hoc Reasoning
This is a subtle fallacy which is often difficult to recognize. In essence, it is the arbitrary introduction of new 
elements into an argument in order to fix them so that they appear valid.  Basically, it is repeatedly ‘finding 
excuses’ every time something seems to go against your theory or conclusion. (Note the difference 
with ‘Moving the Goalpost’)
For example, a person who does not believe in mind-reading may set up a test with people 
who believe they can read minds.  When the test fails, the mind-reader says that it only 
works if he is well-rested, and he isn’t.  So another test is set up, and the well-rested 
mind-reader again fails.  He then claims that the process simply doesn’t work in the 
presence of skeptics….   (this also can go on forever)
A2FCP12 - Fallacies of Reasoning


## PDF page 13

The 26 Most Common Fallacies of Reasoning
26. The Loaded Question 
This is a trick question that is worded in such a way that no matter how the person answers it, it is bad for him or 
represents him in an unfavorable light.
  
e.g., The classic situation is:
Yes or no professor, have you stopped beating your wife?
(Not matter if he answers 'yes' or 'no', the professor will be considered to have beaten his wife at some point in 
time.)
This trick is used quite often by reporters and lawyers, as in "When did your firm first learn that it was polluting 
the environment?" or "Have you told the members of the group that you have been illegally using hard-earned 
donations from thousands of contributors to pay for your personal expenses?" (Ouch!)
I know that’s a lot to take in, but let’s practice them a little.
A2FCP12 - Fallacies of Reasoning


## PDF page 14

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got 
a light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 15

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got 
a light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 16

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 17

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 18

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 19

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 20

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 21

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 22

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 23

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 24

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 25

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 26

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 27

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 28

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 29

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 30

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 31

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to represent 
us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 32

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 33

Practice with (rather obvious) samples:
Samples of fallacies:  What fallacy is being committed?
1. “Dad says smoking is really bad for you, but he smokes two packs a day.  Have you got a 
light?”
2. “It’s common knowledge that ghosts don’t exist; just ask any reasonable person.”
3. “Martin Van Buren was a bad president.  There was a recession while he was in office.”
4. “How can you accept a defense budget from man who didn’t even serve in the military?
5. “It doesn’t matter which Economics class I take next semester.  They’re both taught by 
the same teacher and use textbooks by the same authors.”
6. “All men are pigs.”
7. “Legalize drugs and soon our nation will be one big sixties’ commune, full of tie-dyed 
zombies calmly murmuring ‘groovy’ to one another.”
8. “Why are we discussing asbestos-related cancer cases when tobacco is the real killer in 
this country?”
9. “It’s up to you: put murderers to death or let them go unpunished.”
10. “We have a republican system of government, don’t we?  We elect officials to 
represent us?  Then how can you say that the Republican Party is not the better choice?”
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 34

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.”  Isn’t the life of a little girl more important than the life of a monkey?  We have to 
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die.  Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 35

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey?  We have to 
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die.  Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 36

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey?  We have to 
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die.  Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 37

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to 
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die.  Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 38

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to 
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die.  Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 39

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 40

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 41

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 42

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important.  And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 43

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 44

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?  
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 45

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 46

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 47

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 48

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited.  Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against 
animal experimentation.  There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 49

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited. Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against
animal experimentation. There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 50

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited. Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against
animal experimentation. There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 51

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited. Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against
animal experimentation. There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 52

Practice with (rather obvious) samples:
This (ridiculous) argument is full of fallacies.  Can you spot all nine?  
As the Oscar-winning director Scavan Kleck has argued, “Animal experimentation saves 
lives.” Isn’t the life of a little girl more important than the life of a monkey? We have to
choose: we can either experiment upon animals to find cures for life-threatening diseases 
or we can stand by helplessly while thousands of children die. Experimentation is necessary 
because research is important. And why should we worry about what happens to animals 
in laboratories when the real threat to animals is how badly they are treated as pets?
Advocates of animal rights are a bunch of sentimental vegetarians who don’t care what 
happens to children, and they’ll never be satisfied with banning painful experiments on 
animals.  If they succeed in getting legislation passed that restricts experimentation, it’s only 
a question of time before the sale of meat is prohibited. Just look at the trouble they’ve 
already caused.  The cost of research has soared since people started protesting against
animal experimentation. There are a lot more people out there in favor of research, 
working for those companies that use it, or waiting for new medical breakthroughs to help 
their lives than there are those who oppose animal research –and there is good reason for 
it!
Selection for these exercises:
ad hominem
false authority
false cause / post hoc
either-or fallacy/ false dilemma
non-sequitur
slippery slope
begging the question
tu quoque
red herring
oversimplification
hasty generalization
false analogy
equivocation
bandwagon


## PDF page 53

II. Two famous examples from The New York Times Op-Ed Page:
Here are the opening paragraphs to two landmark essays on legalizing marijuana in the 
United States. For each one, note the rhetorical mode of organization and the appeal being 
used, and see if you can’t spot any fallacies… 
Opening to “Drugs: A Case for Legalizing Marijuana” by Gore Vidal (1970)
It is possible to stop most drug addiction in the United States within a very short time. 
Simply make all drugs available and sell them at cost. Label each drug with a precise 
description of what effect--good and bad--the drug will have on whoever takes it. This will 
require heroic honesty. Don't say that marijuana is addictive or dangerous when it is neither, 
as millions of people know--unlike "speed," which kills most unpleasantly, or heroin, which 
is addictive and difficult to kick. 
For the record, I have tried--once--almost every drug and liked none, disproving the popular 
Fu Manchu theory that a single whiff of opium will enslave the mind. Nevertheless, many 
drugs are bad for certain people to take and they should be told about them in a sensible 
way…


## PDF page 54

II. Two famous examples from The New York Times Op-Ed Page:
Opening to an opposing essay, “The Case for Slavery” by A. M. Rosenthal (1989) 
Across the country, a scattered but influential collection of intellectuals is intensely engaged 
in making the case for slavery.
With considerable passion, these Americans are repeatedly expounding the benefits of not 
only tolerating slavery but legalizing it:
It would make life less dangerous for the free. It would save a great deal of money. And since 
the economies could be used to improve the lot of the slaves, in the end they would be 
better off.
The new anti-abolitionists, like their predecessors in the 19th century, concede that those 
now in bondage do not themselves see the benefits of legalizing their status.
But in time they will, we are assured, because the beautiful part of legalization is that slavery 
would be designed so as to keep slaves pacified with the very thing that enslaves them!
The form of slavery under discussion is drug addiction. It does not have every characteristic of 
more traditional forms of bondage. But they have enough in common to make the 
comparison morally valid - and the campaign for drug legalization morally disgusting.


## PDF page 55

So, can you see the Matrix?  Let’s find out…
Try the 26 exercises on the PDF handout on your own
BEFORE you watch the next video…


