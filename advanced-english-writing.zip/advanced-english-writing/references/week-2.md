# A2FCP12 Week 2 no video PDF.pdf

## Contents
- PDF page 1: A2FCP12 – Lesson 2 / The Three Types of Appeals in Arguments
- PDF page 2: A2FCP12 – Lesson 2 / The Three Types of Appeals in Arguments
- PDF page 3: A2FCP12 – Lesson 2 / The Three Types of Appeals in Arguments
- PDF page 4: Samples of different appeals in same argument: / Pro-Brexit arguments (‘Leave’ Campaign)
- PDF page 5: Samples of different appeals in same argument:     (out of order) / In favor of sending more ICE agents into US cities to find and deport im
- PDF page 6: Shakespeare’s demonstration of Aristotle: Excerpt from Act III, Sc. 2 of Julius Caesar / Pleading with the Plebes of Rome
- PDF page 7: Julius Caesar, Act III, Sc. 2 / (1st tirade)
- PDF page 8: Julius Caesar, Act III, Sc. 2 / (1st tirade)
- PDF page 9: Julius Caesar, Act III, Sc. 2 / (1st tirade)
- PDF page 10: Julius Caesar, Act III, Sc. 2 / (1st & 2nd tirade)
- PDF page 11: Julius Caesar, Act III, Sc. 2 / (1st & 2nd tirade)
- PDF page 12: Ten Rhetorical Modes for Essay-Writing / (seen in lesson 1)
- PDF page 13: Ten Rhetorical Modes for Essay-Writing / 4. classification (sorting the subject into different groups or kinds)
- PDF page 14: Ten Rhetorical Modes for Essay-Writing / 4. classification (sorting the subject into different groups or kinds)
- PDF page 15: Ten Rhetorical Modes for Essay-Writing / 5. comparison & contrast
- PDF page 16: Ten Rhetorical Modes for Essay-Writing / 5. comparison & contrast
- PDF page 17: Ten Rhetorical Modes for Essay-Writing / 6. providing examples
- PDF page 18: Ten Rhetorical Modes for Essay-Writing / 6. providing examples
- PDF page 19: Ten Rhetorical Modes for Essay-Writing / 7. process analysis (explaining ‘how to’ do something step by step)
- PDF page 20: Ten Rhetorical Modes for Essay-Writing / 7. process analysis (explaining ‘how to’ do something step by step)
- PDF page 21: Ten Rhetorical Modes for Essay-Writing / 7. process analysis (explaining ‘how to’ do something step by step)
- PDF page 22: Ten Rhetorical Modes for Essay-Writing / 7. process analysis (explaining ‘how to’ do something step by step)
- PDF page 23: Before discussing the last three rhetorical modes of organization, be sure to / carefully read and study the four sample essays presented he
- PDF page 24: Three Basic Types of Reasoning:  Inductive, Abductive & Deductive / Inductive Reasoning & Abductive Reasoning
- PDF page 25: Three Basic Types of Reasoning:  Inductive, Abductive & Deductive / Deductive Reasoning
- PDF page 26: The Syllogism / One of the most basic and powerful types of logic is the syllogism, which is then the basis for most
- PDF page 27: Venn Diagrams and Euler Circles: / Syllogisms and logical relations between a finite number of items or groups are often visually
- PDF page 28: Exercises – Part I: / Before things get too complicated, let’s make sure you’ve understood the basic difference between
- PDF page 29: Exercises – Part I: / Before things get too complicated, let’s make sure you’ve understood the basic difference between
- PDF page 30: REMINDER: / WHAT YOU NEED TO DO THIS WEEK:

## PDF page 1

A2FCP12 – Lesson 2
The Three Types of Appeals in Arguments
To understand the three main ways that someone can ‘win over’ their listener/reader in an 
argument, we need to go back to 335 BC, to Aristotle and his key work Poetics. He defined 
rhetoric as "the ability, in each particular case, to see the available means of persuasion," 
thereby making it the basis for argumentation.  He also described three main forms of rhetoric: 
Ethos, Logos, and Pathos—each corresponding to a different appeal to the reader or listener. 
Today we speak of the ethical appeal, the logical appeal and the emotional appeal.
ETHOS
1. The ethical appeal (ad vericundiam) involves making the listener see you as an authority on 
the subject, as someone who has expert knowledge or a recognized and respected position, as 
someone whose opinion should be listened to.  It establishes a ‘reputation’ for the author and 
places him on ‘higher ground’ than that of the listener.
e.g., If in the opening to an argument on the dangers of cigarette smoking the writer explains 
that he or she is a world-renown lung-cancer specialist who has spent forty years on researching 
ties between tobacco and cancer, the argument might instantly gain a good deal of weight.


## PDF page 2

A2FCP12 – Lesson 2
The Three Types of Appeals in Arguments
To understand the three main ways that someone can ‘win over’ their listener/reader in an 
argument, we need to go back to 335 BC, to Aristotle and his key work Poetics. He defined 
rhetoric as "the ability, in each particular case, to see the available means of persuasion," 
thereby making it the basis for argumentation.  He also described three main forms of rhetoric: 
Ethos, Logos, and Pathos—each corresponding to a different appeal to the reader or listener. 
Today we speak of the ethical appeal, the logical appeal and the emotional appeal.
LOGOS
2. The logical appeal, which we have already started studying, appeals to a person’s reason and 
good sense.  We can almost imagine the reader nodding and rubbing his chin as he follows the 
flawless logic to the same conclusion.
e.g. , “We have shown beyond a shadow of a doubt that the defendant was 3000 miles away 
from the crime scene at the time of the murder and was giving a speech to three hundred 
witnesses.  Therefore, the ‘anonymous tip’ that accuses him of the murder is either a mistake or 
an attempt to blame an innocent man.”


## PDF page 3

A2FCP12 – Lesson 2
The Three Types of Appeals in Arguments
PATHOS
3. The emotional appeal, then, tries to get a rise out of the listener or to get their emotions 
going.  There are many variations of this type of appeal, as there is a vast array of emotions that 
the speaker or reader can tap into.
Here are a few examples:  
Appeals to Popular Sentiment (ad populum), Appeals to Pity (ad misericordium), Appeals to 
Indignation, Appeals to Fear, Appeals to Spite, Appeals to Joy, Appeals to Profit, Appeals to 
Popularity, Appeals to Loyalty, Appeals To Force (ad baculum—this can be an appeal to fear as 
well, but it usually involves threatening the reader/listener with harm!)
Of course, in addition to these three main rhetorical types or ‘appeals’, the person presenting 
the argument can utilize any number of common rhetorical devices within his presentation.  
These would include, among many others, the use of metaphors, similes, euphemisms, irony, 
hyperbole, understatement, personification, litotes, etc.  
Remember that with rhetoric, it is not just what you say but how you say it that counts.


## PDF page 4

Samples of different appeals in same argument:
Pro-Brexit arguments (‘Leave’ Campaign)
“As a country with centuries of parliamentary democracy, the UK has proven it can govern itself 
responsibly and should trust its own institutions and lawmakers like myself to make laws without 
external oversight.”
“If the UK leaves the EU, it will no longer be bound by EU trade rules, allowing it to negotiate its own 
trade agreements tailored to its economy, which of course increases policy flexibility.”
“Brexit is about taking back control—about restoring pride in our independence and giving future 
generations a sense that their country determines its own destiny.”
Anti-Brexit arguments (‘Stay’ Campaign)
“Economists, business leaders, and civil servants with decades of experience have consistently 
warned that Brexit would harm the UK’s economy, and their expertise deserves serious attention.”
“The EU is the UK’s largest trading partner, so erecting new trade barriers logically increases costs for 
exporters and consumers, reducing economic efficiency.”
“Brexit risks dividing families, communities, and even the nations of the UK, replacing 
cooperation with uncertainty and fear about jobs, borders, and the future.”


## PDF page 5

Samples of different appeals in same argument:     (out of order)
In favor of sending more ICE agents into US cities to find and deport immigrants:
“Communities deserve to feel safe knowing that the laws protecting them are being enforced and 
that dangerous individuals won’t slip through the cracks.”
“If individuals with final deportation orders are not removed, immigration law loses its deterrent 
effect; therefore, increasing ICE staffing logically improves enforcement of existing law.”
“As a former federal law enforcement officer, I’ve seen firsthand that enforcing immigration law 
consistently is essential to maintaining the rule of law and public trust in our institutions.”
Againts sending more ICE agents into US cities to find and deport immigrants:
“Deploying more ICE agents into cities discourages immigrants from reporting crimes or cooperating 
with police, which then reduces public safety rather than improving it.”
“Mayors, police chiefs, and civil rights organizations across the country warn that aggressive ICE 
operations undermine community trust, and their experience working directly with residents should 
be taken seriously.”
“Sending more ICE agents into neighborhoods means parents afraid to walk their children to 
school and families living in constant fear of being torn apart.”


## PDF page 6

Shakespeare’s demonstration of Aristotle: Excerpt from Act III, Sc. 2 of Julius Caesar
Pleading with the Plebes of Rome
As we saw last semester, Shakespeare clearly structures this famous arguments 
around the three pillars of persuasion outlined by Aristotle in his Poetics…
Text studied 
first semester 
in A1FLT11/12


## PDF page 7

Julius Caesar, Act III, Sc. 2
(1st tirade)
(excerpts – ETHOS)
Friends, Romans, countrymen, lend me your ears.        (ll.73-74)
I have come to bury Caesar, not to praise him.
Here, under leave of Brutus and the rest
(ll.81-87)
(For Brutus is an honorable man;
So are they all, all honorable men),
Come I to speak in Caesar’s funeral.
He was my friend, faithful and just to me,
But Brutus says he was ambitious,
And Brutus is an honorable man.
I speak not to disprove what Brutus spoke,
(ll.100-101)
But here I am to speak what I do know.
And the plebes react to it:
Third Citizen 
There's not a nobler man in Rome than Antony.
(ll.116-117) 
Fourth Citizen 
Now mark him, he begins again to speak.


## PDF page 8

Julius Caesar, Act III, Sc. 2
(1st tirade)
(excerpts – LOGOS)
He hath brought many captives home to Rome,
(ll.88-90)
Whose ransoms did the general coffers fill.
Did this in Caesar seem ambitious?
When that the poor have cried, Caesar hath wept;
(ll.91-92)
Ambition should be made of sterner stuff.
You all did see that on the Lupercal
(ll.95-97)
I thrice presented him a kingly crown,
Which he did thrice refuse. Was this ambition?
And the plebes react to it:
First Citizen 
Methinks there is much reason in his sayings.
(ll.107-109) 
Second Citizen 
If thou consider rightly of the matter,
Caesar has had great wrong. 
Fourth Citizen 
Mark'd ye his words? He would not take the crown;  (ll.112-113) 
Therefore 'tis certain he was not ambitious.


## PDF page 9

Julius Caesar, Act III, Sc. 2
(1st tirade)
(excerpts – LOGOS)
He hath brought many captives home to Rome,
(ll.88-90)
Whose ransoms did the general coffers fill.
Did this in Caesar seem ambitious?
When that the poor have cried, Caesar hath wept;
(ll.91-92)
Ambition should be made of sterner stuff.
You all did see that on the Lupercal
(ll.95-97)
I thrice presented him a kingly crown,
Which he did thrice refuse. Was this ambition?
And the plebes react to it:
First Citizen 
Methinks there is much reason in his sayings.
(ll.107-109) 
Second Citizen 
If thou consider rightly of the matter,
Caesar has had great wrong. 
Fourth Citizen 
Mark'd ye his words? He would not take the crown;  (ll.112-113) 
Therefore 'tis certain he was not ambitious.


## PDF page 10

Julius Caesar, Act III, Sc. 2
(1st & 2nd tirade)
(excerpts – PATHOS)
You all did love him once, not without cause.
(ll.102-107)
What cause withholds you, then, to mourn for him?—
O judgment, thou art fled to brutish beasts,
And men have lost their reason!—Bear with me;
My heart is in the coffin there with Caesar,
And I must pause till it come back to me.
And the plebes react to it: 
Third Citizen 
Has he, masters?
(ll.110-111) 
I fear there will a worse come in his place.
First Citizen 
If it be found so, some will dear abide it.
Second Citizen 
Poor soul! his eyes are red as fire with weeping. (ll.114-115)
But yesterday the word of Caesar might
(2nd tirade, ll.118-127)
Have stood against the world; now lies he there.
And none so poor to do him reverence.
O masters, if I were disposed to stir
Your hearts and minds to mutiny and rage,
I should do Brutus wrong, and Cassius wrong,
Who, you all know, are honourable men:
I will not do them wrong; I rather choose
To wrong the dead, to wrong myself and you,
Than I will wrong such honourable men…


## PDF page 11

Julius Caesar, Act III, Sc. 2
(1st & 2nd tirade)
(excerpts – PATHOS)
You all did love him once, not without cause.
(ll.102-107)
What cause withholds you, then, to mourn for him?—
O judgment, thou art fled to brutish beasts,
And men have lost their reason!—Bear with me;
My heart is in the coffin there with Caesar,
And I must pause till it come back to me.
And the plebes react to it: 
Third Citizen 
Has he, masters?
(ll.110-111) 
I fear there will a worse come in his place.
First Citizen 
If it be found so, some will dear abide it.
Second Citizen 
Poor soul! his eyes are red as fire with weeping. (ll.114-115)
But yesterday the word of Caesar might
(2nd tirade, ll.118-127)
Have stood against the world; now lies he there.
And none so poor to do him reverence.
O masters, if I were disposed to stir
Your hearts and minds to mutiny and rage,
I should do Brutus wrong, and Cassius wrong,
Who, you all know, are honourable men:
I will not do them wrong; I rather choose
To wrong the dead, to wrong myself and you,
Than I will wrong such honourable men…


## PDF page 12

Ten Rhetorical Modes for Essay-Writing
(seen in lesson 1)
1.  narrative & anecdote
sample essay: “Graduation” by Maya Angelou (Chapter 23 of I Know Why the Caged Bird Sings, 1969)
2. description
sample essay: “Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was gunned down in the 
street. How running fails Black America” by Mitchell S. Jackson (June 18, 2020) 
3. division or analysis (breaking something down into parts)
sample essay:“Why I Want a Wife” by Judy Brady-Syfers (1971)
Next Four:
4. classification 
5. comparison & contrast
6. providing examples
7. process analysis


## PDF page 13

Ten Rhetorical Modes for Essay-Writing
4. classification (sorting the subject into different groups or kinds)
sample essay: “Three Types of Resistance to Oppression” by Martin Luther King, Jr. 
(1958)
The Process-
-To classify is to make sense of the world you are presenting by arranging many units into 
more manageable groups, the way zoologists classify animals or librarians classify books 
into categories (fiction, biography, history, etc.).  
-This approach is in many ways the opposite of division analysis, which involves taking 
one thing and breaking it into parts.  
-Classification is usually based on similarities and differences
-Classification can become far more complex if one begins to add subcategories to 
one or more categories.
-The subject chosen for classification can be specific, but is usually a large group 
(e.g., mall shoppers, receptionists, grad students, French cars, beneficiaries of white 
privilege,  etc.)


## PDF page 14

Ten Rhetorical Modes for Essay-Writing
4. classification (sorting the subject into different groups or kinds)
sample essay: “Three Types of Resistance to Oppression” by Martin Luther King, Jr. 
(1958) (from his first book: Stride Toward Freedom: The Montgomery Story)
Background on the Rev. Dr. Martin Luther King, Jr.
-U.S. Baptist minister born in Georgia who became the spokesperson for the Civil 
Rights Movement from the 1955 Montgomery Bus Boycott to his assassination in 
Memphis, Tennessee, in 1968.
-preached non-violence and civil disobedience
-famously organized the 1963 March on Washington where he delivered his ‘I Have a 
Dream’ speech on the steps of the Lincoln Memorial, on the anniversary of Lincoln’s 
Emancipation Proclamation
1964 - Awarded Nobel Peace Prize
1965 – Organized Selma to Montgomery Marches; expanded causes to include 
women’s rights and anti-Vietnam War
1968 –Assassinated while organizing another march on Washington
Posthumously awarded Presidential Medal of Freedom, Congressional Gold Medal 
and a national holiday since 1971. 


## PDF page 15

Ten Rhetorical Modes for Essay-Writing
5. comparison & contrast
sample essay: “Racism and Recapitulation” by Stephen Jay Gould (1977)
The Process:
-The method is very simple: you chose to point out the similarities (comparison) and/or 
the differences (contrast) between two things
-The goal can be to show a preference between the two, but it could be simply to 
differentiate between them, or to show that the two items have more in common than 
first meets the eye.
-The chosen subjects must have something in common for their juxtaposition to make 
sense.  Their must be a basis for comparison. (e.g., California wine versus French wine, 
a small town versus a big city.
-When you try to show similarities between two apparently unrelated things, very often 
you create analogy.  For example, this would be the case if you decided to compare the 
workings of the human eye to the use of a simple camera.
-You have to beware not to bite off more than you can chew.  For example, comparing 
the Russian way of life to the American way of life would be impossible to do in a short 
essay, but comparing Russian customs officers to American ones might be feasible.


## PDF page 16

Ten Rhetorical Modes for Essay-Writing
5. comparison & contrast
sample essay: “Racism and Recapitulation” by Stephen Jay Gould (1977)
Background on Stephen Jay Gould:
-Born 1941 in Queens, NYC
-Famous American paleotologist, biologist and ‘historian of science’
-in 1960s, was very active in Civil Rights Movement while studying in Ohio, and even 
while studying abroad (he protested a ‘whites only’ dance hall in Leeds, England).
-he often attacked how science was twisted to serve racist and sexist beliefs
-became a ‘popular’ scientist on public broadcasting programs, seen as a specialist on 
Evolution (a predecessor to Bill Nye), while advancing award-winning theories on 
evolutionary biology.
-taught at Harvard and NYU
-Battled cancer for 20 years before his death in 2002.
His essay ‘Racism and Recapitulation’ applies scientific techniques and philosophical 
perspectives to a critical analysis of the controversial racial (and racist) theories of 
Brinton and Bolt, showing that they are equally flawed.


## PDF page 17

Ten Rhetorical Modes for Essay-Writing
6. providing examples
sample essay: “Just Walk on By: Black People and Public Space” by Brent Staples (1986) 
The Process of ‘Instances & Examples’
-The word ‘example’ comes from the Latin exemplum, meaning “one thing selected from among many”
-Often used to give weight to a general statement or generalization, to provide ‘proof’ to support a broad 
statement being put forth 
-Examples allow you to bring your ideas down to earth and make theories concrete and comprehensible
-An essay can rely on one ‘extended example’, a series of short examples, or any combination of concise 
and extended examples.
-Students often find a good number of examples to help them with their essays from their own life 
experiences. Be sure to try to find examples that are both appropriate and convincing.
-hypothetical examples are risky but sometimes necessary. This is often speculation, 
but an imagined example is often better than no example at all.  
-Try to be as specific as possible when giving examples; it gives an air of 
authenticity to your work and gives more weight to your argument  
-Example essays often use short narratives as illustrations (use of ‘anecdotes’) 
or detailed description, both of which are rhetoric devices in their own right


## PDF page 18

Ten Rhetorical Modes for Essay-Writing
6. providing examples
sample essay: “Just Walk on By: Black People and Public Space” by Brent Staples (1986) 
About Brent Staples (1951-)
-famous American author and longtime editorial writer for The New York Times (still 
active)
-born in Pennsylvania; a graduate of Widener University and the University of Chicago
-books include An American Love Story (1999) and Parallel Time: Growing up In Black and 
White (1994), which won the Anisfield Wolff Book Award.
-Staples often tackles controversial issues, most notably that of race and of the American 
system of education.
-"Black Men and Public Space", a short article widely published by Harper's magazine in 
December of 1987, is often found in student anthologies. It was previously published as 
“Just Walk on By” in Ms. Magazine in September of 1986.
-Note how Staples uses a series of examples from his own experience to get his point 
across. His essay is a combination of personal anecdote (narrative) and example modes.


## PDF page 19

Ten Rhetorical Modes for Essay-Writing
7. process analysis (explaining ‘how to’ do something step by step)
sample essay: “How Our Skins Get Their Color” by Marvin Harris (1988)
The Process (of ‘process analysis’):
-dividing subject up into components again, this time in terms of steps or stages of a 
process
-usually makes a complex process easier to understand [e.g., How mountains or 
hurricanes form, how dinosaurs became extinct, how a bill becomes a law, how a serious 
freshman student becomes a lazy sophomore (or vice-versa)]
2 basic types of process analysis:
1. Directive – telling someone how to do something  (e.g., giving directions to go from 
Victoria Station to Picadilly Circus, on making tie-dyed Easter eggs, on how to insulate a 
wall, on how to vote when living abroad, etc.)
2. Informative – telling how something is done (e.g., how a fertilized egg becomes an 
embryo, how smoking can lead to lung cancer, how corpses are embalmed, how a bill 
becomes a law, how the earth will react to global warming, etc.)


## PDF page 20

Ten Rhetorical Modes for Essay-Writing
7. process analysis (explaining ‘how to’ do something step by step)
sample essay: “How Our Skins Get Their Color” by Marvin Harris (1988)
The Process (of ‘process analysis’):
-Newspapers and magazines are full of both types.  Pick up a copy of Cosmopolitan and you might find an 
article on how a certain new beauty cream reduces wrinkles (informative) and another on how to find the 
man of your dreams (directive).  In Popular Mechanics, you can read how to build your own ping-pong table 
(directive) and how the new hybrid engines work (informative).  There are also lots of books devoted to this 
approach: from self-help books (How to Win Friends and Influence People, How to Pick up Girls, Computer 
Programming for Dummies, etc.) to history books (How the West Was Won, How the Allies Won the War, etc.) 
to science books (How the Universe Was Formed, How Our Genes Control Our Lives, How Greenhouse Gases 
Will Affect Our Climate, etc.) to political papers (How to Fight Capitalism, How to Get through the Recession, 
etc.) to scores of other types of books as well.  


## PDF page 21

Ten Rhetorical Modes for Essay-Writing
7. process analysis (explaining ‘how to’ do something step by step)
sample essay: “How Our Skins Get Their Color” by Marvin Harris (1988)
The Process (of ‘process analysis’):
When writing this type of essay, a good deal of preliminary work is necessary.  You must outline the steps 
yourself and go over them to make sure nothing important is left out. The order of 
presentation has to be checked as well, even if all processes are not necessarily 
given in chronological order).
Remember your audience. Are you writing for someone with no specialized knowledge 
of the topic (usually called a ‘layperson’), or are you writing for someone with expert 
knowledge?  Your vocabulary and the amount of detail you provide would not be the 
same for both, of course.
Be sure to use time-markers and clear transitions to move from stage to the next.  
The reader needs these ‘sign posts’ if he or she is not to skip any stages and to 
thoroughly understand the process. 


## PDF page 22

Ten Rhetorical Modes for Essay-Writing
7. process analysis (explaining ‘how to’ do something step by step)
sample essay: “How Our Skins Get Their Color” by Marvin Harris (1988)
About Marvin Harris (1927-2001):
-a famous cultural anthropologist from Brooklyn, New York 
-studied and taught for three decades at Columbia University, then at the University of 
Florida
-His 18 books include The Rise of Anthropological Theory (1968); Cows, Pigs, Wars and 
Witches: The Riddles of Culture (1974); Cannibals and Pigs: The Origins of Culture
(1977), The Sacred Cow and the Abominable Pig: Riddles of Food and Culture (1987), 
and the well-known student textbook  Culture, People, Nature . 
-He focused greatly on culture and more specifically what he called ‘cultural materialism’, 
which showed parallels between social class, infrastructure and culture
-He is famous for explaining complicated scientific processes to laypeople. 
-This famous essay is taken from his 1988 book Our Kind: Who We Are, 
Where We Came from, Where We Are Going, In it, Harris tries to make the lay reader 
understand exactly what ‘race’ is.  His approach is simplified and scientific, yet his 
aim is much deeper, as the information could, hopefully, make people think differently 
about race.


## PDF page 23

Before discussing the last three rhetorical modes of organization, be sure to 
carefully read and study the four sample essays presented here.
Not only will questions on these essays be included on your first test, but you 
have a short assignment to do before the end of week two.
WHAT YOU NEED TO DO THIS WEEK (Week 2):
1. Carefully read the four essays presented above, taking notes.
2. Short Assessment of Readings for Week 2 (not graded but part of 
participation)
Use the Google Form link on iCampus to select which of these four essays 
you found the most effective and the least effective, and give a few sentences 
of justification for each choice.
3. Study the lessons on three types of appeals & three types of reasoning 
(next slides) carefully. Then take the practice test I set up for you on iCampus.


## PDF page 24

Three Basic Types of Reasoning:  Inductive, Abductive & Deductive
Inductive Reasoning & Abductive Reasoning
Inductive reasoning is quite common and based upon arguments which do not contain ‘categorical’ 
support for a conclusion.  There are no absolutes here, as the conclusion is usually the most 
probable one, which means that it is possible for all the premises to be true and the conclusion to 
turn out to be false. It involves the collection of evidence or proof.  When one feels he has enough 
proof, he makes an ‘inductive leap’ and draws his conclusion.  We usually say that conclusions are 
‘cogent’ rather than ‘true’, as they are based on probabilities.  
If the ‘leap’ is based on a hunch, instinct and very little evidence, this is then abductive reasoning.
This type of reasoning is very often necessary in research, for example, when the researcher has to
make an ‘educated guess’ at what the cause of something might be or what the best course of 
future action might be.  
A2FCP12 – Types of Argumentation


## PDF page 25

Three Basic Types of Reasoning:  Inductive, Abductive & Deductive
Deductive Reasoning
Unlike with induction, if the premises in a deductive argument are true and the reasoning is sound, 
then you can be absolutely sure that the conclusion is true.  Deduction makes the strong claim that 
the conclusion must follow the premises out of strict necessity.  This is more mathematically based 
logic, based on syllogisms:
For example:                     Or:
But be careful…
A = B        All humans die eventually.
Socrates is mortal.
B = C 
I am a human being.
All men are mortal.
: A = C,
Therefore, I will eventually die.
Thus, all men are Socrates.
As you see, if one or more of the premises is false, or if there is fallacious reasoning, the conclusion 
can be untrue (usually called ‘invalid’), or even absurd. 
A2FCP12 – Types of Argumentation


## PDF page 26

The Syllogism
One of the most basic and powerful types of logic is the syllogism, which is then the basis for most 
forms of deductive reasoning.  Syllogisms consist of a minor premise, a major premise, and a 
conclusion, and are of the form If A=B; and B=C; then A=C, as we have seen above.  Here’s one 
more example:  
Minor premise:
Murphy is a dog
Major premise:
All dogs can bark
Conclusion:
Murphy can bark.
If both of the premises of a syllogism are true and the reasoning is sound, then the conclusion has 
to be valid.  Later in this unit we will see many ways in which faulty reasoning can lead to (possibly) 
invalid conclusions.
A2FCP12 – Types of Argumentation


## PDF page 27

Venn Diagrams and Euler Circles:
Syllogisms and logical relations between a finite number of items or groups are often visually 
represented through set diagrams, the two most common of which are Venn diagrams (invented in 
1880 by English mathematician John Venn) and Euler Circles (invented earlier, by Swiss 
mathematician Leonhard Euler in 1770s, with less focus on unmentioned factors).
Syllogism:
-All men are mortal.
-Socrates was a man.
-Socrates was mortal.
A2FCP12 – Types of Argumentation


## PDF page 28

Exercises – Part I:
Before things get too complicated, let’s make sure you’ve understood the basic difference between 
the three types of reasoning we discussed. Deductive, Inductive or Abductive?
1.  I’ve never met an American who didn’t like to watch television.  Their culture must be much 
more TV-oriented.
2. The NRA is one of the most powerful lobbies in the U.S., and they fight for an individual’s right to 
carry guns for protection of home and family.  Bill Clark is a member of the NRA, and thus he is 
opposed to gun control.
3. The only way this poison could have gotten into the man’s bloodstream, I believe, is if it was 
mixed in with his food. His stomach contents should be checked for high concentrations of this rare 
poison.
4. “Thou shalt not kill” is one of the Ten Commandments, and killing one’s fellow man is one of the 
most heinous crimes in our society.  Executing a criminal, whatever his offence, is in fact an 
organized killing, and is itself a heinous crime.
5. There’s a good chance these problems were caused by allergies – possibly an allergy to certain 
foods common to this region that you are not used to consuming.  I’ll prescribe a blood test and a 
clinical test to check for those specific allergies. 
A2FCP12 – Types of Argumentation


## PDF page 29

Exercises – Part I:
Before things get too complicated, let’s make sure you’ve understood the basic difference between 
the three types of reasoning we discussed. Deductive, Inductive or Abductive?
6. It is morally wrong to let another human being go on suffering. Euthanasia prevents a person 
from continuing to suffer, and it is thus a morally justified act.
7. O.J. was found fleeing the scene with the blood of the victims on his trousers, and a pair of 
bloody gloves were discovered, one in his Jeep and the other in his home.  DNA tests later proved 
that there was some of the victims’ blood on the towel in the lavatory on the plane he took to 
Chicago that night, and some of his own blood was found at the crime scene in Westwood.  He also 
has no alibi for what he was doing at the time.  He’s clearly guilty.
8.  If ‘God is Love’ and ‘Love is blind’, and Ray Charles is blind, then Ray Charles must be God.
A2FCP12 – Types of Argumentation


## PDF page 30

REMINDER:
WHAT YOU NEED TO DO THIS WEEK:
1. Carefully read the four essays presented above, taking notes.
2. Short Assessment of Readings for Week 2 (not graded but part of 
participation)
Use the Google Form link on iCampus to select which of these four essays 
you found the most effective and the least effective, and give a few sentences 
of justification for each choice.
3. Study the lessons on three types of appeals & three types of reasoning 
carefully. Then take the practice test I set up for you on iCampus.


