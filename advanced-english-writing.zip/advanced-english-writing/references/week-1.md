# A2FCP12 Week 1 work no video.pdf

## Contents
- PDF page 1: General Presentation of the A2FCP12 Class / Goal of the Class
- PDF page 2: An Introduction on Writing: A Writer’s Questions / 4
- PDF page 3: Unit II: Journalistic Writing / A. The American Journalism Handbook – Concepts, Issues, and Skills, 1st Ed. (Zamith)
- PDF page 4: Unit II: Journalistic Writing / A. The American Journalism Handbook – Concepts, Issues, and Skills, 1st Ed. (Zamith)
- PDF page 5: Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS / A. Civilization Studies: The United Kingdom
- PDF page 6: Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS / B. Civilization Studies: The United States
- PDF page 7: Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS / C. Literary Studies (excerpts)
- PDF page 8: Reminder: GRADING / Week 6 Online Midterm = 25% of your grade
- PDF page 9: Syllabus for A2FCP12 (TREDY) / Week I: (January 19th)
- PDF page 10: Syllabus for A2FCP12 (TREDY) / Week V: (February 16th)
- PDF page 11: Syllabus for A2FCP12 (TREDY) / Week X: (March 30th)
- PDF page 12: Introduction in Brochure: / Read “An Introduction on Writing: A Writer’s Questions” in the brochure
- PDF page 13: Ten Rhetorical Modes for Essay-Writing / (in lesson 1)
- PDF page 14: Ten Rhetorical Modes for Essay-Writing / 1.  narrative & anecdote
- PDF page 15: Ten Rhetorical Modes for Essay-Writing / 1.  narrative & anecdote
- PDF page 16: Ten Rhetorical Modes for Essay-Writing / 1.  narrative & anecdote
- PDF page 17: sample essay: “Graduation” by Maya Angelou / (Chapter 23 of I Know Why the Caged Bird Sings, 1969)
- PDF page 18: Ten Rhetorical Modes for Essay-Writing / 2. description
- PDF page 19: Ten Rhetorical Modes for Essay-Writing / 2. description
- PDF page 20: Ten Rhetorical Modes for Essay-Writing / 2. description
- PDF page 21: sample essay: “Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was gunned / down in the street. How running fails Black Amer
- PDF page 22: Ten Rhetorical Modes for Essay-Writing / 3. division or analysis (breaking something down into parts)
- PDF page 23: Ten Rhetorical Modes for Essay-Writing / 3. division or analysis (breaking something down into parts)
- PDF page 24: Before discussing the other seven rhetorical modes of organization, be sure to / carefully read and study the three sample essays presented 

## PDF page 1

General Presentation of the A2FCP12 Class
Goal of the Class
Source Material You Need:
-The A2CFP12 Brochure
Three Main Units:
Unit I: The Mechanics of Good Essay-Writing  (Focus on Opinion Writing)
(Rhetorical Modes, Ten Samples Essays, Types of Appeals, Types of Reasoning, Fallacies of 
Reasoning, Style Sheets & Plagiarism, Writing Proper Paragraphs, Common Mistakes in Sentence 
Structure, Grammar, Pitfalls, etc.)
Unit II: Journalistic Writing (Just the facts…)
(The journalistic approach, types of journalistic writing, the inverted pyramid technique, sample 
newspaper articles).
Unit III: Academic Writing: Commentaries, the Basics
(The basic rules for writing textual commentaries, sample texts and practice in Civi GB, Civi US, 
British Lit & American Lit).
Let’s take a look at the student booklet….


## PDF page 2

An Introduction on Writing: A Writer’s Questions
4
Unit I: The Mechanics of Good Esay-Writing 
A. The Ten Rhetorical Modes & Sample Essays
10
1. narration & anecdote: “Graduation” by Maya Angelou (1969)
11
2. description: “Twelve Minutes and a Life…” by Mitchell S. Jackson (2020)
17
3. division or analysis: “Why I Want a Wife” by Judy Brady-Syfers (1971)
23
4. classification: “Three Types of Resistance to Oppression” by Martin Luther King, Jr. (1958)
25
5. comparison & contrast: “Racism and Recapitulation” by Stephen Jay Gould (1977)
27
6. providing examples: “Just Walk on By: Black People and Public Space” by Brent Staples (1986)
32 
7. process analysis: “How Our Skins Get Their Color” by Marvin Harris (1988)
35
8; definition: “The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979)
37
9. cause and effect: “Groping toward That Invisible Light” by Richard Wright (1930)
39
10. argument: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)
50
B. Fallacies of Reasoning – General list of Fallacies
53
Practice Exercises on Fallacies of Reasoning
54
C. Tips on Writing College Papers
57


## PDF page 3

Unit II: Journalistic Writing
A. The American Journalism Handbook – Concepts, Issues, and Skills, 1st Ed. (Zamith)
64
B. Sample News Articles
1. “Young Women are Radicalizing…” by Scarlett Maguire
91
2. “MPs across UK Parties Criticise Ministers over Cautious Stance on Venezuela Attack…” by 
Kiran Stacey and Sammy Gecsoyler
94
3. “Some Trumpists Object to MAGA’s White Power Element. Why Now?” by Matt K. Lewis
96
4. “Fierce Backlash within GOP after Tucker Carlson Gives White Nationalist Nick Fuentes a 
Platform” by Andrew Kaczynski and Steve Contorno
98
5. “Tucker Carlson’s Interview with Antisemite Nick Fuentes Exposes Rift among Republicans”, 
PBS News Hour
101
6. “They Saw Their Neighbors Taken Away by ICE…” by Michelle Goldberg
103
7. “ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor” by Joel Kotkin
107
8. “Protests against ICE Have Continued in LA into the Week...” by Ayana Archie
109 


## PDF page 4

Unit II: Journalistic Writing
A. The American Journalism Handbook – Concepts, Issues, and Skills, 1st Ed. (Zamith)
64
B. Sample News Articles
1. “Young Women are Radicalizing…” by Scarlett Maguire
91
2. “MPs across UK Parties Criticise Ministers over Cautious Stance on Venezuela Attack…” by 
Kiran Stacey and Sammy Gecsoyler
94
3. “Some Trumpists Object to MAGA’s White Power Element. Why Now?” by Matt K. Lewis
96
4. “Fierce Backlash within GOP after Tucker Carlson Gives White Nationalist Nick Fuentes a 
Platform” by Andrew Kaczynski and Steve Contorno
98
5. “Tucker Carlson’s Interview with Antisemite Nick Fuentes Exposes Rift among Republicans”, 
PBS News Hour
101
6. “They Saw Their Neighbors Taken Away by ICE…” by Michelle Goldberg
103
7. “ICE Raids Are Cruel, but So Is an Economy Built on Undocumented Labor” by Joel Kotkin
107
8. “Protests against ICE Have Continued in LA into the Week...” by Ayana Archie
109 


## PDF page 5

Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS
A. Civilization Studies: The United Kingdom
“The English Turned Barbados into a Slave Society…” by Suleiman Bulbulia, The Guardian (2021)
113
“Boris Johnson’s Phoney Posturing at the French Won’t Resolve the Migrant Crisis…” by Andrew Rawnsey
116
“Labour Needs Its Own Answer to the Channel Crisis” by Patrick O'Flynn, The Spectator (2021)
119
“The UK and France Must Mend Ties – Lives Depend on It…” by Peter Ricketts, The New Statesman (2021)
121
“This Is the Real Reason Priti Patel Has Been Barred from France” by Sean O’Grady, The Independent (2021) 123
“Boris’s Blundering Brilliance…” by Andrew Sullivan, New York Magazine (2019)
125
“Post-Brexit, We Need Real Capitalism – Not Stealth Foreign Nationalisation” by Allister Heath
127


## PDF page 6

Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS
B. Civilization Studies: The United States
“Remarks at the Democratic National Convention” by Bill Clinton, Aug. 29, 1996
129
“In Defense of Monica” by Amelia Richards and Jennifer Baumgardner, The Nation (1998)
131
“Address on the U.S. Response to the Attacks on September 11” by George W. Bush, Sept. 22, 2001
133
“The Renaissance of Anti-Intellectualism” by Tod Gitlin, Chronicle of Higher Education (2000)
135
“Speech on Health Care Reform” by Barack Obama, March 15, 2010
137
“How the US Justifies Drone Strikes…” by Jameel Jaffer, The Guardian (2016)
139
“Speech Declaring a National Emergency” by Donald Trump, Feb. 15, 2019
141
“Donald Trump Is a Good President: One Foreigner’s Perspective” by Michel Houellebecq (2019)
142
“‘Clueless’ and ‘Saved by the Bell’ Are How We Got Trump…” by Lindy West, The New York Times (2019)
144


## PDF page 7

Unit III: ACADEMIC WRITING: COMMENTARIES, THE BASICS
C. Literary Studies (excerpts)
Wuthering Heights (1847), by Emily Brontë
147
Heart of Darkness (1902), by Joseph Conrad
148
Atonement (2001), by Ian McEwan
149
The Scarlet Letter (1850), by Nathaniel Hawthorne
151
The Human Stain (2000), by Philip Roth
153
No Country for Old Men (2005), by Cormac McCarthy
155


## PDF page 8

Reminder: GRADING
Week 6 Online Midterm = 25% of your grade
CC Work (homework & participation) = 25% of your grade
In-person Final Exam at Nation = 50% of your grade
Important: New University Rules concerning missed assignments!
If you miss even one of these three graded assignments, you will not only get an ABI 
(absence injustifiée) for that assignment but will automatically get an ABI for the class 
(not grade calculated for the whole bloc UE Fondamentales until you take the resit
(rattrapage) in June.
If you have a medical excuse or other written justification, you will get an ABJ (absence 
justifiée) for the assignment, but an ABJ still counts as a zero for that assignment (but 
your grade for the class and the bloc UE Fondamentales will still be calculated). 


## PDF page 9

Syllabus for A2FCP12 (TREDY)
Week I: (January 19th)
Presentation of Class & Brochure
Why Write?
10 Rhetorical Modes Part I (3 modes) + brief assessment to write
Week II: (January 26th)
Three Types of Appeal (Aristotle)
10 Rhetorical Modes Part II (4 modes) + brief assessment to write
Three Types of Reasoning (30”)
Week III: (February 2nd)
10 Rhetorical Modes Part III (3 modes) + brief assessment to write
Fallacies Part One (1h30)
Exercises to do at home
Week IV: (February 9th)
Fallacies Part Two & Trump’s Tweets during First Term (1h)
Google Sheet: Fallacies you come across in the news
Paragraphs Part One (1h)


## PDF page 10

Syllabus for A2FCP12 (TREDY)
Week V: (February 16th)
Paragraphs II & Style Sheets (1h)
Common Mistakes in Sentence Structure
(Study for Midterm)
Week VI: (February 23rd)
Online Midterm on Unit I
Start Unit II: Journalistic Writing
Week VII: (March 9th)
Journalistic Writing II
Practice Exercises to do
Week VIII: (March 16th)
Unit III – Writing Commentaries
Rules and examples
Week IX: (March 23rd)
Commentaries in Civilization vs Commentaries in Literature
Homework Due: A commentary on an excerpt in the brochure


## PDF page 11

Syllabus for A2FCP12 (TREDY)
Week X: (March 30th)
Commetaries III
Sample: Huck Finn
Week XI: (April 7th)
Correction of Week IX Essays
Review for Final Exam
IN-PERSON FINAL EXAM 
At Nation, during the ‘session des épreuves longues’ (April 27th to May 7th)


## PDF page 12

Introduction in Brochure:
Read “An Introduction on Writing: A Writer’s Questions” in the brochure
This text is used in writing classes in the US and Great Britain, for both fiction and non-fiction 
writing classes.
The focus of the text:
-Having a clear purpose when you write
-Doing ‘discovery writing’ (brainstorming, rough drafts)
-How Creative Writing and Non-Fiction Writing Can Overlap
-The importance of finding the right tone and style
-The importance of finding and following the right structure
-The dangers of bias and fallacious reasoning
-Sticking to a step-by-step process (planning, drafting, researching, revising & editing)
All of these points will be expanded on in one way or another throughout the semester….


## PDF page 13

Ten Rhetorical Modes for Essay-Writing
(in lesson 1)
(cf. structure, tone, purpose, etc.)
1.  narrative & anecdote
2. description
3. division or analysis
(in lesson 2)
4. classification
5. comparison & contrast
6. providing examples
7. process analysis
(in lesson 3)
8. definition 
9. cause and effect 
10. argument


## PDF page 14

Ten Rhetorical Modes for Essay-Writing
1.  narrative & anecdote
sample essay: “Graduation” by Maya Angelou (Chapter 23 of I Know Why the Caged Bird Sings, 1969)
The Process:
-Storytelling isn’t just for fiction; ‘true’ stories, no matter how embellished, can have strong impact in an 
essay
-Personally experiencing a topic under discussion can give a strong “ethical appeal’ (Aristotle’s Poetics), 
give a certain level of ‘authority’ on the topic to the author
-It can powerfully engage the reader on a personal level more than hypothetical examples, for example, 
could.
-Anecdotes and narratives are often memorable and stay with the reader
-Every story, long or short, has a purpose (to entertain, to teach a lesson, to provide a warning, to kill 
time, etc.), but one or more stories can be employed within an essay with a larger overall purpose.
-Narratives can often make a very strong point without ever formulating that point 
into words (eg, a story of all of the impossible hoops one has to go through to get 
an American work visa, the Catch-22s and the red tape and the delays, etc., could 
be even more convincing than cold statistics to clearly claim that the work-visa 
process does not work properly and is unfair).


## PDF page 15

Ten Rhetorical Modes for Essay-Writing
1.  narrative & anecdote
sample essay: “Graduation” by Maya Angelou (Chapter 23 of I Know Why the Caged Bird Sings, 1969)
The Process:
-Though personal accounts carry more weight, those of others (if ‘true’) still carry some weight, though 
hypothetical stories, in an essay, wouldn’t carry much weight at all.
-Obviously, telling your own story allows for more subjectivity and relies on the first-person; telling 
someone else’s forces you to be more of an observer, and abide by third-person narration
-Even brief stories are usually complete, and contain most if not all of the ‘5 W’s & the H’
-The importance of details, the ‘effet de réél’. Verisimilitude and credibility can be boosted by the use of
details, or research if necessary. 
-As with all writing modes, consider your audience. Imagine how different one’s tone would be if writing 
an account of being the victim of racism, knowing that your audience will be all minorities and non-
white, or if the audience will be all old white men. The tone and content of the 
storytelling would surely be quite different.
-Good storytellers know what to emphasize to get their point across and will 
never be accused of rambling or droning on


## PDF page 16

Ten Rhetorical Modes for Essay-Writing
1.  narrative & anecdote
sample essay: “Graduation” by Maya Angelou (Chapter 23 of I Know Why the Caged Bird Sings, 1969)
The Process:
-Determine if you will proceed by scene or by summary, or how you will balance the two. Will you go 
micro or macro, and for how long. Will it be a series of connected anecdotes with summary for those 
connections? Will one extended and detailed story/anecdote do the whole job (often the case with Maya 
Angelou)
-Avoid telling stories in the present tense. Some writers feel it gives their stories a sense of immediacy, 
but it also sounds like informal ‘chat’.
-When narrative is used as a device in a non-fiction essay, chronological order is usually respected and 
the story is very pointed. This is not a novel or novella in which anachronies and convoluted storylines 
will get your point across… 
-Special format for a news story: the inverted pyramid. This ‘facts first’ approach 
can be modified to use for essays, though it would be far less repetitive than the 
journalistic format.


## PDF page 17

sample essay: “Graduation” by Maya Angelou 
(Chapter 23 of I Know Why the Caged Bird Sings, 1969)
Background on Maya Angelou:
-born Marguerite Johnson in St. Louis, Missouri, in 1928
-raised with her brother, Bailey, in Stamps, Arkansas, by her grandmother who 
operated a country store
-worked briefly as a dancer in Los Angeles, and jobs as varied fry cook, sex worker 
and Christian missionary abroad.
-became an activist in the Civil Rights Movement in New York City and worked with 
Martin Luther King, Jr. As well as Malcolm X. 
-through her 7 autobiographies (the first of which was I Know Why the Caged Bird 
Sings), 3 books of essays, collections of poetry, plays, films & TV programs, an 
average of 80 speaking performances a year later in life and 50 honorary degrees, 
she has long been an icon for the struggles of African-Americans and for women in 
general.
She died in 2014 of lung failure at the age of 86.


## PDF page 18

Ten Rhetorical Modes for Essay-Writing
2. description
sample essay: “Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was gunned down in the 
street. How running fails Black America” by Mitchell S. Jackson (June 18, 2020) 
-Certainly, description and narration are often intertwined, though you can have one without the other, or at 
times both at once. 
-Description implies details, providing impressions through any or all of the five senses.
Nearly all of the other modes of rhetorical organization can use description to some degree, more frequently 
even than narrative in non-fiction essays. 
-Description is often used to convey information without bias or emotion, but it can be conveyed with feeling 
as well. Technical or scientific descriptive writing is usually objective (e.g., the parts of an internal combustion 
engine, a description of a new animal species, what Chicago looked like at the turn of the century, etc.). 
However, certain subject matters tend to push even the objective-minded writers toward more subjective, 
emotional, personal or impressionistic description (e.g., the description of a devastated New Orleans after 
Hurricane Katrina, or of a mass grave uncovered in a war-torn country, or a violent 
insurrection that took place at the State Capitol). It would be extremely difficult to 
stay completely neutral, unemotional and impartial when describing such things. 
Then again, a writer can purposely choose a subjective or emotional point of view, 
even on what might otherwise be considered an unemotional scene. This is when 
bias, wilful or not, steps in. 


## PDF page 19

Ten Rhetorical Modes for Essay-Writing
2. description
sample essay: “Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was 
gunned down in the street. How running fails Black America” by Mitchell S. Jackson 
(June 18, 2020) 
-Note that, description always involves some degree of selection (no essay would want an 
overly drawn-out and boringly exhaustive description of anything). Yet note how 
‘selection’ also plays into possible biased and subjective description. One right-leaning 
news channel, for example, regularly described the protestors who stormed the Capitol in 
Washington in January as ‘patriotic Americans’ who ‘supported their president’ and ‘were 
convinced they were fighting the good cause’ and ‘didn’t cause much material damage 
out of respect for the government buildings’. All of those details are true, but it is a very 
selective way of only describing those details that support a certain narrative or angle. A 
center-left news channel, on the other hand, described them as “insurrectionists calling 
for the overthrow of the American government’ who ‘fought violently with the police 
they claim they support’ as they ‘stormed the capitol’ screaming ‘Hang Mike Pence’ (then 
Vice President) and with some threatening to shoot Nancy Pelosi (then Speaker of the 
House), in an ‘attack that left six people dead’. All of those details are true too, but some 
might say it is also selective and lends itself to a different narrative.  
-We will return to matters of bias and emotional appeals in a later lesson.


## PDF page 20

Ten Rhetorical Modes for Essay-Writing
2. description
sample essay: “Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was 
gunned down in the street. How running fails Black America” by Mitchell S. Jackson 
(June 18, 2020) 
When writing a description essay, all of these things need to be decided on before writing 
(how subjective/objective, how selective/thorough, which details matter the most, etc.). 
You also need to think of your audience and how well they know the topic and what they 
need or do not need to be told. Describing the mechanics of a jet engine for an 
engineering team would be far more detailed than a description for a middle-school 
textbook, just as describing a rainbow after a rainstorm would sound very different if 
explained to a child, a landscape painter or someone who is vision-impaired. So keep 
your audience in mind.
Another matter to decide on is ‘scope’ and ‘distance’ – will you describe something as if 
you are up close (the micro-view) and from a distance (the macro-view)? This then ties 
into matters of selection…
There is also the matter of whether you will rely on no-nonsense down-to-earth details 
and exact language in your description, or instead imaginative flourishes, use of 
metaphors and similes, using idioms or figures of speech, etc.


## PDF page 21

sample essay: “Twelve Minutes and a Life: Ahmaud Arbery went out for a jog and was gunned 
down in the street. How running fails Black America” by Mitchell S. Jackson (June 18, 2020) 
Background on Mitchell S. Jackson:
-An English professor and successful author (novels such as Oversoul in 2012 & 
The Residue Years in 2013, essays, short stories)
-While teaching Creative Writing at the University of Chicago in 2020, he won the
Pulitzer Prize and the National Magazine Award for this essay, published in Runner’s
World (using the angle of sports to make a statement on racism)
Background on Ahmaud Arbery…
-Feb. 23, 2020: 25-yr-old Arbery jogging through white neighborhood of 
Satilla Shores, GA; pursued by local father and son (Gregory & Travis
McMichael) in one truck, neighbor William ‘Roddie’ Bryan in another,
who filmed it on his phone.
-Travis confronted ‘suspected burglar’, altercation ensued & Travis shot
Arbery. / No arrests for 2 months (the father had worked with local 
police for years!), claiming ‘self-defense’ & ‘stand your ground’
-Father published Bryan’s video online as ‘proof’ but it backfired
and they were arrested, indicted 4 days after Jackson’s article.
-Nov. 2021 trial saw all three convicted of felony murder & other
charges: McMichaels got life + 20 yrs with no parole, Bryan life 
with possible parole after 30 years.


## PDF page 22

Ten Rhetorical Modes for Essay-Writing
3. division or analysis (breaking something down into parts)
sample essay:“Why I Want a Wife” by Judy Brady-Syfers (1971)
The Process: 
-Division or analysis (the terms are interchangeable) is a key skill in learning or in life: 
it allows you to slice a complicated subject into smaller parts that you can grasp and 
relate to one another.  When done correctly, the presentation done of the parts clarifies 
the whole.
-There are usually different ways to divide the same subject.  An analysis of 20th century 
American poetry could be broken down into the various movements or schools that 
succeeded each other, or into different styles that were predominant, or major themes, 
etc.
-This type of essay usually requires writing a clear outline first, so that you are sure you 
have not left any parts out and that you are dealing with the parts in the best possible 
order.
-This approach can be used for many types of essays (scientific analysis, literary 
analysis, etc.), but here we are looking at more ‘creative’ examples.  In Judy Brady-
Syfer’s essay, she breaks down the notion of a “wife” into its various functions and 
roles.  Note her particularly caustic use of ‘observational humor’, and how the entire 
essay relies very heavily on IRONY and sarcasm, from the first word to the last.


## PDF page 23

Ten Rhetorical Modes for Essay-Writing
3. division or analysis (breaking something down into parts)
sample essay:“Why I Want a Wife” by Judy Brady-Syfers (1971)
On Judy Brady-Syfers:  
-born in 1937 in San Francisco, California
-was a painter before becoming involved in political writing.  She 
became a leader in the feminist movement in the U.S.
-she went to Cuba in 1973 to study class relationships as a way of 
understanding ways to change Western society.
-Her famous disclaimer is the following: I am not a ‘writer’, but really am a 
disenfranchised (and fired) housewife, now secretary.”
-She died of pneumonia in 2017 at the age of 80.
-This is her most famous essay, which first appeared in the Spring 1972 issue of Ms. 
Magazine (a strongly feminist publication, as the title implies), but it has been 
reprinted several times since then and is one of the best-known manifestos in 
popular feminist writing.


## PDF page 24

Before discussing the other seven rhetorical modes of organization, be sure to 
carefully read and study the three sample essays presented here.
Not only will questions on these essays be included on your first test, but you 
have a short assignment to do before the end of week one
WHAT YOU NEED TO DO THIS WEEK:
1. Carefully read the three essays presented above, taking notes.
2. Short Assessment of Readings for Week 1 (not graded but part of participation)
Use the Google Form link on iCampus to select which of the first three essays you 
found the most effective and the least effective, and give a few sentences of 
justification for each choice.
3. Read the ‘Introduction to Writing: A Writer’s Questions’


