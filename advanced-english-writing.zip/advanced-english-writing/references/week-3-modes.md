# A2FCP12 Week 3 part 1 modes PDF.pdf

## Contents
- PDF page 1: A2FCP12 Week 3 – Lesson, Part One / Ten Rhetorical Modes for Essay-Writing
- PDF page 2: Ten Rhetorical Modes for Essay-Writing / 8. definition (tracing a boundary and providing information)
- PDF page 3: Ten Rhetorical Modes for Essay-Writing / 8. definition (tracing a boundary and providing information)
- PDF page 4: Ten Rhetorical Modes for Essay-Writing / 8. definition (tracing a boundary and providing information)
- PDF page 5: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 6: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 7: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 8: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 9: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 10: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 11: Ten Rhetorical Modes for Essay-Writing / 9. cause and effect (showing a logical chain of events)
- PDF page 12: Ten Rhetorical Modes for Essay-Writing / 10. argument (persuading the reader to side with your opinions)
- PDF page 13: Ten Rhetorical Modes for Essay-Writing / 10. argument (persuading the reader to side with your opinions)
- PDF page 14: Ten Rhetorical Modes for Essay-Writing / 10. argument (persuading the reader to side with your opinions)
- PDF page 15: Ten Rhetorical Modes for Essay-Writing / 10. argument (persuading the reader to side with your opinions)
- PDF page 16: Ten Rhetorical Modes for Essay-Writing / 10. argument (persuading the reader to side with your opinions)
- PDF page 17: To do: / 1. Read the three essays and answer the online questionnaire.

## PDF page 1

A2FCP12 Week 3 – Lesson, Part One
Ten Rhetorical Modes for Essay-Writing
(seen in lesson 2)
4. classification (sorting the subject into different groups or kinds)
sample essay: “Three Types of Resistance to Oppression” by Martin Luther King, Jr. (1958)
5. comparison & contrast
sample essay: “Racism and Recapitulation” by Stephen Jay Gould (1977)
6. providing examples
sample essay: “Just Walk on By: Black People and Public Space” by Brent Staples (1986)
7. process analysis (explaining ‘how to’ do something step by step)
sample essay: “How Our Skins Get Their Color” by Marvin Harris (1988)
In this lesson:
8. definition 
9. cause and effect 
10. argument


## PDF page 2

Ten Rhetorical Modes for Essay-Writing
8. definition (tracing a boundary and providing information)
sample essay: “The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979)
The Process:
-Short definitions are often used when writing an essay, quite often in the opening 
paragraphs.  This can be done, for example, when using technical terms or terms that 
someone from another culture might not know (a ‘tractor pull’ or ‘Monster truck show’, 
for example). When writing in French dissertation format, we quite often start off with 
definitions of the key words so as to manage and limit the scope of the essay. Sometimes 
using short definitions is a way of “stipulating” which connotation of the term you are 
using.  Note that starting an essay with a definition is often over-used and should not be 
used systematically.
-Quite often, an entire chapter of a book or an entire essay presents an ‘extended 
definition’, which is a common type of expository writing that can include nearly all 
previously mentioned rhetorical devices (e.g., description, process, division, 
comparison and contrast, example, etc.).


## PDF page 3

Ten Rhetorical Modes for Essay-Writing
8. definition (tracing a boundary and providing information)
sample essay: “The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979)
The Process:
-Not all topics of definition essays are cut-and-dry or have an encyclopedia style.  Very often they allow for a 
subjective discussion or to present an opinion on a controversial subject.  The definition one applies to 
‘murder’, for example, could have a great influence on one’s leaning on the question of the death penalty.  
Other ‘concepts’ can make for powerful and persuasive definition essays, such as ‘racism’, ‘cheating’, 
‘adultery’, ‘being a good citizen’ or ‘honesty’.
-Some definition essays set out to coin a new term.  Tom Wolfe’s famous essay “pornoviolence” coins a quite 
strong term for his view of what the American media has become.  In George Orwell’s 1984, for example, the 
author provides a ten-page appendix so as to provide an extended definition of what he calls ‘Newspeak’.  
-There are myriad ways of organizing your extended definition.  Twenty students writing to define the same 
term would undoubtedly come up with twenty totally different essays.  Experiment with 
different ways to organize and present your ideas before you write the actual essay.
-You might need to ask yourself a few questions when preparing your essay, such as 
the following: What makes the topic unique or different?  What is it similar to?  In 
what different forms can it be found? When can it be found and where? What does 
it do and how does it work?  What is it made of?  Why is it important? (and so on)


## PDF page 4

Ten Rhetorical Modes for Essay-Writing
8. definition (tracing a boundary and providing information)
sample essay: “The Holocaust—One Generation After” by Bruno Bettelheim (1960, 1979)
About Bruno Bettelheim (1903-1990):
-born in Austria in 1903, died in the U.S. in 1990
-studied psychoanalysis and trained as a psychologist in Vienna
-was imprisoned by Nazis in concentration camps (Buchenwald & Dachau); 
released in 1939 thanks to U.S. intervention and emigrated to Chicago
-became one of the most renown professors at the University of Chicago
-many of his psychological studies concerned children’s emotional disorders; much of his writing was 
outspoken and controversial
-among his best-known books are Love Is Not Enough (1950), The Children of the Dream (1969) and The Uses 
of Enchantment (1976).
-This essay is in fact an excerpt from a longer essay entitled “The Holocaust –
One Generation After”, which appeared in his 1960 and 1979 collections of essays 
based on his experiences during World War II (The Informal Heart and Surviving, 
and Other Essays).  Here he defines a very powerful word indeed.


## PDF page 5

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
The Process:
-This is a type of essay that is very often a form of opinion writing, as establishing a 
correlation (a connection; cf. causality: a relationship of cause and effect) between two 
events is not always a very easy matter.  
-You must always be able to tell the difference between immediate causes and remote 
causes, for example.  If a man strangles his wife, for example, the immediate cause may 
have been that he found her with her another man (Sorry for the rather macabre 
example).  This would be an immediate cause.  However, we may find more remote 
causes, such as the fact that the man was prone to violence and had frequently attacked 
his wife, that he is insanely jealous and often falsely accused his wife of being unfaithful, 
or even that he had seen his own father strangle his mother when he was a child and 
had been traumatized and prone to violence ever since.  Some of these remote causes 
would tend to lessen the severity of his punishment, others would seem to exacerbate it.
Remember that your essay here can go either way: looking for the cause(s) or looking for 
the effect(s)….  


## PDF page 6

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
In either case, you would have to prove a ‘causal chain’ (a series of causes and effects) that have led (or will 
lead) from one condition/event to the other.  If you are trying to argue that Reagan-era policies were the 
remote cause of the 2009 economic crisis, then you would have to come up with a detailed ‘causal chain’ that 
covers about three decades of economics – no easy task.  If you are trying to explain how the 2008 housing 
crisis caused the 2009 recession, that task might be a little easier.  
Similarly, when looking forward, a solid causal chain needs to be found to establish a correlation or causality.  
This is often used in essays that speculate on what will happen if a certain type of law is passed or a certain 
action is taken.  This of course can be much harder to prove as it is based on prediction and not on established 
events or facts.  For example, trying to prove that legalizing medical use of marijuana will lead to an increase in 
soft-drug use among young people would be hard to prove, whether it is a valid argument or not.
Another problem with this type of essay is that there is rarely one single initial or 
remote cause for an event.  If you want to do an honest job of finding causes, for 
example, you need to consider what other possible causes exist and how they 
interacted with the particular cause you are discussing.  Unfortunately, things do 
not always form a neat, linear series for you to demonstrate.


## PDF page 7

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
Also beware of confusing causes and effects.  This is typical of one of the fallacies we will discuss later, 
‘argument from final consequences’ or teleological arguments.  It’s the old ‘chicken-and-the-egg trick: 
did the egg come first, giving us the first chicken, or did the chicken come first, giving us the first egg?  In 
some arguments the cause and effect might be easy to confuse.  Also beware of a fallacy we call ‘post 
hoc’ (or ‘false cause’), in which the writer assumes (or implies) that because two things followed each 
other in time they were necessarily cause and effect.  This is a trick often used in politics to place blame 
on a politician, as we shall see.
Tips:
-Make sure that your subject is manageable.  Don’t take something that you would never have time to 
develop given the length of the assignment.  The causes of underage drinking in America might be a big 
topic for an essay, for example.  However, outlining the five main consequences for teens who 
drink too much alcohol might be narrow enough for an essay.  
-When looking for remote causes, try not to go too far back.  If you are analyzing
the causes of the closing of a factory in your town, for example, you might need 
to focus on recent problems, rather than going back to the founding of the company 
four generations ago.  At the same time, do not turn a blind eye to more remote 
causes by focusing only on recent events either.


## PDF page 8

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
Tips:
-You may want to plot a sort of chronological time line when preparing your essay, to be 
sure that the causal chain is easy to follow (both for you or the reader), even if you will 
not necessarily deal with events in chronological order.
-When there are many causes you want to discuss (or many effects, of course) be sure 
to establish some type of hierarchy, in order to determine which were the main causes
and which were secondary or minor causes
-Be sure to give your topic enough thought and consideration.  If you write something 
off quickly chances are your essay will show that lack of depth, and be far less 
convincing.
-Try to focus on making a well-reasoned plea or argument, even if some of your ideas 
are based on conjecture or a hunch.  This type of argument requires a strong logical 
appeal, no matter how emotional the plea might be.


## PDF page 9

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
About Richard Wright (1908-1960);
-Born on a plantation near Roxie, Mississippi, in 1908, son of share-croppers and 
grandson to slaves. Largely self-educated through reading.
-A key African American voice in America (novels, stories, essays), focusing on racism 
and oppression of blacks (and what would later be called  ‘white privilege’) from the 
late 19th to mid-20th century.
WEB Dubois was one of his greatest influences, as he in turn would influence younger 
James Baldwin and Ralph Ellison.
-Chicago years:
-started out as active Communist Party member in mid-1930s, with over 200 articles in The 
Daily Worker.
-gained fame with his first collection of short stories Uncle Tom’s Children (on lynchings in 
the South)
-1939-40: thanks to Guggenheim Fellowship, publishes his most famous novel, Native Son 
(about an oppressed black man fighting back against the system)


## PDF page 10

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
About Richard Wright (1908-1960);
-Born on a plantation near Roxie, Mississippi, in 1908, son of share-croppers and 
grandson to slaves. Largely self-educated through reading.
-A key African American voice in America (novels, stories, essays), focusing on racism 
and oppression of blacks (and what would later be called  ‘white privilege’) from the 
late 19th to mid-20th century.
WEB Dubois was one of his greatest influences, as he in turn would influence younger 
James Baldwin and Ralph Ellison.
-Chicago years:
-started out as active Communist Party member in mid-1930s, with over 200 articles in The 
Daily Worker.
-gained fame with his first collection of short stories Uncle Tom’s Children (on lynchings in 
the South)
-1939-40: thanks to Guggenheim Fellowship, publishes his most famous novel, Native Son 
(about an oppressed black man fighting back against the system)


## PDF page 11

Ten Rhetorical Modes for Essay-Writing
9. cause and effect (showing a logical chain of events)
sample essay: “Groping toward That Invisible Light” by Richard Wright (1930)
About Richard Wright (1908-1960);
-New York years:
-1941- adapts Native Son as a successful Broadway play, directed by Orson Welles.
-1945- publishes his memoir Black Boy, focusing on his life as a child in Roxie and 
ten in Chicago. This essay is from the last section, “Southern Nights”, and served as its 
conclusion.
-posthumous sequel: American Hunger (1977), focused more on his Communist endeavours, 
marriage to a Communist leader in NYC, etc.
-Paris Years:
-last 13 years spent in Paris as part of the existential/philosophical group that included Jean-
Paul Sartre, Albert Camus and Simone de Beauvoir.
-perhaps this exile to France spared him trouble from the McCarthy years


## PDF page 12

Ten Rhetorical Modes for Essay-Writing
10. argument (persuading the reader to side with your opinions)
sample essay: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)
The Process:
Even though most of the previous types of rhetorical modes are often used, 
separately or in combination, to present an argument, they are not always a pointed 
argument. We can use ‘process analysis’ to explain a cake recipe or ‘cause and 
effect’ to explain why the light bulb turns on if I flip the switch, or why my 
daughter’s birthday cake did not come out the way I had planned it to, or what 
would happen if you put unleaded gasoline into a diesel engine.  In this final section, 
we will be talking about pure opinion writing, plain and obvious (though not always 
simple) arguments.
This type of essay, then, deals more openly with convincing or persuading people to 
agree with you and possibly to take action.  It is the purest form of opinion writing
as it does not usually try to hide the fact that you are presenting and defending an 
opinion or a personal point of view. 


## PDF page 13

Ten Rhetorical Modes for Essay-Writing
10. argument (persuading the reader to side with your opinions)
sample essay: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)
If I present you with some positive opinions on a candidate running for the next 
election, my first goal is to convince you (if you are undecided) or persuade you (if 
you are a fan of the other candidate) that my candidate is the best (or better) 
choice. My argument will most likely include an explicit or implicit proposal as well –
the suggestion you vote for my candidate.
We are of course bombarded with opinions every day.  It may be a political opinion 
urging us to support or oppose a piece of legislation (such as a health care bill), a 
religious opinion urging us to give a donation or change religions, a scientific opinion 
urging us to focus funds on a new area of research, a medical and humanitarian 
opinion urging us to donate to research on AIDS or cancer, an academic opinion 
urging you to study for a certain profession, an advertising opinion urging you to buy 
a new toothpaste or a new car, and the list goes on and on.


## PDF page 14

Ten Rhetorical Modes for Essay-Writing
10. argument (persuading the reader to side with your opinions)
sample essay: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)
Certain professions, of course, rely more on opinion writing than others.  Lawyers need to write careful 
and convincing arguments every day, especially if they are to plead in court, but one of the jurors who 
runs a grocery store may not have to write as much.  Still, he or she needs to use argumentation quite 
often at work – to promote a certain product that is on special this week, to convince an employee to 
work overtime this Sunday, to persuade customers who go to the big supermarket up the street to come 
to his store instead, to talk the angry woman whose son fell ill from bad meat purchased in his store not 
to take them to court (where he might find himself with that same lawyer from the first example!), etc. 
The point is that all college students, undergraduates or grad students, need to master 
the art of persuasion. However, you will also need it when you leave school, 
when you want to convince a prospective employer to hire you, and then quite 
often in whatever line of work you choose.  You also need to be able to spot the 
tricks and errors in opinion writing (which will be the focus of our next lesson), so 
that you can avoid them in your own arguments and not be duped by those 
who use them.


## PDF page 15

Ten Rhetorical Modes for Essay-Writing
10. argument (persuading the reader to side with your opinions)
sample essay: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)
Arguments usually begin with a very clear THESIS or CLAIM, this is the proposition you will defend.  
Sometimes, this will also include a proposal, which is the course of action we hope the reader will take.  
Your claim usually appears early in your essay, but it does not have to. Of course, if you want to convince 
anyone of anything, you need to provide some kind of evidence or proof.  You also need to use one or 
more of the three appeals we soon explain at length: the ethical appeal, the logical appeal or the 
emotional appeal.
This type of essay relies most heavily on different forms of rhetoric, 
argumentation, reasoning, rhetorical devices and fallacies that we 
will study in the next section of this Unit.  


## PDF page 16

Ten Rhetorical Modes for Essay-Writing
10. argument (persuading the reader to side with your opinions)
sample essay: “I Have a Dream” by Martin Luther King, Jr. (August 28, 1963)
April 28, 1963: as final stage of his 
‘March on Washington for Jobs and Freedom’, 
on the steps of the Lincoln Memorial, 
on the anniversary of Lincoln’s 
Emancipation Proclamation/


## PDF page 17

To do:
1. Read the three essays and answer the online questionnaire.
2. Watch the second part of this week’s lesson, on the fallacies of reasoning.
3. Do the 26 practice exercises on fallacies before next week (as next week’s lesson will 
start by correcting those exercises).


