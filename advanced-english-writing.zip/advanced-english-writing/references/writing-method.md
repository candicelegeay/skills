# Writing method

## Contents
- Ten rhetorical modes
- Argument and composition
- Mechanics and language
- Transfer to professional writing

## Ten rhetorical modes

The following operational guide paraphrases the course's ten modes. Practical safeguards and professional applications are editorial additions, not quotations from the course. Modes operate at essay and paragraph level and can be combined. They are not ten narrative voices.

| Mode | Function and design | Main pitfall | Possible technical use |
|---|---|---|---|
| Narration and anecdote | Develop an event through selected actions, perspective and meaningful sequence; connect the experience to the larger purpose. | Inventing experience or treating one event as representative proof. | Open with a documented incident or a labelled hypothetical scenario. |
| Description | Select precise sensory, spatial or technical details; control distance and perspective. | Detail without purpose, or selective description presented as exhaustive neutrality. | Make a system or interaction observable. |
| Division or analysis | Break one whole into parts under an explicit organizing principle; explain relationships. | A catalogue that loses the whole or mixes incompatible levels. | Explain an architecture through interacting responsibilities. |
| Classification | Group multiple instances into meaningful categories using explicit criteria. | Inconsistent categories, hidden overlaps or false exhaustiveness. | Establish a bounded taxonomy of agent patterns. |
| Comparison and contrast | Compare on a shared basis and consistent dimensions; use point-by-point or block organization deliberately. | False equivalence or analogy mistaken for proof. | Compare two architectures against the same constraints. |
| Providing examples | Ground an abstract proposition in a developed example or a purposeful series. | Cherry-picking or confusing illustration with sufficient evidence. | Show what a governance principle changes in an actual workflow. |
| Process analysis | Explain how to do something (directive) or how it works (informative); make stages and dependencies explicit. | Missing prerequisites, skipped steps or misleading linearity. | Explain execution, failure handling and human intervention. |
| Definition | Delimit a term, distinguish neighboring concepts and establish scope; use extended definition where needed. | Circular definitions or presenting a stipulated definition as universal. | Clarify what qualifies as an AI system in a particular argument. |
| Cause and effect | Trace mechanisms and distinguish enabling, contributing, immediate and downstream factors. | Post hoc inference, monocausal stories or unsupported certainty. | Explain how tool permissions can contribute to an observed failure. |
| Argument | Advance a contestable thesis using reasons, evidence, warrants and a fair treatment of objections. | Rhetorical force exceeding support or rebutting a weakened opponent. | Defend a design principle under stated conditions. |

Select modes by purpose. For example, a technical opinion article may open with an anecdote, define a disputed term, analyze the system and develop an argument. Do not force that sequence on every piece.

## Argument and composition

Course grounding: week-2 (appeals/reasoning), fallacies-1/2, paragraphs, openings-citations. Apply the source-index corrections.

Use ethos to establish relevant credibility, logos for the connection between reasons and conclusion, and pathos for human stakes. None replaces evidence. Distinguish deduction from induction and abduction; calibrate claims accordingly. A plausible inference is not a proven result.

For an argument audit, reconstruct the strongest reasonable reading. Identify a specific sentence, its inference and the missing support. Consider alternative interpretations before assigning a fallacy. Common checks include hasty generalization, false dilemma, equivocation, straw man, irrelevant authority, circular reasoning, non sequitur, red herring, post hoc and unsupported slippery slope. A flawed argument does not by itself establish the opposite conclusion.

Use paragraph unity, order, coherence and adequate development as tests. Topic/support/conclusion is a useful teaching pattern, not a required visible template. Split when the idea, time, place, emphasis or logical task changes. Build transitions through the substance of adjacent sentences before inserting connective adverbs. Distinguish contrast, concession, correction, consequence and addition; these are not interchangeable.

Design openings for the genre: orient the reader, establish stakes and set a direction. A news lead may prioritize the 5 Ws and H; an analytical essay may foreground a claim; a narrative may establish a scene. Do not require a hook plus explicit thesis plus plan for every format. Design endings to deliver the final implication, synthesis, recommendation or return to the opening; do not introduce unsupported new evidence or mechanically repeat the whole article.

Preserve attribution in paraphrase. Keep quotations separate from the user's words. Use the requested MLA, APA, Chicago or house style consistently; do not invent bibliographic details or assume older course examples establish current edition rules.

## Mechanics and language

Course grounding: mechanics pp. 2–30. The following includes contextual safeguards and supplemental English editing practice.

- Correct comma splices by selecting the intended relationship: period for separation, semicolon for closely related independent clauses, comma plus coordinating conjunction for coordination, or subordination for dependency. Do not change logic accidentally.
- Use colons to introduce an elaboration or list after a grammatically complete lead-in in ordinary prose. Explain semicolon versus colon through clause structure and effect.
- Do not separate a subject from its predicate with a stray comma. Set off genuinely parenthetical material consistently. Distinguish restrictive from supplementary information.
- Apply the serial/Oxford comma according to house style and ambiguity, not as an absolute right/wrong rule.
- Diagnose accidental fragments; retain deliberate fragments when their rhythm, emphasis and genre justify them. A long sentence is not automatically a run-on.
- Attach introductory participles to their actual agents. Check pronoun antecedents, parallel constructions, tense and point of view. Do not ban valid postpositive adjectives or supplementary modifiers simply because they resemble French syntax.
- Distinguish dialogue tags from action beats. Start a new narrative paragraph when the speaker changes, while recognizing that scripts, transcripts and other genres use different conventions. Integrated quotations do not always require a preceding comma.
- Keep English punctuation spacing and quotation conventions consistent. US/UK punctuation placement and quotation choices can differ. Do not rewrite exact quotations to fit house style without marking changes appropriately.
- Distinguish ellipsis (omission or trailing speech), dash (interruption or parenthesis), and etc. (continuing a list). Use each intentionally; never add dashes merely because the course recommends them more often.
- Match title capitalization and italics/quotation marks to the requested style. Course title-case instructions are not a universal rule across style guides.
- Prefer an appropriate register over a blanket ban on contractions or phrasal verbs. Technical precision may require specialized vocabulary; clarity does not require erasing nuance.
- Check French interference selectively: realize/carry out; actually/currently; experiment/experience; development/evolution; remember/remind; agree; used to versus be used to; amount/number; simple past with a finished historical date; concrete nouns after nominalized superlatives. Explain in context rather than treating near-synonyms as universally forbidden.
- Check collocations and prepositions in the actual sentence. Label a change as grammatical, idiomatic, conventional or optional. Do not manufacture frequency statistics or dictionary authority; verify disputed usage when possible.

## Transfer to professional writing

Apply the course's composition principles to articles, technical reports, explanatory essays and presentations without importing academic formatting automatically. Keep claims proportional to supplied evidence. Preserve distinctions such as capability versus deployment, association versus mechanism, prototype versus production, and hypothesis versus finding. These are application safeguards, not claims that the course teaches AI architecture.

For sentence-level alternatives, explain the reader effect: emphasis, pace, information order, agency, distance or degree of commitment. Avoid describing every change as simply more professional or more native. Preserve unusual but effective phrasing.
