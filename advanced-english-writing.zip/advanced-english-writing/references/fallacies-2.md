# A2FCP12 fallacies part two with Trump PDF.pdf

## Contents
- PDF page 1: A2FCP12 – Week 4, Part One: / Fallacies II:
- PDF page 2: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 3: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 4: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 5: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 6: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 7: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 8: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 9: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 10: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 11: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 12: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 13: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 14: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 15: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 16: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 17: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 18: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 19: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 20: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 21: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 22: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 23: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 24: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 25: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 26: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 27: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 28: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 29: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 30: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 31: Identifying Fallacies of Reasoning: / Try these on your own before watching this correction
- PDF page 32: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 33: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 34: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 35: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 36: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 37: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 38: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 39: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 40: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 41: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 42: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 43: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 44: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 45: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 46: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 47: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 48: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 49: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 50: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 51: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 52: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 53: Identifying Fallacies of Reasoning: / Health Care Examples under President Obama
- PDF page 54: III. Examples & Expansion: Trump Tweets and Logical Fallacies during his First Term / Just as Trump kept ‘fact-checkers’ working overtime du
- PDF page 55: ________________ / Lyin’ Ted
- PDF page 56: Ad Hominem attacks: / Lyin’ Ted
- PDF page 57: Trump variation: Poisoning the Well / (attacking the reputation of a source of information so as to discredit any information
- PDF page 58: _________________ / _________________
- PDF page 59: Argument from Authority / _________________
- PDF page 60: Argument from Authority / Moving the Goalposts
- PDF page 61: _______________ / _____________
- PDF page 62: Bandwagon / _____________
- PDF page 63: Bandwagon / Straw Man
- PDF page 64: ___________________ / ___________________
- PDF page 65: Equivocation / ___________________
- PDF page 66: Equivocation / False Dilemma (Either…Or)
- PDF page 67: ___________ / esp. Whataboutism: shifting focus away from your problem to someone else’s.
- PDF page 68: Red Herring / esp. Whataboutism: shifting focus away from your problem to someone else’s.
- PDF page 69: Red Herring / esp. Whataboutism: shifting focus away from your problem to someone else’s.
- PDF page 70: Trump expands our list of fallacies… with many forms of speculation / Historian’s Fallacy: judging the past based on elements not known at t
- PDF page 71: Counterfactual Evidence: a hypothesis about what ‘would have happened’ with no / possible evidence to support the claim.
- PDF page 72: Proof by Assertion (repeating a statement over and over again until it becomes / accepted as true).
- PDF page 73: cf. Goebbel’s famous boast about how to propagate a ‘big lie’ / -whereas Hitler, in Mein Kampf, claimed the ‘Big Lie’ was propagated by Jews
- PDF page 74: ‘Gaslighting’ / (cf. 1938 Patrick Hamilton play, US films in 1940 & 1944)
- PDF page 75: And Trump’s second term? / He’s doubled down on all the ones we’ve seen, with particular emphasis
- PDF page 76: Plus two seen in the introduction: / -Enthymeme                  -Wordplay

## PDF page 1

A2FCP12 – Week 4, Part One:
Fallacies II:
Correction of practice exercises from last week
Taking it to another level: Trump’s ‘tweets’ during his first term
A2FCP12 – Week 4, Part Two:
Paragraphs I – On writing coherent paragraphs


## PDF page 2

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 3

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 4

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 5

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 6

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 7

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 8

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 9

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 10

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 11

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 12

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 13

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
1. “The bailout Obama signed on for has led to the worst housing 
market crisis in decades.”
2. “The President spoke about the reports he received angry letters, 
which were filled with errors and inconsistencies.”
3. “All the French are Socialists anyway.  It’s not surprising that they 
like our new ‘President’.”
4. “Since Obama came into office, unemployment is up 20% - those 
millions of men and women who lost their jobs know who to thank 
for that!”
5. “Bob is a Republican, and Bob is quite racist.  That’s why I say that Republicans are racist.”
6. June 2004: 
Alan: “You should get behind your President.  Protesting the decisions of our Commander-in-Chief is un-
American!”
June 2009:
Alan: “Impeach the President!  He’s a Socialist! He’s a terrorist!”
Bill: “But last time you told me that it was un-American to protest our President.  
You said we have to ‘get behind our President’ – remember?” 
Alan: “Yes, but that applies when the country is at war.  We had just started the war in Iraq.”
Bill: “But the Iraq War is still going on, plus there’s the war in Afghanistan, too.”
Alan: “Yes, but in fact it is only the case if the President in question is himself a good American!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning
loaded question


## PDF page 14

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I told 
you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 15

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I told 
you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 16

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I 
told you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 17

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I 
told you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 18

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I told 
you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 19

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I told 
you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 20

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I told 
you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 21

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
7. “Sarah Palin is a real, down-to-earth American like you and me.  
She’ll be the best vice-president we’ve ever had.”
8. Arvin:” I’m telling you, he was born in Kenya and he’s a foreigner.”
Bob: “No, he was born in Hawaii.  He’s registered as being born on 
August 4th, 1961, in Kapi’olani Hospital in Honolulu.”  
Arvin: “I’m not buying it.  I need hard evidence.”
Bob: “Well, here’s a photocopy of the hospital register – you see, 
born at 8:45 pm, 7 lbs. 4 oz.”
Arvin:” That could have been scribbled in by anyone.  I need proof 
that he was there.”
Bob: “Well, here’s a family photo – you see his mother and father holding him in the maternity ward when he 
was just a few hours old.  Notice the name of the hospital on that sign on the wall…”
Arvin: “How do I know that’s him?  That could be a doll they’re holding, for all I know!  I need to see a birth 
certificate.  Why won’t he produce a birth certificate?  What’s he trying to hide?”
Bob: “Well, he shouldn’t have had to do this, but here’s a copy of his birth certificate.  You see it’s there, as I told 
you, in black and white.”
Arvin: “A copy?!  I’d need to see the real thing!” 
9. “I cannot imagine someone as important as the Vice-President being involved in something 
so underhanded and illegal.  No way!”
10. “Give me a straight answer on this.  Did you decide to betray the American people who 
voted for you by accepting ‘gifts’ from lobbyists before or after taking those bribes?” 
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 22

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 23

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 24

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 25

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 26

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 27

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 28

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 29

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 30

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 31

Identifying Fallacies of Reasoning:
Try these on your own before watching this correction  
11. “The constitution says that when the country is “at war”, 
individual liberties may have to be infringed.  Well, if that’s the only 
way to win the War on Terror, then so be it!”
12. “I’ll say it again – I think he’s a terrorist sent to infiltrate our 
government at the highest level –that’s just what I think, and no one 
has shown me proof that he isn’t.” 
13. “Geithner was a cabinet member under Bush and Cheney. They 
all went to Yale or Harvard.  He was probably all on board for the 
Iraq War.  There’s no way he should be part of the new administration. 
Would you make Bush or Cheney Secretary of the Treasury?!”
Health Care Examples under President Obama
1. “So basically the opposition’s argument is that it is more important to help those who 
have no health care than to care at all about the 85% of hard-working Americans who 
already have coverage. How on earth can anyone agree to that?”
2. “I’m telling you – the man has a doctoral degree and two Masters – he’s been published 
in The New England Journal of Medicine – he’s a medical doctor for Pete’s sake! If he says 
this health care bill will increase the deficit and raise health care costs, I believe him!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 32

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 33

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 34

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 35

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 36

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 37

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 38

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 39

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 40

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 41

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 42

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 43

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 44

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 45

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
3. “Listen, 85% of the citizens of our state think changing health care 
is a bad idea.  Isn’t it obvious that this is wrong-headed?”
4. “The choice is yours, America – accept this health care reform or 
stick with the status quo and its ever-rising premiums and 
outrageous medical bills.”
5. “Both the House and the Senate health care proposals were 
written by a Democratic majority, aim at providing health care to 
those who have no coverage and were developed in committees at 
the request of the same liberal President.  One is just as bad as the 
other and they should both be rejected.”
6. “I’ve seen legislation like this a hundred times before and you haven’t – trust me, this bill will not improve 
health care.”
7. “Representatives who voted against the new health care bill were just voting along party lines”
8. “If you allow the government to get involved in our health care, in no time we’ll have 
government-controlled ‘death panels’, we’ll be waiting on bread-lines, and we’ll be living
in a Communist state!”
9. “Why are we talking so much about health care when the real problem in this country 
is unemployment?”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 46

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 47

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 48

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 49

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 50

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 51

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 52

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 53

Identifying Fallacies of Reasoning:
Health Care Examples under President Obama
10. “I’m not going to accept a health care proposal from a man 
who is not even a real American. He’s a terrorist, I’m telling you.  
Go home, Hussein!”
11. “I can tell you why this health care proposal isn’t good enough.  
It’s because there are many provisions that could be improved and 
too many policies regarding hard-working Americans that just don’t 
cut the mustard.  It’s clear that it needs to be revamped, isn’t it?”
12. “Listen, Mom, how can you say that it is un-American to accept 
government money and aid when you’re young and healthy enough 
to work.  You were on Welfare for years before you got re-married.”
13. (The same news presenter from a cable news channel)
November 2008: “We have the worst health care system in the world, ladies and gentlemen.  
I know – I’ve just been through it myself for a botched operation. They only care about money, 
not your well-being.”
November 2009: “Ladies and Gentlemen, this president is trying to tamper with 
the best health care system in the world – bar none!  He’s trying to bring 
down America!”
Selection for these exercises:
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences 
post hoc / false cause 
argument from personal Incredulity
inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning     loaded question


## PDF page 54

III. Examples & Expansion: Trump Tweets and Logical Fallacies during his First Term
Just as Trump kept ‘fact-checkers’ working overtime during his first presidency, he also 
gave those who esteem logic and define fallacies many sleepless nights…


## PDF page 55

________________
Lyin’ Ted  
 
Sleepy Joe 
 
Pocahontas
Low Energy Jeb 
 
Leakin’ Lyin’ James Comey 
Jeff Flakey
Al Frankenstein 
 
Little Marco 
 
Crazy Bernie
Cryin’ Chuck 
 
Low-IQ Maxine Waters 
Sleazy Adam Schi**


## PDF page 56

Ad Hominem attacks:
Lyin’ Ted  
 
Sleepy Joe 
 
Pocahontas
Low Energy Jeb 
 
Leakin’ Lyin’ James Comey 
Jeff Flakey
Al Frankenstein 
 
Little Marco 
 
Crazy Bernie
Cryin’ Chuck 
 
Low-IQ Maxine Waters 
Sleazy Adam Schi**


## PDF page 57

Trump variation: Poisoning the Well
(attacking the reputation of a source of information so as to discredit any information 
they provide)


## PDF page 58

_________________
_________________
-I have nothing to do with the Russians and have no business with them. Fake news!
-No one in my campaign ever met or talked with any Russians. No collusion! 
Fake News! 
-My son only met with a Russian lawyer to discuss adoptions. No collusion!
-The meeting was routine Opposition Research. Dems do it too!
-No one in my campaign worked with Russia. Dems are sore losers! Witch hunt!
-No one close to Trump ever colluded with the Russians. 
-Trump never colluded with the Russians! Witch hoax!


## PDF page 59

Argument from Authority
_________________
-I have nothing to do with the Russians and have no business with them. Fake news!
-No one in my campaign ever met or talked with any Russians. No collusion! 
Fake News! 
-My son only met with a Russian lawyer to discuss adoptions. No collusion!
-The meeting was routine Opposition Research. Dems do it too!
-No one in my campaign worked with Russia. Dems are sore losers! Witch hunt!
-No one close to Trump ever colluded with the Russians. 
-Trump never colluded with the Russians! Witch hoax!


## PDF page 60

Argument from Authority
Moving the Goalposts
-I have nothing to do with the Russians and have no business with them. Fake news!
-No one in my campaign ever met or talked with any Russians. No collusion! 
Fake News! 
-My son only met with a Russian lawyer to discuss adoptions. No collusion!
-The meeting was routine Opposition Research. Dems do it too!
-No one in my campaign worked with Russia. Dems are sore losers! Witch hunt!
-No one close to Trump ever colluded with the Russians. 
-Trump never colluded with the Russians! Witch hoax!


## PDF page 61

_______________
_____________
Variation: Appeal to ‘Common Sense’


## PDF page 62

Bandwagon
_____________
Variation: Appeal to ‘Common Sense’


## PDF page 63

Bandwagon
Straw Man
Variation: Appeal to ‘Common Sense’


## PDF page 64

___________________
___________________
(plus Ad terrorem: the alternative is terrifying!)


## PDF page 65

Equivocation
___________________
(plus Ad terrorem: the alternative is terrifying!)


## PDF page 66

Equivocation
False Dilemma (Either…Or)
(plus Ad terrorem: the alternative is terrifying!)


## PDF page 67

___________
esp. Whataboutism: shifting focus away from your problem to someone else’s.
_______________


## PDF page 68

Red Herring
esp. Whataboutism: shifting focus away from your problem to someone else’s.
_______________


## PDF page 69

Red Herring
esp. Whataboutism: shifting focus away from your problem to someone else’s.
Post Hoc


## PDF page 70

Trump expands our list of fallacies… with many forms of speculation
Historian’s Fallacy: judging the past based on elements not known at the time, in 
light of new information.
Subverted Support: basing an argument 
on a premise that is not true.
Appeal to Probability: Just because 
something is possible, or even probable, 
does not mean it is the case.


## PDF page 71

Counterfactual Evidence: a hypothesis about what ‘would have happened’ with no 
possible evidence to support the claim.
Argumentum ex silentio (argument from silence): drawing a conclusion based on 
the silence of the opponent.
Also-
‘Notice how the lamestream 
media is NOT talking about the 
the rigged elections… Collusion 
with the Dims! Their silence 
speaks volumes. Sad!’


## PDF page 72

Proof by Assertion (repeating a statement over and over again until it becomes 
accepted as true).
And two other trademark fallacies:


## PDF page 73

cf. Goebbel’s famous boast about how to propagate a ‘big lie’ 
-whereas Hitler, in Mein Kampf, claimed the ‘Big Lie’ was propagated by Jews, who 
blamed Germany for World War I, Goebbel’s used the tactic to blame the Jewish 
people for all of Germany’s trouble and claiming Germany had not lost World War 
I!)
“If you tell a lie big enough and keep repeating it, people will eventually come to 
believe it. The lie can be maintained only for such time as the State can shield the 
people from the political, economic and/or military consequences of the lie. It thus 
becomes vitally important for the State to use all of its powers to repress dissent, 
for the truth is the mortal enemy of the lie, and thus by extension, the truth is the 
greatest enemy of the State.”
In late 2020, Trump propagated what many call the ‘Big Lie’ of his presidency?
Not only did he repeat it, but his lawyers and supporters repeated it incessantly until the Capitol was 
stormed by believers, who then represented 39% of the population…
(And the fact that 39% of the population believed was then used by Trump cronies, such as Ted Cruz 
on the Senate floor, to ‘prove’ it wasn’t a lie!)
And two other trademark fallacies:
Proof by Assertion (repeating a statement over and over again until it becomes 
accepted as true).


## PDF page 74

‘Gaslighting’  
(cf. 1938 Patrick Hamilton play, US films in 1940 & 1944)
-manipulating someone to such a point or being so inconsistent that the listener 
begins to doubt his own memory, perceptions and sanity.
Remember the first rule of Trumpism: For every Trump tweet (or ‘Truth’) there exists 
an equal and opposite tweet (or ‘Truth’).
This can lead to what Orwell
called Doublethink!


## PDF page 75

And Trump’s second term?
He’s doubled down on all the ones we’ve seen, with particular emphasis 
on…
Gaslighting / Doublethink
Selective Emphasis / Cherry Picking
Appeal to Tradition / Argument from Tradition
Appeal to Vanity / National Pride
Appeal to Fear (argument in terrorem and ad baculum)
Like fact-checkers, rhetoricians can’t keep up!


## PDF page 76

Plus two seen in the introduction:
-Enthymeme                  -Wordplay
Additions in the era of Trumpism:
-Poisoning the Well (within Ad hominem)
-Appeal to Common Sense (within Bandwagon)
-Ad terrorem (with False Dilemma or Slippery Slope)
-Ad baculum 
-Whataboutism (with Red Herring)
-Selective Emphasis / Cherry Picking
-Appeal to Tradition / Argument from Tradition
-Appeal to Vanity / National Pride
Extended forms of Speculation:
-Historian’s Fallacy
-Appeal to Probability
-Contrafactual Evidence 
-Argumentum ex silentio
Going to Extremes:
-Subverted Support
-Proof by Assertion
-Gaslighting
The Main 26 Fallacies
ad hominem
ad ignorantiam
argument from authority
false authority   
argument from final consequences      post hoc / false cause 
argument from personal Incredulity    inconsistency
false dilemma / either-or fallacy 
non-sequitur
reductio ad absurdum
slippery slope
straw man
begging the question 
moving goalpost
tu quoque
red herring
oversimplification
hasty generalization
false analogy
guilt by association
amphiboly/ double talk
equivocation
bandwagon
special pleading / ad-hoc reasoning    loaded question


