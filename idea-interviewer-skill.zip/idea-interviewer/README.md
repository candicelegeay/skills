# idea-interviewer

Portable skill bundle for turning a raw idea into a structured `IdeaBrief` while preserving provenance.

## Contents

- `SKILL.md` — behavioral specification for the skill.
- `schemas/IdeaInterviewRequest.schema.yaml` — input contract.
- `schemas/IdeaBrief.schema.yaml` — output contract.
- `examples/` — valid YAML examples.
- `tools/tool_manifest.yaml` — optional local tool declarations.
- `tools/generate_idea_id.py` — UUID generator.
- `tools/validate_idea_brief.py` — YAML/schema validator.

## Install

Copy the whole `idea-interviewer/` directory into the skills directory used by your agent/harness. Keep the relative paths intact.

Python helper tools require:

```bash
pip install -r requirements.txt
```

Validate the example:

```bash
python tools/validate_idea_brief.py examples/IdeaBrief.example.yaml
```

## Runtime behavior

1. Load `SKILL.md` as the skill instruction.
2. Start with an `IdeaInterviewRequest`.
3. Ask one high-value question at a time.
4. Stop when the thesis, reasoning, evidence/examples, assumptions, objections and significance are sufficiently clear.
5. Emit an `IdeaBrief` matching the YAML schema.
6. Keep user claims, external context and AI hypotheses separated in `provenance`.
