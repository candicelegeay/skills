#!/usr/bin/env python3
import uuid

if __name__ == "__main__":
    print(uuid.uuid4())
