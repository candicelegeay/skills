#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "schemas" / "IdeaBrief.schema.yaml"


def main() -> int:
    if len(sys.argv) != 2:
        print(json.dumps({"valid": False, "errors": ["Usage: validate_idea_brief.py <idea-brief.yaml>"]}))
        return 2

    data_path = Path(sys.argv[1]).expanduser().resolve()
    with SCHEMA_PATH.open("r", encoding="utf-8") as f:
        schema = yaml.safe_load(f)
    with data_path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(data), key=lambda e: list(e.path))

    payload = {
        "valid": not errors,
        "errors": [
            f"{'.'.join(map(str, e.path)) or '<root>'}: {e.message}" for e in errors
        ],
    }
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload["valid"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
