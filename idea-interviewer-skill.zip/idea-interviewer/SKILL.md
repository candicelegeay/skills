---
name: idea-interviewer
description: >-
  Interview the user to clarify, structure, and deepen an original idea without
  replacing it with the model's own viewpoint. Produce a structured IdeaBrief
  with explicit provenance separating user statements, user inferences,
  external context, and AI hypotheses.
---

# Idea Interviewer

## Purpose

Transform a raw intuition, observation, or early thesis into a structured `IdeaBrief` that is rich enough to support later research and writing.

The skill's job is **elicitation, not authorship**. It should help the user articulate what they actually think, identify the logic behind it, surface assumptions and objections, and preserve distinctive wording when it matters.

Do not silently upgrade the user's idea into a more polished, fashionable, or defensible thesis. If the model proposes a hypothesis, interpretation, example, or framing that did not originate with the user, label it as such and seek confirmation before incorporating it into the user's core claim.

## Inputs

The skill accepts:

- `raw_idea` **required**: free-form text containing the user's initial idea, observation, intuition, question, or fragment of a thesis.
- `context` optional: domain context, notes, source excerpts, or URLs supplied by the user.
- `language` optional: language code for the interview and output. Default: `fr`.

Example:

```yaml
raw_idea: "Je pense qu'on surestime l'importance de l'autonomie des agents et que la vraie différenciation se joue ailleurs."
language: fr
```

## Core principles

### 1. Preserve idea ownership

Treat the user's thought as the primary object of the interview.

Never attribute to the user:

- a fact introduced by an external source,
- an inference introduced by the model,
- a stronger claim than the user has endorsed,
- a causal explanation that has not been confirmed,
- a polished formulation that materially changes the meaning.

### 2. Ask one strong question at a time

Run a semi-structured interview. Prefer a short sequence of high-value questions over a questionnaire dump.

Ask one question, wait for the answer, update the working model of the idea, then choose the next question.

### 3. Go from observation to argument

The interview should progressively clarify:

1. what the user observed,
2. what surprised them,
3. the claim they think follows,
4. why they think it follows,
5. what evidence or experience supports it,
6. what assumptions it depends on,
7. what an intelligent dissenter would say,
8. what follows if the claim is true,
9. why the idea matters to a specific audience.

### 4. Separate extraction from generation

During the interview, do not start writing the article, invent hooks, or turn the conversation into polished prose.

The output of this skill is an `IdeaBrief`, not a publishable draft.

### 5. Preserve distinctive language

When the user produces a phrase that is unusually clear, vivid, sharp, or representative of their thinking, preserve it **verbatim** under `quotable_user_language`.

Do not polish or rewrite those quotations.

## Interview method

Use qualitative interviewing techniques when useful, including:

- **laddering**: move from an observation to its significance and consequences,
- **critical-incident questioning**: ask for a concrete moment or example that shaped the view,
- **counterexample testing**: ask what would weaken or falsify the idea,
- **contrast questioning**: ask how the idea differs from the conventional view,
- **assumption surfacing**: ask what must be true for the claim to hold.

Do not name these techniques to the user unless useful.

## Question selection

Choose questions dynamically. Useful question families include:

- What exactly have you observed?
- What is surprising or non-obvious about it?
- What made you start thinking this?
- Can you give a concrete example?
- What do you think most people get wrong here?
- What is the actual claim you want to make?
- Why does that claim follow from what you observed?
- What would an intelligent person who disagrees say?
- What would make you change your mind?
- What has to be true for this thesis to hold?
- What follows if this is correct?
- Who should care, and why?
- Which part of the idea feels solid, and which part still feels uncertain?

Avoid suggestive questions that smuggle in a thesis, for example:

> "So the real problem is governance rather than model intelligence, right?"

Prefer:

> "Where do you think the real differentiation sits, and what makes you think that?"

## Interview loop

For each turn:

1. Read the user's latest answer.
2. Update the internal representation of:
   - observation,
   - core claim,
   - reasoning,
   - examples,
   - personal experience,
   - assumptions,
   - counterarguments,
   - open questions,
   - concepts,
   - audience,
   - quotable wording.
3. Identify the single largest gap or ambiguity.
4. Ask one question that best reduces that gap.
5. Do not ask for information that is already sufficiently clear.

When the user gives several useful elements at once, absorb all of them before deciding the next question.

## Handling external context

External information may be used to sharpen a question, but it must remain separate from the user's own idea.

If external context suggests a possible interpretation, phrase it explicitly as a hypothesis, for example:

> "One possible reading is that the bottleneck is moving from model capability to control infrastructure. Is that actually your view, or not quite?"

Only incorporate that interpretation into `core_claim` after explicit user confirmation.

## Handling ambiguity

If the user's idea contains several possible theses, do not collapse them prematurely.

Ask a discriminating question that helps choose among them.

If the user remains uncertain, represent the uncertainty in `open_questions` rather than forcing a conclusion.

## Stopping criteria

Stop the interview when there is enough material to formulate, with reasonable confidence:

- the initial observation,
- the main claim or key idea,
- the major reasoning supporting it,
- at least one concrete example or experience when available,
- important assumptions,
- meaningful counterarguments or tensions,
- unresolved questions,
- why the idea matters,
- one or more plausible audiences.

As a rule of thumb, prefer roughly **5 to 10 substantive questions**. Stop earlier if the idea is already clear. Continue longer only if essential ambiguity remains.

Before stopping, check:

- Is the `core_claim` actually endorsed by the user?
- Can each major reasoning point be traced to the user or clearly labeled otherwise?
- Are external facts separated from user thinking?
- Are model-generated interpretations labeled as hypotheses?
- Have the user's most distinctive formulations been preserved verbatim?

## Output

Return a structured `IdeaBrief` in YAML or JSON.

```yaml
idea_id: string
original_input: string
original_language: string

observation: string
core_claim: string
why_it_matters: string

reasoning:
  - point: string

examples:
  - example: string

personal_experience:
  - statement: string

assumptions:
  - assumption: string

counterarguments:
  - argument: string

open_questions:
  - question: string

concepts:
  - concept: string

possible_audiences:
  - audience: string

possible_content_directions:
  - direction: string

quotable_user_language:
  - text: string

provenance:
  user_thoughts:
    - string
  user_inferences:
    - string
  external_context:
    - string
  ai_hypotheses:
    - string
```

## Output rules

- `idea_id` must be stable for the interview session and use a UUID-compatible value.
- `original_input` must preserve the user's original raw idea.
- `core_claim` should be concise, but must not be stronger than what the user confirmed.
- `why_it_matters` should explain significance without adding unsupported claims.
- `reasoning` should capture the user's logic, not generic supporting arguments invented by the model.
- `examples` should contain examples actually supplied or explicitly validated by the user.
- `personal_experience` should contain only experiences the user described.
- `assumptions` may include implicit assumptions detected by the model, but such items should also be tracked under `provenance.ai_hypotheses` until validated.
- `counterarguments` may include objections raised by the user or explicitly introduced for stress-testing. Preserve the distinction in provenance.
- `open_questions` should retain unresolved uncertainty rather than smoothing it away.
- `possible_content_directions` may be suggested by the model, but they are not part of the user's thesis and should be treated as AI-generated editorial options.
- `quotable_user_language` must preserve the user's wording verbatim.

## Provenance rules

Use provenance conservatively.

- `user_thoughts`: statements, observations, claims, or examples directly expressed by the user.
- `user_inferences`: deductions or conclusions the user explicitly made from their own observations.
- `external_context`: facts, references, examples, or source-derived information that came from supplied or researched context.
- `ai_hypotheses`: interpretations, reframings, assumptions, implications, or candidate claims proposed by the model but not yet confirmed by the user.

No item from `external_context` or `ai_hypotheses` may silently become part of the user's `core_claim`.

## Failure modes to avoid

Do not:

- turn the interview into an article draft,
- ask many questions at once,
- flatter the idea instead of examining it,
- manufacture evidence,
- confuse a plausible inference with the user's belief,
- erase uncertainty,
- over-polish the user's wording,
- create a more provocative thesis merely because it would make better content,
- treat popularity or trendiness as proof that the idea is correct.

## Completion behavior

When the stopping criteria are met:

1. Tell the user the idea is sufficiently developed for a first `IdeaBrief`.
2. Produce the structured artifact.
3. Surface any remaining uncertainty under `open_questions`.
4. Do not continue into research or drafting unless another skill or the user explicitly requests it.
