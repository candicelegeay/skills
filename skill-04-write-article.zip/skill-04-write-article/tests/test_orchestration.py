import json
import sys
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.write_article import main as run_orchestrator  # noqa: E402


def test_full_pipeline_quick():
    output = run_orchestrator({"prompt": "idée sur l'IA", "mode": "quick"})
    assert "article" in output
    assert "body" in output["article"]
    assert output["provenance"]["original_idea"] == "idée sur l'IA"
    assert output["next_actions"] == ["HumanEdit"]

    schema = json.loads((ROOT / "schemas" / "ArticleArtifact.schema.json").read_text(encoding="utf-8"))
    jsonschema.Draft7Validator(schema, format_checker=jsonschema.FormatChecker()).validate(output)


def test_standard_mode_keeps_mock_research_explicit():
    output = run_orchestrator({"prompt": "gouvernance des agents", "mode": "standard"})
    assert output["research"]["important_sources"] == []
    assert output["research"]["factual_claims"] == []
