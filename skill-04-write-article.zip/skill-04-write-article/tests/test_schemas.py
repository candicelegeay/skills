import json
from pathlib import Path

import jsonschema
import yaml

ROOT = Path(__file__).resolve().parents[1]


def test_request_example_matches_schema():
    data = yaml.safe_load((ROOT / "examples" / "ArticleRequest.example.yaml").read_text(encoding="utf-8"))
    schema = yaml.safe_load((ROOT / "schemas" / "ArticleRequest.schema.yaml").read_text(encoding="utf-8"))
    jsonschema.Draft202012Validator(schema).validate(data)


def test_artifact_example_matches_schema():
    data = yaml.safe_load((ROOT / "examples" / "ArticleArtifact.example.yaml").read_text(encoding="utf-8"))
    schema = json.loads((ROOT / "schemas" / "ArticleArtifact.schema.json").read_text(encoding="utf-8"))
    jsonschema.Draft7Validator(schema, format_checker=jsonschema.FormatChecker()).validate(data)
