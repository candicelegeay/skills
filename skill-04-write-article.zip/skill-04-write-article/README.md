# Skill 04 — write-article

Package autonome du skill orchestrateur `write-article`.

Il implémente le contrat décrit dans le document source : trois modes (`quick`, `standard`, `deep`), orchestration de `idea-interviewer`, `trend-researcher` et `voice-writer`, persistance de la provenance, schémas d'entrée/sortie et exécution locale avec providers mock.

## Arborescence

```text
write-article/
├── SKILL.md
├── skill.yaml
├── schemas/
│   ├── ArticleRequest.schema.yaml
│   └── ArticleArtifact.schema.json
├── examples/
│   ├── ArticleRequest.example.yaml
│   └── ArticleArtifact.example.yaml
├── state/
│   └── WorkflowState.schema.yaml
├── tools/
│   ├── __init__.py
│   ├── tools.yaml
│   ├── orchestrator.py
│   ├── write_article.py
│   └── validate_contracts.py
├── tests/
│   ├── test_schemas.py
│   └── test_orchestration.py
├── requirements.txt
└── Makefile
```

## Quick Start

Prérequis : Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make validate-schemas
make test
```

Exécution :

```bash
python tools/write_article.py \
  --prompt "Mon idée sur la gouvernance IA" \
  --mode quick
```

Ou :

```bash
python tools/write_article.py \
  --input examples/ArticleRequest.example.yaml \
  --output article.yaml
```

## Brancher les trois autres skills

`tools/orchestrator.py` définit trois interfaces (`Protocol`) : `IdeaInterviewer`, `TrendResearcher`, `VoiceWriter`.

Par défaut, le package utilise des implémentations `Mock*` afin d'être exécutable sans API ni secrets. Pour le brancher dans un harness, implémentez ces interfaces avec vos runners réels puis injectez-les dans `run_pipeline(...)`.

Le mock ne fait aucune recherche web et ne fabrique donc aucun claim factuel externe.
