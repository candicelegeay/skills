from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Protocol


class IdeaInterviewer(Protocol):
    def run(self, prompt: str, depth: str) -> Dict[str, Any]: ...


class TrendResearcher(Protocol):
    def run(self, idea_brief: Dict[str, Any], depth: str) -> Dict[str, Any]: ...


class VoiceWriter(Protocol):
    def run(
        self,
        idea_brief: Dict[str, Any],
        trend_report: Dict[str, Any] | None,
        mode: str,
    ) -> Dict[str, Any]: ...


@dataclass
class MockIdeaInterviewer:
    def run(self, prompt: str, depth: str) -> Dict[str, Any]:
        return {
            "original_input": prompt,
            "core_claim": prompt.strip(),
            "why_it_matters": "À préciser avec l'utilisateur dans une implémentation connectée.",
            "reasoning": [],
            "provenance": {
                "user_thoughts": ["original_input"],
                "user_inferences": [],
                "external_context": [],
                "ai_hypotheses": [],
            },
            "interview_depth": depth,
        }


@dataclass
class MockTrendResearcher:
    def run(self, idea_brief: Dict[str, Any], depth: str) -> Dict[str, Any]:
        return {
            "dominant_themes": [],
            "emerging_themes": [],
            "contrarian_positions": [],
            "sources": [],
            "research_depth": depth,
            "note": "Mock provider: aucune recherche externe effectuée.",
        }


@dataclass
class MockVoiceWriter:
    def run(
        self,
        idea_brief: Dict[str, Any],
        trend_report: Dict[str, Any] | None,
        mode: str,
    ) -> Dict[str, Any]:
        prompt = idea_brief["original_input"]
        angle_count = 1 if mode == "quick" else 3
        titles = [
            f"{prompt}: l'angle à examiner",
            f"Ce que {prompt.lower()} change réellement",
            f"Repenser {prompt.lower()} par le système qui l'entoure",
        ][: max(1, angle_count)]

        angle = "Développer l'idée originale sans la remplacer"
        thesis = idea_brief.get("core_claim", prompt)
        outline = [
            {"point": "Partir de l'observation originale."},
            {"point": "Développer le raisonnement et ses implications."},
            {"point": "Distinguer les faits externes des inférences IA."},
        ]
        body = (
            "[MOCK DRAFT]\n\n"
            f"Idée de départ : {prompt}\n\n"
            "Ce brouillon est volontairement minimal. Branchez voice-writer pour produire "
            "un article complet dans la voix de l'utilisateur."
        )
        return {
            "title_options": titles,
            "selected_angle": angle,
            "thesis": thesis,
            "outline": outline,
            "body": body,
        }


MODE_CONFIG = {
    "quick": {"interview": "minimal", "research": False, "research_depth": "none"},
    "standard": {"interview": "normal", "research": True, "research_depth": "standard"},
    "deep": {"interview": "deep", "research": True, "research_depth": "deep"},
}


def run_pipeline(
    request: Dict[str, Any],
    idea_interviewer: IdeaInterviewer | None = None,
    trend_researcher: TrendResearcher | None = None,
    voice_writer: VoiceWriter | None = None,
) -> Dict[str, Any]:
    prompt = str(request["prompt"]).strip()
    mode = request.get("mode", "standard")
    if mode not in MODE_CONFIG:
        raise ValueError(f"Unsupported mode: {mode}")

    cfg = MODE_CONFIG[mode]
    interviewer = idea_interviewer or MockIdeaInterviewer()
    researcher = trend_researcher or MockTrendResearcher()
    writer = voice_writer or MockVoiceWriter()

    idea_brief = interviewer.run(prompt, cfg["interview"])
    trend_report = researcher.run(idea_brief, cfg["research_depth"]) if cfg["research"] else None
    draft = writer.run(idea_brief, trend_report, mode)

    sources = []
    external_evidence = []
    if trend_report:
        for source in trend_report.get("sources", []):
            url = source.get("url") if isinstance(source, dict) else str(source)
            if url:
                sources.append(url)
                external_evidence.append(url)

    return {
        "article": draft,
        "research": {
            "important_sources": sources,
            "factual_claims": [],
        },
        "provenance": {
            "original_idea": prompt,
            "external_evidence": external_evidence,
            "ai_contributions": [
                "orchestration du workflow",
                "suggestion d'angle",
                "génération du plan",
                "rédaction du brouillon mock",
            ],
        },
        "editorial": {
            "voice_examples_used": [],
            "style_preferences_used": [],
        },
        "next_actions": ["HumanEdit"],
    }
