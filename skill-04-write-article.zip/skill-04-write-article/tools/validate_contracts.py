from __future__ import annotations

import json
from pathlib import Path

import jsonschema
import yaml

ROOT = Path(__file__).resolve().parent.parent


def main() -> int:
    request = yaml.safe_load((ROOT / "examples" / "ArticleRequest.example.yaml").read_text(encoding="utf-8"))
    request_schema = yaml.safe_load((ROOT / "schemas" / "ArticleRequest.schema.yaml").read_text(encoding="utf-8"))
    jsonschema.Draft202012Validator(request_schema).validate(request)

    artifact = yaml.safe_load((ROOT / "examples" / "ArticleArtifact.example.yaml").read_text(encoding="utf-8"))
    artifact_schema = json.loads((ROOT / "schemas" / "ArticleArtifact.schema.json").read_text(encoding="utf-8"))
    jsonschema.Draft7Validator(artifact_schema, format_checker=jsonschema.FormatChecker()).validate(artifact)

    print("OK: ArticleRequest + ArticleArtifact examples validate against their schemas.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
