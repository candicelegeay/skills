"""Runtime helpers for the write-article skill."""
