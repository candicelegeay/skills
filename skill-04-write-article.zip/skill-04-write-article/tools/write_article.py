from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import jsonschema
import yaml

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))

from tools.orchestrator import run_pipeline  # noqa: E402


def load_yaml(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def validate_request(request):
    schema = load_yaml(ROOT / "schemas" / "ArticleRequest.schema.yaml")
    jsonschema.Draft202012Validator(schema).validate(request)


def validate_output(output):
    schema = load_json(ROOT / "schemas" / "ArticleArtifact.schema.json")
    jsonschema.Draft7Validator(schema, format_checker=jsonschema.FormatChecker()).validate(output)


def main(request=None):
    if request is not None:
        validate_request(request)
        output = run_pipeline(request)
        validate_output(output)
        return output

    parser = argparse.ArgumentParser(description="write-article orchestrator")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--prompt", help="Idée brute de l'utilisateur")
    source.add_argument("--input", type=Path, help="Fichier YAML ArticleRequest")
    parser.add_argument("--mode", choices=["quick", "standard", "deep"], default="standard")
    parser.add_argument("--output", type=Path, help="Fichier YAML de sortie")
    args = parser.parse_args()

    if args.input:
        request = load_yaml(args.input)
    else:
        request = {"prompt": args.prompt, "mode": args.mode}

    validate_request(request)
    output = run_pipeline(request)
    validate_output(output)
    rendered = yaml.safe_dump(output, sort_keys=False, allow_unicode=True)

    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    return output


if __name__ == "__main__":
    main()
