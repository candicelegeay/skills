---
name: write-article
description: Orchestrer les skills d'idée, de tendances et de rédaction pour produire un article complet, sourcé et traçable en mode quick, standard ou deep.
version: 1.0.0
entrypoint: tools/write_article.py
inputs: schemas/ArticleRequest.schema.yaml
outputs: schemas/ArticleArtifact.schema.json
---

# write-article

## Objectif

`write-article` est l'orchestrateur du pipeline éditorial. Il transforme une idée brute en article final sans absorber la logique métier des autres skills. Il enchaîne les composants spécialisés, conserve les états intermédiaires et maintient une séparation explicite entre :

- ce qui vient de l'utilisateur ;
- ce qui vient de sources externes ;
- ce qui est proposé ou inféré par l'IA ;
- ce qui a été validé ou édité par un humain.

Le skill doit laisser à l'utilisateur des points de contrôle explicites, surtout en modes `standard` et `deep`.

## Contrat d'entrée

Entrée minimale :

```yaml
prompt: "Mon idée sur la gouvernance IA"
mode: standard
```

`mode` accepte `quick`, `standard` ou `deep`. Si absent, utiliser `standard`.

## Modes

### QUICK

Pour un premier jet rapide.

- interview d'idée minimale ;
- recherche de tendances désactivée par défaut ;
- génération directe d'un angle et d'un brouillon ;
- revue finale légère ;
- durée cible indicative : 5 à 10 minutes dans une implémentation connectée.

### STANDARD

Mode par défaut.

- interview normale ;
- recherche de tendances standard ;
- génération de trois angles réellement distincts ;
- sélection humaine de l'angle ;
- plan avant rédaction ;
- rédaction dans la voix de l'utilisateur ;
- revue de fidélité, factualité et style.

### DEEP

Pour un contenu long ou important.

- interview approfondie ;
- primer de domaine si nécessaire ;
- recherche plus large avec contradictions et contre-arguments ;
- génération et sélection d'angles ;
- plan argumenté ;
- plusieurs passes de révision ;
- vérifications factuelles fines ;
- provenance renforcée.

## Dépendances logiques

Le skill orchestre les skills suivants :

1. `idea-interviewer` → produit un `IdeaBrief`.
2. `trend-researcher` → produit un `TrendReport` lorsque le mode ou le sujet le justifie.
3. `voice-writer` → produit l'article à partir de l'idée structurée, de la recherche et des exemples de voix.

Ces dépendances sont des interfaces. L'orchestrateur ne doit pas réimplémenter leur logique interne.

## Workflow

```mermaid
flowchart TD
    A[Raw idea] --> B[idea-interviewer]
    B --> C[IdeaBrief]
    C --> D{Mode}
    D -->|quick| G[voice-writer]
    D -->|standard/deep| E[trend-researcher]
    E --> F[TrendReport]
    F --> G[voice-writer]
    G --> H[ArticleDraft]
    H --> I[Human review]
    I --> J[ArticleArtifact]
```

### Étape 1 : Idea interview

Appeler `idea-interviewer` et obtenir un `IdeaBrief`. L'idée originale ne doit jamais être remplacée par une thèse fabriquée par l'orchestrateur.

### Étape 2 : Tendances

- `quick` : sauter par défaut cette étape ;
- `standard` : lancer une recherche de tendances ciblée ;
- `deep` : élargir aux contradictions, sources de contexte et signaux émergents.

Le `TrendReport` reste séparé de l'`IdeaBrief`.

### Étape 3 : Synthèse et recherche

Préparer le contexte destiné au rédacteur sans fusionner provenance utilisateur et contexte externe. Toute assertion factuelle ajoutée doit pouvoir être reliée à une source.

### Étape 4 : Rédaction

Appeler `voice-writer` avec au minimum :

```text
IdeaBrief + optional TrendReport + target_format=article + target_language
```

En `standard` et `deep`, demander trois angles distincts puis conserver l'angle choisi par l'utilisateur avant la rédaction complète.

### Étape 5 : Révision

Effectuer ou déclencher une revue de :

- fidélité à l'idée ;
- fidélité à la voix ;
- généricité ;
- risques factuels ;
- citations manquantes ;
- cohérence de la provenance.

La version humaine éditée est la version de référence finale.

## Persistance d'état

Les états intermédiaires doivent pouvoir être persistés :

- requête initiale ;
- `IdeaBrief` ;
- `TrendReport` éventuel ;
- angles proposés ;
- angle sélectionné ;
- outline ;
- draft ;
- revue ;
- édition humaine ;
- artefact final.

Le schéma `state/WorkflowState.schema.yaml` fournit un contrat minimal pour cette persistance.

## Sortie : ArticleArtifact

La sortie respecte `schemas/ArticleArtifact.schema.json` et contient cinq blocs :

- `article` : titres, angle, thèse, outline et corps ;
- `research` : sources importantes et claims factuels sourcés ;
- `provenance` : idée originale, preuves externes, contributions IA ;
- `editorial` : exemples de voix et préférences utilisées ;
- `next_actions` : revue humaine, publication ou autre étape.

## Boucle d'apprentissage

Lorsqu'une version humaine éditée est disponible, comparer `AI draft → human edit` et classifier les changements : style, structure, factualité, ton, lexique.

Ne jamais transformer automatiquement une correction isolée en préférence permanente. Seuls des patterns répétés et confirmés peuvent devenir des préférences éditoriales.

## Règles invariantes

1. Ne jamais attribuer une source externe à l'utilisateur.
2. Ne jamais présenter une inférence IA comme un fait sans source.
3. Ne pas écraser l'`IdeaBrief` d'origine avec la recherche ultérieure.
4. Garder les étapes aussi déterministes et inspectables que possible.
5. Préférer des contrats structurés aux prompts monolithiques.
6. Conserver les décisions humaines importantes dans l'état du workflow.
7. Si une dépendance n'est pas disponible, utiliser un provider mock explicite plutôt que de simuler silencieusement un appel réel.

## Exécution locale

```bash
pip install -r requirements.txt
python tools/write_article.py --prompt "Mon idée sur les agents" --mode quick
```

Ou depuis un fichier YAML :

```bash
python tools/write_article.py --input examples/ArticleRequest.example.yaml
```

Valider les contrats :

```bash
python tools/validate_contracts.py
```

Lancer les tests :

```bash
pytest -q
```
