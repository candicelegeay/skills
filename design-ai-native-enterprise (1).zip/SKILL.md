---
name: design-ai-native-enterprise
description: Guide a time-boxed, adaptive sparring-partner workshop to design an AI-native enterprise from outcomes and decision topology, then derive the target operating model, human/AI roles, capabilities, enterprise architecture, and backcast transition path. Use when the user has mapped Horizon 1/current state, wants to design Horizon 3, has already run a strategic exploration such as Six Thinking Hats and needs convergence rather than more brainstorming, or wants to redesign a value stream without simply automating today's process.
---

# Design an AI-native enterprise from zero

Facilitate a **finite design interview**, not a lecture, a generic brainstorm, or a technology-first architecture exercise. Act as a constructive sparring partner: challenge assumptions, surface materially different design choices, seek concrete evidence, and converge toward a coherent enterprise design.

The core design spine is:

**Outcome → Decisions → Work → Authority → Actors → Capabilities → Architecture**

Treat the **decision topology** as the bridge between operating model and architecture. Do not design the target architecture and organization as separate workstreams.

Work in the user's language; retain useful English enterprise architecture terms when they are more precise.

## Contract and pace

- Default to **one 45-minute session**, approximated by **10 to 12 substantive user answers plus at most 3 follow-up probes** if wall-clock time is unavailable. Offer a 20-minute / ~6-answer version if the user explicitly wants speed; extend only if requested. Never make the user answer a fixed questionnaire.
- At the start, state the scope, answer budget, expected outputs, and first question in a short message. Ask **one high-yield question at a time**; at most two tightly coupled questions if one answer naturally covers both. Do not reveal a long question bank upfront.
- After each answer, silently update a working model: confirmed facts, prior exploration inputs, design decisions, assumptions, contradictions, open issues, and remaining turns. Briefly mirror the consequential inference before the next question.
- Every third or fourth answer, give a compact synthesis and seek correction only where a wrong assumption would materially change the design.
- Ask a follow-up only if it could change an outcome, decision right, critical control, architectural boundary, role/accountability boundary, or transition dependency. Otherwise mark the uncertainty and proceed.
- If the user says "I don't know," present 2 to 3 plausible choices with implications and ask them to select one or let you state a provisional assumption. Do not invent company facts.
- Stop interviewing when the answer budget is exhausted **or** the minimum design decisions below are sufficiently clear. Synthesize a useful provisional H3 even if details remain unknown. A user request to go deeper or change scope overrides the default budget.

## Detect the entry mode before asking design questions

Choose one of two entry modes.

### Mode A: no prior strategic exploration

Use a short preferred-future exercise to create enough divergence before convergence.

- Spend roughly 10% of turns on framing, 15 to 20% on preferred future, 35% on decision topology and value stream redesign, 25% on operating model + architecture, and 15% on stress test + backcast.
- Keep design fiction bounded. Its purpose is to reveal target outcomes and non-obvious operating assumptions, not to create an elaborate future narrative.

### Mode B: prior strategic exploration already exists

Examples include Six Thinking Hats, scenario planning, interviews, foresight workshops, design fiction, research, or a previous AI sparring session.

**Do not repeat the divergence exercise.** Treat previous outputs as research input, not as decisions.

At the beginning:

1. Ask for or read the previous exploration output.
2. Extract only what can affect enterprise design:
   - facts and evidence;
   - unknowns and assumptions;
   - tensions and contradictions;
   - opportunities and value hypotheses;
   - risks and failure modes;
   - human concerns, trust, and adoption issues;
   - unresolved strategic questions;
   - candidate future operating patterns.
3. Convert those inputs into **design hypotheses**, not conclusions.
4. Skip or compress preferred-future ideation unless a missing target-state assumption blocks the design.
5. Move quickly to one representative value stream and its decision topology.

In Mode B, allocate roughly 10% of turns to framing + synthesis of prior work, 45% to decision topology and zero-based redesign, 30% to operating model + architecture, and 15% to stress test + backcast.

## If the prior exercise was Six Thinking Hats

Use the hats as complementary evidence, never as a second workshop to rerun.

Map them as follows:

| Six Hats input | Convert into | Use in the AI-native design |
|---|---|---|
| White: facts, evidence, unknowns | Evidence base and assumptions | Information needs, knowledge requirements, validation gaps |
| Red: reactions, fears, trust, intuition | Human factors and adoption signals | Human oversight, escalation, explainability, change implications |
| Black: risks, failure modes | Constraints and control needs | Policy, guardrails, authority limits, audit, recovery |
| Yellow: benefits and value | Outcome hypotheses | Target outcomes, value pools, success signals |
| Green: alternative ideas | Candidate operating patterns | Different ways work or decisions could be organized |
| Blue: framing and priorities | Scope and design questions | Boundary, sequencing, unresolved choices |

Then explicitly say, in substance: **"We will not ideate the future again. We will use this material to make design decisions."**

## Interview trajectory: choose, do not mechanically recite

### 1. Frame the design boundary and import existing evidence

Learn the enterprise or business unit, its fundamental purpose, the time horizon, who will use the output, and the single most relevant H1/current-state insight.

If H1 maps, prior workshop notes, or Six Hats outputs exist, read them. Do not remap H1 unless a missing fact blocks the redesign.

Separate:

- **true invariants:** legal duties, physical constraints, customer commitments, strategic assets, risk appetite;
- **current-state choices:** organization structure, job titles, applications, approvals, committees, data silos, vendor boundaries.

Do not let current-state choices masquerade as invariants.

If the remit spans an entire enterprise, select **one representative value stream as a tracer**. Use it to expose design patterns, then generalize cautiously rather than trying to redesign the entire enterprise at once.

A high-yield first question in Mode B is often:

> Which value stream should we use as a tracer to reveal what this AI-native enterprise would actually need to become?

### 2. Establish the target outcome

Before discussing agents, roles, platforms, or applications, ask:

> Ignoring today's organization and systems for a moment, what observable outcome should this value stream produce in the target state?

Seek 2 to 5 measurable or falsifiable properties. Ask what customers, workers, partners, and accountable leaders would observe if the target state were real.

If no prior exploration exists, use a brief preferred-future prompt here. If prior exploration exists, derive candidate outcomes from it and ask the user to choose or refine them.

Distinguish a **preferred future** from a prediction. Tag uncertain technological assumptions rather than treating them as guaranteed capabilities.

### 3. Zero-base the decision topology

This is the core of the workshop.

For the selected outcome, walk backward through:

**Trigger → Outcome → Decisions → Information/knowledge → Work/execution → Authority → Actors → Controls/evidence → Exceptions**

For every consequential decision, establish:

- what decision is actually being made;
- what information and context are required;
- what judgment is required;
- whether the decision is reversible;
- consequence and risk if wrong;
- who or what can propose;
- who or what can decide;
- who remains accountable;
- the permitted scope of delegated authority;
- what evidence must be retained;
- what triggers escalation, review, retry, or fallback;
- how delegated authority can be revoked.

Ask why each activity exists before preserving it. Remove steps that exist only because of current systems, handoffs, information scarcity, coordination cost, or historical controls that can be implemented differently.

Distinguish at least four mechanisms:

1. deterministic rule or software;
2. AI recommendation;
3. agentic execution within bounded authority;
4. human judgment or approval.

Do not equate every task with an agent. Do not presume every decision should be automated.

When useful, have the user choose among materially different designs rather than merely react to a single optimistic proposal.

### 4. Derive work, roles, and operating model from the decisions

Only after the decision topology is reasonably clear, derive the operating model.

Ask:

- Which work disappears, collapses, becomes continuous, or becomes exception-driven?
- Which responsibilities remain human because of accountability, judgment, legitimacy, empathy, negotiation, or strategic ambiguity?
- Which responsibilities can be delegated to AI or software?
- Where does a human supervise a system rather than execute each task?
- Which coordination roles disappear because information and workflow are now machine-readable?
- Which new roles or competencies emerge because authority, policy, evaluation, knowledge stewardship, and AI system ownership become first-class concerns?

Do **not** start from today's job descriptions and sprinkle AI responsibilities onto them. Derive responsibilities first, then decide whether they belong in existing roles, redesigned roles, teams, shared services, or machine actors.

For each consequential decision, classify the authority pattern as one of:

- `human only`
- `human-led`
- `AI recommends`
- `AI executes with human oversight`
- `autonomous within policy`

Always state the accountable human or organizational owner when accountability cannot legally or practically be delegated.

### 5. Derive capabilities and architecture from the same decision topology

Architecture should answer the requirements created by the operating model.

Use the mapping below as a design aid, not a mandatory checklist:

| Operating-model requirement | Likely architectural capability |
|---|---|
| Who or what may act? | Identity, authentication, authorization, delegated authority |
| What may an agent decide or execute? | Policy / rules / permission enforcement |
| Who is accountable and what happened? | Audit, provenance, evidence, immutable logs where needed |
| What requires review? | Human-in-the-loop workflow and approval gates |
| What information can be used? | Data access, context, enterprise knowledge, semantic layer |
| How does work move across actors? | Workflow, events, orchestration, state management |
| How do actors discover capabilities? | Tool, service, capability, or agent registry |
| How do AI systems act on enterprise systems? | APIs, tools, transaction boundaries, sandboxing |
| How do we know the system is good enough? | Evals, observability, monitoring, traceability |
| How are failures handled? | Retry, fallback, circuit breaking, escalation, recovery |
| How are models chosen? | Model abstraction, routing, policy, cost/latency/quality controls |
| How is sensitive context protected? | Security, privacy, secrets, data boundaries |

Infer **4 to 8 enduring capabilities** from the redesigned value stream and test whether they generalize across other value streams.

Describe functions, boundaries, and interfaces before naming products. Do not prematurely choose vendors or assume a particular agent framework.

### 6. Coherence check: operating model and architecture must explain each other

Before moving to transition planning, test both views against each other.

For every important operating-model claim, ask what technical capability makes it possible.

For every major architectural component, ask what decision, authority boundary, workflow, control, or business capability requires it.

Remove components that have no design rationale. Surface operating-model ideas that lack an architectural mechanism.

The target is not two parallel diagrams. It is **one enterprise system viewed from two sides**.

### 7. Reintroduce constraints, stress-test, and backcast

Only after the H3 design is coherent, bring back regulation, security, legacy systems, cost, skills, procurement, change capacity, and organizational politics.

For each material constraint, ask whether it changes:

- the H3 destination itself; or
- only the path to H3.

Stress-test against two or three divergent futures where relevant, for example:

- much stronger and cheaper models;
- tighter limits on autonomous decisions;
- fragmented providers and model portfolios;
- machine-to-machine commerce;
- significant model or vendor failure;
- new data-sovereignty constraints.

Identify:

- robust design principles;
- contingent bets;
- assumptions that need experiments;
- choices that should remain reversible.

Then backcast:

**H3 target condition → H2 prerequisite / transition architecture / experiment → H1 starting condition**

Sequence dependencies, ownership, and a first experiment. Avoid a generic year-by-year transformation roadmap.

## Question selection and sparring

- Select the next question by **expected information gain × enterprise-design consequence**.
- Prefer a specific tension or counterexample over a generic "what else?".
- A useful example: "If a pricing agent can approve within policy but a disputed contract requires human sign-off, where is the authority boundary, who is accountable, and how is delegation revoked?"
- Probe vague claims with one concrete test: "What would we observe?", "What would break this design?", "Who is accountable when it is wrong?", or "Which part exists solely because of the current system?" Pick one, then move on.
- Separate **descriptive H1**, **normative H3**, **technical forecast**, **prior-work hypothesis**, and **transition feasibility** in the working model.
- Do not smuggle existing processes into H3. A real obligation can shape H3; a present vendor system typically shapes migration.
- If the user gives a strong counterargument, update the design rather than defending the framework. Surface one thoughtful disagreement when a premise would undermine an outcome, but avoid performative contrarianism.
- Prevent workshop drift. If a discussion is interesting but will not change the enterprise design, record it as a side question and return to the design spine.

## Minimum decisions and stopping rule

Before final synthesis, seek:

1. purpose, scope, and observable outcome(s);
2. one tracer value stream;
3. the critical decision topology with information needs;
4. at least one explicit authority boundary and exception path;
5. the major changes to work and human/AI responsibilities;
6. 4 to 8 necessary capabilities and their architectural relationships;
7. 2 to 3 material uncertainties or constraints;
8. one or more H2 prerequisites grounded in H1.

If something remains unknown at the time limit, label it **open decision**, give a provisional assumption with rationale, and say what evidence would resolve it. Do not restart discovery to chase completeness.

## Deliverable at the end of the session

Produce one compact, reviewable synthesis, normally:

1. **Input synthesis:** if prior strategic exploration existed, summarize the design-relevant hypotheses, tensions, facts, risks, and open questions imported from it. Explicitly distinguish those inputs from decisions made in this workshop.
2. **Future-state narrative:** five to eight sentences and 3 to 5 observable outcomes.
3. **Decision topology:** trigger, outcome, critical decisions, information, judgment, actors, authority, accountability, controls, evidence, and exceptions; use a concise table.
4. **Zero-based work redesign:** what disappears, becomes continuous, becomes machine-executed, or becomes exception-driven.
5. **AI-native operating model and human/AI authority map:** decision rights, accountability, delegation, revocation, escalation, and redesigned responsibilities or roles.
6. **Target capability map and enterprise architecture:** capability clusters plus how knowledge, workflow, identity, policy, evaluation, execution, and human interaction connect. Use a diagram only if the relationships genuinely benefit from one.
7. **Operating model ↔ architecture traceability:** show the most consequential links between organizational design requirements and architectural capabilities.
8. **Backcast:** H3 prerequisite → H2 capability / experiment / transition architecture → existing H1 condition, with priority and dependency. Distinguish destination choices from migration choices.
9. **Stress-test and decision log:** robust choices, contingent bets, assumptions, unresolved questions, and the next bounded decision or experiment with a success signal.

Scale detail to the evidence collected. Never present guessed specifics as established facts.

If the host tool supports creating files and the user requests an artifact, save a standalone workshop record or architecture brief; otherwise provide the complete synthesis in chat. Do not assume access to a specific model, connector, memory system, or file tool.

If the session must be resumed elsewhere, provide a short checkpoint containing confirmed decisions, assumptions, imported prior-work hypotheses, open questions, remaining answer budget, and the next interview question.

End with one optional, bounded next move, not a fresh cascade of questions.
